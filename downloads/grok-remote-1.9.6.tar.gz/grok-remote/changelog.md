## 2026-08-21 v1.9.6 - published: GitHub release + site downloads, wear app key un-baked

- v1.9.6 pushed (watch cockpit polish, catchup tests, checklists). Release assets:
  GrokRemote-windows-portable.exe / GrokRemote-windows-setup.exe (electron-builder) and
  grok-remote-1.9.6-source.tar.gz (git archive - tracked files only, secrets stay home).
- android-wear published with MainActivity reading assets/watch_url.txt (untracked;
  .example committed) - the baked key/IP never reached GitHub.
- start.sh: posix launcher (python3 + aiohttp bootstrap) for the linux/mac tarball.
- amni-scient.com/grok-remote.html: Windows button -> GitHub release (Cloudflare Pages
  caps files at 25MB and the 74MB portable exe broke a deploy), linux/mac -> site tarball,
  legacy 9.8MB GrokDesktop.exe restored so old links keep working.

## 2026-08-20 — Wear OS companion: android-wear/ GrokRemoteWatch
- Minimal Wear WebView app for the /watch companion page (the "needs a Wear browser" gotcha
  is dead — the app IS the browser): loads http://192.168.0.7:2421/watch with the key baked,
  keep-screen-on, standalone. 2.3MB debug APK, pushed to the phone at
  /sdcard/Download/GrokRemoteWatch.apk.

## 2026-08-18 v1.9.5 - phone "down": 30-day auth cookie expired, never refreshed

Phone went dark at ~22:24 while every keepalive stayed green. The auth middleware only re-set
the 30-day cookie when the request carried `?key=` (or came from loopback). A phone that paired
once by QR rides the cookie alone: page loads, fetches, and the WS handshake all auth by cookie,
none refresh it, so day 30 = silent 401 on everything. Hub logs nothing (middleware rejects
before "client join"), /health is exempt from auth, watchdog says healthy. Desktop tabs never
die because the loopback branch refreshes them on every response.

- `server.py` auth_mw: refresh condition `request.query.get("key")==token` -> `supplied==token`
  (any authenticated request slides the 30-day window; expiry now means 30 days of NO use)
- Verified A/B: cookie-only GET had no Set-Cookie on old server, has Max-Age=2592000 on new;
  wrong cookie still 401; hub WS initialize + sessions/list + full turn OK
- Phone re-paired via keyed URL; LAN client reconnected

## 2026-08-19 v1.9.5 - Braid markdown + Work dock on Remote

Anthony: bring the chat formatting and tools we recently added to Braid over to grok-remote.

- `web/md.js` is Braid's line-based markdown engine (nested lists, task boxes, tables
  without outer pipes, fence highlighting, math that does not eat `$10`). Feed bubbles
  and live stream use it; closed fences still fold into the existing collapsible chrome.
- `web/work-dock.js` is a Remote-sized Work sheet: live tool timeline from ACP
  `tool_call` events, plus a Files tab on `/api/fs/list` + `/api/fs/read`. Command deck
  **Work**. No Braid activity watcher or approval queue — those are Delve-only.

## 2026-08-18 v1.9.4 - pair QR was clipped on camera scan

Segno emits an SVG with width/height and **no viewBox**. The pair page then set
`width:100%;height:auto`, so the modules got cropped. Setup's `#phoneQr` also used
`border-radius` on the bitmap, which ate the finder corners.

- `qr_svg` injects `viewBox` + `preserveAspectRatio`, quiet zone `border=4`, bigger scale
- Pair page: `overflow:visible`, `aspect-ratio:1`, more pad, no grid overflow on narrow windows
- Setup QR sits in a white pad (no radius on the code), 220px + margin 16

## 2026-08-18 v1.9.3 - pair phone back in the header, session filters one line

Anthony: pairing gone from the upper-right menu, amni-scient / leftover module chips still
clogging the left Sessions rail, filters wrapping off a single line.

- **Pair phone** is back on the orbit menu (status cluster) and the command deck Help row.
  Loopback opens `/pair` (QR codes). A LAN phone falls back to Setup with the copy/QR card.
- Session scope chips are **Active / Live / Arch / All** only. Cwd-derived "modules"
  (Amni-scient, folder leftovers, Apps, Background, …) no longer paint as filters.
  A leftover `app:*` scope in localStorage snaps back to Active.
- Rail + filter pop stay **one line** (`flex-wrap:nowrap`, horizontal scroll if the rail is
  tight). Archived chip shortens to **Arch**.
- Default wordmark is GROK BUILD. Scient + the other AMNI product skins (AI / Explore / Calc /
  Learn / Crypt / Haven / Core) are hidden and remapped to Grok. Amni-Delve is off the Apps menu.

## 2026-08-17 v1.9.2 - a hidden tab put its own link to sleep

Anthony: *"the persistence issue with grok-remote not continuing if the tab isn't forefront on the
pc."* Three separate gates fire when a tab goes to the background, and together they park the tab
completely.

- `startPoll` returned early while hidden, so a hidden tab ran **no** catch-up. Anything the room
  produced behind your back was not on that tab when you came back to it.
- `startLinkKeepalive` runs on a **4s** `setInterval` and closes the socket when nothing has arrived
  for 45s. Chrome throttles background timers and drops them to about **once a minute** after five
  minutes hidden - so `silent > 45000` is true on the first fire regardless of how healthy the link
  is. The stale-link guard was killing the connection it exists to protect.
- `scheduleReconnect` then re-parked on every retry because the tab was *still* hidden, so the link
  never came back until the tab was looked at.

The socket was never the problem. `web.WebSocketResponse(heartbeat=12,autoping=True)` already sends
protocol-level pings, but the browser answers those in its network stack - they never reach
`onmessage`, so they cannot refresh `linkLastRx`. **Liveness has to arrive as an application frame.**

- Server: `_watch_loop` broadcasts `_x.ai/remote/hub` every 15s while any client is connected. That
  method is one the client **already** handles, and `ws.onmessage` stamps `linkLastRx` on every
  frame - so the link stays fresh with no client timer at all, which is what makes it immune to
  throttling.
- Client: hidden tabs catch up every 15s instead of never; the link is never torn down from a hidden
  tab; a reconnect while hidden backs off to 30s instead of parking forever.

Measured: an idle client that sends nothing gets **0** application frames in 50s from the old server
and **4** from the new one, and 2 in 40s from the live :2421 after restart. A visible tab held one
socket for 7+ minutes with zero reconnect churn. The end-to-end hidden-tab case is **not** verified
here - CDP pages report `visible` even when another tab is selected, so the harness cannot produce
the condition. See `docs/checklists/checklist_hidden_tab_persistence_v1.9.2.md` for the 30-second
manual check.

## 2026-08-14 v1.9.1 - opening a session: 13.3 s to 41 ms

Opening a conversation stalled the whole server. On a cold page load, `/api/session/titles`
took **19035 ms of server time**, and every request issued beside it finished at the same
instant: history 18212 ms, git status 16641 ms, signals 16641 ms, room feed 18377 ms. Later
requests then showed `queued: 13265 ms` — the browser's connection pool backed up behind the
stalled ones. `openSession()` measured 13347 ms.

- **`find_session_dir()` rebuilt the whole session index on every miss.** A miss called
  `_sid_index(force=True)`, which walks 2981 session directories (130 ms). `session_titles`
  does that for up to 250 ids, and twice per id when the cwd lookup fails first — roughly
  32 s of rebuilds to answer one request. The forced rebuild is now rate-limited to once
  per 5 s, so a new session still appears promptly and a batch of misses costs one rebuild.
- **`session_titles` ran its 250-session loop directly on the event loop**, so while it worked
  nothing else in the server could answer. It now runs in the executor, the same way
  `session_history` already did. That is what let one slow handler freeze history and signals.
- **`read_session_updates(chat_only=True)` re-read and re-parsed its whole window on every
  doubling** (1.9 MB, then 5.9, 11.9, 23.9 MB, each from scratch) to return 24 messages. It now
  reads only the newly exposed older prefix and keeps what it already parsed. Coalescing moved
  to a single pass at the end, because `_coalesce_chat()` mutates the events it merges and
  running it per round double-appended message text.

`tests/test_history_scan.py` compares the new reader against the v1.8.4 backup on the six
largest transcripts (458 MB down to 125 MB) and asserts identical events for the open page,
load-older, a bigger page, and the untouched live and non-chat paths. Same output, 1.0-1.9x
faster warm and up to 26x when the window has to grow.

Measured after, on a fresh navigation: titles 267 ms, history 24 ms, git status 40 ms, nothing
queued. Session opens run 23-273 ms and settle in 133-422 ms, first navigation and
renavigation alike.

Also fixed a clock flake in `tests/test_room.py`: `members(window=0)` compares `now-ts > 0`,
which is false when Windows returns the same coarse tick. The test now waits 50 ms and uses a
10 ms window. All 11 room tests pass.

## 2026-08-14 v1.9.0 - agent room (beta)

A short-message channel shared by every agent on this hub. Not a transcript: one line each,
240 characters, newest last.

- `room.py` - append-only JSONL in the plugin data dir, with a CLI: `say`, `read`, `watch`,
  `who`, `clear`. Text is collapsed to a single line and capped rather than rejected, empty
  messages are refused, the author name is bounded at 32 chars, and a corrupt line in the store
  is skipped instead of killing the read.
- API: `GET /api/room/feed?since=&limit=`, `POST /api/room/say`, `GET /api/room/members`,
  `POST /api/room/clear`.
- **Agents need no key.** The auth middleware already exempts loopback, so an agent on this PC
  posts with one curl, or `python room.py say --who Name "..."`. The UI prints the exact command
  for the current host.
- UI: a dock in the bottom-right corner with a BETA badge, live member list, 240-char counter
  and Enter-to-send. It is `position:fixed` **on purpose** - it never joins `#app`'s grid, which
  is where the sidebar-collapse breakage lived. Open state persists in localStorage.
- 11 tests in `tests/test_room.py`. Verified end to end: three agents posting over both the HTTP
  and CLI paths, the browser posting as `you`, members listing all four, and the feed surviving
  a server restart.

## 2026-08-14 v1.8.4 - hiding the sessions rail no longer wrecks the layout

Collapsing the sidebar left a dead column, squeezed the chat into a corner and stranded the
session list in the bottom-right. Two causes, both in braid-layout.css:

- The Braid picker rule `html[data-layout=braid] body.desktop #picker.panel.on` sets
  `display:flex` and `grid-area:side` with `!important` at specificity (1,4,2). The generic
  collapse rule in index.html is (1,4,1), so it lost. The picker stayed laid out, still asking
  for a `side` area that the collapsed template does not define, and the browser invented
  implicit columns for it - the computed grid read `0px 820px 0px 454px` instead of two tracks.
- The `min-width:1200px` block re-states the *expanded* grid, so above 1200px it also beat the
  collapsed rule from the 900px block (equal specificity, later wins).

Fixes: hide `#picker` in Braid's own collapsed rule so it wins on specificity, covering the
whole desktop range from 900px up; and restate the collapsed grid inside the 1200px block.
Verified at 1052, 1274 and 1500px, toggling repeatedly: collapsed gives `0px <full width>` with
the picker display:none, expanded gives `280-300px <rest>`, and it survives round trips.

Also: the stylesheet link is re-keyed (`braid-layout.css?v=1.8.4`). Without it the browser kept
serving a cached copy and the fix appeared not to work.

## 2026-08-14 v1.8.3 - the reconnect storm, root-caused

**Two supervisors sharing one log file was the whole problem.** The generated `cmd-supervise` batch appends the server's output with `>> logs\ui.out.log`. cmd takes an *exclusive* lock on a `>>` target, so when a second supervisor existed its python line could not launch at all: the redirect failed, the command never ran, and the loop recorded `exit=0` within the same millisecond and span again 3 seconds later, forever. Neither supervisor ever held :2421, so the UI was unreachable and the phone sat on CONNECTING / no link.

Fixes, in the order they matter:
- **Per-instance log files** (`ui-<stamp>.out.log`). No shared handle, no lock collision.
- **Per-instance batch file.** cmd reads a batch line by line *while running it*, so regenerating `cmd-supervise.cmd` under a live supervisor corrupted that loop mid-flight. Each supervisor gets its own file now; old ones age out after a day.
- **The "already running" guard matched any process whose command line merely mentioned cmd-supervise** - including a shell that referenced it. ensure-running.ps1 would then skip the spawn and nothing started. It now requires Name -eq cmd.exe, and the orphan sweep likewise requires a python process.
- **Backoff and a give-up cap**: 4s, 8s, 16s ... 61s, standing down after 12 failed starts so the 2-minute keepalive owns the retry instead of a 3-second hot loop.
- **Duplicate retirement + orphan cleanup**: keep the oldest supervisor, kill the rest, clear any server.py running without owning the port.
- `exit=%RC%` never logged a value, because a digit touching `>>` is parsed as a file handle. It has a space now.

Verified: one supervisor, one server, /health 200 with ready/hub_up/agent_listening true. Header went from `CONNECTING - no link` to `TOOLS - 1ms - hub`; footer from `link: connecting` to `link: live - running tools`.

## 2026-08-14 client - status spam and a self-inflicted disconnect
- **A slow session list no longer drops a live link.** init ran fetchSessions() inside its try block, so when the PC was busy and _x.ai/sessions/list blew its 30s timeout, the exception tore down a connection that had already succeeded, restarted the agent and armed a reconnect. It now keeps the link, keeps the list it already has, says so once, and refills in the background with backoff.
- **Repeated chips collapse.** chip() appended a fresh line every time, so eleven identical "wifi blip - catch-up on HTTP" pills buried the conversation. Same text as the previous chip increments a count on it instead.

﻿## 2026-08-14 v1.8.2 — stale-link / session/load death loop
Anthony: `link stale · forcing reconnect` then `timeout: session/load` then `init failed: connection closed` ×5.

- **Root:** hub `async for` awaited `session/load`/`ensure` so **pings never ran**. 15s silence → client `ws.close()` mid-init.
- **Root:** `session/load` client timeout was **10s**; grok 1.0.3 attach of an existing chat is slower.
- **Root:** hub→agent WS used aiohttp `heartbeat=12` + `ClientTimeout(total=6)` — agent often ignores WS pings → **upstream closed** → `:2419` looks dead. cmd.exe spawn sometimes never bound the port.
- **Fix:** answer pings in the read loop (never behind RPC). session/load waits 90s. stale only after 45s and no in-flight RPC. No protocol heartbeat to agent. Spawn `grok.exe` directly. Hard-refresh phone.

## 2026-08-14 v1.8.1 — mirror grok-build + stop random disconnects
Anthony: grok-remote dropped the phone and lagged behind grok-build.

- **Root:** `/api/stack/start` defaulted `force=true` and `start_agent_process` always `claim_port(:2419)`, so Start / init-blip / supervisor murdered a live agent (log: `[claim] free agent :2419` then `[hub] upstream closed`).
- **Root:** client skipped disk catch-up while WS looked “fresh”, so grok-build TUI turns never painted on the phone.
- **Note:** `grok agent --leader serve` does **not** bind `:2419` (it attaches to the TUI leader with no local WS). Remote still uses `--no-leader serve` so the hub has a socket. Live mirror is **disk** (`updates.jsonl`) on a 0.5–0.9s poll.
- **Fix:** Never kill a listening agent unless `force`. stack_start defaults force off. Watchdog respawns only if the port is empty. `start.ps1` leaves healthy :2419/:2421 alone. Phone always polls disk so grok-build and remote stay in step.
- Hard-refresh the phone UI after this drop.

## 2026-08-13 v1.8.0 — radio chips + cheap health + /pair
- `/health` is cheap (`ok` = UI alive, `hub_up` / `agent_listening` / `ready`). Supervisor 2s timeout no longer waits on agent `initialize`.
- `/health/deep` keeps the old initialize probe.
- `/pair` wired (loopback-only). Startup prints QR banner. Pair page uses Braid paper/lavender.
- `/` is `Cache-Control: no-store`.
- Phone radio chip paints pong RTT + hub + quiet-age. Chat meta shows cwd + short sid. Braid session list cwd always visible; livebar extra not hidden.
- Catch-up poll skips when WS is fresh (2.8s idle / 0.9s busy). First reconnect ~120ms. Stale force-close 15s. Ping every 4s.
- Tests: `tests/test_radio_v18.py`. Restart UI to load.
## 2026-08-12 silent keepalive (blank cmd flash)
- `GrokRemoteKeepAlive` every 2m was launching visible `powershell.exe` (blank cmd flash then close).
- Tasks now run `wscript.exe ensure-running.vbs` (window 0). `Win32_Process.Create(cmd)` replaced with `Start-Process -WindowStyle Hidden`.
- Session hook + actor hook prefer silent launchers (`wscript` / `pythonw`).
## 2026-08-12 v39 — chat load fast (long sessions)
Anthony: chats take forever to load, especially long ones (updates.jsonl up to ~450MB).

- **Server** `find_session_dir`: sid→dir index (60s) + per-lookup cache (90s) — no full walk of ~1800 sessions every open
- **Server** `chat_only` history: byte-prefilter message lines, scan grow to **64MB**, coalesce then slice; text cap 120k
- **Client**: first page 24 msgs / 450k; fast plain paint during history; `upgradeRichBubbles` after open; no full-history fallback; older pages stay chat_only
- Bench (local): top 458MB session → **24 events in ~28ms** (was sparse misses under 8MB cap)

## 2026-08-11 v1.7.0 — connection reliability + session organization
Anthony: "persistent reconnection and first connection bugs" then "other apps are prompting
grok-remote and those chats flood my active space — put secondary access in a different
organization than user chats."

CONNECTION (each verified with a live killed-process gauntlet):
- FIRST CONNECT: the stored ws url pointed at one interface (192.168.0.7) while the auth cookie
  is scoped to whatever host is in the address bar - browse via meshnet/loopback and the socket
  dialed a host the cookie never rides to: 401, close, retry forever. The socket now always
  follows the page's own host unless the url was hand-typed this session.
- COLD BOOT: the web port serves BEFORE the agent finishes booting (up to ~18s); initialize used
  to get "agent offline" after 0.6s of retry, fail the connection, and loop. handle_client waits
  up to 12s, initialize up to 15s - the client just shows "connecting..." like it should.
- SUPERVISOR MURDER LOOP: bind-busy triggered claim_port, which KILLS the existing listener.
  Stacked supervisors (ensure-running spawns cmd-supervise; supervisor.log shows three "start"
  entries with no ends) made servers kill each other, dropping every client each cycle. A server
  that finds a HEALTHY instance on the port now stands down with exit 97 and every supervisor
  loop (cmd + template) stops respawning on 97.
- CONNECTED-BUT-DEAD: client pings are answered by the HUB, so the link looked alive while the
  agent behind it was gone. The hub now broadcasts _x.ai/remote/hub up/down; the client paints
  "agent restarting..." and, on recovery, re-initializes ON THE SAME SOCKET (no teardown).
  Upstream watcher retries every 2s (was 10) while clients wait, and respawns grok.exe itself
  (rate-limited 30s) - agent death used to be permanent until the next hook fired.
- INIT ERROR CACHE: one transient initialize error was cached and served to every later client
  until the upstream happened to cycle. Only success is cached now.
- Gauntlet: first connect OPEN in 1.5s; agent killed under a live client -> "hub false" in 2.5s,
  auto-respawn, hub true + same socket re-init in 15s; server killed -> client reconnected in 5s.

SESSIONS (v1.7.0 organization):
- sessionOrigin(): cwd fingerprint (Amni-Delve->Braid, Temp/scratchpad->Background, plugin root,
  Azno, per-folder) PLUS the uuid-version tell: apps that pin their own session ids mint uuid v4
  (Braid re-pins every ~2 turns - THE flood), grok-native sessions are v7. Home-cwd v4 -> "Apps".
- Scope chips now include one chip per origin with counts; Active/Live/Archived/All cover YOUR
  chats only. Measured on the live store: Active 190 -> 5 real chats; 185 sessions filed under
  Apps; store-wide split 525 v4 vs 1043 v7.
- The old isNoiseSession title-regex blacklist stays as a second net but no longer needs a new
  regex per app.

# Changelog

## 2026-08-11 — Archived chats actually list (v38.4)

- **Bug:** Archived scope filtered the *agent live list only* — ~318 archive ids on disk never appeared once dropped from agent sessions
- **Fix:** merge archive stubs into the rail; hydrate titles/cwd from disk; show **Active / Live / Archived / All** chips on the rail (not buried only in ⌕); Archived preview 50 rows
- Hard-refresh UI. Archive count shows on the chip (e.g. Archived · 318)

## 2026-08-11 — Blank offline/connecting screen (v38.3)

- **Bug:** disconnect mid chat-load left horizon/loading chrome with feed `visibility:hidden` → blank page while orbit said offline/connecting
- **Fix:** `clearLoadingChrome()` on boot, close, connect fail; sticky **Reconnect / Setup** banner when offline; auto-connect starts on setup (not empty chat); 401 pair page shows phone + localhost links
- Auth sets pairing cookie on successful key (path=/); loopback also seeds cookie
- Bounce UI (supervisor respawn). Hard-refresh phone.

## 2026-08-10 — Stay up + simple phone open + chat perf (v38.2)

- **UI kept dying:** bare `server.py` exits left remote “up” only on paper. **`scripts/supervise-ui.ps1`** watches `/health` and respawns UI; `ensure-running` + `start.ps1` use it
- **Basic setup:** setup panel **Phone setup (3 steps)** — copy link, open on PC, QR; advanced theme/ws collapsed; Desktop **Grok Remote** still one-click; `start.ps1` opens browser with key
- **Chat perf / memory:** open loads **36** chat events (~700KB) not 80/multi‑MB; no mid-paint scroll; thoughts/tools stubbed+collapsed on history; DOM cap **90** rows; catch-up poll **1.2s** + skip when tab hidden; smaller event de-dupe set
- Hard-refresh phone after UI is healthy. Backups: `*.v_simple_perf.bak`

## 2026-08-10 — Session isolation / no more Untitled bleed (v38.1)

- **Symptom:** Open chat rail showed **Untitled** while feed was another conversation (e.g. Haven Mobile); livebar tools/busy could flash from a different session
- **Title:** agent session list often has empty titles — hydrate from disk `summary.json` via `POST /api/session/titles`; openSession applies history `title` into rail + chat title
- **Live:** `busySid` so busy/tools phase only for the open session; gate hub `client_rpc` / auto-permission noise; strict event `sessionId` match when painting disk events (dropped 8-char fuzzy keep)
- **Disk:** `find_session_dir` multi-hit prefers matching cwd before newest-mtime fallback
- Hard-refresh phone; UI restarted. Backups: `*.v_session_bleed.bak`

## 2026-08-07 — Wireless resilience (v38)

- **Problem:** Phone Wi‑Fi link felt fragile — constant hub join/leave thrash, dual reconnect loops, reconnect giving up, catch-up poll dying with the socket
- **Client:** app-level WS keepalive + silent-death reconnect; never permanently stop retry while page open (slow park after cap); single-flight connect; **HTTP disk catch-up keeps running** when WS soft-drops
- **Server:** client heartbeat 12s, `_x.ai/remote/ping`→`pong`, hub watch keeps upstream agent warm
- **Cockpit:** dual `setupReconnect` interval removed (was opening a second socket)
- Restart UI once; hard-refresh phone (or re-open paired URL)
- Backups: `*.v_wireless_resilience.bak` · checklist: `docs/checklists/checklist_wireless_resilience_v38.md`

## 2026-08-02 — Detach-safe turns: leave page without killing work (v37.7)

- **Bug:** Leaving the remote page (navigate away, phone sleep, tab background) felt like it **interrupted** the agent turn
- **Causes:** (1) hub reverse-RPC fulfillment had regressed — tools needed the phone to answer `fs/*` / `terminal/*` / permissions; (2) WS `onclose` rejected in-flight prompts and cleared the session, so the UI looked cancelled even when the PC could keep going
- **Hub:** restore `HubTerminal` + `_handle_reverse` (read/write/terminal/auto-allow permission); on client leave **detach** pending RPCs (reparent to hub) instead of dropping/cancelling
- **UI:** soft-close keeps session id; phase `sync · bg on PC`; no prompt-fail on link loss; `visibilitychange` / `pageshow` / `online` re-arm reconnect; maxReconnect 80
- Restart remote UI once (server.py); hard-refresh phone
- Backups: `server.py.v_detach_nav.bak`, `index.html.v_detach_nav.bak`
- Checklist: `docs/checklists/checklist_detach_nav_v1.md`

## 2026-08-01 — Math formatting on mobile (v37.6)

- **Bug:** LaTeX/`$...$`/`$$...$$` showed as raw text — markdown renderer had no math engine
- **Fix:** ship KaTeX under `web/vendor/katex/`; extract math before markdown; typeset inline + display; ` ```math ` fences; nested `/static/{name:.*}` for fonts
- Mobile: scrollable display math, slightly tuned font size
- Restart remote UI once for static route; hard-refresh phone

## 2026-08-01 — Orbit dialed back (v37.5.1)

- **Orbit:** one solid ring + one moon (removed dashed spinner, extra rings, multi-sats, corner LED on the path)
- **Online** lives in the side pill with its own dot — not on the satellite track
- Hard-refresh

## 2026-08-01 — Chat rename + orbit status cluster (v37.5)

- **Rename chat:** session row **Rename**, double-click title, chat bar title, Command deck **Rename chat**
- Persists via `POST /api/session/rename` → `summary.json` (`remote_title` + `generated_title`) and local `grok_remote_titles` fallback
- **Orbit (top-right):** planet + ring + status pill (header `#status` hidden)
- Hard-refresh UI; **restart remote UI** once so `/api/session/rename` is registered
- Backups: `index.html.v_rename_orbit.bak`, `server.py.v_rename_orbit.bak`, `braid-layout.css.v_rename_orbit.bak`

## 2026-08-01 — Braid filter z-stack + top-3 collapse (v37.4)

- **Bug:** conversation **⌕ filter** pop was clipped / buried under the session list (`#picker{overflow:hidden}` + list paint order)
- **Fix:** filter pop uses **`position:fixed` + z-index 20060**, placed from the ⌕ button; picker/head overflow visible; list `z-index:1`
- **Rail:** always show **top 3** sessions; **▸ N more conversations** expands an **Older** section; **▴ Show less** collapses (search still shows full matches)
- Hard-refresh. Backups: `braid-layout.css.v_filter_z.bak`, `index.html.v_filter_z.bak`

## 2026-07-29 — Cancel / interject actually sticks (v37.3)

- **Bug:** Cancel looked like it worked (UI went idle) then a **stale** `session/prompt` resolve or `turn_completed` from the cancelled turn cleared the **new** turn’s busy state — or interject re-prompted before cancel settled
- **Fix:** turn tokens (`activeTurnToken`) so only the current prompt can set idle; drop pending prompts on cancel; send cancel as **notification + request**; await ~320ms before interject send; ignore stale turn_complete / queue_changed during cancel; Cancel button targets bound session id
- Hard-refresh. Backup: `index.html.v_cancel_interject.bak`

## 2026-07-29 — Fix sidebar clipped by chat (v37.2)

- **Cause:** `.panel{max-width/margin}` applied to `#picker`; invisible Archive/Pin still ate row width; chat/footer could paint over the rail (same z-index + overflow)
- **Fix:** locked sidebar column (`minmax(280–300px)`); picker `z-index:5`, full width, no max-width/margin; session actions **absolutely positioned** on hover; chat/footer `min-width:0` + `overflow:hidden`
- Hard-refresh. Backup: `braid-layout.css.v_sidebar_clip.bak`

## 2026-07-29 — Braid compact chrome + full-width chat (v37.1)

- **Chat column:** feed + composer use the full center stage (no 760px bottle-neck); shared `--braid-chat-pad`; agent bubbles ~920–1120px
- **Sessions rail:** compact head — **+ New chat** / ↻ / **⌕** filter menu (search + Active/Live/Archived/All); hide path/meta until hover; archive/pin on hover
- **List collapse:** Braid shows **first 3** sessions + **Show N more** (keeps open chat in the visible set); **Show less** when expanded
- **Livebar:** quiet strip (link · phase · perm · effort); **···** reveals git/cost/hint
- Hard-refresh. Backups: `index.html.v_braid_compact.bak`, `braid-layout.css.v_compact.bak`

## 2026-07-29 — Braid layout shell (v37)

- **Default UI:** clean **Braid** shell (Haven-Braid language) — soft surfaces, quiet chrome, channel-style sessions, 280px rail, centered ~760px chat, pill composer
- **Legacy preserved:** full previous mission-control look kept as layout **Legacy**
- **Switch:** Setup + Theme sheet **Layout** chips, Command deck **Layout**, or `?skin=braid|legacy`
- **Persist:** `localStorage.grok_remote_layout`; early `<head>` bootstrap sets `data-layout` before first paint
- **CSS:** `web/braid-layout.css` (scoped under `html[data-layout="braid"]` — no JS logic rewrite)
- Hard-refresh remote UI. Backup: `backups/index.html.v_braid_layout.bak`

## 2026-07-28 — Session rail highlight matches open chat (v36.2)

- **Symptom:** left sessions list highlighted a different chat than the feed
- **Cause:** `.current` only applied inside `renderSessions()`, and `openSession` never re-rendered after changing `sid` (demo path did). Mid-switch `sid=null` also left the previous row lit.
- **Fix:** `selectedSid` + `paintSessionCurrent()` / `setSelectedSession()`; highlight immediately on open/new; re-sync after load; `data-sid` on rows; open badge tracks selection
- Hard-refresh. Backup: `backups/index.html.v_sess_highlight.bak`

## 2026-07-28 — Stop duplicate You bubble after attach send (v36.1)

- **Symptom:** text+images painted correctly, then a second You bubble with the same text only
- **Cause:** disk live catch-up uses `paintHistoryUser` with `historyPainting` and **no** local-echo dedupe; WS/history re-echoed the prompt after `paintLocalUserTurn`
- **Fix:** `isLocalUserEcho` / `normUserEcho`; skip in `handleUpdate`, `paintHistoryUser` (when not replaying full history), and wire `appendUser`; extend local echo window on local turn paint
- Hard-refresh. Backup: `backups/index.html.v_dup_user_echo.bak`

## 2026-07-27 — New chat only + image+text shows both (v36)

- **UI:** Sessions rail is **+ New chat** only (removed **New task…**). Command deck (9-dot) no longer lists New task or Sessions — Skills / Delivery stay; use the rail for chats.
- **Bug:** Sending an image with caption text painted **only the image**. Cause: `lastLocalUserPlain` + `localEchoUntil` were set *before* `appendUser`, so local text was treated as a duplicate echo and skipped; attachments then opened a You-bubble with media only.
- **Fix:** `paintLocalUserTurn(text, files)` builds one You bubble (markdown then previews); queue drain uses the same path; `appendUser` keeps `.att-prev` / `.file-chip` when re-rendering text.
- Hard-refresh remote UI. Backup: `backups/index.html.v_newchat_attach_text.bak`

## 2026-07-23 — Agent reply no longer splits into multiple Grok bubbles

- **Symptom:** one reply painted as several short Grok bubbles (mid-sentence fragments before tools)
- **Cause:** every `agent_thought_chunk` did `curAgent=null`, so the next text chunk opened a **new** bubble; history paint also forced a new row per agent event
- **Fix:** thoughts no longer close the open Grok bubble; history agent chunks coalesce into the open bubble; tool calls still close it so post-tool text lands after tools
- Hard-refresh remote UI. Backup: `backups/index.html.v_agent_bubble_split.bak`

## 2026-07-23 — Stop rotating the pairing secret on every launch (v35.2)

- **Symptom:** the shortcut kept landing on the raw `{"error": "unauthorized ..."}` response even seconds after a fresh instance had been confirmed healthy and its key confirmed working.
- **Cause:** `start.ps1` minted a brand-new random `--secret` on *every single invocation* — including every `ensure-running.ps1` fire from the shortcut. Any already-open tab, or a second click landing while the first was still mid-boot, held a key that had already rotated out from under it the moment a new instance spun up. This is what made v35.1's health-polling fix insufficient on its own — the instance being polled could be perfectly healthy and still reject a request carrying yesterday's (or ten-seconds-ago's) key.
- **Fix:** the secret is now resolved once and persisted to `.ui-secret` next to `start.ps1` (gitignored, machine-local) — explicit `--secret`/env var still wins, then the persisted file, then generate-and-save only if neither exists. `desktop/main.js`'s Electron cockpit reads/writes the same file so it can never mint a secret that disagrees with the shortcut path. The key now stays constant across restarts; `connect.url` only ever changes if you delete `.ui-secret` yourself.

## 2026-07-23 — Fix the desktop shortcut breaking under v35 auth (v35.1)

- **Symptom:** double-clicking "Grok Remote.lnk" opened the browser to a raw `{"error": "unauthorized ..."}` JSON response instead of the UI.
- **Cause 1:** `launch-remote.cmd` still opened the hardcoded `http://127.0.0.1:2421/?auto=1` with no key — it predated v35's auth requirement and was never updated. A first-pass fix tried extracting the secret via a nested `for /f` + inline PowerShell inside batch, which is exactly as fragile as it sounds and doesn't reliably run before the server's first-ever `connect.url` write completes anyway (a flat 2-second `timeout` before opening the browser, vs. the stack's actual multi-second boot time).
- **Cause 2 (the sneaky one):** the PowerShell fix-attempt itself, `scripts/open-remote-ui.ps1`, used an em-dash (`—`) inside a double-quoted string. Windows PowerShell 5.1 run via `-File` on a BOM-less UTF-8 script can misread that multibyte character and lose track of the string terminator — `"The string is missing the terminator"` — silently killing the script. `start.ps1` had the identical landmine in a `Write-Host` line, unrelated to this bug but caught by the same sweep. Same failure class as the changelog mojibake fixed earlier this session; scanned every `.ps1` in the repo and parse-checked all of them with the real Windows PowerShell tokenizer — all clean now.
- **Fix:** `launch-remote.cmd` now calls `scripts/open-remote-ui.ps1`, which polls `/health` (unauthenticated, exempt from auth) for up to 25s, then reads the already-correct `connect.url` (written by `start.ps1` as its last boot step, always carrying the current key) and opens *that* — no manual secret extraction anywhere. Falls back to a plain unkeyed URL with a console warning only if the stack genuinely never came up in time.
- Deployed to `~/.grok/plugins/grok-remote/`; live-tested end to end against a running instance (silent success = healthy path, correct keyed URL read from `connect.url`).

## 2026-07-23 — Auth: gate every endpoint behind the pairing secret (v35)

- **Gap:** none of the HTTP/WS endpoints required authentication — anyone on the LAN who found `:2421` could read/write any file under the workspace, inject prompts into any session, or kill the stack via `/api/stack/stop`. Called out as deferred (C1) at the end of the v34 bug sweep.
- **Fix:** every route now runs through `make_auth_middleware`, keyed on the existing `--secret` (already required at startup, already a fresh random value per launch — no new secret to manage). First request with `?key=<secret>` sets an httpOnly cookie; the browser then carries it automatically on every same-origin fetch/WS call, so **no client JS changes were needed**.
- **Exemptions:** `?demo=1` (privacy-safe sample-data mode, used for screenshots) and `/health` (a boolean + sanitized string, polled unauthenticated by three existing local scripts that don't know the secret ahead of time — persisting a shared-secret file for them was more machinery than the exposure justified).
- **Pairing:** `connect.url` and the printed "open on your phone" links now embed `?key=$Secret`. **Old bookmarked links without the key will 401 once — re-pair from a fresh `start.ps1` run.**
- **Desktop cockpit:** `desktop/main.js` now shares one `UI_SECRET` across window loads, the health poll, and the workspace-picker's `/api/fs/root` call (repo-only; not part of the installed plugin, which doesn't ship the Electron app).
- Live-smoke-tested on a throwaway port: unauthenticated → 401, wrong key → 401, correct key → 200 + cookie set, cookie-only follow-up → 200, `?demo=1` → 200, `/health` → 200 unauthenticated.

## 2026-07-23 — Hide Azno/amni watchdog sessions from chat list (v1)

- **Symptom:** remote session rail flooded with *Azno Market Watch*, *Market Watch Co-Pilot*, *Azno TA Cache…* chats — one new session per automated market-watch co-pilot tick (~hourly), plus similar watchdog labels
- **Cause:** Azno co-pilot spawns real Grok sessions (`azno-v2` cwd); list showed every ACP session as a human chat
- **Fix:** `isNoiseSession()` title/cwd filter; applied in `normalizeSessions`, `renderSessions`, and `pickBestSession` so noise never lists or auto-opens
- Does not delete disk history; hard-refresh remote UI after deploy
- Backup: `backups/index.html.v_noise_sessions.bak`
- Checklist: `docs/checklists/checklist_noise_sessions_v1.md`

## 2026-07-22 — Bug sweep: security, correctness, reliability (v34)

**Security**
- `esc()` never escaped `"`/`'`; autolinked URLs (`https?://[^\s<]+`) inject straight into `href="$2"` — a URL containing a quote could break out into a live attribute/event handler (stored XSS from any agent/tool output). Fixed: `esc()` now escapes quotes too.
- Agent connection secret (`?server-key=...`) could leak into `_last_err` on a handshake failure, surfaced verbatim on unauthenticated `/health` and `/api/stack/status`. Fixed: sanitized before storing.
- `_pump`'s cleanup path called `self._reader.cancel()`/`await self._reader` on itself when disconnect cleanup ran from inside the pump task — broke cleanup of the client `pending` map and `_rpc_futs` (both silently orphaned, hanging in-flight RPCs up to their full timeout). Fixed: guard against self-cancel; both maps are now rejected/cleared on disconnect.
- `netstat` port matching was substring-based (`:2421` matched `:24210`) — `claim_port`/`wait_port` could kill an unrelated process or falsely report a port bound. Fixed: exact port match on the parsed local-address column.
- `static` handler's root-containment check was missing the path-separator boundary (matches the class of bug `under_root()` already guards against). Now reuses `under_root()`.
- Agent-initiated requests (e.g. permission prompts) are broadcast to every connected client; every client's response was forwarded verbatim, so the agent could receive multiple responses to one request. Fixed: only the first response per broadcast request id is forwarded.

**Correctness**
- `msgQueue` (the cross-session remote message queue) was wiped on every chat switch (`clearSessionFeed`) and on reconnect — queued Queue/FYI messages vanished silently. The queue is already per-item session-tagged and `drainMsgQueue` already gates on it; neither function needed to touch it. Removed both wipes.
- `newSession` never stamped `composerBoundSid` — a stale bind from the previous chat could route a brand-new session's first message to the old chat instead. Now stamped on success, cleared on failure.
- `drainMsgQueue` only requeued on a thrown exception; a `false` return from `dispatchPromptPayload` (not connected, empty prompt, mid-switch) dropped the item while the feed still showed it as sent. Now requeues on `false` too.
- WebSocket `onclose` never rejected the `pending` RPC map — in-flight sends orphaned on disconnect instead of failing fast.
- ide.js: `reviewDirty`'s per-file save loop mutated `state.active` without calling `activate()`, so the editor kept showing the previously-open file while `onEditorInput` (keyed on `state.active`) wrote new keystrokes into the wrong tab's buffer — a subsequent save could write file A's content into file B on disk. Fixed: use `activate()`; `onEditorInput` now keys off the editor's own `dataset.rel`.
- ide.js: `saveActive` cleared the dirty flag unconditionally after `await`ing the write — edits typed during the network round-trip got silently marked clean (and could be discarded by `closeTab` with no warning). Now only clears dirty if the content is still what was saved.
- ide.js: Ctrl+Shift+S never fired `reviewActive` (uppercase `"S"` never matched the lowercase check) and, on platforms reporting lowercase, would have fired both save and review at once. Fixed.
- ide.js: `closeTab`'s tab-0 fallback skipped `activate()`, leaving the status line and tree highlight pointing at the closed file.
- voice-mode.js: `stopSpeak()` (the "Quiet" button) called `audioEl.pause()`, which fires neither `onended` nor `onerror` — the `grokSpeak` promise the drain loop was awaiting never settled, permanently hanging that loop and leaking the blob URL. Fixed with an explicit settle path invoked by both natural completion and manual stop.
- voice-mode.js: a fatal mic error (`not-allowed`, `audio-capture`, `service-not-allowed`) in Go/XR mode triggered an infinite `onend`→restart→`onerror` loop, flooding the feed with a chip roughly every 400ms. Fixed: fatal errors now stop voice mode instead of retrying.

**Reliability**
- Live-tail polling (`read_session_updates(..., live=True)`) could read a partial trailing line mid-write from the agent, fail to parse it, and still advance `end_pos` past it — permanently dropping that event from the stream. Fixed: trim the read to the last complete line.
- `/health` imported `websockets`, a package never installed by this project (only `aiohttp` is auto-installed) — reported unhealthy forever regardless of actual agent state. Rewritten to reuse the already-imported `aiohttp` client.
- `run-agent.cmd` was written with `encoding="ascii",errors="replace"` — any non-ASCII character in the workspace path corrupted the launch command. Switched to UTF-8 (same class of bug as the changelog mojibake incident this pass started from).
- `fs_read`'s UTF-8-sig fallback branch was unreachable (a BOM decodes fine under plain `"utf-8"`, just leaving a literal `﻿` in the content) — could seed exactly the kind of encoding corruption found in `changelog.md`. Now decodes `utf-8-sig` first.
- `--claim-ports` was documented as opt-in but the UI port was claimed unconditionally on every startup even without the flag. Fixed.
- Legacy loop jobs missing `expires_at` (older save format) were purged on the very next load instead of getting the intended 7-day grace window.
- `kill_pids_list`/`lan_ip`: added explicit UTF-8 decoding to `taskkill` output (matching the netstat call's existing convention) and fixed a socket handle leak on connection failure.
- `changelog.md` (914KB, doubly re-encoded mojibake from a non-UTF-8 write somewhere in the toolchain) repaired via iterative `ftfy` passes back to its original ~21KB / 48 entries; root cause addressed above (`run-agent.cmd` encoding, `fs_read` BOM handling).

Deployed to `~/.grok/plugins/grok-remote/` (web/ + server.py). Backups of every touched file under `backups/`.

## 2026-07-18 — Composer bind: send to chat where typed (v33)

- **Log where typed:** `composerBoundSid` stamps on composer input/focus; send uses that id, not live `sid` after await
- Per-session drafts: switch chat saves/restores composer text; empty chat does not steal an in-flight bind at send time
- Cross-chat send allowed with pinned `sessionId` + chip `sent → <id> (typed there)`
- Cancel/interject already target the same bound sid

## 2026-07-13 — Cancel/interject immediate + session-pin sends (v31)

- **Cancel** always fires `session/cancel` on the captured session id immediately (no cockpit-only path that can stall)
- **Interject** cancels then prompts without the 350ms delay
- **Wrong-chat send:** pin `sessionId` + `sessionGen` at send start; abort if chat switched mid-await; queue items store session id
- Session switch rejects pending prompts and drops other-chat queue items

## 2026-07-13 — Calm scroll settle on open/send (v30)

- Remove multi-rAF / multi-timeout scroll spam that caused twitchy feed on chat load and send
- `forceScrollBottom`: single `scrollTop` set; optional one soft settle (~80–120ms); no `scrollIntoView` fight
- Live follow uses one assignment only; open/send/jump use pin + single settle

## 2026-07-13 — Scroll: open-only pin + Bottom jump (v29)

- **No more tool-step whiplash:** live updates only follow when you are already at the bottom (`stickBottom`); execute/write/stream no longer re-pin scroll
- **↓ Bottom** button shows when you scroll up; tap to jump to latest
- **Chat open** still snaps to bottom once; **send** pins once so you see your message
- Older history: larger page (80), no bottom snap while prepending; scroll position preserved

## 2026-07-13 — Double-send + mobile autoscroll (v28)

- **Double You bubbles:** `sendInFlight` gate (Enter/click race); stronger local-echo dedupe vs agent `user_message_chunk` (12s window + plain-text match)
- **Mobile scroll:** ignore scroll-stick flips during keyboard/viewport reflow; wider atBottom slop when `kb-open`; force bottom on send/focus/agent paint

## 2026-07-13 — Product README + screenshot revamp

- Regenerated `docs/screenshots/*` from `?demo=1` only (no real chats)
- Capture script: command deck, tools, orbit, skills, theme gallery, phone, spoiler
- README rewritten as product tour (Grok default + Scient/Matrix/Ubuntu/Commodore/light)

## 1.3.0 — 2026-07-13

- Strip INTERJECT / AGENT SETUP / system-reminder / REMOTE LOOP chrome from You bubbles
- Hub `/loop` (no CLI TUI required) + `/effort` via ACP `session/set_model`
- History: closed bubbles per turn when switching chats
- Mobile keyboard / rotate reflow; command deck menu; todo badge fix
- Plugin + package version aligned to **1.3.0**

## 2026-07-13 — Hide instruction chrome in You bubbles (v27)

- Harden `stripPromptChrome`: strip `[INTERJECT…]`, `[FYI…]`, `[Queued…]`, `[AGENT SETUP]…[END]`, `[REMOTE LOOP…]`, `<system-reminder>…` (multi-pass, not start-only)
- Fixes Remote painting delivery-mode / persona / scheduler wrappers above the real user text

## 2026-07-12 — Chat switch history: one bubble per turn (v25)

- **Switch-only bug:** disk history is coalesced full turns, but the live streaming buffer still reused one You/Grok bubble — older turns vanished when opening another chat
- History/replay path now paints each user/agent event as its **own closed bubble**
- Fallback: if chat-only paint is empty, retry full history / cwd-less resolve; warn+retry if events painted zero DOM rows

## 2026-07-12 — History: restore You bubbles on refresh (v24)

- **Bug:** chat-only disk history has no `turn_completed`, so `curUser` stayed open and every user line overwrote the first You bubble — looked like older messages vanished
- **Fix:** start a new You bubble when wire buffer is empty; clear `curUser` on agent/tool/thought; skip local-echo dedupe during history replay

## 2026-07-12 — Composer shake + hide agent setup in chat (v23)

- **Shake fix:** multi-line typing no longer force-scrolls the feed every keystroke; pad updates stabilize scroll by footer delta only
- **Setup chrome:** persona / mode wrappers still sent to the agent, but stripped from You bubbles (local echo + wire + history)
- Pushed prior commits; this ships shake + display strip

## 2026-07-12 — Command deck menu + todo badge fix (v22)

- **Why "Todo 4":** `paintTodoBadge` overwrote the whole Tools row button with `todo N` (open count). Now keeps **Todos** label + badge key (`3/4`, `board`)
- **Command deck:** glass panel, brand header, live status chips, icon rows, pop-in, 3×3 glyph trigger (replaces plain ☰)
- Tools inject with icons; status bar refreshes while menu open

## 2026-07-12 — ☰ menu dedupe (v21)

- Flattened upper-right menu: Chat · Tools · Hide · Collapse · Apps · Appearance · Help
- **Permission** is one cycle control (Always → Ask → Plan), same as livebar
- Removed duplicate **Fonts** (Theme sheet), **Go voice / XR** (composer), hide/collapse chips from Theme UX
- Hide/collapse as compact 2-column grids; denser menu chrome

## 2026-07-12 — Keyboard clearance + rotate formatting (v20)

- **Keyboard:** pin shell to `visualViewport` whenever the composer is focused (not only when inset >48px); re-measure footer stack and lift feed so last messages clear keyboard + bottom bar
- **Rotate:** hard-reset body pin + CSS vars (`--vv-h`, `--feed-pad-bottom`, …); multi-stage reflow through ~1.6s; detect width/height flip as orientation
- **Phone landscape:** do not enter desktop sidebar layout when wide-but-short without fine pointer (`body.phone-landscape` stays single-column)
- Composer font-size 16px (iOS zoom guard); tighter max height while keyboard open

## 2026-07-09 — Mobile keyboard + orientation reflow

- Pin shell to **visualViewport height/top** while typing (iOS-safe baseline when unfocused)
- Feed padding = measured footer height so chat clears keyboard + bottom bar
- **Rotate** portrait↔landscape: multi-stage reflow (reset composer height, layout, stack pad, scroll)
- Permission chip/menu; always-approve skips plan approve UI
- Markdown lettered lists + safer path chips

## 2026-07-09 — Fix mixed history across sessions

- Abort stale history paints when `sessionGen` / `sid` changes mid-load (race was blending chats)
- Live updates require a matching `sessionId` (no unscoped bleed)
- Disk live catchup + older pages check session identity; history API stamps `resolvedDir`
- `find_session_dir` prefers cwd match; multi-hit fallback picks newest only

## 2026-07-09 — Start server reliability + faster chat open

- **Start server:** force-spawn agent with UI secret; if hub still 401s, kill/rebind and retry; clearer error toast
- **Chat open:** paint **disk messages first** (chat-only, ~80, small byte window); reveal UI immediately
- `session/load` + commands run **in background** with live-stream suppressed (no full agent replay dump)
- Skip blocking `_x.ai/prompt_history` on open

## 2026-07-09 — Fast history: last 100 + scroll-up load

- Open session loads only the **latest ~100** disk events (smaller read window)
- **Scroll up** (or tap "earlier messages") loads the previous page and prepends it
- API: `/api/session/history?limit=100&before=<byte>` + `meta.has_more` / `older_before`

## 2026-07-09 — Footer de-clutter + menu fonts + Amni-Delve

- ☰ menu uses UI `--font` / size (no fixed 12px mono)
- Removed above-composer clutter: no more "not a git repo", cost strip, or always-on When busy row
- Git + turns/ctx move into the **livebar** (only when useful); Interject/Queue/FYI only while busy
- **Amni-Delve** always in ☰ · Voice & wear; owner auto-unlock for Anthony/Amni paths

## 2026-07-09 — Fix new chat inheriting old user messages

- **Root cause:** `softCatchup` painted full `_x.ai/prompt_history` when `promptCount===0`, so **New chat** filled with prior turns
- **Fix:** `sessionFresh` gate; skip prompt-history backfill on empty/new sessions; only append prompt deltas after a known baseline; hard-clear feed/queue on new/open

## 2026-07-09 — Composer UX + XR detect + Watch v19

- **+** is attach-only; **Mic** sits beside the composer for Go voice
- Special functions moved to top-right **☰** (Todos, Terminal, Git, Export, …)
- **Chat view** toggles in ☰: hide/collapse thinking, tools, edits, reads, code
- **XR/AR autodetect** (`navigator.xr` + wearable UA); prefers AR when available
- **Galaxy Watch companion** at `/watch` (round UI, mic, session sync)
- Git strip stays under composer; tools tray removed from +

## 2026-07-09 — Message queue modes + Cancel v18

- **Interject / Queue / FYI** chips above composer (`When busy`)
- **Interject:** cancel current steps → send now
- **Queue:** hold until a good pause (`turn_completed`), then send with guidance framing
- **FYI:** extra context only — never cancels; applied at next pause with "don't stop" framing
- **Cancel** button beside **Send** (Send no longer turns into Cancel)
- Queue strip shows pending remote items (dismissible) + agent queue note

## 2026-07-09 — Voice Go + XR/AR + Grok TTS v17

- **Dictate / Go / XR** controls in composer tools + floating `#voiceHud`
- **Go mode:** continuous voice-to-text, pause-to-send for on-the-go tasks
- **XR/AR mode:** large smartwear-friendly HUD; WebXR immersive-ar/vr when the browser supports it
- Spoken replies are **ack on task receipt** + **summarized final answer** only (not full tool chatter)
- **Real Grok voice:** `POST /api/tts` → `https://api.x.ai/v1/tts` (needs `XAI_API_KEY`); browser `speechSynthesis` fallback
- `GET /api/voice/status` reports TTS readiness; voice picker (eve, ara, leo, …)

## 2026-07-09 — Promote archived → live on message v16

- Messaging an **archived** session unarchives it (`POST {id, archived:false}`), marks it **live**/resident, switches scope Archived → Active, and **auto-refreshes** the session list
- Promote runs optimistically on send + again on prompt resolve
- Archive load no longer re-merges stale local IDs over a successful server unarchive (merge only on `migrate`)
- Synced to `~/.grok/plugins/grok-remote`

## 2026-07-10 — Polish v15 (syntax, greyscale, tools, tour, repo)

- **Syntax colors** fixed in tool edits/reads (token CSS covered `.code-with-lines` / tool panes; removed `!important` greys that killed tokens)
- **Grok theme** full greyscale chrome (no green status accents); code keeps distinct syntax hues
- **Delve** hidden for normal users (owner unlock only; code kept)
- **Composer + tray** clearer labels + Chat/Work/Share groups
- **Tour** reworked steps, prep focus, no auto-hijack on first run (gentle chip instead)
- **Screenshots** varied non-spoiler sample session views; README/CONTRIBUTING/package.json professionalized

## 2026-07-10 — Spoiler-safe Grok screenshots v14

- Privacy blurs **session titles** (not just paths); stronger blur; title tooltips stripped when spoiler on
- Spoiler badge: **private screen** by default; **hold Alt to peek** only on real desktop (`can-hover.desktop`)
- Default product theme remains **Grok**; `applyTheme` fallback no longer lands on Scient
- `?demo=1&variant=grok&privacy=1` scrubbed sessions for public captures; `scripts/capture-screenshots.mjs`
- README shots retaken — no personal paths/chats, Grok dark default, phone without Alt

## 2026-07-10 — Menu stacking + code line numbers / syntax

- Header ☰ / orbit menus use `position:fixed` + high z-index so they paint above chat
- Thinking renders markdown + fenced code (syntax colors)
- Tool in/out, reads, edits: line numbers + token highlighting
- Markdown fenced code blocks no longer skipped

## 2026-07-10 — Live CLI→remote disk catch-up

- Remote polls `updates.jsonl` via `/api/session/history?live=1&since=<bytes>` every 500ms
- Thinking / tools / agent text from desktop TUI (same session id) stream into remote without hard refresh
- EventId de-dupe keeps history paint + live tail from double-rendering

## 2026-07-10 — Start Server + port claim + reconnect guard v8

- **Start Server** header + setup button → `POST /api/stack/start` (kills stale :2419, spawns `grok agent --no-leader serve`, rebinds hub)
- **Boot:** UI claims free :2421 listeners; auto-starts agent if missing; `start.ps1` kills :2419/:2421 before bind
- **Reconnect:** max 5 tries, no infinite reconnecting #N loop; agent error no longer thrashing; after give-up → hit Start Server
- Auto-connect: if `/health` agent down, Start Server first then connect

## 2026-07-10 — Live status + init/session reliability v7

- **Root cause of init failed:** agent serve was down / started with wrong `--leader` flag (means *attach to leader*, not run server). Fixed launcher to `--no-leader serve` via cmd append (no stdout pipe hang).
- **Hub:** keep client WS open when agent is briefly down; retry ensure; cache `initialize` for multi-client; fast connect timeouts; clearer offline errors.
- **Session list:** unwrap nested `result.result.sessions`; sort/auto-open by `lastChangeUnixMs` (opens this chat: latest).
- **Live status bar:** bottom strip shows **idle / waiting for response / thinking / responding / running tools** with pulse dot; header short status.
- **Reconnect:** auto-retry on close/init fail; auto-open best session after connect.
- Restart stack: `scripts\restart-ui-only.ps1` + `logs\run-agent.cmd`; hard-refresh remote UI.

## 2026-07-10 — Pin fix + feature tour v6

- **Pin bugfix:** local `import subprocess` inside `main_async` except-block made nested handlers fail with *cannot access free variable 'subprocess'…* when aiohttp was already installed. Use module-level `subprocess` only.
- **Feature tour:** header **Tour** + setup **Feature tour**; 12-step spotlight walkthrough; first-run auto; `?tour=1` force; localStorage `grok_remote_tour_done`.
- **Tutorial prompt:** **Paste tutorial prompt** fills composer + clipboard for a live Grok-narrated walkthrough of all features.
- Restart UI on `:2421` after pull; hard-refresh clients.

## 2026-07-10 — Stop button + pin/start from anywhere

- UI header **Stop** → `POST /api/stack/stop` (UI + agent serve only; never mass-kill grok)
- UI **Pin** → `POST /api/stack/shortcut` creates Desktop + Start Menu shortcuts
- Scripts: `stop-remote.ps1`, `launch-remote.cmd`, `install-shortcut.ps1`
- Commands: `/remote-start`, hardened `/remote-stop`
- Desktop shortcuts installed: **Grok Remote** + **Grok Remote Stop**

## 2026-07-09 — Claude-gap pack v5.1

Closer to Claude Code day-to-day flow:

- **Stop turn** button (session/cancel) while agent is busy
- **Git strip** branch/sha/dirty + `/api/git/status|diff|log` + Δ working-tree diff
- **Context meter** live est. fill; `/cost` slash helper
- **Todos board** (plan sync + manual); badge count
- **Slash autocomplete** for skills + local `/clear /cost /diff /stop /agents /compact`
- **Open tool paths in IDE** (click 📄 locs)
- **Copy** on message hover
- **MD** inject AGENTS.md / CLAUDE.md into composer
- APIs: `/api/git/*`, `/api/project/context`

Restart UI server (`:2421`) for new routes; hard-refresh clients.

## 2026-07-09 — UX fix: contrast, horizon loader, terminal lag v4.2

- Contrast: solid bubbles, readable `--tx`/`--soft`/`--mut`, softened Grok mono (no pure black/white)
- **Event horizon loader** lives in `#chatStage` (chat area above composer only — not header/fullscreen)
- Space puns rotate under the spinning accretion disk while history/session loads
- Terminal stream: throttled paint, no auto-open spam, badge on `$_` instead, skip during replay
- Header no-wrap scroll; cockpit bar height capped

## 2026-07-09 — xAI product UX polish v4.1b

- Design tokens: `--ease`, `--elev-*`, `--glass`, `--hairline`
- Near-black monochrome base; **Grok** variant as official black/white product look (white CTA)
- Hover/focus/active micro-motion on header, chips, sessions, tools, composer, sheets
- Message row enter animation; glass header/footer; refined scrollbars
- Soft ambient glow + grid; reduced-motion + retro-theme exclusions
- Deployed to plugin + marketplace copies

## 2026-07-09 — Claude-gap cockpit features v5.0

High impact: inline red/green diffs + accept/reject hunk apply; @ workspace file picker; plan approve/edit/hold; Always-allow permission; terminal stream pane; background tasks list/cancel/notify  
Medium: chat search; local checkpoints; voice PTT; reconnect resume; HTML export (spoiler-aware)  
Diff: pin sessions bar; cost budgets; Delve launcher  

Files: `web/cockpit-features.js`, index wiring. Hard-refresh after stack up.

## 2026-07-09 — Full skills palette v4.3

- **Disk skill scan** `/api/skills/list`: `~/.grok/skills`, bundled, plugins, marketplace-cache, project skills + plugin commands
- Skills UI merges agent `commands/list` + disk scan; source chips + filter
- Advanced skills (design, execute-plan, review, …) appear even if agent list is sparse
- Restart UI server required

## 2026-07-09 — Multi-client hub + history snap v4.2

- **WS hub:** one shared agent connection; fan-out `session/update` to all phone/desktop clients; route RPC replies to the requester
- **History open:** hide feed while loading, then `snapChatToBottom` (no scroll-from-top marathon)
- Restart UI on :2421 required for hub

## 2026-07-09 — Personas & directions v4.1

- **Persona flyout:** personalities (Concise, Unhinged, Programmer, Engineer, Manager, Clown, Warlord, …)
- **Directions:** Build, Debug, Review, Explore, Plan, Ship, Refactor, Security, Docs, Teach, Speedrun
- Setup preamble on first send per session; **Inject setup now** button
- **Risk** persona owner-gated (`Users\antho` path or `?owner=1` unlock); not shown to others by default
- Prefs: `grok_remote_persona`, `grok_remote_direction`

## 2026-07-09 — Cockpit IDE + auto-stack + Grok Review v4.0

- **Electron auto-stack:** launch app → agent + UI proxy (no daily terminal)
- **`scripts/launch-desktop.cmd`** double-click entry
- **FS API** on UI server: `/api/fs/list|read|write|root` (workspace sandboxed)
- **Built-in IDE** panel: tree, tabs, editor, Save, Folder, New session here
- **Grok Review:** post-edit bug-check prompt for active / dirty files
- Desktop menus: Open workspace, IDE review shortcuts, New session

## 2026-07-09 — X-like labels + Ubuntu Yaru-ish v3.7

- Skin labels: **AIM-like**, **Win95-like**, **C64-like**, **Atari-like**, **Ubuntu-like**, **Matrix-like**, **DOS-like**, **Amiga-like**
- **Ubuntu-like:** modern Yaru-ish slate surfaces + orange accent (not old aubergine-only)

## 2026-07-09 — Tool payloads + rename skins v3.6

- **Tool cards:** merge rawInput/rawOutput/locations/content across updates; real titles (kind + path/cmd); no empty white bars
- Earlier playful aliases replaced by X-like naming

## 2026-07-09 — Code colors + collapsible rail + flyouts v3.5

- **Syntax colors** in fenced code: keywords/strings/numbers/comments/fns use theme tokens (`--acc`, `--ok`, `--you`, …)
- **Collapsible sessions rail:** « Hide / ☰ / edge tab; pref `grok_remote_sidebar`
- **Top-right flyouts:** Theme, Skills, Task open frosted glass panels sliding from top-right (Esc closes)

## 2026-07-09 — Legacy themes v3.4

- **Legacy palettes:** AIM, Win95, Commodore 64, Atari, Ubuntu, Matrix, MS-DOS, Amiga Workbench
- Full surface overrides (fonts, radius, chrome) + dark/light twists
- Theme picker groups **Product** then **Legacy · retro**
- Win95 bevel chrome, Amiga/Win95 title bars, Matrix phosphor glow

## 2026-07-09 — Chat polish + attachments v3.3

- **Markdown render:** headings, lists, bold/italic, inline code, tables, blockquotes, links, path chips, fenced code cards
- **Consistent bubbles:** solid 1px borders (no hover jitter); tools/cards match radius; cleaner clean-mode edge accents
- **File upload:** 📎 attach / drag-drop / paste; images as ACP `image` blocks; text/code as resource + fenced body
- Limits: 8 files, 6MB each · hard-refresh clients (`?v=3`)

## 2026-07-09 — SpaceXAI beauty + session isolation v3.2

- **Orbital status dial:** satellite orbits planet (spin when linked, fast when busy, red offline)
- **Pulse frames:** thin theme-accent borders on header / rail / feed / footer / setup
- **Polish:** bubble glow, composer focus halo, session card hover lift, reduced-motion safe
- **New-chat history bug:** clear `sid` first; `loadExpectSid` gates unscoped load stream; abandon softCatchup/silentReload across `sessionGen`; re-wipe feed after `session/new`
- Deployed to `~/.grok/plugins/grok-remote/web` + marketplace plugin copy

## 2026-07-09 — Sessions scroll + jump + archive v2

- **↓ Bottom** always on in chat (not only when scrolled up); forced scroll + `scrollIntoView`
- **Independent scrolls:** body locked; session rail list vs chat feed scroll separately
- **Archive / Unarchive** per session (localStorage); scope chips Active · Live · Archived · All + search
- Layout: picker-head sticky controls, `.sess` flex scroll region

## 2026-07-09 — UX options v1

- **Auto-scroll:** toggle on setup/Theme UX chips; stick-to-bottom while reading live; jump FAB
- **Collapse:** thinking rows, fenced code, tool cards — defaults + per-block tap
- **Borders vs clean:** bordered cards or clean edge-accent layout
- Prefs: `localStorage.grok_remote_ux`

