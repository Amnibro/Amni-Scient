import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import init, { compute_all, version } from './pkg/amni_life.js';
const KIND_COLORS = { person:'#7cc4ff', place:'#7be0a4', event:'#ffb060', work:'#cc8cff', idea:'#f5c842', era:'#dccdb1' };
const KIND_SIZE = { person:1.0, place:1.0, event:1.0, work:1.05, idea:1.0, era:1.9 };
const STORAGE_KEY = 'amni-life-map-v1';
const VIEW_KEY = 'amni-life-view-v1';
const THEME_KEY = 'amni-life-theme';
const THEMES = ['dark','light','sepia','midnight','solarized','nord','forest','sunset'];
const SCALE = 1.6;
const LERP_FRAMES = 60;
const CAM_FRAMES = 45;
const PICK_PIXELS = 28;
const MEDIA_DB = 'amni-life-media';
const MEDIA_STORE = 'blobs';
const MAX_TAG_CHIPS = 14;
let scene, camera, renderer, controls, raycaster, mouse;
let pointsMesh = null, edgesMesh = null;
let positions = {}, currentView = 'constellation';
let fragments = [], idToIdx = new Map(), edges = [];
let lerpSrc = null, lerpDst = null, lerpT = 1.0;
let camSrc = null, camDst = null, camTgtSrc = null, camTgtDst = null, camT = 1.0;
let selectedIdx = -1, hoveredIdx = -1;
let showEdges = true, autoSpin = true;
let activeKinds = new Set(['person','place','event','work','idea','era']);
let activeTags = new Set();
let editingId = null, linkingFrom = null, sharing = false;
let dbHandle = null;
let mediaURLCache = new Map();
let yearMin = 1900, yearMax = 2100, activeYearMin = 1900, activeYearMax = 2100;
let lightboxItems = [], lightboxIdx = 0;
let installPromptEvent = null;
let tourTimer = null, tourQueue = [], tourIdx = 0, tourPrevSpin = true;
const EDGE_TYPES = ['with','at','inspired-by','part-of'];
let activeEdgeTypes = new Set(EDGE_TYPES);
let linking = null;
const UNDO_LIMIT = 30;
let undoStack = [], redoStack = [], lastSnapshot = null;
let narrating = false;
let multiSelected = new Set();
let pathHighlight = new Set(), pathEdges = new Set();
const WELCOME_KEY = 'amni-life-welcome-v1';
const SOUND_KEY = 'amni-life-sound';
let soundEnabled = (localStorage.getItem(SOUND_KEY) || 'off') === 'on';
let audioCtx = null;
const HOVER_LABEL_RADIUS = 140;
const HOVER_LABEL_MAX = 8;
let hoverLabelPool = [];
const DOT_SIZE_KEY = 'amni-life-dot-size';
let userDotSize = parseFloat(localStorage.getItem(DOT_SIZE_KEY) || '1.0') || 1.0;
const OTD_DISMISS_KEY = 'amni-life-otd-dismissed-date';
let revealing = false, revealTimer = null;
let moodOverlay = false;
const MOOD_COLORS = { '-2':'#cc4060', '-1':'#d28080', '0':'#aaaaaa', '1':'#7bb88a', '2':'#5fd47b' };
const TOUR_STEP_MS = 4200;
const $ = id => document.getElementById(id);
const tooltip = $('tooltip'), statsEl = $('stats');
const ease = t => t < 0.5 ? 2*t*t : -1+(4-2*t)*t;
function toast(msg, ms = 2200) {
    const t = $('toast'); t.textContent = msg; t.classList.add('show');
    clearTimeout(toast._t); toast._t = setTimeout(() => t.classList.remove('show'), ms);
}
function loadFragments() {
    try { const s = localStorage.getItem(STORAGE_KEY); if (s) return JSON.parse(s).fragments || []; } catch {}
    return null;
}
function snapshot() { return JSON.stringify({ fragments }); }
function pushUndo(label = 'edit') {
    if (lastSnapshot !== null) {
        undoStack.push({ s: lastSnapshot, label });
        if (undoStack.length > UNDO_LIMIT) undoStack.shift();
        snd('save');
    }
    lastSnapshot = snapshot();
    redoStack = [];
}
async function restoreSnapshot(s) {
    const parsed = JSON.parse(s);
    fragments = parsed.fragments || [];
    lastSnapshot = s;
    try { localStorage.setItem(STORAGE_KEY, s); } catch {}
    rebuildIndex(); recomputeYearBounds();
    await computeLayouts();
    buildPoints(); buildEdges(); buildTimelineAxis();
    renderFragsList(); renderTagFilters(); renderEdgeFilters();
    if (selectedIdx >= fragments.length) selectFragment(-1);
    else if (selectedIdx >= 0) selectFragment(selectedIdx);
    updateStats();
}
async function undo() {
    if (undoStack.length === 0) { toast('Nothing to undo'); snd('error'); return; }
    const top = undoStack.pop();
    redoStack.push({ s: lastSnapshot, label: top.label });
    if (redoStack.length > UNDO_LIMIT) redoStack.shift();
    try { await restoreSnapshot(top.s); snd('undo'); toast(`Undone: ${top.label} · ${undoStack.length} more`); }
    catch (err) { toast('Undo failed: ' + err.message); snd('error'); }
}
async function redo() {
    if (redoStack.length === 0) { toast('Nothing to redo'); return; }
    const top = redoStack.pop();
    undoStack.push({ s: lastSnapshot, label: top.label });
    try { await restoreSnapshot(top.s); toast(`Redone: ${top.label} · ${redoStack.length} more`); }
    catch (err) { toast('Redo failed: ' + err.message); }
}
function saveFragments() {
    pushUndo('edit');
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify({ fragments })); } catch {}
}
async function fetchSample() {
    const r = await fetch('./data/sample_life.json');
    const j = await r.json();
    return j.fragments;
}
function openMediaDB() {
    return new Promise((res, rej) => {
        const r = indexedDB.open(MEDIA_DB, 1);
        r.onupgradeneeded = () => { r.result.createObjectStore(MEDIA_STORE); };
        r.onsuccess = () => res(r.result);
        r.onerror = () => rej(r.error);
    });
}
async function mediaPut(id, blob) {
    const tx = dbHandle.transaction(MEDIA_STORE, 'readwrite');
    tx.objectStore(MEDIA_STORE).put(blob, id);
    return new Promise(res => { tx.oncomplete = () => res(); tx.onerror = () => res(); });
}
async function mediaGet(id) {
    return new Promise(res => {
        const r = dbHandle.transaction(MEDIA_STORE, 'readonly').objectStore(MEDIA_STORE).get(id);
        r.onsuccess = () => res(r.result || null);
        r.onerror = () => res(null);
    });
}
async function mediaDelete(id) {
    const tx = dbHandle.transaction(MEDIA_STORE, 'readwrite');
    tx.objectStore(MEDIA_STORE).delete(id);
    if (mediaURLCache.has(id)) { URL.revokeObjectURL(mediaURLCache.get(id)); mediaURLCache.delete(id); }
}
async function mediaURL(id) {
    if (mediaURLCache.has(id)) return mediaURLCache.get(id);
    const blob = await mediaGet(id); if (!blob) return null;
    const u = URL.createObjectURL(blob); mediaURLCache.set(id, u); return u;
}
function rebuildIndex() {
    idToIdx = new Map();
    fragments.forEach((f, i) => idToIdx.set(f.id, i));
    edges = [];
    fragments.forEach((f, i) => (f.connections || []).forEach(c => {
        const j = idToIdx.get(c.to);
        if (j !== undefined) edges.push({ s: i, t: j, type: c.type || 'with' });
    }));
}
function newId() {
    let n = 1;
    while (idToIdx.has('f' + String(n).padStart(2, '0'))) n++;
    return 'f' + String(n).padStart(2, '0');
}
function newMediaId() { return 'm-' + Math.random().toString(36).slice(2,10) + '-' + Date.now().toString(36); }
let mediaRecorder = null, recChunks = [], recStart = 0, recTimer = null;
function pickRecorderMime() {
    const cands = ['audio/webm;codecs=opus','audio/webm','audio/mp4','audio/ogg;codecs=opus','audio/ogg'];
    if (typeof MediaRecorder === 'undefined') return null;
    for (const m of cands) if (MediaRecorder.isTypeSupported && MediaRecorder.isTypeSupported(m)) return m;
    return '';
}
async function openWall() {
    const grid = $('wall-grid'); grid.innerHTML = '';
    const stats = $('wall-stats');
    const items = [];
    fragments.forEach((f, i) => (f.media || []).forEach(m => items.push({ f, i, m })));
    stats.textContent = items.length === 0 ? 'No media yet — attach photos / videos / audio in the detail panel' : `${items.length} media · ${fragments.filter(f => (f.media||[]).length).length} fragments with media`;
    if (items.length === 0) {
        const e = document.createElement('div'); e.className = 'wall-empty';
        e.textContent = 'No media yet — attach photos / videos / audio to a fragment, or use + FOLDER to import a folder of photos.';
        grid.appendChild(e);
    } else {
        for (const { f, i, m } of items) {
            const url = await mediaURL(m.id); if (!url) continue;
            const card = document.createElement('div'); card.className = 'wall-card';
            const inner = m.kind === 'video' ? `<video src="${url}" muted preload="metadata"></video>`
                : m.kind === 'audio' ? `<audio src="${url}" controls></audio>`
                : `<img src="${url}" alt="${m.name||''}" loading="lazy"/>`;
            card.innerHTML = inner + `<div class="wall-card-overlay"><span class="t">${f.title || '(untitled)'}</span><span class="y">${f.year || ''} · ${f.kind}</span></div>`;
            card.onclick = () => { closeWall(); selectFragment(i); flyTo(i); };
            grid.appendChild(card);
        }
    }
    $('wall').classList.add('open');
}
function closeWall() { $('wall').classList.remove('open'); $('wall-grid').innerHTML = ''; }
function ensureAudio() { if (!audioCtx) try { audioCtx = new (window.AudioContext || window.webkitAudioContext)(); } catch {} return audioCtx; }
function chime(freq, dur = 0.12, gain = 0.06, type = 'sine') {
    if (!soundEnabled) return;
    const ctx = ensureAudio(); if (!ctx) return;
    const t = ctx.currentTime;
    const osc = ctx.createOscillator(); const g = ctx.createGain();
    osc.type = type; osc.frequency.value = freq;
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(gain, t + 0.005);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    osc.connect(g); g.connect(ctx.destination);
    osc.start(t); osc.stop(t + dur + 0.02);
}
function snd(kind) {
    switch (kind) {
        case 'select': chime(740, 0.08, 0.04); break;
        case 'fly': chime(520, 0.16, 0.05, 'triangle'); break;
        case 'view': chime(380, 0.10, 0.05); setTimeout(() => chime(640, 0.18, 0.04, 'triangle'), 60); break;
        case 'save': chime(880, 0.06, 0.04); setTimeout(() => chime(1180, 0.10, 0.04), 50); break;
        case 'undo': chime(220, 0.18, 0.05, 'triangle'); break;
        case 'error': chime(180, 0.20, 0.06, 'sawtooth'); break;
        case 'tour': chime(660, 0.06, 0.04); setTimeout(() => chime(880, 0.06, 0.04), 60); setTimeout(() => chime(1100, 0.14, 0.04), 130); break;
    }
}
function toggleSound() {
    soundEnabled = !soundEnabled;
    localStorage.setItem(SOUND_KEY, soundEnabled ? 'on' : 'off');
    const btn = $('btn-sound');
    if (btn) { btn.textContent = soundEnabled ? '🔊 SOUND' : '🔇 SOUND'; btn.style.borderColor = soundEnabled ? 'var(--accent)' : ''; btn.style.color = soundEnabled ? 'var(--accent)' : ''; }
    if (soundEnabled) snd('select');
    toast(soundEnabled ? 'Sound on' : 'Sound off');
}
function showWelcome() {
    if (localStorage.getItem(WELCOME_KEY) === 'dismissed') return;
    $('welcome').classList.add('show');
}
function dismissWelcome(skip) {
    $('welcome').classList.remove('show');
    if (skip) localStorage.setItem(WELCOME_KEY, 'dismissed');
}
function ensureHoverLabels() {
    const host = $('hover-labels'); if (!host) return;
    while (hoverLabelPool.length < HOVER_LABEL_MAX) {
        const el = document.createElement('div'); el.className = 'hover-lbl';
        host.appendChild(el); hoverLabelPool.push(el);
    }
}
const _hv = new THREE.Vector3();
function updateHoverLabels() {
    ensureHoverLabels();
    if (!pointsMesh || hoveredIdx < 0) { hoverLabelPool.forEach(el => el.classList.remove('show')); return; }
    const arr = pointsMesh.geometry.attributes.position.array;
    const rect = renderer.domElement.getBoundingClientRect();
    _hv.set(arr[hoveredIdx*3], arr[hoveredIdx*3+1], arr[hoveredIdx*3+2]);
    _hv.project(camera);
    const hx = (_hv.x + 1) * 0.5 * rect.width + rect.left;
    const hy = (1 - _hv.y) * 0.5 * rect.height + rect.top;
    const candidates = [];
    for (let i = 0; i < fragments.length; i++) {
        if (!isVisible(i) || i === selectedIdx) continue;
        _hv.set(arr[i*3], arr[i*3+1], arr[i*3+2]);
        _hv.project(camera);
        if (_hv.z >= 1 || _hv.z <= -1) continue;
        const sx = (_hv.x + 1) * 0.5 * rect.width + rect.left;
        const sy = (1 - _hv.y) * 0.5 * rect.height + rect.top;
        const dx = sx - hx, dy = sy - hy;
        const d = Math.sqrt(dx*dx + dy*dy);
        if (d < HOVER_LABEL_RADIUS) candidates.push({ i, d, sx, sy });
    }
    candidates.sort((a, b) => a.d - b.d);
    candidates.length = Math.min(HOVER_LABEL_MAX, candidates.length);
    hoverLabelPool.forEach((el, k) => {
        const c = candidates[k];
        if (!c) { el.classList.remove('show'); return; }
        const f = fragments[c.i];
        el.textContent = f.title || '(untitled)';
        el.style.left = c.sx + 'px';
        el.style.top = c.sy + 'px';
        el.classList.add('show');
    });
}
function todayMD() { const d = new Date(); return { m: d.getMonth() + 1, dd: d.getDate() }; }
function onThisDay() {
    const { m, dd } = todayMD();
    const out = [];
    fragments.forEach((f, i) => { if (f.month === m && f.day === dd) out.push({ f, i }); });
    out.sort((a, b) => (a.f.year || 9999) - (b.f.year || 9999));
    return out;
}
function renderOTD() {
    const dismissed = localStorage.getItem(OTD_DISMISS_KEY);
    const today = new Date().toISOString().slice(0, 10);
    if (dismissed === today) { $('otd').classList.remove('show'); return; }
    const matches = onThisDay();
    const card = $('otd');
    if (matches.length === 0) { card.classList.remove('show'); return; }
    const thisYear = new Date().getFullYear();
    const body = $('otd-body'); body.innerHTML = '';
    matches.forEach(({ f, i }) => {
        const row = document.createElement('div'); row.className = 'otd-row';
        const yago = f.year ? (thisYear - f.year) + 'y ago' : '';
        row.innerHTML = `<span class="otd-dot" style="background:${KIND_COLORS[f.kind]}"></span><span class="otd-title">${f.title || '(untitled)'}</span><span class="otd-yago">${yago}</span>`;
        row.onclick = () => { selectFragment(i); flyTo(i); };
        body.appendChild(row);
    });
    $('otd-count').textContent = matches.length;
    card.classList.add('show');
}
function dismissOTD() {
    localStorage.setItem(OTD_DISMISS_KEY, new Date().toISOString().slice(0, 10));
    $('otd').classList.remove('show');
}
function startReveal() {
    if (revealing) return;
    if (fragments.length === 0) return;
    revealing = true;
    const minY = yearMin, maxY = yearMax;
    const span = Math.max(1, maxY - minY);
    let yr = minY;
    $('reveal-overlay').classList.add('show');
    $('reveal-year').textContent = String(yr);
    $('reveal-progress-fill').style.width = '0%';
    fragments.forEach((_, i) => setHilite(i, 0));
    if (pointsMesh) {
        const sa = pointsMesh.geometry.attributes.size;
        for (let i = 0; i < fragments.length; i++) sa.array[i] = 0;
        sa.needsUpdate = true;
    }
    const stepMs = 380;
    let stoppedEarly = false;
    revealTimer = setInterval(() => {
        if (!revealing) { clearInterval(revealTimer); revealTimer = null; return; }
        $('reveal-year').textContent = String(yr);
        $('reveal-progress-fill').style.width = (((yr - minY) / span) * 100).toFixed(1) + '%';
        if (pointsMesh) {
            const sa = pointsMesh.geometry.attributes.size;
            fragments.forEach((f, i) => {
                if ((f.year || 9999) <= yr && isVisible(i)) sa.array[i] = (KIND_SIZE[f.kind] || 1.0);
            });
            sa.needsUpdate = true;
        }
        yr++;
        if (yr > maxY) {
            clearInterval(revealTimer); revealTimer = null;
            setTimeout(() => { stopReveal(); toast('Reveal complete'); }, 700);
        }
    }, stepMs);
    snd('tour');
}
function stopReveal() {
    revealing = false;
    if (revealTimer) clearInterval(revealTimer); revealTimer = null;
    $('reveal-overlay').classList.remove('show');
    if (pointsMesh) applyFilters();
}
function toggleReveal() { revealing ? stopReveal() : startReveal(); }
function parseQuickCapture(text) {
    const tags = [];
    let kind = 'event'; let year = null; let title = text;
    title = title.replace(/(?:^|\s)#([\w\-]+)/g, (m, t) => { tags.push(t); return ''; });
    title = title.replace(/(?:^|\s):(person|place|event|work|idea|era)\b/gi, (m, k) => { kind = k.toLowerCase(); return ''; });
    title = title.replace(/(?:^|\s)@(\d{4})\b/g, (m, y) => { year = parseInt(y, 10); return ''; });
    title = title.replace(/\s+/g, ' ').trim();
    return { title, kind, year, tags };
}
function renderQCPreview() {
    const text = $('qc-input').value;
    if (!text.trim()) { $('qc-preview').textContent = ''; return; }
    const p = parseQuickCapture(text);
    const parts = [];
    if (p.kind) parts.push(`<span class="pv-kind">${p.kind}</span>`);
    if (p.year) parts.push(`<span class="pv-year">${p.year}</span>`);
    p.tags.forEach(t => parts.push(`<span class="pv-tag">#${t}</span>`));
    if (p.title) parts.push(`"${p.title}"`);
    $('qc-preview').innerHTML = '→ ' + parts.join(' ');
}
function openQuickCapture() {
    $('qc-input').value = '';
    $('qc-preview').textContent = '';
    $('quick-capture').classList.add('show');
    setTimeout(() => $('qc-input').focus(), 50);
}
function closeQuickCapture() { $('quick-capture').classList.remove('show'); }
async function commitQuickCapture() {
    const raw = $('qc-input').value.trim();
    if (!raw) { closeQuickCapture(); return; }
    const p = parseQuickCapture(raw);
    if (!p.title) { closeQuickCapture(); return; }
    fragments.push({ id: newId(), title: p.title, kind: p.kind, year: p.year, summary: '', tags: p.tags, connections: [], media: [] });
    saveFragments(); rebuildIndex(); recomputeYearBounds();
    await computeLayouts();
    buildPoints(); buildEdges(); renderFragsList(); renderTagFilters();
    updateStats();
    closeQuickCapture();
    selectFragment(fragments.length - 1); flyTo(fragments.length - 1);
    toast(`Added: ${p.title}`);
}
function toggleMood() {
    moodOverlay = !moodOverlay;
    const btn = $('btn-mood');
    btn.textContent = moodOverlay ? '🎨 MOOD' : '🔇 MOOD';
    btn.style.borderColor = moodOverlay ? 'var(--accent)' : '';
    btn.style.color = moodOverlay ? 'var(--accent)' : '';
    if (pointsMesh) {
        const cAttr = pointsMesh.geometry.attributes.color;
        fragments.forEach((f, i) => {
            const c = new THREE.Color(fragmentColor(f));
            cAttr.array[i*3] = c.r; cAttr.array[i*3+1] = c.g; cAttr.array[i*3+2] = c.b;
        });
        cAttr.needsUpdate = true;
    }
    toast(moodOverlay ? 'Mood overlay on (red=heavy / gray=neutral / green=light)' : 'Mood overlay off');
}
function showStats() {
    const body = $('stats-body'); body.innerHTML = '';
    const total = fragments.length;
    if (total === 0) { body.innerHTML = '<div class="stat-card"><p style="color:var(--dim);font-style:italic">No fragments yet</p></div>'; $('stats-panel').classList.add('show'); return; }
    const ys = fragments.map(f => f.year).filter(y => typeof y === 'number');
    const ymin = ys.length ? Math.min(...ys) : null;
    const ymax = ys.length ? Math.max(...ys) : null;
    const span = (ymin && ymax) ? (ymax - ymin) : 0;
    const geoCount = fragments.filter(f => fragmentLatLon(f)).length;
    const mediaCount = fragments.reduce((s, f) => s + (f.media || []).length, 0);
    const moodFrags = fragments.filter(f => typeof f.mood === 'number');
    const avgMood = moodFrags.length ? (moodFrags.reduce((s, f) => s + f.mood, 0) / moodFrags.length).toFixed(2) : '—';
    const yearBuckets = {};
    fragments.forEach(f => { if (f.year) yearBuckets[f.year] = (yearBuckets[f.year] || 0) + 1; });
    const busiestYear = Object.entries(yearBuckets).sort((a, b) => b[1] - a[1])[0];
    const inbound = new Map();
    fragments.forEach(f => (f.connections || []).forEach(c => inbound.set(c.to, (inbound.get(c.to) || 0) + 1)));
    let mostConnected = null, mostConnectedCount = 0;
    fragments.forEach(f => {
        const out = (f.connections || []).length;
        const inc = inbound.get(f.id) || 0;
        const tot = out + inc;
        if (tot > mostConnectedCount) { mostConnectedCount = tot; mostConnected = f; }
    });
    const tagMap = tagCounts();
    const topTagsArr = [...tagMap.entries()].sort((a, b) => b[1] - a[1]).slice(0, 8);
    const kindMap = kindCounts();
    const totalKinds = Object.values(kindMap).reduce((s, n) => s + n, 0);
    const overview = document.createElement('div'); overview.className = 'stat-card';
    overview.innerHTML = `<h4>Overview</h4><div class="stat-grid">
        <div><span class="stat-num">${total}</span><span class="stat-label">Fragments</span></div>
        <div><span class="stat-num">${edges.length}</span><span class="stat-label">Connections</span></div>
        <div><span class="stat-num">${span}</span><span class="stat-label">Year span</span></div>
        <div><span class="stat-num">${mediaCount}</span><span class="stat-label">Media items</span></div>
        <div><span class="stat-num">${geoCount}</span><span class="stat-label">Geo-tagged</span></div>
        <div><span class="stat-num">${avgMood}</span><span class="stat-label">Avg mood</span></div>
    </div>`;
    body.appendChild(overview);
    if (busiestYear) {
        const peakCard = document.createElement('div'); peakCard.className = 'stat-card';
        peakCard.innerHTML = `<h4>Peak years</h4>` + Object.entries(yearBuckets).sort((a, b) => b[1] - a[1]).slice(0, 5).map(([y, n]) => {
            const pct = (n / busiestYear[1]) * 100;
            return `<div class="stat-row"><span class="stat-key">${y}</span><span class="stat-val">${n} fragment${n === 1 ? '' : 's'}</span></div><div class="stat-bar"><div class="stat-bar-fill" style="width:${pct}%"></div></div>`;
        }).join('');
        body.appendChild(peakCard);
    }
    const kindCard = document.createElement('div'); kindCard.className = 'stat-card';
    kindCard.innerHTML = `<h4>By kind</h4>` + Object.entries(kindMap).sort((a, b) => b[1] - a[1]).map(([k, n]) => {
        const pct = totalKinds ? (n / totalKinds) * 100 : 0;
        return `<div class="stat-row"><span class="stat-key" style="display:flex;align-items:center;gap:8px"><span style="width:8px;height:8px;border-radius:50%;background:${KIND_COLORS[k]};display:inline-block"></span>${k}</span><span class="stat-val">${n} (${pct.toFixed(0)}%)</span></div>`;
    }).join('');
    body.appendChild(kindCard);
    if (topTagsArr.length > 0) {
        const tagCard = document.createElement('div'); tagCard.className = 'stat-card';
        tagCard.innerHTML = `<h4>Top tags</h4>` + topTagsArr.map(([t, n]) => `<div class="stat-row"><span class="stat-key">#${t}</span><span class="stat-val">${n}</span></div>`).join('');
        body.appendChild(tagCard);
    }
    if (mostConnected) {
        const mcCard = document.createElement('div'); mcCard.className = 'stat-card';
        mcCard.innerHTML = `<h4>Most connected</h4><div class="stat-row"><span class="stat-key">${mostConnected.title || '(untitled)'}</span><span class="stat-val">${mostConnectedCount} link${mostConnectedCount === 1 ? '' : 's'}</span></div>`;
        body.appendChild(mcCard);
    }
    $('stats-panel').classList.add('show');
}
function closeStats() { $('stats-panel').classList.remove('show'); }
function nextVisibleIdx(curIdx, dir) {
    const visIdx = fragments.map((_, i) => i).filter(i => isVisible(i)).sort((a, b) => (fragments[a].year || 9999) - (fragments[b].year || 9999));
    if (visIdx.length === 0) return -1;
    if (curIdx < 0) return dir > 0 ? visIdx[0] : visIdx[visIdx.length - 1];
    const k = visIdx.indexOf(curIdx);
    if (k < 0) return visIdx[0];
    return visIdx[(k + dir + visIdx.length) % visIdx.length];
}
function stepFragment(dir) {
    const idx = nextVisibleIdx(selectedIdx, dir);
    if (idx >= 0) { selectFragment(idx); flyTo(idx); }
}
function buildPrintView() {
    const frame = $('print-frame'); frame.innerHTML = '';
    const sorted = fragments.slice().sort((a, b) => (a.year || 9999) - (b.year || 9999));
    const byYear = new Map();
    sorted.forEach(f => { const y = f.year || 'undated'; if (!byYear.has(y)) byYear.set(y, []); byYear.get(y).push(f); });
    let html = `<h1 style="font-size:28px;margin-bottom:6px">My Memory Map</h1><p style="color:#666;margin-bottom:24px">${fragments.length} fragments · ${edges.length} connections · printed ${new Date().toLocaleDateString()}</p>`;
    for (const [y, frags] of byYear) {
        html += `<h2 style="font-size:18px;margin-top:24px">${y}</h2>`;
        for (const f of frags) {
            const dateStr = f.year ? (f.month ? f.year + '-' + String(f.month).padStart(2,'0') + (f.day ? '-' + String(f.day).padStart(2,'0') : '') : f.year) : '';
            const tagStr = (f.tags || []).map(t => '#' + t).join(' ');
            html += `<div class="pr-frag"><strong>${(f.title || '(untitled)').replace(/[<>&]/g, c => ({'<':'&lt;','>':'&gt;','&':'&amp;'}[c]))}</strong>
                <div class="pr-meta">${dateStr} · ${f.kind}${typeof f.mood === 'number' ? ' · mood ' + (f.mood > 0 ? '+' : '') + f.mood : ''}${(f.media||[]).length ? ' · ' + f.media.length + ' media' : ''}</div>
                ${f.summary ? `<div class="pr-summary">${f.summary.replace(/[<>&]/g, c => ({'<':'&lt;','>':'&gt;','&':'&amp;'}[c])).replace(/\n/g, '<br/>')}</div>` : ''}
                ${tagStr ? `<div class="pr-tags">${tagStr}</div>` : ''}
                ${(f.connections || []).length ? `<div class="pr-tags">→ ${(f.connections || []).map(c => { const t = idToIdx.get(c.to); return t !== undefined ? (fragments[t].title || c.to) + ` <em>(${c.type})</em>` : c.to; }).join(' · ')}</div>` : ''}
            </div>`;
        }
    }
    frame.innerHTML = html;
}
function doPrint() {
    buildPrintView();
    setTimeout(() => { window.print(); }, 100);
}
const HELP_KEYS = [
    { sect: 'Navigate', rows: [
        ['/','Focus search'],
        ['→ / j','Next fragment chronologically'],
        ['← / k','Previous fragment chronologically'],
        ['L','Toggle fragment list'],
        ['Esc','Close panels / lightbox / modal']
    ]},
    { sect: 'Create / Edit', rows: [
        ['N','Open ADD fragment modal'],
        ['Ctrl+K','Quick capture (inline)'],
        ['Shift+drag','Link two nodes (in 3D scene)'],
        ['Shift+click','Multi-select rows in fragment list'],
        ['Alt+click','Find path between two fragments'],
        ['Ctrl+Z','Undo'],
        ['Ctrl+Y / Ctrl+Shift+Z','Redo']
    ]},
    { sect: 'View / Mood', rows: [
        ['T','Cycle theme'],
        ['E','Toggle edges'],
        ['S','Toggle auto-spin'],
        ['Ctrl+/','Show this cheatsheet']
    ]}
];
function showHelp() {
    const body = $('help-body'); body.innerHTML = '';
    HELP_KEYS.forEach(s => {
        const sec = document.createElement('div'); sec.className = 'help-section';
        sec.innerHTML = `<h4>${s.sect}</h4>` + s.rows.map(([k, d]) => `<div class="help-row"><span class="help-desc">${d}</span><span class="help-key">${k}</span></div>`).join('');
        body.appendChild(sec);
    });
    $('help-panel').classList.add('show');
}
function closeHelp() { $('help-panel').classList.remove('show'); }
let mmCtx = null;
function drawMinimap() {
    const c = $('minimap'); if (!c || !c.classList.contains('show')) return;
    if (!mmCtx) mmCtx = c.getContext('2d');
    const w = c.width, h = c.height;
    mmCtx.clearRect(0, 0, w, h);
    if (!pointsMesh || fragments.length === 0) return;
    const arr = pointsMesh.geometry.attributes.position.array;
    let xmin = Infinity, xmax = -Infinity, zmin = Infinity, zmax = -Infinity;
    for (let i = 0; i < fragments.length; i++) {
        if (!isVisible(i)) continue;
        const x = arr[i*3], z = arr[i*3+2];
        if (x < xmin) xmin = x; if (x > xmax) xmax = x;
        if (z < zmin) zmin = z; if (z > zmax) zmax = z;
    }
    if (!Number.isFinite(xmin)) return;
    const pad = 12;
    const sw = w - 2*pad, sh = h - 2*pad;
    const span = Math.max(1, Math.max(xmax - xmin, zmax - zmin));
    const cx = (xmin + xmax) / 2, cz = (zmin + zmax) / 2;
    const scale = Math.min(sw, sh) / span;
    const proj = (x, z) => [pad + sw / 2 + (x - cx) * scale, pad + sh / 2 + (z - cz) * scale];
    mmCtx.fillStyle = 'rgba(255,255,255,0.04)';
    mmCtx.fillRect(0, 0, w, h);
    mmCtx.lineWidth = 0.5;
    mmCtx.strokeStyle = 'rgba(255,255,255,0.1)';
    if (showEdges) {
        for (const e of edges) {
            if (!isVisible(e.s) || !isVisible(e.t)) continue;
            if (!activeEdgeTypes.has(e.type || 'with')) continue;
            const a = proj(arr[e.s*3], arr[e.s*3+2]);
            const b = proj(arr[e.t*3], arr[e.t*3+2]);
            mmCtx.beginPath(); mmCtx.moveTo(a[0], a[1]); mmCtx.lineTo(b[0], b[1]); mmCtx.stroke();
        }
    }
    for (let i = 0; i < fragments.length; i++) {
        if (!isVisible(i)) continue;
        const f = fragments[i];
        const [px, py] = proj(arr[i*3], arr[i*3+2]);
        mmCtx.fillStyle = fragmentColor(f);
        mmCtx.beginPath();
        mmCtx.arc(px, py, i === selectedIdx ? 3.5 : (f.kind === 'era' ? 2.5 : 1.8), 0, 6.283);
        mmCtx.fill();
    }
    const camP = proj(camera.position.x, camera.position.z);
    const tgtP = proj(controls.target.x, controls.target.z);
    mmCtx.strokeStyle = 'rgba(245,200,66,0.7)';
    mmCtx.lineWidth = 1;
    mmCtx.beginPath(); mmCtx.moveTo(camP[0], camP[1]); mmCtx.lineTo(tgtP[0], tgtP[1]); mmCtx.stroke();
    mmCtx.fillStyle = 'rgba(245,200,66,0.9)';
    mmCtx.beginPath(); mmCtx.arc(camP[0], camP[1], 2.5, 0, 6.283); mmCtx.fill();
}
function onMinimapClick(e) {
    if (!pointsMesh || fragments.length === 0) return;
    const c = $('minimap'); const rect = c.getBoundingClientRect();
    const arr = pointsMesh.geometry.attributes.position.array;
    let xmin = Infinity, xmax = -Infinity, zmin = Infinity, zmax = -Infinity;
    for (let i = 0; i < fragments.length; i++) {
        if (!isVisible(i)) continue;
        const x = arr[i*3], z = arr[i*3+2];
        if (x < xmin) xmin = x; if (x > xmax) xmax = x;
        if (z < zmin) zmin = z; if (z > zmax) zmax = z;
    }
    if (!Number.isFinite(xmin)) return;
    const w = c.width, h = c.height, pad = 12;
    const sw = w - 2*pad, sh = h - 2*pad;
    const span = Math.max(1, Math.max(xmax - xmin, zmax - zmin));
    const scale = Math.min(sw, sh) / span;
    const cx = (xmin + xmax) / 2, cz = (zmin + zmax) / 2;
    const px = e.clientX - rect.left, py = e.clientY - rect.top;
    const wx = (px - pad - sw / 2) / scale + cx;
    const wz = (py - pad - sh / 2) / scale + cz;
    let bestIdx = -1, bestD = Infinity;
    for (let i = 0; i < fragments.length; i++) {
        if (!isVisible(i)) continue;
        const dx = arr[i*3] - wx, dz = arr[i*3+2] - wz;
        const d = dx*dx + dz*dz;
        if (d < bestD) { bestD = d; bestIdx = i; }
    }
    if (bestIdx >= 0) { selectFragment(bestIdx); flyTo(bestIdx); }
}
function startSummaryEdit() {
    if (selectedIdx < 0) return;
    const f = fragments[selectedIdx];
    const sumEl = $('detail-summary');
    if (!sumEl) return;
    const ta = document.createElement('textarea');
    ta.className = 'summary-edit';
    ta.value = f.summary || '';
    sumEl.replaceWith(ta);
    ta.focus(); ta.setSelectionRange(ta.value.length, ta.value.length);
    let committed = false;
    const commit = (cancel) => {
        if (committed) return; committed = true;
        const val = cancel ? (f.summary || '') : ta.value.trim();
        if (!cancel && val !== f.summary) {
            f.summary = val;
            saveFragments();
        }
        const fresh = document.createElement('div');
        fresh.id = 'detail-summary'; fresh.className = 'editable-summary';
        fresh.title = 'Click to edit';
        fresh.innerHTML = renderMarkdown(f.summary || '');
        fresh.onclick = startSummaryEdit;
        ta.replaceWith(fresh);
    };
    ta.addEventListener('blur', () => commit(false));
    ta.addEventListener('keydown', e => {
        if (e.key === 'Escape') { e.preventDefault(); commit(true); }
        if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) { e.preventDefault(); commit(false); }
    });
}
function isTouring() { return tourTimer !== null; }
function startTour() {
    const visibleFragments = fragments.map((f, i) => ({ f, i })).filter(({ i }) => isVisible(i));
    if (visibleFragments.length === 0) { toast('No fragments to tour'); return; }
    snd('tour');
    tourQueue = visibleFragments.sort((a, b) => (a.f.year || 9999) - (b.f.year || 9999)).map(x => x.i);
    tourIdx = 0;
    tourPrevSpin = autoSpin;
    if (autoSpin) { autoSpin = false; controls.autoRotate = false; }
    $('btn-tour').textContent = '◼ STOP';
    $('btn-tour').style.borderColor = 'var(--accent)';
    $('btn-tour').style.color = 'var(--accent)';
    toast(`Touring ${tourQueue.length} fragments…`);
    tourStep();
    tourTimer = setInterval(tourStep, TOUR_STEP_MS);
}
function stopTour() {
    if (tourTimer) clearInterval(tourTimer); tourTimer = null;
    tourQueue = []; tourIdx = 0;
    $('btn-tour').textContent = '▶ TOUR';
    $('btn-tour').style.borderColor = '';
    $('btn-tour').style.color = '';
    if (tourPrevSpin) { autoSpin = true; controls.autoRotate = true; }
    stopSpeaking();
}
function speak(text) {
    if (!('speechSynthesis' in window)) return;
    speechSynthesis.cancel();
    if (!text) return;
    const u = new SpeechSynthesisUtterance(text);
    u.rate = 1.0; u.pitch = 1.0; u.volume = 1.0;
    speechSynthesis.speak(u);
}
function stopSpeaking() { if ('speechSynthesis' in window) speechSynthesis.cancel(); }
function toggleNarrate() {
    if (!('speechSynthesis' in window)) { toast('Speech synthesis unavailable in this browser'); return; }
    narrating = !narrating;
    const btn = $('btn-narrate');
    btn.textContent = narrating ? '🔊 NARRATE' : '🔇 NARRATE';
    btn.style.borderColor = narrating ? 'var(--accent)' : '';
    btn.style.color = narrating ? 'var(--accent)' : '';
    if (!narrating) stopSpeaking();
    toast(narrating ? 'Narration on (used during TOUR)' : 'Narration off');
}
function tourStep() {
    if (tourIdx >= tourQueue.length) { stopTour(); stopSpeaking(); toast('Tour complete'); return; }
    const idx = tourQueue[tourIdx];
    selectFragment(idx); flyTo(idx);
    if (narrating) {
        const f = fragments[idx];
        const text = `${f.title || 'untitled'}${f.year ? '. ' + f.year + '.' : '.'} ${f.summary || ''}`.replace(/\s+/g,' ').trim();
        speak(text);
    }
    tourIdx++;
}
function toggleTour() { isTouring() ? stopTour() : startTour(); }
async function toggleRecording() {
    const btn = $('btn-rec');
    if (mediaRecorder && mediaRecorder.state === 'recording') {
        mediaRecorder.stop();
        return;
    }
    if (selectedIdx < 0) { toast('Select a fragment first'); return; }
    if (!navigator.mediaDevices?.getUserMedia) { toast('Microphone API unavailable'); return; }
    let stream;
    try { stream = await navigator.mediaDevices.getUserMedia({ audio: true }); }
    catch (err) { toast('Mic blocked: ' + err.message); return; }
    const mime = pickRecorderMime();
    try { mediaRecorder = new MediaRecorder(stream, mime ? { mimeType: mime } : undefined); }
    catch (err) { toast('Recorder error: ' + err.message); stream.getTracks().forEach(t => t.stop()); return; }
    recChunks = [];
    recStart = Date.now();
    btn.textContent = '◼ STOP';
    btn.style.borderColor = '#ff6868'; btn.style.color = '#ff8888';
    recTimer = setInterval(() => {
        const s = Math.floor((Date.now() - recStart) / 1000);
        btn.textContent = '◼ ' + String(Math.floor(s/60)).padStart(2,'0') + ':' + String(s%60).padStart(2,'0');
    }, 250);
    mediaRecorder.ondataavailable = e => { if (e.data.size > 0) recChunks.push(e.data); };
    mediaRecorder.onstop = async () => {
        clearInterval(recTimer); recTimer = null;
        btn.textContent = 'REC'; btn.style.borderColor = ''; btn.style.color = '';
        stream.getTracks().forEach(t => t.stop());
        if (recChunks.length === 0) { toast('No audio captured'); mediaRecorder = null; return; }
        const blob = new Blob(recChunks, { type: mime || 'audio/webm' });
        const f = fragments[selectedIdx]; if (!f) return;
        const id = newMediaId();
        await mediaPut(id, blob);
        f.media = f.media || [];
        const dur = ((Date.now() - recStart) / 1000).toFixed(1);
        f.media.push({ id, kind: 'audio', name: `voice-note-${new Date().toISOString().slice(0,16).replace(/[:T]/g,'-')}.webm`, mime: blob.type, size: blob.size });
        saveFragments();
        selectFragment(selectedIdx);
        toast(`Saved ${dur}s voice note`);
        mediaRecorder = null;
    };
    mediaRecorder.start();
    toast('Recording… click again to stop');
}
const GP_CID_KEY = 'amni-life-gphotos-cid';
const GP_TOKEN_KEY = 'amni-life-gphotos-token';
const GP_SCOPE = 'https://www.googleapis.com/auth/photoslibrary.readonly';
const GP_GSI_URL = 'https://accounts.google.com/gsi/client';
let gpTokenClient = null, gpToken = null, gpTokenExpiry = 0;
async function readExif(blob) {
    try {
        const head = await blob.slice(0, Math.min(blob.size, 256 * 1024)).arrayBuffer();
        const v = new DataView(head);
        if (v.byteLength < 4 || v.getUint16(0) !== 0xFFD8) return null;
        let off = 2;
        while (off < v.byteLength - 4) {
            const m = v.getUint16(off);
            if ((m & 0xFF00) !== 0xFF00) break;
            const len = v.getUint16(off + 2);
            if (m === 0xFFE1 && v.byteLength >= off + 10) {
                const sig = String.fromCharCode(v.getUint8(off+4), v.getUint8(off+5), v.getUint8(off+6), v.getUint8(off+7));
                if (sig === 'Exif') return parseTiff(v, off + 10);
            }
            if (m === 0xFFDA || len < 2) break;
            off += 2 + len;
        }
    } catch {}
    return null;
}
function parseTiff(v, base) {
    if (v.byteLength < base + 8) return null;
    const bo = v.getUint16(base);
    const le = bo === 0x4949;
    const u16 = o => v.getUint16(o, le);
    const u32 = o => v.getUint32(o, le);
    if (u16(base + 2) !== 0x002A) return null;
    const ifd0 = base + u32(base + 4);
    const tags0 = readIFD(v, base, ifd0, le);
    let exifPtr = tags0[0x8769];
    let gpsPtr = tags0[0x8825];
    let result = {};
    if (exifPtr) {
        const exif = readIFD(v, base, base + exifPtr, le);
        const dt = exif[0x9003] || exif[0x9004] || tags0[0x0132];
        if (dt) {
            const m = dt.match(/^(\d{4}):(\d{2}):(\d{2})/);
            if (m) result.year = parseInt(m[1], 10);
            result.dateStr = dt.trim();
        }
    } else if (tags0[0x0132]) {
        const m = tags0[0x0132].match(/^(\d{4}):(\d{2}):(\d{2})/);
        if (m) result.year = parseInt(m[1], 10);
        result.dateStr = tags0[0x0132].trim();
    }
    if (gpsPtr) {
        const gps = readIFD(v, base, base + gpsPtr, le);
        const latRef = gps[0x0001], lat = gps[0x0002];
        const lonRef = gps[0x0003], lon = gps[0x0004];
        if (lat && Array.isArray(lat) && lon && Array.isArray(lon)) {
            const dms = a => a[0] + a[1]/60 + a[2]/3600;
            result.lat = dms(lat) * (latRef === 'S' ? -1 : 1);
            result.lon = dms(lon) * (lonRef === 'W' ? -1 : 1);
        }
    }
    return result;
}
function readIFD(v, base, ifdOff, le) {
    const u16 = o => v.getUint16(o, le);
    const u32 = o => v.getUint32(o, le);
    if (ifdOff + 2 > v.byteLength) return {};
    const n = u16(ifdOff);
    const out = {};
    for (let i = 0; i < n; i++) {
        const e = ifdOff + 2 + i * 12;
        if (e + 12 > v.byteLength) break;
        const tag = u16(e);
        const type = u16(e + 2);
        const count = u32(e + 4);
        const valOff = e + 8;
        const sizes = { 1:1, 2:1, 3:2, 4:4, 5:8, 7:1, 9:4, 10:8 };
        const sz = (sizes[type] || 1) * count;
        const dataOff = sz <= 4 ? valOff : base + u32(valOff);
        if (type === 2) {
            try {
                let s = '';
                for (let k = 0; k < count - 1; k++) s += String.fromCharCode(v.getUint8(dataOff + k));
                out[tag] = s;
            } catch {}
        } else if (type === 3) {
            out[tag] = u16(dataOff);
        } else if (type === 4) {
            out[tag] = u32(dataOff);
        } else if (type === 5 && count >= 1) {
            const arr = [];
            for (let k = 0; k < Math.min(count, 4); k++) {
                const num = u32(dataOff + k * 8);
                const den = u32(dataOff + k * 8 + 4);
                arr.push(den ? num / den : 0);
            }
            out[tag] = count === 1 ? arr[0] : arr;
        }
    }
    return out;
}
function pickFolder() { $('folder-input').click(); }
async function readTakeoutSidecar(file) {
    try {
        const text = await file.text();
        const j = JSON.parse(text);
        const ts = j.photoTakenTime?.timestamp || j.creationTime?.timestamp;
        const out = {};
        if (ts) {
            const d = new Date(parseInt(ts, 10) * 1000);
            out.year = d.getFullYear();
            out.dateStr = d.toISOString().slice(0, 19).replace('T', ' ');
        }
        const g = j.geoData || j.geoDataExif;
        if (g && (g.latitude || g.longitude)) { out.lat = g.latitude; out.lon = g.longitude; }
        if (j.title) out.takeoutTitle = j.title;
        if (j.description) out.description = j.description;
        return out;
    } catch { return null; }
}
function indexTakeoutSidecars(files) {
    const map = new Map();
    for (const f of files) {
        const path = f.webkitRelativePath || f.name;
        if (!path.toLowerCase().endsWith('.json')) continue;
        const photoPath = path.replace(/\.json$/i, '');
        map.set(photoPath, f);
        const photoPath2 = path.replace(/\.suppl\.json$/i, '').replace(/\.supplemental-metadata\.json$/i, '').replace(/\.json$/i, '');
        if (photoPath2 !== photoPath) map.set(photoPath2, f);
    }
    return map;
}
async function importFolder(files) {
    if (!dbHandle) { toast('IndexedDB unavailable; can\'t store media'); return; }
    const allFiles = [...files];
    const photos = allFiles.filter(f => f.type.startsWith('image/') || f.type.startsWith('video/'));
    if (photos.length === 0) { toast('No images or videos found in that folder'); return; }
    const sidecarMap = indexTakeoutSidecars(allFiles);
    const prog = $('folder-progress');
    let done = 0, withDate = 0, withGps = 0, withSidecar = 0, errs = 0;
    const startSize = fragments.length;
    const baseId = (n) => 'p' + Date.now().toString(36).slice(-4) + '-' + n.toString(36);
    for (const file of photos) {
        try {
            const path = file.webkitRelativePath || file.name;
            const sf = sidecarMap.get(path);
            const sidecar = sf ? await readTakeoutSidecar(sf) : null;
            if (sidecar) withSidecar++;
            const exif = file.type.startsWith('image/') ? await readExif(file) : null;
            const lm = new Date(file.lastModified);
            const year = sidecar?.year || exif?.year || lm.getFullYear();
            const dateStr = sidecar?.dateStr || exif?.dateStr || lm.toISOString().slice(0, 19).replace('T', ' ');
            const lat = sidecar?.lat ?? exif?.lat;
            const lon = sidecar?.lon ?? exif?.lon;
            if (sidecar?.year || exif?.year) withDate++;
            const tags = [file.type.startsWith('video/') ? 'video' : 'photo'];
            if (typeof lat === 'number') { tags.push('geo'); withGps++; }
            if (sidecar) tags.push('takeout');
            const id = baseId(fragments.length);
            const mediaId = newMediaId();
            await mediaPut(mediaId, file);
            const folderName = (file.webkitRelativePath || '').split('/').slice(0, -1).join('/') || (file.type.startsWith('video/') ? 'videos' : 'photos');
            const summary = `${dateStr}${typeof lat === 'number' ? `\nlat ${lat.toFixed(4)}, lon ${lon.toFixed(4)}` : ''}\n${file.name} · ${(file.size/1024).toFixed(0)} KB${sidecar?.description ? '\n' + sidecar.description : ''}`;
            fragments.push({ id, title: (sidecar?.takeoutTitle || file.name).replace(/\.[^.]+$/, '').replace(/[-_]/g, ' '), kind: 'event', year, summary, tags: [...tags, folderName.split('/').pop()].filter(Boolean), connections: [], lat, lon, media: [{ id: mediaId, kind: file.type.startsWith('video/') ? 'video' : 'image', name: file.name, mime: file.type, size: file.size, lat, lon }] });
            done++;
        } catch (err) { errs++; console.warn('import skip', file.name, err); }
        if (done % 8 === 0 || done === photos.length) prog.textContent = `imported ${done}/${photos.length}…`;
        if (done % 25 === 0) await new Promise(r => setTimeout(r, 0));
    }
    prog.textContent = `done — ${done} imported (${withDate} with date, ${withGps} with GPS, ${withSidecar} via Takeout sidecar, ${errs} skipped)`;
    saveFragments(); rebuildIndex(); recomputeYearBounds();
    await computeLayouts();
    buildPoints(); buildEdges(); renderFragsList(); renderTagFilters(); renderEdgeFilters(); updateStats();
    toast(`Imported ${done}${withSidecar ? ` (${withSidecar} from Takeout)` : ''} · ${fragments.length - startSize} new fragments`);
}
async function loadGSI() {
    if (window.google?.accounts?.oauth2) return true;
    return new Promise((res) => {
        const s = document.createElement('script');
        s.src = GP_GSI_URL; s.async = true; s.defer = true;
        s.onload = () => res(true); s.onerror = () => res(false);
        document.head.appendChild(s);
    });
}
function loadGPState() {
    try { const t = JSON.parse(localStorage.getItem(GP_TOKEN_KEY) || 'null'); if (t && t.exp > Date.now()) { gpToken = t.token; gpTokenExpiry = t.exp; } } catch {}
}
function saveGPToken(token, expiresIn) {
    gpToken = token; gpTokenExpiry = Date.now() + (expiresIn - 60) * 1000;
    try { localStorage.setItem(GP_TOKEN_KEY, JSON.stringify({ token, exp: gpTokenExpiry })); } catch {}
}
function gpStatus(msg) { $('gphotos-status').textContent = msg; }
function gpUpdateUI() {
    const cid = localStorage.getItem(GP_CID_KEY) || '';
    $('gphotos-client-id').value = cid;
    const connected = !!gpToken && Date.now() < gpTokenExpiry;
    $('btn-gphotos-import').disabled = !connected;
    $('btn-gphotos-disconnect').disabled = !connected;
    gpStatus(connected ? `connected · token expires in ${Math.floor((gpTokenExpiry-Date.now())/60000)} min` : (cid ? 'client ID saved · click CONNECT' : 'enter client ID + SAVE first'));
}
function gpSaveCid() {
    const v = $('gphotos-client-id').value.trim();
    if (!v) { toast('Paste a Client ID first'); return; }
    localStorage.setItem(GP_CID_KEY, v); gpUpdateUI();
    toast('Client ID saved');
}
async function gpConnect() {
    const cid = localStorage.getItem(GP_CID_KEY);
    if (!cid) { toast('Save a Client ID first'); return; }
    const ok = await loadGSI();
    if (!ok) { toast('Could not load Google Identity Services (offline?)'); return; }
    gpTokenClient = google.accounts.oauth2.initTokenClient({
        client_id: cid, scope: GP_SCOPE,
        callback: (resp) => { if (resp.access_token) { saveGPToken(resp.access_token, resp.expires_in || 3600); gpUpdateUI(); toast('Connected to Google Photos'); } else { toast('Auth failed: ' + (resp.error || 'unknown')); } }
    });
    gpTokenClient.requestAccessToken({ prompt: '' });
}
function gpDisconnect() {
    gpToken = null; gpTokenExpiry = 0;
    try { localStorage.removeItem(GP_TOKEN_KEY); } catch {}
    if (window.google?.accounts?.oauth2 && gpToken) google.accounts.oauth2.revoke(gpToken, () => {});
    gpUpdateUI(); toast('Disconnected');
}
async function gpImport() {
    if (!gpToken) { toast('Connect first'); return; }
    gpStatus('fetching mediaItems…');
    let added = 0, errs = 0;
    try {
        const r = await fetch('https://photoslibrary.googleapis.com/v1/mediaItems?pageSize=50', { headers: { Authorization: 'Bearer ' + gpToken } });
        if (!r.ok) throw new Error('HTTP ' + r.status);
        const j = await r.json();
        const items = j.mediaItems || [];
        gpStatus(`fetched ${items.length} items, downloading…`);
        for (const item of items) {
            try {
                const isVideo = item.mimeType?.startsWith('video/');
                const url = item.baseUrl + (isVideo ? '=dv' : '=w1280-h1280');
                const blob = await (await fetch(url)).blob();
                const id = 'g' + (item.id || Math.random().toString(36).slice(2)).slice(0, 12);
                const mediaId = newMediaId();
                await mediaPut(mediaId, blob);
                const yr = item.mediaMetadata?.creationTime ? new Date(item.mediaMetadata.creationTime).getFullYear() : null;
                const summary = `${item.mediaMetadata?.creationTime || ''}\n${item.filename || ''}\n${item.mediaMetadata?.width||''}×${item.mediaMetadata?.height||''}`.trim();
                fragments.push({ id, title: (item.filename || 'photo').replace(/\.[^.]+$/, ''), kind: 'event', year: yr, summary, tags: ['google-photos','photo'], connections: [], media: [{ id: mediaId, kind: isVideo ? 'video' : 'image', name: item.filename, mime: item.mimeType }] });
                added++;
                gpStatus(`importing ${added}/${items.length}…`);
            } catch (err) { errs++; console.warn('gp item skip', err); }
        }
        saveFragments(); rebuildIndex();
        await computeLayouts();
        buildPoints(); buildEdges(); renderFragsList(); renderTagFilters(); updateStats();
        gpStatus(`imported ${added} (${errs} skipped) · token good for ${Math.floor((gpTokenExpiry-Date.now())/60000)} min`);
        toast(`Imported ${added} from Google Photos`);
    } catch (err) {
        gpStatus('error: ' + err.message);
        if (String(err).includes('401') || String(err).includes('403')) { gpToken = null; localStorage.removeItem(GP_TOKEN_KEY); gpUpdateUI(); }
    }
}
function openConnect() {
    sharing = false; editingId = null; linkingFrom = null;
    showOnly(['connect-fields']);
    $('modal-save').style.display = 'none';
    loadGPState(); gpUpdateUI();
    $('folder-progress').textContent = '';
    const oh = $('origin-hint'); if (oh) oh.textContent = location.origin;
    openModal('CONNECT TO YOUR LIFE');
}
function fragmentLatLon(f) {
    if (typeof f.lat === 'number' && typeof f.lon === 'number') return [f.lat, f.lon];
    for (const m of f.media || []) if (typeof m.lat === 'number' && typeof m.lon === 'number') return [m.lat, m.lon];
    return null;
}
const GLOBE_R = 22;
function latLonToXYZ(lat, lon, r) {
    const phi = (90 - lat) * Math.PI / 180;
    const theta = (lon + 180) * Math.PI / 180;
    return { x: -r * Math.sin(phi) * Math.cos(theta), y: r * Math.cos(phi), z: r * Math.sin(phi) * Math.sin(theta) };
}
function computeMapLayout() {
    const out = new Array(fragments.length);
    const ungeo = fragments.filter(f => !fragmentLatLon(f)).length;
    let stripIdx = 0;
    const ringR = GLOBE_R * 1.55;
    fragments.forEach((f, i) => {
        const ll = fragmentLatLon(f);
        if (ll) {
            const p = latLonToXYZ(ll[0], ll[1], GLOBE_R + 0.4);
            out[i] = { x: p.x, y: p.y, z: p.z };
        } else {
            const a = ungeo > 1 ? (stripIdx / ungeo) * Math.PI * 2 : 0;
            stripIdx++;
            out[i] = { x: ringR * Math.cos(a), y: -GLOBE_R * 1.4, z: ringR * Math.sin(a) };
        }
    });
    return out;
}
let globeMesh = null, globeGroup = null;
function buildGlobe() {
    if (globeGroup) { scene.remove(globeGroup); globeGroup.traverse(o => { o.geometry?.dispose(); o.material?.dispose(); }); globeGroup = null; globeMesh = null; }
    globeGroup = new THREE.Group();
    const sphereGeom = new THREE.SphereGeometry(GLOBE_R, 32, 24);
    const cs = getComputedStyle(document.documentElement);
    const fillCol = new THREE.Color(cs.getPropertyValue('--bg2').trim() || '#10131a');
    const lineCol = new THREE.Color(cs.getPropertyValue('--accent').trim() || '#7cc4ff');
    const fill = new THREE.Mesh(sphereGeom, new THREE.MeshBasicMaterial({ color: fillCol, transparent: true, opacity: 0.45, depthWrite: false }));
    globeGroup.add(fill);
    const wire = new THREE.Mesh(sphereGeom.clone(), new THREE.MeshBasicMaterial({ color: lineCol, wireframe: true, transparent: true, opacity: 0.18, depthWrite: false }));
    globeGroup.add(wire);
    const ringGeo = new THREE.RingGeometry(GLOBE_R * 1.5, GLOBE_R * 1.6, 96);
    ringGeo.rotateX(-Math.PI / 2);
    ringGeo.translate(0, -GLOBE_R * 1.4, 0);
    const ring = new THREE.Mesh(ringGeo, new THREE.MeshBasicMaterial({ color: lineCol, transparent: true, opacity: 0.16, side: THREE.DoubleSide, depthWrite: false }));
    globeGroup.add(ring);
    globeMesh = globeGroup;
    globeGroup.visible = (currentView === 'map');
    scene.add(globeGroup);
}
function setGlobeVisible(v) { if (globeGroup) globeGroup.visible = v; }
function syncGlobeColors() {
    if (!globeGroup) return;
    const cs = getComputedStyle(document.documentElement);
    const fillCol = new THREE.Color(cs.getPropertyValue('--bg2').trim() || '#10131a');
    const lineCol = new THREE.Color(cs.getPropertyValue('--accent').trim() || '#7cc4ff');
    globeGroup.children[0].material.color = fillCol;
    globeGroup.children[1].material.color = lineCol;
    globeGroup.children[2].material.color = lineCol;
}
function computeCalendarLayout() {
    const out = new Array(fragments.length);
    const ys = fragments.map(f => f.year).filter(y => typeof y === 'number');
    const ymin = ys.length ? Math.min(...ys) : 2000;
    const ymax = ys.length ? Math.max(...ys) : 2000;
    const yspan = Math.max(1, ymax - ymin);
    const yScale = Math.max(2.6, Math.min(4.0, 50 / Math.max(yspan, 6)));
    const cellCount = new Map();
    fragments.forEach((f, i) => {
        const y = f.year || ymin;
        const m = (f.month && f.month >= 1 && f.month <= 12) ? f.month : ((Math.abs(f.id?.split('').reduce((a,c)=>a+c.charCodeAt(0),0) || i*31) % 12) + 1);
        const key = y + ':' + m;
        const seen = cellCount.get(key) || 0;
        cellCount.set(key, seen + 1);
        const x = (m - 6.5) * 4.5;
        const z = ((y - ymin) - yspan / 2) * yScale;
        const yOffset = seen * 1.6;
        out[i] = { x: x * SCALE * 0.6, y: yOffset * SCALE * 0.6, z: z * SCALE * 0.6 };
    });
    return out;
}
async function computeLayouts() {
    const g = { nodes: fragments.map(f => ({ id: f.id, kind: f.kind, year: f.year || 2000, mass: 1.0 })), edges: edges.map(e => ({ s: e.s, t: e.t })) };
    const json = compute_all(JSON.stringify(g), 220);
    const all = JSON.parse(json);
    const apply = arr => arr.map(p => ({ x: p.x * SCALE, y: p.y * SCALE, z: p.z * SCALE }));
    positions = { timeline: apply(all.timeline), constellation: apply(all.constellation), spiral: apply(all.spiral), cluster: apply(all.cluster), radial: apply(all.radial), map: computeMapLayout(), calendar: computeCalendarLayout() };
}
function makeSpriteTexture() {
    const c = document.createElement('canvas'); c.width = 128; c.height = 128;
    const ctx = c.getContext('2d');
    const g = ctx.createRadialGradient(64,64,0,64,64,64);
    g.addColorStop(0,'rgba(255,255,255,1)'); g.addColorStop(0.35,'rgba(255,255,255,0.85)'); g.addColorStop(0.7,'rgba(255,255,255,0.18)'); g.addColorStop(1,'rgba(255,255,255,0)');
    ctx.fillStyle = g; ctx.fillRect(0,0,128,128);
    const t = new THREE.CanvasTexture(c); t.needsUpdate = true; return t;
}
function isVisible(idx) {
    const f = fragments[idx]; if (!activeKinds.has(f.kind)) return false;
    const y = f.year;
    if (y && (y < activeYearMin || y > activeYearMax)) return false;
    if (activeTags.size === 0) return true;
    return (f.tags || []).some(t => activeTags.has(t));
}
function recomputeYearBounds() {
    const ys = fragments.map(f => f.year).filter(y => typeof y === 'number');
    if (ys.length === 0) { yearMin = 1900; yearMax = 2100; }
    else { yearMin = Math.min(...ys); yearMax = Math.max(...ys); }
    activeYearMin = Math.min(activeYearMin, yearMin);
    activeYearMax = Math.max(activeYearMax, yearMax);
    if (activeYearMin < yearMin || activeYearMin > yearMax) activeYearMin = yearMin;
    if (activeYearMax > yearMax || activeYearMax < yearMin) activeYearMax = yearMax;
    const lo = $('year-min'), hi = $('year-max');
    if (lo && hi) {
        lo.min = yearMin; lo.max = yearMax; lo.value = activeYearMin;
        hi.min = yearMin; hi.max = yearMax; hi.value = activeYearMax;
        $('year-lo').textContent = activeYearMin;
        $('year-hi').textContent = activeYearMax;
    }
}
let timelineAxis = null;
function buildTimelineAxis() {
    if (timelineAxis) { scene.remove(timelineAxis); timelineAxis.geometry.dispose(); timelineAxis.material.dispose(); timelineAxis = null; }
    const arr = positions.timeline; if (!arr || arr.length === 0) return;
    let xMin = Infinity, xMax = -Infinity;
    for (const p of arr) { if (p.x < xMin) xMin = p.x; if (p.x > xMax) xMax = p.x; }
    if (!Number.isFinite(xMin)) return;
    const pad = (xMax - xMin) * 0.05 + 1;
    const cs = getComputedStyle(document.documentElement);
    const col = new THREE.Color(cs.getPropertyValue('--accent').trim() || '#7cc4ff');
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(new Float32Array([xMin - pad, 0, 0, xMax + pad, 0, 0]), 3));
    timelineAxis = new THREE.Line(g, new THREE.LineBasicMaterial({ color: col, transparent: true, opacity: 0.18, depthWrite: false }));
    timelineAxis.visible = (currentView === 'timeline');
    scene.add(timelineAxis);
}
function setTimelineAxisVisible(v) { if (timelineAxis) timelineAxis.visible = v; }
function fragmentColor(f) {
    if (moodOverlay) {
        const m = (typeof f.mood === 'number') ? Math.max(-2, Math.min(2, f.mood)) : 0;
        return MOOD_COLORS[String(m)] || MOOD_COLORS['0'];
    }
    return KIND_COLORS[f.kind] || '#cccccc';
}
function buildPoints() {
    if (pointsMesh) { scene.remove(pointsMesh); pointsMesh.geometry.dispose(); pointsMesh.material.dispose(); }
    const n = fragments.length;
    const geom = new THREE.BufferGeometry();
    const pos = new Float32Array(n * 3);
    const col = new Float32Array(n * 3);
    const siz = new Float32Array(n);
    const hi = new Float32Array(n);
    const src = positions[currentView] || positions.constellation;
    for (let i = 0; i < n; i++) {
        pos[i*3] = src[i].x; pos[i*3+1] = src[i].y; pos[i*3+2] = src[i].z;
        const c = new THREE.Color(fragmentColor(fragments[i]));
        col[i*3] = c.r; col[i*3+1] = c.g; col[i*3+2] = c.b;
        siz[i] = (KIND_SIZE[fragments[i].kind] || 1.0) * (isVisible(i) ? 1.0 : 0.0);
        hi[i] = 0.0;
    }
    geom.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    geom.setAttribute('color', new THREE.BufferAttribute(col, 3));
    geom.setAttribute('size', new THREE.BufferAttribute(siz, 1));
    geom.setAttribute('aHi', new THREE.BufferAttribute(hi, 1));
    const themeMul = (parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--canvas-mul')) || 1.0) * userDotSize;
    const isLight = document.documentElement.getAttribute('data-theme') === 'light';
    const mat = new THREE.ShaderMaterial({
        uniforms: { uMap: { value: makeSpriteTexture() }, uPixelRatio: { value: window.devicePixelRatio || 1 }, uTime: { value: 0 }, uMul: { value: themeMul } },
        vertexShader: `attribute float size;attribute float aHi;varying vec3 vColor;varying float vHi;uniform float uPixelRatio;uniform float uMul;void main(){vColor=color;vHi=aHi;vec4 mv=modelViewMatrix*vec4(position,1.0);float boost=1.0+aHi*0.9;gl_PointSize=size*900.0*uPixelRatio*boost*uMul/(-mv.z);gl_Position=projectionMatrix*mv;}`,
        fragmentShader: `varying vec3 vColor;varying float vHi;uniform sampler2D uMap;void main(){vec4 t=texture2D(uMap,gl_PointCoord);if(t.a<0.04)discard;vec3 col=vColor*(1.0+vHi*0.6);gl_FragColor=vec4(col,t.a);}`,
        vertexColors: true, transparent: true, depthWrite: false, blending: isLight ? THREE.NormalBlending : THREE.AdditiveBlending
    });
    pointsMesh = new THREE.Points(geom, mat);
    scene.add(pointsMesh);
}
function setHilite(idx, val) {
    if (!pointsMesh) return;
    const a = pointsMesh.geometry.attributes.aHi;
    if (idx >= 0 && idx < a.count) { a.array[idx] = val; a.needsUpdate = true; }
}
function clearHilites() {
    if (!pointsMesh) return;
    const a = pointsMesh.geometry.attributes.aHi;
    a.array.fill(0); a.needsUpdate = true;
}
function buildEdges() {
    if (edgesMesh) { scene.remove(edgesMesh); edgesMesh.geometry.dispose(); edgesMesh.material.dispose(); edgesMesh = null; }
    if (!showEdges || edges.length === 0) return;
    const src = positions[currentView] || positions.constellation;
    const visible = edges.filter(e => isVisible(e.s) && isVisible(e.t) && activeEdgeTypes.has(e.type || 'with'));
    if (visible.length === 0) return;
    const pos = new Float32Array(visible.length * 6);
    const col = new Float32Array(visible.length * 6);
    visible.forEach((e, i) => {
        const a = src[e.s], b = src[e.t];
        pos[i*6]=a.x; pos[i*6+1]=a.y; pos[i*6+2]=a.z;
        pos[i*6+3]=b.x; pos[i*6+4]=b.y; pos[i*6+5]=b.z;
        const ca = new THREE.Color(KIND_COLORS[fragments[e.s].kind] || '#888');
        const cb = new THREE.Color(KIND_COLORS[fragments[e.t].kind] || '#888');
        col[i*6]=ca.r; col[i*6+1]=ca.g; col[i*6+2]=ca.b;
        col[i*6+3]=cb.r; col[i*6+4]=cb.g; col[i*6+5]=cb.b;
    });
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    g.setAttribute('color', new THREE.BufferAttribute(col, 3));
    g.userData.visible = visible;
    const m = new THREE.LineBasicMaterial({ vertexColors: true, transparent: true, opacity: 0.22, depthWrite: false });
    edgesMesh = new THREE.LineSegments(g, m);
    scene.add(edgesMesh);
}
function syncEdgePositions() {
    if (!edgesMesh) return;
    const src = positions[currentView] || positions.constellation;
    const visible = edgesMesh.geometry.userData.visible || edges;
    const pa = edgesMesh.geometry.attributes.position;
    visible.forEach((e, i) => {
        const a = src[e.s], b = src[e.t];
        pa.array[i*6]=a.x; pa.array[i*6+1]=a.y; pa.array[i*6+2]=a.z;
        pa.array[i*6+3]=b.x; pa.array[i*6+4]=b.y; pa.array[i*6+5]=b.z;
    });
    pa.needsUpdate = true;
}
function viewExtent(view) {
    const a = positions[view] || [];
    let max = 0;
    for (const p of a) { const r = Math.max(Math.abs(p.x), Math.abs(p.y), Math.abs(p.z)); if (r > max) max = r; }
    return Math.max(max, 6);
}
function fitCameraToView(view) {
    const ext = viewExtent(view);
    const fovRad = camera.fov * Math.PI / 180;
    const dist = (ext * 1.35) / Math.tan(fovRad / 2) * 0.65 + ext * 0.4;
    camSrc = camera.position.clone();
    camTgtSrc = controls.target.clone();
    const dir = new THREE.Vector3().subVectors(camera.position, controls.target).normalize();
    camDst = new THREE.Vector3(dir.x * dist, dir.y * dist + ext * 0.18, dir.z * dist);
    camTgtDst = new THREE.Vector3(0, 0, 0);
    camT = 0.0;
    controls.maxDistance = Math.max(220, dist * 3);
}
function setView(view, animate = true) {
    if (!positions[view]) return;
    if (view === currentView && animate) return;
    snd('view');
    currentView = view;
    localStorage.setItem(VIEW_KEY, view);
    setGlobeVisible(view === 'map');
    setTimelineAxisVisible(view === 'timeline');
    if (animate && pointsMesh) {
        lerpSrc = pointsMesh.geometry.attributes.position.array.slice();
        lerpDst = new Float32Array(fragments.length * 3);
        const dst = positions[view];
        for (let i = 0; i < fragments.length; i++) { lerpDst[i*3] = dst[i].x; lerpDst[i*3+1] = dst[i].y; lerpDst[i*3+2] = dst[i].z; }
        lerpT = 0.0;
        fitCameraToView(view);
    } else {
        buildPoints(); buildEdges();
    }
    $('view-select').value = view;
}
function flyTo(idx) {
    if (idx < 0 || idx >= fragments.length) return;
    const p = positions[currentView][idx];
    const dist = Math.max(8, controls.target.distanceTo(camera.position) * 0.6);
    const dir = new THREE.Vector3().subVectors(camera.position, controls.target).normalize();
    camSrc = camera.position.clone();
    camDst = new THREE.Vector3(p.x + dir.x * dist, p.y + dir.y * dist + 2, p.z + dir.z * dist);
    camTgtSrc = controls.target.clone();
    camTgtDst = new THREE.Vector3(p.x, p.y, p.z);
    camT = 0.0;
}
async function renderMediaGallery(f) {
    const el = $('detail-media'); el.innerHTML = '';
    const items = f.media || [];
    if (items.length === 0) { el.style.display = 'none'; return; }
    el.style.display = 'grid';
    const lbItems = [];
    for (const m of items) {
        const url = await mediaURL(m.id);
        if (!url) continue;
        const tile = document.createElement('div'); tile.className = 'media-tile';
        if (m.kind === 'image') tile.innerHTML = `<img src="${url}" alt="${m.name||''}" loading="lazy"/>`;
        else if (m.kind === 'video') tile.innerHTML = `<video src="${url}" controls muted preload="metadata"></video>`;
        else if (m.kind === 'audio') tile.innerHTML = `<audio src="${url}" controls></audio>`;
        const x = document.createElement('button'); x.className = 'media-x'; x.textContent = '×';
        x.onclick = async (ev) => { ev.stopPropagation(); await mediaDelete(m.id); f.media = (f.media||[]).filter(z => z.id !== m.id); saveFragments(); selectFragment(selectedIdx); };
        tile.appendChild(x);
        const lbIdx = lbItems.length;
        lbItems.push({ url, kind: m.kind, name: m.name, mime: m.mime, lat: m.lat, lon: m.lon });
        if (m.kind === 'image' || m.kind === 'video') tile.onclick = (ev) => { if (ev.target === x) return; openLightbox(lbItems, lbIdx); };
        el.appendChild(tile);
    }
}
function openLightbox(items, startIdx) {
    lightboxItems = items.filter(i => i.kind === 'image' || i.kind === 'video');
    lightboxIdx = Math.max(0, Math.min(startIdx, lightboxItems.length - 1));
    if (lightboxItems.length === 0) return;
    renderLightbox();
    $('lightbox').classList.add('open');
}
function closeLightbox() { $('lightbox').classList.remove('open'); $('lightbox-stage').innerHTML = ''; }
function lightboxStep(d) {
    if (lightboxItems.length === 0) return;
    lightboxIdx = (lightboxIdx + d + lightboxItems.length) % lightboxItems.length;
    renderLightbox();
}
function renderLightbox() {
    const m = lightboxItems[lightboxIdx]; if (!m) return;
    const stage = $('lightbox-stage');
    stage.innerHTML = m.kind === 'video' ? `<video src="${m.url}" controls autoplay></video>` : `<img src="${m.url}" alt="${m.name||''}"/>`;
    const meta = `${m.name || ''}${m.lat !== undefined ? ` · ${m.lat.toFixed(3)}, ${m.lon.toFixed(3)}` : ''} · ${lightboxIdx + 1}/${lightboxItems.length}`;
    $('lightbox-meta').textContent = meta;
}
const MD_ESCAPE = s => s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
function renderMarkdown(src) {
    if (!src) return '';
    let s = MD_ESCAPE(src);
    s = s.replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noopener" style="color:var(--accent)">$1</a>');
    s = s.replace(/(^|[^*])\*\*([^*\n]+)\*\*/g, '$1<strong>$2</strong>');
    s = s.replace(/(^|[^*_])\*([^*\n]+)\*/g, '$1<em>$2</em>');
    s = s.replace(/(^|[^_])_([^_\n]+)_/g, '$1<em>$2</em>');
    s = s.replace(/`([^`\n]+)`/g, '<code style="background:var(--bg);padding:1px 5px;border-radius:3px;font-size:0.8em">$1</code>');
    s = s.replace(/\n/g, '<br/>');
    return s;
}
function findPath(srcIdx, dstIdx) {
    if (srcIdx < 0 || dstIdx < 0 || srcIdx === dstIdx) return;
    const adj = new Map();
    fragments.forEach((f, i) => {
        const list = adj.get(i) || [];
        (f.connections || []).forEach(c => { const j = idToIdx.get(c.to); if (j !== undefined) list.push(j); });
        adj.set(i, list);
    });
    fragments.forEach((f, i) => {
        (f.connections || []).forEach(c => {
            const j = idToIdx.get(c.to); if (j === undefined) return;
            const back = adj.get(j) || []; if (!back.includes(i)) back.push(i); adj.set(j, back);
        });
    });
    const visited = new Set([srcIdx]);
    const parent = new Map();
    const q = [srcIdx];
    while (q.length) {
        const u = q.shift(); if (u === dstIdx) break;
        for (const v of (adj.get(u) || [])) {
            if (visited.has(v)) continue;
            visited.add(v); parent.set(v, u); q.push(v);
        }
    }
    if (!parent.has(dstIdx) && srcIdx !== dstIdx) { toast(`No path from "${fragments[srcIdx].title}" to "${fragments[dstIdx].title}"`); return; }
    pathHighlight.clear(); pathEdges.clear();
    let cur = dstIdx; pathHighlight.add(cur);
    const seq = [cur];
    while (parent.has(cur)) { const p = parent.get(cur); pathHighlight.add(p); seq.push(p); cur = p; }
    seq.reverse();
    for (let i = 0; i < seq.length - 1; i++) pathEdges.add(seq[i] + ':' + seq[i+1]);
    fragments.forEach((_, i) => setHilite(i, pathHighlight.has(i) ? 1.2 : 0));
    renderFragsList();
    toast(`Path: ${seq.length - 1} hops · ${seq.map(i => fragments[i].title).join(' → ')}`);
}
function clearPath() { pathHighlight.clear(); pathEdges.clear(); clearHilites(); renderFragsList(); }
function backlinks(idx) {
    const id = fragments[idx]?.id; if (!id) return [];
    return fragments.map((f, i) => ({ f, i })).filter(({ f, i }) => i !== idx && (f.connections || []).some(c => c.to === id));
}
function selectFragment(idx) {
    clearHilites();
    if (hoveredIdx >= 0) setHilite(hoveredIdx, 0.6);
    if (idx !== selectedIdx && idx >= 0) snd('select');
    selectedIdx = idx;
    if (idx >= 0) setHilite(idx, 1.4);
    if (idx < 0) { $('detail').classList.remove('open'); return; }
    const f = fragments[idx];
    $('detail-kind').textContent = f.kind.toUpperCase();
    $('detail-kind').style.color = KIND_COLORS[f.kind];
    $('detail-title').textContent = f.title || '(untitled)';
    const ll = fragmentLatLon(f);
    const llStr = ll ? ' · ' + ll[0].toFixed(2) + ',' + ll[1].toFixed(2) : '';
    $('detail-meta').textContent = (f.year ? f.year + ' · ' : '') + f.kind + ' · ' + f.id + ((f.media||[]).length ? ' · ' + f.media.length + ' media' : '') + llStr;
    const sumEl = $('detail-summary');
    sumEl.innerHTML = renderMarkdown(f.summary || '');
    sumEl.classList.add('editable-summary');
    sumEl.title = 'Click to edit';
    sumEl.onclick = startSummaryEdit;
    const tagsEl = $('detail-tags'); tagsEl.innerHTML = '';
    (f.tags || []).forEach(t => { const e = document.createElement('span'); e.className = 'tag'; e.textContent = t; e.onclick = () => toggleTag(t); tagsEl.appendChild(e); });
    renderMediaGallery(f);
    const connEl = $('detail-connections'); connEl.innerHTML = '';
    const conns = (f.connections || []).map(c => ({ ...c, idx: idToIdx.get(c.to) })).filter(c => c.idx !== undefined);
    if (conns.length === 0) connEl.innerHTML = '<div style="color:var(--dim);font-size:0.74rem;font-style:italic">no connections yet</div>';
    conns.forEach(c => {
        const row = document.createElement('div'); row.className = 'conn';
        const tgt = fragments[c.idx];
        row.innerHTML = `<span>${tgt.title || '(untitled)'}</span><span class="conn-type">${c.type || 'with'}</span>`;
        row.onclick = () => { selectFragment(c.idx); flyTo(c.idx); renderFragsList(); };
        connEl.appendChild(row);
    });
    const backs = backlinks(idx);
    const backEl = $('detail-backlinks'), backTitle = $('detail-back-title');
    backEl.innerHTML = '';
    if (backs.length === 0) { backTitle.style.display = 'none'; }
    else {
        backTitle.style.display = '';
        backs.forEach(({ f: bf, i: bi }) => {
            const c = (bf.connections || []).find(x => x.to === f.id);
            const row = document.createElement('div'); row.className = 'conn';
            row.innerHTML = `<span>${bf.title || '(untitled)'}</span><span class="conn-type">← ${c?.type || 'links'}</span>`;
            row.onclick = () => { selectFragment(bi); flyTo(bi); renderFragsList(); };
            backEl.appendChild(row);
        });
    }
    $('detail').classList.add('open');
    renderFragsList();
}
function updateMultiUI() {
    const m = $('fragslist-multi');
    if (multiSelected.size === 0) m.style.display = 'none';
    else { m.style.display = ''; $('multi-count').textContent = multiSelected.size; }
}
function clearMulti() { multiSelected.clear(); updateMultiUI(); renderFragsList(); }
function renderFragsList() {
    const body = $('fragslist-body'); body.innerHTML = '';
    const sorted = fragments.map((f,i)=>({f,i})).sort((a,b)=>(a.f.year||9999)-(b.f.year||9999));
    sorted.forEach(({f,i}) => {
        const row = document.createElement('div');
        let cls = 'frag-row' + (i === selectedIdx ? ' active' : '');
        if (multiSelected.has(i)) cls += ' multi';
        if (pathHighlight.has(i)) cls += ' path';
        row.className = cls;
        row.innerHTML = `<span class="frag-dot" style="background:${KIND_COLORS[f.kind]}"></span><span class="frag-title">${f.title || '(untitled)'}</span><span class="frag-year">${f.year || ''}</span>`;
        row.onclick = (e) => {
            if (e.shiftKey) {
                multiSelected.has(i) ? multiSelected.delete(i) : multiSelected.add(i);
                row.classList.toggle('multi');
                updateMultiUI();
                return;
            }
            if (e.altKey && selectedIdx >= 0 && selectedIdx !== i) { findPath(selectedIdx, i); return; }
            selectFragment(i); flyTo(i);
        };
        body.appendChild(row);
    });
    updateMultiUI();
}
async function multiDelete() {
    if (multiSelected.size === 0) return;
    if (!confirm(`Delete ${multiSelected.size} fragments? Connections to/from them will also be removed.`)) return;
    const toDel = new Set([...multiSelected].map(i => fragments[i].id));
    fragments = fragments.filter(f => !toDel.has(f.id));
    fragments.forEach(f => { f.connections = (f.connections || []).filter(c => !toDel.has(c.to)); });
    saveFragments(); rebuildIndex(); recomputeYearBounds();
    await computeLayouts();
    buildPoints(); buildEdges(); renderFragsList(); renderTagFilters(); renderEdgeFilters();
    multiSelected.clear(); selectFragment(-1);
    updateStats();
    toast(`Deleted ${toDel.size} fragments`);
}
function multiAddTag() {
    if (multiSelected.size === 0) return;
    const tag = prompt(`Tag to add to ${multiSelected.size} fragments:`, '');
    if (!tag) return;
    const t = tag.trim().replace(/^#/, '');
    if (!t) return;
    multiSelected.forEach(i => {
        const f = fragments[i]; f.tags = f.tags || [];
        if (!f.tags.includes(t)) f.tags.push(t);
    });
    saveFragments();
    renderTagFilters(); renderFragsList();
    if (selectedIdx >= 0) selectFragment(selectedIdx);
    toast(`Tagged ${multiSelected.size} fragments with #${t}`);
}
function kindCounts() {
    const m = {};
    Object.keys(KIND_COLORS).forEach(k => m[k] = 0);
    fragments.forEach(f => { if (m[f.kind] !== undefined) m[f.kind]++; });
    return m;
}
function renderFilters() {
    const f = $('filters'); f.innerHTML = '';
    const counts = kindCounts();
    Object.keys(KIND_COLORS).forEach(k => {
        const chip = document.createElement('div');
        chip.className = 'chip' + (activeKinds.has(k) ? '' : ' off');
        chip.innerHTML = `<span class="chip-dot" style="background:${KIND_COLORS[k]}"></span>${k}<span class="chip-count">${counts[k]}</span>`;
        chip.onclick = () => {
            activeKinds.has(k) ? activeKinds.delete(k) : activeKinds.add(k);
            chip.classList.toggle('off');
            applyFilters();
        };
        f.appendChild(chip);
    });
}
function topTags(limit) {
    const m = new Map();
    fragments.forEach(f => (f.tags || []).forEach(t => m.set(t, (m.get(t) || 0) + 1)));
    return [...m.entries()].sort((a,b) => b[1] - a[1]).slice(0, limit).map(x => x[0]);
}
function tagCounts() {
    const m = new Map();
    fragments.forEach(f => (f.tags || []).forEach(t => m.set(t, (m.get(t) || 0) + 1)));
    return m;
}
function edgeCounts() {
    const m = {}; EDGE_TYPES.forEach(t => m[t] = 0);
    edges.forEach(e => { const t = e.type || 'with'; if (m[t] !== undefined) m[t]++; });
    return m;
}
function renderEdgeFilters() {
    const el = $('edgefilters'); el.innerHTML = '';
    const counts = edgeCounts();
    if (edges.length === 0) return;
    EDGE_TYPES.forEach(t => {
        if (counts[t] === 0) return;
        const chip = document.createElement('div');
        chip.className = 'chip edge' + (activeEdgeTypes.has(t) ? ' on' : '');
        chip.innerHTML = `${t}<span class="chip-count">${counts[t]}</span>`;
        chip.onclick = () => {
            activeEdgeTypes.has(t) ? activeEdgeTypes.delete(t) : activeEdgeTypes.add(t);
            chip.classList.toggle('on');
            buildEdges();
        };
        el.appendChild(chip);
    });
}
function renderTagFilters() {
    const el = $('tagfilters'); el.innerHTML = '';
    const tags = topTags(MAX_TAG_CHIPS);
    if (tags.length === 0) return;
    const counts = tagCounts();
    tags.forEach(t => {
        const chip = document.createElement('div');
        chip.className = 'chip tag' + (activeTags.has(t) ? ' on' : '');
        chip.innerHTML = `#${t}<span class="chip-count">${counts.get(t) || 0}</span>`;
        chip.onclick = () => toggleTag(t);
        el.appendChild(chip);
    });
}
function toggleTag(t) {
    activeTags.has(t) ? activeTags.delete(t) : activeTags.add(t);
    renderTagFilters();
    applyFilters();
}
function applyFilters() {
    if (!pointsMesh) return;
    const sa = pointsMesh.geometry.attributes.size;
    fragments.forEach((f, i) => { sa.array[i] = (KIND_SIZE[f.kind] || 1.0) * (isVisible(i) ? 1.0 : 0.0); });
    sa.needsUpdate = true;
    buildEdges();
    updateStats();
}
const _pickV = new THREE.Vector3();
function pickAtPixel(px, py, rect) {
    if (!pointsMesh) return -1;
    const arr = pointsMesh.geometry.attributes.position.array;
    let bestIdx = -1, bestScore = PICK_PIXELS * PICK_PIXELS;
    for (let i = 0; i < fragments.length; i++) {
        if (!isVisible(i)) continue;
        _pickV.set(arr[i*3], arr[i*3+1], arr[i*3+2]);
        _pickV.project(camera);
        if (_pickV.z >= 1 || _pickV.z <= -1) continue;
        const sx = (_pickV.x + 1) * 0.5 * rect.width;
        const sy = (1 - _pickV.y) * 0.5 * rect.height;
        const dx = sx - px, dy = sy - py;
        const d2 = dx*dx + dy*dy;
        if (d2 < bestScore) { bestScore = d2; bestIdx = i; }
    }
    return bestIdx;
}
function onPointer(e) {
    if (linking) { updateLinkLine(e.clientX, e.clientY); }
    const rect = renderer.domElement.getBoundingClientRect();
    const px = e.clientX - rect.left, py = e.clientY - rect.top;
    const idx = pickAtPixel(px, py, rect);
    if (hoveredIdx !== idx) {
        if (hoveredIdx >= 0 && hoveredIdx !== selectedIdx) setHilite(hoveredIdx, 0.0);
        if (idx >= 0 && idx !== selectedIdx) setHilite(idx, 0.6);
        hoveredIdx = idx;
    }
    if (idx >= 0) {
        const f = fragments[idx];
        tooltip.style.display = 'block';
        tooltip.style.left = (e.clientX + 12) + 'px';
        tooltip.style.top = (e.clientY + 12) + 'px';
        tooltip.textContent = `${f.title}${f.year ? ' · ' + f.year : ''}`;
        renderer.domElement.style.cursor = 'pointer';
    } else {
        tooltip.style.display = 'none';
        renderer.domElement.style.cursor = 'grab';
    }
}
function onClick(e) {
    if (e.target !== renderer.domElement) return;
    if (linking) return;
    if (hoveredIdx >= 0) { selectFragment(hoveredIdx); flyTo(hoveredIdx); }
    else { selectFragment(-1); }
}
function startLink(srcIdx, e) {
    if (srcIdx < 0) return;
    linking = { src: srcIdx, x: e.clientX, y: e.clientY };
    $('link-overlay').classList.add('active');
    controls.enabled = false;
    updateLinkLine(e.clientX, e.clientY);
    toast('Drag to another node to link');
}
function updateLinkLine(x, y) {
    if (!linking) return;
    const arr = pointsMesh.geometry.attributes.position.array;
    const v = new THREE.Vector3(arr[linking.src*3], arr[linking.src*3+1], arr[linking.src*3+2]);
    v.project(camera);
    const rect = renderer.domElement.getBoundingClientRect();
    const sx = (v.x + 1) * 0.5 * rect.width + rect.left;
    const sy = (1 - v.y) * 0.5 * rect.height + rect.top;
    const line = $('link-line');
    line.setAttribute('x1', sx); line.setAttribute('y1', sy);
    line.setAttribute('x2', x); line.setAttribute('y2', y);
}
function cancelLink() {
    if (!linking) return;
    linking = null;
    $('link-overlay').classList.remove('active');
    controls.enabled = true;
}
async function commitLink(dstIdx) {
    if (!linking) return;
    const src = linking.src;
    cancelLink();
    if (dstIdx < 0 || dstIdx === src) { toast('Link cancelled'); return; }
    const sf = fragments[src], df = fragments[dstIdx];
    if (!sf || !df) return;
    sf.connections = sf.connections || [];
    if (sf.connections.some(c => c.to === df.id)) { toast(`Already linked → ${df.title}`); return; }
    sf.connections.push({ to: df.id, type: 'with' });
    saveFragments(); rebuildIndex();
    buildEdges(); renderEdgeFilters();
    selectFragment(src);
    toast(`Linked: ${sf.title} → ${df.title}`);
}
function onPointerDown(e) {
    if (!e.shiftKey) return;
    if (e.target !== renderer.domElement) return;
    const rect = renderer.domElement.getBoundingClientRect();
    const idx = pickAtPixel(e.clientX - rect.left, e.clientY - rect.top, rect);
    if (idx < 0) return;
    e.preventDefault();
    startLink(idx, e);
}
function onPointerUp(e) {
    if (!linking) return;
    const rect = renderer.domElement.getBoundingClientRect();
    const idx = pickAtPixel(e.clientX - rect.left, e.clientY - rect.top, rect);
    commitLink(idx);
}
function showOnly(rows) { ['f-title-row','f-kindyear-row','f-summary-row','f-tags-row','f-mood-row','link-fields','share-fields','connect-fields','decrypt-fields'].forEach(id => { const el = $(id); if (el) el.style.display = rows.includes(id) ? '' : 'none'; }); }
function openModal(title) { $('modal-title').textContent = title; $('modal-bg').classList.add('open'); }
function closeModal() { $('modal-bg').classList.remove('open'); editingId = null; linkingFrom = null; sharing = false; showOnly(['f-title-row','f-kindyear-row','f-summary-row','f-tags-row']); $('modal-save').style.display = ''; $('connect-fields').style.display = 'none'; }
function openAdd() {
    editingId = null; sharing = false; linkingFrom = null;
    const now = new Date();
    $('m-title').value = ''; $('m-kind').value = 'event';
    $('m-year').value = String(now.getFullYear());
    $('m-month').value = ''; $('m-day').value = '';
    $('m-summary').value = ''; $('m-tags').value = '';
    $('m-mood').value = '0'; $('m-mood-num').textContent = '0';
    showOnly(['f-title-row','f-kindyear-row','f-summary-row','f-tags-row','f-mood-row']);
    $('modal-save').style.display = '';
    openModal('ADD FRAGMENT');
}
function openEdit() {
    if (selectedIdx < 0) return;
    const f = fragments[selectedIdx];
    editingId = f.id; sharing = false; linkingFrom = null;
    $('m-title').value = f.title || ''; $('m-kind').value = f.kind;
    $('m-year').value = f.year || '';
    $('m-month').value = f.month || '';
    $('m-day').value = f.day || '';
    $('m-summary').value = f.summary || ''; $('m-tags').value = (f.tags || []).join(', ');
    $('m-mood').value = String(typeof f.mood === 'number' ? f.mood : 0);
    $('m-mood-num').textContent = $('m-mood').value;
    showOnly(['f-title-row','f-kindyear-row','f-summary-row','f-tags-row','f-mood-row']);
    $('modal-save').style.display = '';
    openModal('EDIT FRAGMENT');
}
function openLink() {
    if (selectedIdx < 0) return;
    linkingFrom = fragments[selectedIdx].id; sharing = false; editingId = null;
    const sel = $('m-link-target'); sel.innerHTML = '';
    fragments.forEach((f, i) => {
        if (i === selectedIdx) return;
        const o = document.createElement('option'); o.value = f.id; o.textContent = `${f.title} (${f.kind}${f.year ? ', ' + f.year : ''})`;
        sel.appendChild(o);
    });
    showOnly(['link-fields']);
    $('modal-save').style.display = '';
    openModal('LINK FRAGMENTS');
}
function bytesToB64Url(bytes) { return btoa(String.fromCharCode(...bytes)).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,''); }
function b64UrlToBytes(b64) {
    const norm = b64.replace(/-/g,'+').replace(/_/g,'/');
    const padded = norm + '==='.slice((norm.length + 3) % 4);
    const bin = atob(padded);
    const out = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
}
async function deriveKey(passphrase, salt) {
    const km = await crypto.subtle.importKey('raw', new TextEncoder().encode(passphrase), 'PBKDF2', false, ['deriveKey']);
    return crypto.subtle.deriveKey({ name: 'PBKDF2', salt, iterations: 200000, hash: 'SHA-256' }, km, { name: 'AES-GCM', length: 256 }, false, ['encrypt','decrypt']);
}
async function encryptCompressed(jsonStr, passphrase) {
    const compressed = await new Response(new Blob([jsonStr]).stream().pipeThrough(new CompressionStream('deflate-raw'))).arrayBuffer();
    const salt = crypto.getRandomValues(new Uint8Array(16));
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const key = await deriveKey(passphrase, salt);
    const ct = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, compressed);
    const out = new Uint8Array(salt.length + iv.length + ct.byteLength);
    out.set(salt, 0); out.set(iv, salt.length); out.set(new Uint8Array(ct), salt.length + iv.length);
    return { b64: bytesToB64Url(out), bytes: out.byteLength, plain: jsonStr.length, compressed: compressed.byteLength };
}
async function decryptShare(b64, passphrase) {
    const bytes = b64UrlToBytes(b64);
    if (bytes.byteLength < 28) throw new Error('payload too short');
    const salt = bytes.slice(0, 16);
    const iv = bytes.slice(16, 28);
    const ct = bytes.slice(28);
    const key = await deriveKey(passphrase, salt);
    const compressed = await crypto.subtle.decrypt({ name: 'AES-GCM', iv }, key, ct);
    return await new Response(new Blob([compressed]).stream().pipeThrough(new DecompressionStream('deflate-raw'))).text();
}
async function buildShareLink() {
    const compact = { fragments: fragments.map(f => ({ i: f.id, t: f.title, k: f.kind, y: f.year || null, s: f.summary || '', g: f.tags || [], la: typeof f.lat==='number'?f.lat:undefined, lo: typeof f.lon==='number'?f.lon:undefined, c: (f.connections || []).map(x => [x.to, x.type || 'with']) })) };
    const json = JSON.stringify(compact);
    const enc = $('share-encrypt').checked;
    if (enc) {
        const pass = $('share-passphrase').value.trim();
        if (!pass || pass.length < 4) { $('share-link').textContent = '(passphrase too short)'; $('share-stats').textContent = 'Need at least 4 characters'; return null; }
        const r = await encryptCompressed(json, pass);
        const url = location.origin + location.pathname + '#e=' + r.b64;
        $('share-link').textContent = url;
        $('share-stats').textContent = `${fragments.length} fragments · ${edges.length} edges · ${r.plain} → ${r.bytes} bytes (${Math.round(r.bytes/r.plain*100)}%) · AES-GCM 256, PBKDF2 200k, encrypted`;
        return url;
    }
    const stream = new Blob([json]).stream().pipeThrough(new CompressionStream('deflate-raw'));
    const buf = await new Response(stream).arrayBuffer();
    const b64 = bytesToB64Url(new Uint8Array(buf));
    const url = location.origin + location.pathname + '#m=' + b64;
    $('share-link').textContent = url;
    $('share-stats').textContent = `${fragments.length} fragments · ${edges.length} edges · ${json.length} → ${buf.byteLength} bytes (${Math.round(buf.byteLength/json.length*100)}%) · plaintext`;
    return url;
}
async function openShare() {
    sharing = true; editingId = null; linkingFrom = null;
    showOnly(['share-fields']);
    $('share-encrypt').checked = false;
    $('share-passphrase').style.display = 'none'; $('share-passphrase').value = '';
    $('share-link').textContent = 'Compressing…';
    $('share-stats').textContent = '';
    $('modal-save').style.display = 'none';
    openModal('SHARE MAP');
    const url = await buildShareLink();
    if (url) { try { await navigator.clipboard.writeText(url); toast('Share link copied to clipboard'); } catch {} }
}
async function regenShareLink() {
    $('share-link').textContent = 'Working…';
    const url = await buildShareLink();
    if (url) { try { await navigator.clipboard.writeText(url); toast('New link copied'); } catch {} }
}
function applyShareFragments(text) {
    const c = JSON.parse(text);
    fragments = (c.fragments || []).map(f => ({ id: f.i, title: f.t, kind: f.k, year: f.y, summary: f.s, tags: f.g || [], lat: typeof f.la==='number'?f.la:undefined, lon: typeof f.lo==='number'?f.lo:undefined, connections: (f.c || []).map(([to,ty]) => ({ to, type: ty })), media: [] }));
}
async function tryRestoreFromHash() {
    const plain = location.hash.match(/[#&]m=([A-Za-z0-9_-]+)/);
    const enc = location.hash.match(/[#&]e=([A-Za-z0-9_-]+)/);
    if (plain) {
        try {
            const bytes = b64UrlToBytes(plain[1]);
            const stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream('deflate-raw'));
            const text = await new Response(stream).text();
            applyShareFragments(text);
            toast(`Loaded shared map: ${fragments.length} fragments`);
            return true;
        } catch (err) { console.warn('plain hash restore failed', err); return false; }
    }
    if (enc) { window._pendingEncShare = enc[1]; return false; }
    return false;
}
async function promptDecrypt() {
    if (!window._pendingEncShare) return;
    showOnly(['decrypt-fields']);
    $('modal-save').style.display = 'none';
    $('decrypt-msg').textContent = '';
    $('decrypt-passphrase').value = '';
    openModal('UNLOCK SHARED MAP');
    setTimeout(() => $('decrypt-passphrase').focus(), 100);
}
async function tryDecrypt() {
    const pass = $('decrypt-passphrase').value;
    if (!pass) { $('decrypt-msg').textContent = 'enter a passphrase'; return; }
    $('decrypt-msg').textContent = 'unlocking…';
    try {
        const text = await decryptShare(window._pendingEncShare, pass);
        applyShareFragments(text);
        rebuildIndex(); recomputeYearBounds();
        await computeLayouts();
        buildPoints(); buildEdges(); renderFragsList(); renderTagFilters(); renderEdgeFilters();
        updateStats();
        window._pendingEncShare = null;
        closeModal();
        toast(`Unlocked: ${fragments.length} fragments`);
    } catch (err) { $('decrypt-msg').textContent = 'wrong passphrase or corrupt link'; }
}
async function saveModal() {
    if (sharing) { closeModal(); return; }
    if ($('connect-fields').style.display !== 'none') { closeModal(); return; }
    if ($('decrypt-fields').style.display !== 'none') { closeModal(); return; }
    const title = $('m-title').value.trim();
    const kind = $('m-kind').value;
    const yearRaw = $('m-year').value.trim();
    const year = yearRaw ? parseInt(yearRaw, 10) : null;
    const monthRaw = $('m-month').value;
    const month = monthRaw ? parseInt(monthRaw, 10) : null;
    const dayRaw = $('m-day').value.trim();
    const day = dayRaw ? Math.max(1, Math.min(31, parseInt(dayRaw, 10))) : null;
    const summary = $('m-summary').value.trim();
    const tags = $('m-tags').value.split(',').map(s => s.trim()).filter(Boolean);
    const moodRaw = parseInt($('m-mood').value, 10);
    const mood = (Number.isFinite(moodRaw) && moodRaw !== 0) ? Math.max(-2, Math.min(2, moodRaw)) : null;
    if (linkingFrom) {
        const tgt = $('m-link-target').value;
        const ty = $('m-link-type').value;
        const f = fragments.find(x => x.id === linkingFrom);
        if (f && tgt && tgt !== linkingFrom) {
            f.connections = f.connections || [];
            if (!f.connections.some(c => c.to === tgt)) f.connections.push({ to: tgt, type: ty });
        }
    } else if (editingId) {
        if (!title) { alert('Title is required.'); return; }
        const f = fragments.find(x => x.id === editingId);
        if (f) {
            Object.assign(f, { title, kind, year, summary, tags });
            if (month) f.month = month; else delete f.month;
            if (day) f.day = day; else delete f.day;
            if (mood !== null) f.mood = mood; else delete f.mood;
        }
    } else {
        if (!title) { alert('Title is required.'); return; }
        const f = { id: newId(), title, kind, year, summary, tags, connections: [], media: [] };
        if (month) f.month = month;
        if (day) f.day = day;
        if (mood !== null) f.mood = mood;
        fragments.push(f);
    }
    saveFragments();
    rebuildIndex();
    recomputeYearBounds();
    await computeLayouts();
    buildPoints(); buildEdges(); buildTimelineAxis();
    renderFragsList(); renderTagFilters(); renderEdgeFilters();
    if (selectedIdx >= 0 && selectedIdx < fragments.length) selectFragment(selectedIdx);
    closeModal();
    updateStats();
}
function deleteSelected() {
    if (selectedIdx < 0) return;
    const f = fragments[selectedIdx];
    if (!confirm(`Delete "${f.title}"? This removes it and any connections to it. Media stays in IndexedDB until garbage-collected.`)) return;
    const id = f.id;
    (f.media || []).forEach(m => mediaDelete(m.id));
    fragments.splice(selectedIdx, 1);
    fragments.forEach(x => { x.connections = (x.connections || []).filter(c => c.to !== id); });
    saveFragments(); rebuildIndex();
    computeLayouts().then(() => { buildPoints(); buildEdges(); renderFragsList(); renderTagFilters(); selectFragment(-1); updateStats(); });
}
function exportJSON() {
    const blob = new Blob([JSON.stringify({ fragments }, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = `amni-life-${new Date().toISOString().slice(0,10)}.json`; a.click();
    URL.revokeObjectURL(url);
    toast('Exported (media not included; export each via the gallery)');
}
function importJSON() { $('file-input').click(); }
function parseCSV(text) {
    const out = [];
    let i = 0, field = '', row = [], inQuotes = false;
    while (i < text.length) {
        const c = text[i];
        if (inQuotes) {
            if (c === '"' && text[i+1] === '"') { field += '"'; i += 2; continue; }
            if (c === '"') { inQuotes = false; i++; continue; }
            field += c; i++;
        } else {
            if (c === '"') { inQuotes = true; i++; continue; }
            if (c === ',') { row.push(field); field = ''; i++; continue; }
            if (c === '\r') { i++; continue; }
            if (c === '\n') { row.push(field); out.push(row); row = []; field = ''; i++; continue; }
            field += c; i++;
        }
    }
    if (field !== '' || row.length > 0) { row.push(field); out.push(row); }
    return out;
}
function csvToFragments(text) {
    const rows = parseCSV(text).filter(r => r.length > 0 && r.some(c => c.trim() !== ''));
    if (rows.length === 0) return [];
    const header = rows[0].map(s => s.trim().toLowerCase());
    const find = names => { for (const n of names) { const k = header.indexOf(n); if (k >= 0) return k; } return -1; };
    const iTitle = find(['title','name','subject','headline']);
    const iKind = find(['kind','category','type']);
    const iYear = find(['year','date']);
    const iSummary = find(['summary','description','notes','body']);
    const iTags = find(['tags','keywords','labels']);
    const iLat = find(['lat','latitude']);
    const iLon = find(['lon','lng','long','longitude']);
    const VALID_KINDS = new Set(['person','place','event','work','idea','era']);
    const out = [];
    let n = 1;
    while (idToIdx.has('c' + String(n).padStart(3, '0'))) n++;
    rows.slice(1).forEach((r, idx) => {
        const title = (iTitle >= 0 ? r[iTitle] : r[0] || '').trim();
        if (!title) return;
        let kind = (iKind >= 0 ? r[iKind] : 'event').trim().toLowerCase();
        if (!VALID_KINDS.has(kind)) kind = 'event';
        const yearRaw = (iYear >= 0 ? r[iYear] : '').trim();
        const yearMatch = yearRaw.match(/(\d{4})/);
        const year = yearMatch ? parseInt(yearMatch[1], 10) : null;
        const summary = (iSummary >= 0 ? r[iSummary] : '').trim();
        const tagsStr = (iTags >= 0 ? r[iTags] : '').trim();
        const tags = tagsStr ? tagsStr.split(/[,;|]/).map(s => s.trim()).filter(Boolean) : [];
        const lat = iLat >= 0 ? parseFloat(r[iLat]) : NaN;
        const lon = iLon >= 0 ? parseFloat(r[iLon]) : NaN;
        const id = 'c' + String(n + idx).padStart(3, '0');
        const f = { id, title, kind, year, summary, tags, connections: [], media: [] };
        if (Number.isFinite(lat) && Number.isFinite(lon)) { f.lat = lat; f.lon = lon; }
        out.push(f);
    });
    return out;
}
async function onFile(e) {
    const file = e.target.files[0]; if (!file) return;
    const text = await file.text();
    const isCSV = file.name.toLowerCase().endsWith('.csv') || file.type === 'text/csv';
    try {
        if (isCSV) {
            const newFrags = csvToFragments(text);
            if (newFrags.length === 0) throw new Error('no rows parsed; check headers (title, kind, year, summary, tags, lat, lon)');
            fragments = fragments.concat(newFrags);
            saveFragments(); rebuildIndex(); recomputeYearBounds();
            await computeLayouts();
            buildPoints(); buildEdges(); renderFragsList(); renderTagFilters(); renderEdgeFilters();
            updateStats();
            toast(`Imported ${newFrags.length} from CSV`);
        } else {
            const j = JSON.parse(text);
            if (!Array.isArray(j.fragments)) throw new Error('expected { fragments: [...] }');
            fragments = j.fragments;
            saveFragments(); rebuildIndex(); recomputeYearBounds();
            await computeLayouts();
            buildPoints(); buildEdges(); renderFragsList(); renderTagFilters(); renderEdgeFilters(); selectFragment(-1);
            updateStats();
            toast(`Imported ${fragments.length} fragments`);
        }
    } catch (err) { snd('error'); alert('Import failed: ' + err.message); }
    e.target.value = '';
}
async function resetToSample() {
    if (!confirm('Reset to sample data? Your current map will be replaced (media stays in IndexedDB).')) return;
    localStorage.removeItem(STORAGE_KEY);
    location.hash = '';
    fragments = await fetchSample();
    saveFragments(); rebuildIndex(); recomputeYearBounds();
    await computeLayouts();
    buildPoints(); buildEdges(); renderFragsList(); renderTagFilters(); selectFragment(-1);
    updateStats();
}
function searchMatches(q) {
    q = q.trim().toLowerCase();
    if (!q) return [];
    return fragments.map((f, i) => ({ f, i })).filter(({ f }) =>
        (f.title || '').toLowerCase().includes(q) ||
        (f.summary || '').toLowerCase().includes(q) ||
        (f.tags || []).some(t => t.toLowerCase().includes(q)) ||
        (f.kind || '').toLowerCase() === q ||
        String(f.year || '') === q ||
        (f.id || '').toLowerCase() === q
    );
}
function renderSearchResults(q) {
    const el = $('search-results');
    if (!q.trim()) { el.style.display = 'none'; el.innerHTML = ''; return; }
    const hits = searchMatches(q).slice(0, 50);
    el.style.display = 'block'; el.innerHTML = '';
    if (hits.length === 0) { el.innerHTML = '<div class="sr-empty">no fragments match this query</div>'; return; }
    hits.forEach((h, idx) => {
        const f = h.f;
        const row = document.createElement('div');
        row.className = 'sr-row' + (idx === 0 ? ' sel' : '');
        row.innerHTML = `<span class="sr-dot" style="background:${KIND_COLORS[f.kind]}"></span><span class="sr-title">${f.title || '(untitled)'}<div class="sr-summary">${(f.summary || '').slice(0, 110).replace(/\n/g, ' ')}</div></span><span class="sr-meta">${f.year || ''} · ${f.kind}</span>`;
        row.onclick = () => { selectFragment(h.i); flyTo(h.i); $('search-results').style.display = 'none'; };
        el.appendChild(row);
    });
}
function searchHandler() {
    const q = $('search').value.trim();
    if (!q) { $('search-results').style.display = 'none'; return; }
    const hits = searchMatches(q);
    if (hits.length === 0) { toast('No match'); return; }
    selectFragment(hits[0].i); flyTo(hits[0].i);
    $('search-results').style.display = 'none';
}
function syncSceneToTheme() {
    const cs = getComputedStyle(document.documentElement);
    const sceneCol = cs.getPropertyValue('--scene').trim() || '#0b0d12';
    const fogStr = parseFloat(cs.getPropertyValue('--fog')) || 0.012;
    if (scene) {
        scene.background = new THREE.Color(sceneCol);
        scene.fog = new THREE.FogExp2(sceneCol, fogStr);
    }
    syncGlobeColors();
    const themeMul = (parseFloat(cs.getPropertyValue('--canvas-mul')) || 1.0) * userDotSize;
    if (pointsMesh) {
        pointsMesh.material.uniforms.uMul.value = themeMul;
        const isLight = document.documentElement.getAttribute('data-theme') === 'light';
        const want = isLight ? THREE.NormalBlending : THREE.AdditiveBlending;
        if (pointsMesh.material.blending !== want) { pointsMesh.material.blending = want; pointsMesh.material.needsUpdate = true; }
    }
    if (edgesMesh) {
        const isLight = document.documentElement.getAttribute('data-theme') === 'light';
        edgesMesh.material.opacity = isLight ? 0.35 : 0.22;
        edgesMesh.material.needsUpdate = true;
    }
    if (timelineAxis) {
        const accent = new THREE.Color(cs.getPropertyValue('--accent').trim() || '#7cc4ff');
        timelineAxis.material.color = accent;
        timelineAxis.material.needsUpdate = true;
    }
}
function applyTheme(t) {
    document.documentElement.setAttribute('data-theme', t);
    localStorage.setItem(THEME_KEY, t);
    syncSceneToTheme();
}
function cycleTheme() {
    const cur = document.documentElement.getAttribute('data-theme') || 'dark';
    const next = THEMES[(THEMES.indexOf(cur) + 1) % THEMES.length];
    applyTheme(next);
    toast(`Theme: ${next}`);
}
async function attachFiles(files) {
    if (selectedIdx < 0) { toast('Select a fragment first to attach media'); return; }
    const f = fragments[selectedIdx];
    f.media = f.media || [];
    let added = 0;
    for (const file of files) {
        const k = file.type.startsWith('image/') ? 'image' : file.type.startsWith('video/') ? 'video' : file.type.startsWith('audio/') ? 'audio' : null;
        if (!k) continue;
        const id = newMediaId();
        await mediaPut(id, file);
        f.media.push({ id, kind: k, name: file.name, mime: file.type, size: file.size });
        added++;
    }
    if (added === 0) { toast('No supported files (image/video/audio only)'); return; }
    saveFragments();
    selectFragment(selectedIdx);
    toast(`Attached ${added} ${added === 1 ? 'file' : 'files'}`);
}
function setupDropzone() {
    const dz = $('dropzone');
    let depth = 0;
    window.addEventListener('dragenter', e => { if (e.dataTransfer && [...e.dataTransfer.types].includes('Files')) { depth++; dz.classList.add('show'); } });
    window.addEventListener('dragleave', e => { depth = Math.max(0, depth - 1); if (depth === 0) dz.classList.remove('show'); });
    window.addEventListener('dragover', e => { e.preventDefault(); });
    window.addEventListener('drop', e => {
        e.preventDefault(); depth = 0; dz.classList.remove('show');
        const files = [...(e.dataTransfer.files || [])];
        const csv = files.find(f => f.name.toLowerCase().endsWith('.csv'));
        if (csv) {
            csv.text().then(async text => {
                try {
                    const newFrags = csvToFragments(text);
                    if (newFrags.length === 0) throw new Error('no rows parsed');
                    fragments = fragments.concat(newFrags);
                    saveFragments(); rebuildIndex(); recomputeYearBounds();
                    await computeLayouts();
                    buildPoints(); buildEdges(); renderFragsList(); renderTagFilters(); renderEdgeFilters();
                    updateStats();
                    toast(`Imported ${newFrags.length} from CSV`);
                } catch (err) { snd('error'); toast('CSV import failed: ' + err.message); }
            });
            return;
        }
        if (files.length > 0) attachFiles(files);
    });
}
function updateStats() {
    const filtCount = fragments.filter((_, i) => isVisible(i)).length;
    const filterStr = (filtCount === fragments.length) ? '' : ` (${filtCount} shown)`;
    const geoCount = fragments.filter(f => fragmentLatLon(f)).length;
    const geoStr = geoCount > 0 ? ` · ${geoCount} geo` : '';
    $('stats').textContent = `${fragments.length} fragments${filterStr}${geoStr} · ${edges.length} connections · wasm ${version()} · v0.14.0`;
}
function setupUI() {
    $('view-select').onchange = e => setView(e.target.value);
    $('btn-add').onclick = openAdd;
    $('btn-edit').onclick = openEdit;
    $('btn-link').onclick = openLink;
    $('btn-delete').onclick = deleteSelected;
    $('btn-media').onclick = () => { if (selectedIdx < 0) { toast('Select a fragment first'); return; } $('media-input').click(); };
    $('btn-rec').onclick = toggleRecording;
    $('btn-tour').onclick = toggleTour;
    $('btn-reveal').onclick = toggleReveal;
    $('btn-stats').onclick = showStats;
    $('btn-mood').onclick = toggleMood;
    $('btn-print').onclick = doPrint;
    $('btn-help').onclick = showHelp;
    $('help-close').onclick = closeHelp;
    $('help-panel').addEventListener('click', e => { if (e.target.id === 'help-panel') closeHelp(); });
    $('minimap').addEventListener('click', onMinimapClick);
    $('minimap').classList.add('show');
    $('stats-close').onclick = closeStats;
    $('stats-panel').addEventListener('click', e => { if (e.target.id === 'stats-panel') closeStats(); });
    $('m-mood').addEventListener('input', e => { $('m-mood-num').textContent = e.target.value; });
    $('btn-narrate').onclick = toggleNarrate;
    $('otd-close').onclick = dismissOTD;
    $('qc-input').oninput = renderQCPreview;
    $('qc-input').addEventListener('keydown', e => {
        if (e.key === 'Escape') { closeQuickCapture(); return; }
        if (e.key === 'Enter') { commitQuickCapture(); return; }
    });
    $('quick-capture').addEventListener('click', e => { if (e.target.id === 'quick-capture') closeQuickCapture(); });
    $('btn-sound').onclick = toggleSound;
    const ds = $('dot-size');
    ds.value = String(Math.round(userDotSize * 100));
    ds.oninput = e => {
        userDotSize = parseFloat(e.target.value) / 100;
        localStorage.setItem(DOT_SIZE_KEY, String(userDotSize));
        syncSceneToTheme();
    };
    if (soundEnabled) { const b = $('btn-sound'); b.textContent = '🔊 SOUND'; b.style.borderColor = 'var(--accent)'; b.style.color = 'var(--accent)'; }
    $('welcome-close').onclick = () => dismissWelcome($('welcome-skip').checked);
    $('welcome-go-btn').onclick = () => dismissWelcome($('welcome-skip').checked);
    $('welcome-tour-btn').onclick = () => { dismissWelcome($('welcome-skip').checked); setTimeout(() => toggleTour(), 600); };
    $('multi-delete').onclick = multiDelete;
    $('multi-tag').onclick = multiAddTag;
    $('multi-clear').onclick = clearMulti;
    $('share-encrypt').onchange = e => { $('share-passphrase').style.display = e.target.checked ? 'block' : 'none'; if (e.target.checked) setTimeout(() => $('share-passphrase').focus(), 80); };
    $('share-passphrase').oninput = () => { /* user updates pass; click REGENERATE to apply */ };
    $('btn-share-regen').onclick = regenShareLink;
    $('btn-decrypt').onclick = tryDecrypt;
    $('decrypt-passphrase').addEventListener('keydown', e => { if (e.key === 'Enter') tryDecrypt(); });
    $('btn-wall').onclick = openWall;
    $('wall-close').onclick = closeWall;
    $('btn-export').onclick = exportJSON;
    $('btn-import').onclick = importJSON;
    $('btn-import').title = 'Import JSON or CSV (drop a CSV anywhere too)';
    $('btn-share').onclick = openShare;
    $('btn-folder').onclick = pickFolder;
    $('btn-folder-modal').onclick = pickFolder;
    $('btn-connect').onclick = openConnect;
    $('btn-gphotos-save').onclick = gpSaveCid;
    $('btn-gphotos-connect').onclick = gpConnect;
    $('btn-gphotos-import').onclick = gpImport;
    $('btn-gphotos-disconnect').onclick = gpDisconnect;
    $('folder-input').onchange = e => { const fs = [...e.target.files]; e.target.value = ''; if (fs.length) importFolder(fs); };
    $('lightbox-prev').onclick = () => lightboxStep(-1);
    $('lightbox-next').onclick = () => lightboxStep(1);
    $('lightbox-close').onclick = closeLightbox;
    $('lightbox').addEventListener('click', e => { if (e.target.id === 'lightbox') closeLightbox(); });
    $('year-min').oninput = e => { let v = parseInt(e.target.value, 10); if (v > activeYearMax) v = activeYearMax; activeYearMin = v; e.target.value = v; $('year-lo').textContent = v; applyFilters(); };
    $('year-max').oninput = e => { let v = parseInt(e.target.value, 10); if (v < activeYearMin) v = activeYearMin; activeYearMax = v; e.target.value = v; $('year-hi').textContent = v; applyFilters(); };
    window.addEventListener('beforeinstallprompt', e => { e.preventDefault(); installPromptEvent = e; $('btn-install').classList.add('show'); });
    $('btn-install').onclick = async () => {
        if (!installPromptEvent) { toast('Install via your browser menu (no install prompt available)'); return; }
        installPromptEvent.prompt();
        const r = await installPromptEvent.userChoice;
        if (r.outcome === 'accepted') toast('Installed!');
        installPromptEvent = null; $('btn-install').classList.remove('show');
    };
    window.addEventListener('appinstalled', () => { toast('Amni-Life installed'); $('btn-install').classList.remove('show'); });
    $('btn-reset').onclick = resetToSample;
    $('btn-theme').onclick = cycleTheme;
    $('btn-list').onclick = () => $('fragslist').classList.toggle('open');
    $('btn-edges').onclick = () => { showEdges = !showEdges; buildEdges(); };
    $('btn-spin').onclick = () => { autoSpin = !autoSpin; controls.autoRotate = autoSpin; };
    $('detail-close').onclick = () => selectFragment(-1);
    $('modal-close').onclick = closeModal;
    $('modal-cancel').onclick = closeModal;
    $('modal-save').onclick = saveModal;
    $('file-input').onchange = onFile;
    $('media-input').onchange = e => { const fs = [...e.target.files]; e.target.value = ''; if (fs.length) attachFiles(fs); };
    $('search').addEventListener('keydown', e => { if (e.key === 'Enter') searchHandler(); else if (e.key === 'Escape') { $('search-results').style.display = 'none'; e.target.blur(); } });
    $('search').addEventListener('input', e => renderSearchResults(e.target.value));
    $('search').addEventListener('blur', () => setTimeout(() => $('search-results').style.display = 'none', 180));
    $('search').addEventListener('focus', e => { if (e.target.value.trim()) renderSearchResults(e.target.value); });
    $('modal-bg').addEventListener('click', e => { if (e.target.id === 'modal-bg') closeModal(); });
    document.addEventListener('keydown', e => {
        if (e.key === 'Escape') { if ($('lightbox').classList.contains('open')) { closeLightbox(); return; } if ($('wall').classList.contains('open')) { closeWall(); return; } if (linking) { cancelLink(); return; } if (isTouring()) { stopTour(); return; } closeModal(); selectFragment(-1); }
        if ($('lightbox').classList.contains('open')) {
            if (e.key === 'ArrowLeft') { lightboxStep(-1); return; }
            if (e.key === 'ArrowRight') { lightboxStep(1); return; }
        }
        if ((e.metaKey || e.ctrlKey) && e.key === 'z' && !e.shiftKey) { e.preventDefault(); undo(); return; }
        if ((e.metaKey || e.ctrlKey) && (e.key === 'Z' || (e.shiftKey && e.key === 'z') || e.key === 'y')) { e.preventDefault(); redo(); return; }
        if ((e.metaKey || e.ctrlKey) && e.key === 'k') { e.preventDefault(); openQuickCapture(); return; }
        if ((e.metaKey || e.ctrlKey) && e.key === '/') { e.preventDefault(); showHelp(); return; }
        if ((e.metaKey || e.ctrlKey) && e.key === 'p') { e.preventDefault(); doPrint(); return; }
        if (e.key === 'ArrowRight' || e.key === 'j') { e.preventDefault(); stepFragment(1); return; }
        if (e.key === 'ArrowLeft' || e.key === 'k') { e.preventDefault(); stepFragment(-1); return; }
        if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
        if (e.key === '/') { e.preventDefault(); $('search').focus(); }
        if (e.key === 'l') $('btn-list').click();
        if (e.key === 't') cycleTheme();
        if (e.key === 'n') openAdd();
        if (e.key === 'e') $('btn-edges').click();
        if (e.key === 's') $('btn-spin').click();
    });
    renderer.domElement.addEventListener('pointermove', onPointer);
    renderer.domElement.addEventListener('pointerdown', onPointerDown);
    window.addEventListener('pointerup', onPointerUp);
    renderer.domElement.addEventListener('click', onClick);
    window.addEventListener('resize', onResize);
    setupDropzone();
}
function onResize() {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
}
function animate() {
    requestAnimationFrame(animate);
    if (lerpDst && lerpT < 1.0) {
        lerpT = Math.min(1.0, lerpT + 1.0 / LERP_FRAMES);
        const t = ease(lerpT);
        const arr = pointsMesh.geometry.attributes.position.array;
        for (let i = 0; i < arr.length; i++) arr[i] = lerpSrc[i] + (lerpDst[i] - lerpSrc[i]) * t;
        pointsMesh.geometry.attributes.position.needsUpdate = true;
        syncEdgePositions();
        if (lerpT >= 1.0) { lerpSrc = null; lerpDst = null; }
    }
    if (camDst && camT < 1.0) {
        camT = Math.min(1.0, camT + 1.0 / CAM_FRAMES);
        const t = ease(camT);
        camera.position.lerpVectors(camSrc, camDst, t);
        controls.target.lerpVectors(camTgtSrc, camTgtDst, t);
        if (camT >= 1.0) { camSrc = null; camDst = null; }
    }
    if (pointsMesh) pointsMesh.material.uniforms.uTime.value = performance.now() * 0.001;
    controls.update();
    renderer.render(scene, camera);
    updateSelectedLabel();
    updateHoverLabels();
    if (performance.now() % 4 < 1) drawMinimap();
}
const _labelV = new THREE.Vector3();
function updateSelectedLabel() {
    const lbl = $('sel-label'); if (!lbl) return;
    if (selectedIdx < 0 || !pointsMesh) { lbl.classList.remove('show'); return; }
    const arr = pointsMesh.geometry.attributes.position.array;
    _labelV.set(arr[selectedIdx*3], arr[selectedIdx*3+1], arr[selectedIdx*3+2]);
    _labelV.project(camera);
    if (_labelV.z >= 1 || _labelV.z <= -1) { lbl.classList.remove('show'); return; }
    const rect = renderer.domElement.getBoundingClientRect();
    const sx = (_labelV.x + 1) * 0.5 * rect.width + rect.left;
    const sy = (1 - _labelV.y) * 0.5 * rect.height + rect.top;
    const f = fragments[selectedIdx]; if (!f) return;
    if (lbl.dataset.idx !== String(selectedIdx)) { lbl.textContent = `${f.title || '(untitled)'}${f.year ? ' · ' + f.year : ''}`; lbl.dataset.idx = String(selectedIdx); }
    lbl.style.left = sx + 'px';
    lbl.style.top = (sy - 18) + 'px';
    lbl.classList.add('show');
}
async function load() {
    scene = new THREE.Scene();
    camera = new THREE.PerspectiveCamera(55, window.innerWidth / window.innerHeight, 0.1, 1000);
    camera.position.set(0, 18, 52);
    renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setSize(window.innerWidth, window.innerHeight);
    document.getElementById('root').insertBefore(renderer.domElement, document.getElementById('topbar'));
    controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true; controls.dampingFactor = 0.08;
    controls.autoRotate = autoSpin; controls.autoRotateSpeed = 0.35;
    controls.minDistance = 4; controls.maxDistance = 220;
    raycaster = new THREE.Raycaster();
    mouse = new THREE.Vector2();
    scene.add(new THREE.AmbientLight(0xffffff, 0.6));
    buildGlobe();
    await init();
    try { dbHandle = await openMediaDB(); } catch (err) { console.warn('IDB unavailable', err); }
    const restored = await tryRestoreFromHash();
    if (!restored) {
        let stored = loadFragments();
        fragments = stored && stored.length > 0 ? stored : await fetchSample();
        if (!stored) saveFragments();
    }
    if (window._pendingEncShare) setTimeout(() => promptDecrypt(), 600);
    rebuildIndex();
    activeYearMin = 1900; activeYearMax = 2100;
    recomputeYearBounds();
    activeYearMin = yearMin; activeYearMax = yearMax;
    await computeLayouts();
    const savedView = localStorage.getItem(VIEW_KEY);
    if (savedView && positions[savedView]) currentView = savedView;
    $('view-select').value = currentView;
    buildPoints(); buildEdges(); buildTimelineAxis(); renderFilters(); renderTagFilters(); renderEdgeFilters(); renderFragsList(); recomputeYearBounds();
    setGlobeVisible(currentView === 'map');
    setTimelineAxisVisible(currentView === 'timeline');
    const initExt = viewExtent(currentView);
    const initDist = Math.max(58, initExt * 1.35);
    camera.position.set(0, initExt * 0.32, initDist);
    controls.target.set(0, 0, 0);
    setupUI();
    applyTheme(localStorage.getItem(THEME_KEY) || 'dark');
    new MutationObserver(syncSceneToTheme).observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });
    updateStats();
    setTimeout(() => { $('loader').classList.add('fade'); setTimeout(() => $('loader').remove(), 600); }, 200);
    animate();
    setTimeout(() => showWelcome(), 1100);
    setTimeout(() => renderOTD(), 1400);
}
load().catch(err => { console.error(err); $('loader-text').textContent = 'load failed: ' + err.message; });
