# Amni-Life Changelog

## v0.26.0 — 2026-05-01
### Time Scrubber
- New **⏱ SCRUB** button in the topbar opens a bottom bar with a year range slider. Drag left/right to travel through time — nodes with a year after the current scrub position fade to 14% opacity (still visible as "not yet born"). **▶ play** animates forward at ×1 / ×2 / ×5 speed. Click SCRUB again or the × button to close and restore full opacity. Implemented as a new `aAlpha` per-vertex Float32 attribute passed through both GLSL shaders (`vAlpha` varying) — zero rebuild cost, just an attribute write on each tick.

### Fragment Templates
- New "Quick start" template row at the top of the ADD modal. Seven chips: ⚡ Moment, 👤 Person, 📍 Place, 🏆 Milestone, 🎨 Work, 💡 Idea, 📅 Era. Clicking one pre-fills **Kind** and seeds default tags (without overwriting user-typed tags). Chips highlight on selection. Hidden in EDIT mode.

### Focus Mode
- Press **F** (or the **○ FOCUS** topbar button) to hide the topbar, left rail, legend, stats, minimap, On-This-Day, prompt bar, and scrubber — only the 3D canvas and any open detail panel remain. A translucent pill reads *"Press F or Esc to exit focus mode"*. Press **F** or **Esc** to restore. Great for screenshots, presentations, or just meditating on your map.

### CSV Export
- New **CSV · spreadsheet** option in the EXPORT dropdown. Exports all fragment metadata as a UTF-8 CSV with a BOM (Excel-compatible): id, title, kind, year, month, day, tags (`;`-separated), summary, mood, lat, lon, connection count, media count.

### Verification
- `node test/v26_smoke.mjs`: scrubber toggle, 7 template chips, focus mode toggle via F key, CSV button in export menu. **0 errors, PASS**.

## v0.25.0 — 2026-05-01
### Voice search
- 🎤 Mic button next to the search input. Click → Web Speech API listens, live-populates the search field with interim transcripts, and runs a search on stop. Pulses red while recording. Cancel by clicking again. Falls back gracefully when API isn't supported.

### Opt-in geocoding (OpenStreetMap)
- New ADD/EDIT row: **Coordinates**. Paste `"lat, lon"` directly OR enable OpenStreetMap geocoding in CONNECT modal and type a place name → click **FIND** → fetches `nominatim.openstreetmap.org` for coords. Privacy-disclosed: only the place name leaves your device. Off by default.

### Photo rotate in lightbox
- New **↻** button (and **R** key) in the lightbox rotates current image/video 90° CW. Rotation persists on the media item — the gallery thumbnail and lightbox both honor it. 90 / 180 / 270 / 0 cycle.

### Verification
- `node test/v25_smoke.mjs`: mic button exists + SpeechRecognition API present. ADD modal "Paris trip" with `48.8566, 2.3522` saves with `lat=48.8566, lon=2.3522`. Lightbox rotate goes `rotate(90deg) → rotate(180deg)` on consecutive clicks. **0 errors**.
- `node test/views_smoke.mjs`: 7/7 views render under WebGL2.

## v0.24.0 — 2026-05-01
### QR codes for deep links
- Clicking **↗ LINK** in the detail panel now opens a modal with a **QR code** for the deep link, plus the URL itself (selectable). Scan the QR with your phone to fly to that fragment on a different device. Library `qrcode-generator@1.4.4` lazy-loads on first use, then SW-cached for offline.

### Smart connection suggestions
- New "Possibly related" section in the detail panel scoring fragments by:
  - tag overlap (×4 weight)
  - title + summary word overlap (×1.5 weight, stopwords filtered)
  - year proximity (same year +2, ±1 +1.2, ±3 +0.6)
- Top 4 candidates with score ≥ 3 surface as one-click `+ link` rows. Click → instant `with` connection added.

### Memory-of-the-day fallback
- When On This Day has no calendar matches, the card transforms into "FROM YOUR MAP" — a random fragment seeded by today's date so it stays consistent throughout the day.

### Verification
- `node test/v24_smoke.mjs`: QR modal opens with `http://127.0.0.1:8765/#f=f04` URL + 245px canvas; clipboard receives same URL. Suggester shows 1 result for "First memory of the ocean" (filtered out already-connected f02/f03), `+link` toggles to "linked". When sample fragments have month/day stripped, OTD card shows `FROM YOUR MAP · 1 row`. **0 errors**.
- `node test/views_smoke.mjs`: 7/7 views render under WebGL2.

## v0.23.0 — 2026-05-01
### Continent outlines on globe
- The Map view now has rough continent outlines drawn on the sphere surface in accent-gold. Hand-coded as 6 simplified polylines (North America, Europe, Africa, Eurasia, Australia, South America). ~75 lat/lon vertices total. Shifts color with theme via `syncGlobeColors`.

### Drag-to-reorder pinned fragments
- Pinned fragment rows in the list are now `draggable`. Drag one onto another → reorders. Order persists via `pinOrder` field on the fragment. Visual: gold tint on drag-over.

### Lazy media wall
- Photo Wall now uses `IntersectionObserver` to only load media when scrolled into view. Pre-allocates placeholder cards; populates `<img>/<video>/<audio>` source on first intersection (300px lookahead). Big maps with 100+ media items are now snappy.

### Verification
- `node test/v23_smoke.mjs`: globe screenshot saved with continent outlines visible. Two fragments pinned, then DOM drag-drop simulation reorders them: dragged f04 onto f01, post-state has f01 first → matches expected. Lazy wall: 1 card observed + media loaded after intersection. **0 errors**.
- `node test/views_smoke.mjs`: 7/7 views render under WebGL2.

## v0.22.0 — 2026-05-01
### Memory recall quiz
- New **? QUIZ** topbar button → modal showing a random fragment's metadata (year · kind · tags · summary) with the title hidden. Type your guess, hit Enter — fuzzy-matches against the actual title (60% word overlap = correct). Live score `correct / attempted`. **SKIP** / **REVEAL** / **NEXT →** controls.
- Helps surface fragments you've forgotten — and exposes which ones lack enough summary detail to be recallable.

### Clickable mood filter chips
- New 5-chip row in the "Mood over time" stats card (heavy / low / neutral / light / bright). Click to filter the entire map by that mood value. Multi-select supported. Clicking again removes. Stats line updates with `(N shown)`.

### Append-mode summary editing
- New **append mode** checkbox under the summary in the detail panel. When on, clicking the summary opens a blank textarea instead of pre-filling with the existing text. Saving appends a new dated entry (`— YYYY-MM-DD —`) to the existing summary instead of replacing it. Auto-disables after one save. Lets each fragment grow into a multi-entry thread.

### Verification
- `node test/v22_smoke.mjs`: quiz opens, wrong guess → "✗ It was 'The cottage by the bay'", score `0/1`, next question advances, reveal shows answer, closes cleanly. 5 mood chips render in stats; clicking mood=+2 → "25 fragments (2 shown)". Append-mode placeholder reads "New entry — appended with today's date…", saving appends `— 2026-05-01 — A new note added today` to existing summary. **0 errors**.
- `node test/views_smoke.mjs`: 7/7 views render under WebGL2.

## v0.21.0 — 2026-05-01
### Deep-link to fragment
- New URL hash `#f=<fragment-id>` auto-selects + flies to that fragment on load. Works alongside `#m=…` (plaintext share) and `#e=…` (encrypted share).
- New **↗ LINK** button in detail-panel actions copies the deep link to clipboard. Shareable as a permanent reference to that specific fragment.

### Daily writing prompts
- Pill-shaped floating prompt at bottom-center: 20 evocative writing prompts cycle daily ("A moment this week that surprised you.", "The view from your favorite window.", etc).
- **+** button → opens quick-capture pre-filled with the prompt text. **↻** skips to the next prompt. **×** dismisses for the rest of the day.

### Mobile burger menu
- Below 880 px viewport width, the topbar collapses behind a **☰** button at the top-right. Click to expand into a vertical stack with all controls.
- Year-range slider, dot-size slider, and tour-speed slider now span full-width on mobile.

### Verification
- `node test/v21_smoke.mjs`: prompt bar visible with rotating text, skip changes prompt, capture opens quick-capture with prompt as title, × dismisses. Copy deep link returns `#f=f04` for first fragment; navigating to `#f=f15` flies to "Becoming an engineer". Burger appears at 700 px width, topbar collapses + expands on click. **0 errors**.
- `node test/views_smoke.mjs`: 7/7 views render under WebGL2.

## v0.20.0 — 2026-05-01
### iCal (.ics) import
- IMPORT now accepts `.ics` files. Parses all `VEVENT` blocks with `DTSTART` (date or date-time), `SUMMARY` → title, `DESCRIPTION` → summary, `CATEGORIES` → tags, `GEO` → lat/lon, `RRULE:FREQ=YEARLY` → `recurring: 'yearly'`. Round-trip with v0.19's iCal export confirmed: export → re-import preserves every field. Drop a Google Calendar / Apple Calendar export and your map populates.

### Persistent labels
- New **🏷 LABELS** topbar button. When on, every visible fragment gets its title rendered as an overlay pill anchored to its 3D position. Updates 60×/sec via projection. Fades the selected one's persistent label so the dedicated `#sel-label` stays primary. Persists to `amni-life-persistent-labels`.

### About + re-show welcome
- Cheatsheet (Ctrl+/) gains an **About** section with a description, a **Re-show welcome** button (clears `amni-life-welcome-v1` and reopens the modal), and a link to `amni-scient.com/amni-life`.

### Verification
- `node test/v20_smoke.mjs`: synthetic .ics with 2 VEVENTs imports cleanly — wedding anniversary at lat 48.8566 with `recurring='yearly'`, hike with summary `"Sunrise at the summit, fog below."` (escaping handled). Persistent-labels toggle persists `1`/`0` and renders 27 visible labels when on. About section + re-show-welcome button work, welcome modal reopens. **0 errors**.
- `node test/views_smoke.mjs`: 7/7 views render under WebGL2.

## v0.19.0 — 2026-05-01
### Export menu (JSON + iCal)
- The **EXPORT** topbar button is now a dropdown with two options:
  - **JSON · full backup** — same as before
  - **iCal · .ics calendar** — exports every dated fragment as a `VEVENT` with proper `DTSTART/DTEND/SUMMARY/DESCRIPTION/CATEGORIES/GEO`. Yearly-recurring fragments emit `RRULE:FREQ=YEARLY`. Drop the file into Apple Calendar, Google Calendar, Outlook, etc.

### Recurring yearly fragments
- New checkbox in ADD/EDIT: "Recurring yearly (birthdays / anniversaries)". Marked fragments display a **↻** badge in the fragment list and emit yearly RRULE in iCal exports. Combine with month + day to make On This Day fire on every anniversary.

### Raw JSON viewer
- New **{ }** button in detail-panel actions → modal showing the selected fragment's raw JSON, formatted. **COPY** button copies to clipboard. Useful for debugging, manual edits via export-edit-import, or sharing structure.

### Backup reminder banner
- If 14+ days have passed since last JSON export AND map has 5+ fragments AND user hasn't dismissed in 3 days → small floating banner top-center: "Map edited 14+ days since last backup — EXPORT JSON / later". `exportJSON()` updates the timestamp and hides the banner.

### Verification
- `node test/v19_smoke.mjs`: export menu opens with 2 options ("JSON · full backup", "iCal · .ics calendar"). Recurring checkbox saves `recurring: 'yearly'`, ↻ icon appears in list. Raw JSON modal opens with valid JSON containing `"id"`. Backup banner shows after seeding 20-day-old export timestamp. **0 errors**.
- `node test/views_smoke.mjs`: 7/7 views render under WebGL2.

## v0.18.0 — 2026-05-01
### Streak + 30-day activity
- New fragments are stamped with `addedAt` (Unix ms) on creation. Stats overview now shows two extra tiles: **Day streak** (consecutive days with activity ending today) and **Added · 30d** (count in last 30 days).

### Activity heatmap
- New stats card "Activity · last 52 weeks" — GitHub-style 53×7 cell grid. Cells colored by per-day fragment-add count, intensity scaled to your max-day. Theme accent.

### Custom theme builder
- **Right-click the THEME button** → modal with color pickers for bg / surface / fg / dim / accent / accent2. Live preview swatches at the bottom. Save → adds the new theme to the rotation; THEME button cycles through it. Right-clicking while a custom theme is active opens it for editing (with a DELETE button).
- Custom themes persist to `amni-life-custom-themes` and are CSS-injected on each load.

### Verification
- `node test/v18_smoke.mjs`: streak shows `3` after seeding 3 consecutive days + a 7-day-old + a 15-day-old. Heatmap canvas renders ink. Right-click on THEME opens builder; saving "oceanic" with bg `#0a1828` → builder closes, theme cycles to oceanic, `--bg` becomes `#0a1828`, persisted in LocalStorage. **0 errors**.
- `node test/views_smoke.mjs`: 7/7 views still render under WebGL2.

## v0.17.0 — 2026-05-01
### Voice transcription
- Web Speech API (`SpeechRecognition`) runs alongside `MediaRecorder` during voice notes. Live transcript shows in a floating overlay above the canvas while you speak. On stop, the final transcript is appended to the fragment summary as a timestamped `🎙` block, and saved with the audio media item as `transcript`. Falls back gracefully when speech API isn't available (Firefox / Safari may not support).

### Mood chart in stats
- New "Mood over time" card in the stats panel: canvas line + dot chart of average mood per year, dot radius scaled by fragment count that year. Theme-accent stroke color. Min/max year labels at the corners.

### Search highlights in summary
- Search query (filter mode OR live in dropdown, ≥2 chars) → matches in the selected fragment's summary get wrapped in a gold-tinted `<mark>` highlight. Clears when the query is empty.

### Verification
- `node test/v17_smoke.mjs`: speech recognition API present in Chrome headless runtime, mood-chart canvas (572×120) renders ink with 7 sample mood values seeded across the timeline, "salt" query highlights inside the "First memory of the ocean" summary as `<mark>...salt...</mark>` and clears cleanly. **0 errors**.
- `node test/views_smoke.mjs`: 7/7 views render under WebGL2.

## v0.16.0 — 2026-05-01
### Custom kinds
- Click the dashed **+ kind** chip in the kind-filter row → name + optional hex color → new kind appears in the row, in the ADD/EDIT dropdown, and persists to LocalStorage as `amni-life-custom-kinds`. Auto-picked color from a 10-color palette if none provided. **Shift-click** any custom-kind chip to remove it.
- Default 6 kinds (person/place/event/work/idea/era) untouched as a base.

### Inline kind edit
- Click the **kind label** in the detail panel header → small popover lists every kind with its color dot. Click any → kind swap, color in scene updates immediately. Click outside / press Esc to close.

### Audio waveform
- When an audio media item is in the gallery, decode the Blob via `AudioContext.decodeAudioData` → render 60-bar peak waveform to a canvas → embed as overlay behind the audio controls. Color uses the current theme accent. Falls back gracefully on decode error.

### Tour speed control
- New 🐢↔🐇 slider in topbar between REVEAL and STATS. Adjusts `tourStepMs` between 1500 ms (fast) and 8000 ms (slow). Persisted to `amni-life-tour-speed`. Live-applies even mid-tour.

### Verification
- `node test/v16_smoke.mjs`: custom kind "trip" added with color `#ff6b9d`, persists to LocalStorage. Kind popover opens with 7 options (6 default + trip), click changes ERA → TRIP. Synthetic WAV import → audio tile renders with `data:image/png` waveform overlay. Tour speed slider 4200 → 2000 persists. **0 errors**.
- `node test/views_smoke.mjs`: 7/7 views render under WebGL2.

## v0.15.0 — 2026-05-01
### Inline title + tag editing
- Click any fragment's **title** in the detail panel → in-place text input. Enter saves; Esc cancels. Mirrors the inline-summary edit shipped in v0.14.
- Tags now have a hover-only **×** badge → one click removes the tag from that fragment (and from `activeTags` if currently filtered).
- New **+ TAG** button under the tag row → prompts for a new tag and adds it to the selected fragment.

### Pin fragments
- New **☆/★** button in the detail panel header. Pinned fragments float to the **top of the fragment list** (above the chronological order) and render with a gold left border. State persists via `pinned: true` on the fragment.

### Search-as-filter
- New **FILTER** toggle button next to the search box. When **off** (default), search behaves as before — click → fly to first hit, dropdown shows all matches. When **on**, the search query becomes a **visibility filter**: only matching fragments stay visible; stats line shows `(N shown)`.

### Verification
- `node test/v15_smoke.mjs`: title edit "Childhood → Renamed inline" persists. Tag remove (era → []) + add (inline-added-tag) round-trip. Pin: ☆ → ★, count=1, first list row gets `.pinned` class. FILTER toggle: "family" query → `25 fragments (2 shown)` when on, `25 fragments` when off. **0 errors**.
- `node test/views_smoke.mjs`: 7/7 views render under WebGL2.

## v0.14.0 — 2026-05-01
### Print / save as PDF
- New **PRINT** topbar button (also Ctrl+P). Generates a chronological book-style HTML view of every fragment grouped by year, then triggers `window.print()`. Print stylesheet renders fragments as bordered cards with title, date, kind, mood, summary, tags, and outgoing connections. Save-as-PDF works directly through the browser's print dialog.

### Mini-map overview
- Small 180×180 canvas in the top-right corner. Shows fragments as colored dots in their projected x/z positions, edges as thin lines, and the camera frustum as a gold line from camera to look-at. **Click anywhere on the map → fly to the nearest fragment.** Auto-hides when the detail or fragment-list panels are open.

### Inline summary edit
- Click any fragment's summary in the detail panel → it converts in-place to a textarea pre-filled with the current summary. **Blur** or **Ctrl+Enter** saves; **Esc** cancels. Markdown is re-rendered after save. No modal needed for tiny edits.

### Keyboard cheatsheet
- New **?** topbar button + **Ctrl+/** shortcut → modal listing every keyboard shortcut grouped into Navigate · Create / Edit · View / Mood. 16 shortcuts total. Esc closes.

### Verification
- `node test/v14_smoke.mjs`: mini-map exists at 180×180 and renders content, cheatsheet opens with 3 sections × 16 rows, inline edit saves "Inline edited: a new summary about this moment." round-trips through localStorage, print() generates 25 fragment cards across 17 year-headers with title "My Memory Map". **0 errors**.
- `node test/views_smoke.mjs`: 7/7 views still render under WebGL2.

## v0.13.0 — 2026-05-01
### Stats panel
- New **∑ STATS** topbar button. Modal shows 5 cards:
  - **Overview** — fragments, connections, year span, media items, geo-tagged count, average mood
  - **Peak years** — top 5 busiest years with bar chart
  - **By kind** — colored bullet + percent breakdown across the 6 kinds
  - **Top tags** — top 8 tags with counts
  - **Most connected** — fragment with most inbound + outbound edges

### Mood field + overlay
- Optional `mood` per fragment (-2 to +2). New slider in ADD/EDIT modal with red→gray→green gradient track and live numeric readout.
- New **🔇 MOOD** topbar button toggles to **🎨 MOOD**. When on, dot colors swap from kind-based to mood-based: heavy reds (-2), muted reds (-1), neutral gray (0), warm green (1), bright green (2). Restores kind colors when toggled off.

### Keyboard navigation
- **→** / **j** steps to next visible fragment chronologically; **←** / **k** steps back. Wraps at start/end. Respects active kind / tag / year / edge filters.

### Verification
- `node test/v13_smoke.mjs`: stats panel opens with 5 cards (Overview · Peak years · By kind · Top tags · Most connected), overview shows `25 / 15 / 29 / 0 / 5`. Mood toggle 🔇↔🎨 cycles cleanly. Mood slider in ADD: dragged to +2, saved fragment carries `mood=2`. Keyboard nav: Childhood → Grandmother → Cottage → Grandmother. **0 errors**.
- `node test/views_smoke.mjs`: 7/7 views still render under WebGL2.

## v0.12.0 — 2026-05-01
### Date precision
- Fragment schema gains optional `month` (1-12) and `day` (1-31). The ADD/EDIT modal swaps its row to a 4-cell grid: kind · year · month · day. Backwards-compat: existing year-only fragments stay valid; month/day fields default to "—".
- Sample data updated: 3 fragments now carry `month`/`day` (incl. two with today's date) so On This Day has data on first load.

### On This Day widget
- Bottom-right floating card surfaces fragments whose `month` / `day` matches today's date. Each row shows kind-dot · title · "Ny ago". Click → fly to + select. Auto-hides when nothing matches today. × button dismisses for the rest of the calendar day (`amni-life-otd-dismissed-date`).

### Time-lapse REVEAL mode
- New **⟳ REVEAL** topbar button. Hides all dots, then reveals them year-by-year from `yearMin` to `yearMax` at ~380 ms per year. A floating overlay shows the current year and a progress bar. Click again or Esc to stop.

### Quick capture (Ctrl+K)
- New floating capture bar (Ctrl+K / Cmd+K). Single text input parses inline syntax:
  - `@YYYY` → year
  - `#tag` → tag (multiple OK)
  - `:person` / `:place` / `:event` / `:work` / `:idea` / `:era` → kind
  - everything else → title
- Live preview shows what will be saved; Enter commits, Esc cancels. Saved fragment auto-selects + fly-to.

### Verification
- `node test/v12_smoke.mjs`: date picker saves year=2014 month=6 day=12, On This Day shows 2 matching rows ("First time playing music in public" / "Moving to the city") with "18y ago" / "9y ago" annotations, Ctrl+K parses `A spontaneous walk @2023 #travel #early :event` correctly into all four fields, REVEAL overlay shows starting year + 0% progress and toggles off cleanly. **0 errors**.
- `node test/views_smoke.mjs`: 7/7 views still render under WebGL2.

## v0.11.0 — 2026-05-01
### Per Anthony's feedback
- **True straight-line timeline.** Dropped the within-year vertical stack. Same-year fragments now spread *along the line* via small within-year x-jitter (`±0.42` of a year-step, capped). Every point sits at `y=z=0`. A faint accent-colored axis line is rendered as a horizontal guide when in Timeline view.
- **Resizable dots.** New top-bar slider (40%–250%) multiplies into the shader's size uniform. Live preview, persisted to LocalStorage as `amni-life-dot-size`. Composes with the per-theme `--canvas-mul`.
- **8 themes total** — added `solarized`, `nord`, `forest`, `sunset` to the existing `dark / light / sepia / midnight`. THEME button cycles through all 8.
- **Hover labels always-on.** Removed the `camDist > 110` gate; nearby-node labels now appear when hovering at any zoom level.

### Verification
- `node test/v11_smoke.mjs`: 8/8 themes cycle with distinct fg/bg, dot slider persists `2.0 → 0.6` cleanly, hover labels show 3 nearby nodes at default zoom (was 0 in v0.10), timeline view loads with the new straight-line layout. **0 errors.**
- `node test/views_smoke.mjs`: 7/7 views still render under WebGL2.

## v0.10.0 — 2026-05-01
### First-visit welcome modal
- One-time onboarding card explains the four core ideas in 30 seconds: 7 visualizations, drop-folder photo import, local-first encrypted shares, quick-keys cheatsheet. **EXPLORE** / **▶ TAKE TOUR** / × actions. "Don't show this again" checkbox persists `amni-life-welcome-v1=dismissed` so it never re-appears for that user.

### Hover-zoom labels
- When the camera is close to the scene (`<110` world units from target), hovering reveals a fading set of pill labels for up to 8 nearby visible nodes within ~140 px of the cursor. Pool is pre-allocated, repositioned per frame via projection. Falls back gracefully (zero labels) when zoomed out.

### WebAudio sound design
- New **🔇 SOUND** topbar toggle. When on, subtle chimes play on:
  - **select** (740 Hz, 80 ms)
  - **fly-to** (520 Hz triangle, 160 ms)
  - **view switch** (380 → 640 Hz, two-tone)
  - **save** (880 → 1180 Hz, two-tone confirmation)
  - **undo** (220 Hz triangle, 180 ms)
  - **error** (180 Hz sawtooth)
  - **tour start** (660 → 880 → 1100 Hz arpeggio)
- ~50 lines of inline WebAudio. Lazy-creates AudioContext on first sound. Off by default; persisted to LocalStorage.

### CSV import
- Drop a `.csv` file anywhere on the page (or pick via IMPORT) and Amni-Life parses it into fragments. Auto-detects columns: `title` (or `name`/`subject`/`headline`), `kind`, `year`, `summary`/`description`/`notes`, `tags`/`keywords`/`labels`, `lat`/`latitude`, `lon`/`longitude`. Tags split on `,` `;` `|`. Invalid kinds default to `event`. Year extracted by regex from any string containing 4 digits. RFC 4180-style quoting handled.

### Verification
- `node test/v10_smoke.mjs`: welcome modal shows + EXPLORE dismisses + persists across reload, sound 🔇↔🔊 toggle persists `amni-life-sound`, hover-label pool of 8 (1 shown when hovered), CSV `25 → 28 fragments` with `Mentor in Tokyo` carrying `kind=person · year=2018 · lat=35.65 · lon=139.65 · tags=[mentor,travel]`. **0 errors**.
- `node test/views_smoke.mjs`: 7/7 views still render under WebGL2.

## v0.9.0 — 2026-05-01
### Redo
- Companion to undo. Every undo pushes the popped state onto a redo stack; **Ctrl+Y** or **Cmd+Shift+Z** plays it back. New edits clear redo (standard editor behavior).

### Multi-select + batch ops
- **Shift+click** any row in the fragment list to add/remove from a multi-selection set. Selected rows highlighted with cyan border + tinted background.
- A new toolbar appears in the FRAGMENTS header: `<N> selected · +TAG · DEL · ×`.
  - **+TAG** prompts for a tag and adds it to every selected fragment.
  - **DEL** confirms then deletes them all (and any incoming connections).
  - **×** clears the selection.

### Path-finder (Alt+click)
- After selecting fragment A, **Alt+click** fragment B in the list → BFS through the bidirectional connection graph → highlights the path in gold and posts a toast like `Path: 4 hops · A → … → B`. Reports "No path" if the two are in disconnected components.

### Google Takeout sidecar import
- The folder importer now detects `<photo>.json` sidecar files (and `<photo>.supplemental-metadata.json`) and merges the metadata in: `photoTakenTime` / `creationTime` → year, `geoData.latitude/longitude` → fragment lat/lon, `title` → fragment title, `description` → appended to summary. Auto-tags any Takeout-sourced fragment with `#takeout` so they're easy to filter.
- Also extends to videos now (was photos-only before).

### Verification
- `node test/v09_smoke.mjs`: redo cycle (25 → 24 → 25 → 24), shift-click 3 rows + batch-tag adds a new tag chip, alt-click between connected fragments highlights 5 path rows + posts `Path: 4 hops · First book that mattered → idea that the world is patterned → Becoming an engineer → First real project → Lab partner`, synthetic Takeout import (1 jpg + 1 sidecar.json) creates a fragment with year=2019, lat=47.27, title="A magic morning", `#geo` + `#takeout` tags. **0 errors.**

## v0.8.0 — 2026-05-01
### Encrypted share-link
- Share modal gains an **Encrypt with passphrase** checkbox + **REGENERATE** button. With encryption on, the URL hash uses `#e=…` (vs `#m=…` for plaintext). Encryption: **AES-GCM 256** with key derived from the passphrase via **PBKDF2-SHA256, 200k iterations** + 16-byte salt + 12-byte IV. Layout = `salt | iv | ciphertext` packed and base64url-encoded.
- Recipient opening an `#e=…` URL gets an **UNLOCK SHARED MAP** modal asking for the passphrase. Wrong → "wrong passphrase or corrupt link". Right → fragments restore + modal closes + toast confirms count.
- `lat`/`lon` now travel through the share payload (compact keys `la`/`lo`), so geo data follows shares.
- Sample round-trip: 4105 plaintext bytes → **1740 encrypted bytes (42%)**, ~2.3k char URL.

### Undo
- `pushUndo()` snapshots the fragments array on every `saveFragments()` call (max 30 snapshots). **Cmd+Z / Ctrl+Z** pops the stack, restores state, replays through layout/build/render. Toast confirms: "Undone: edit · N more". Survives delete, edit, link, import, voice-note attach, etc.

### TTS narration in TOUR
- New **🔇 NARRATE** topbar button toggles to **🔊 NARRATE**. When on and TOUR is running, each step calls `speechSynthesis.speak(title + ". " + year + ". " + summary)`. Auto-cancels speech when fragment changes mid-utterance, when tour ends, or when narrate is toggled off.

### Verification
- `node test/v08_smoke.mjs`: encrypted round-trip (encrypt → reload → wrong-passphrase rejected → correct-passphrase restores 25 fragments + closes modal). Undo: delete one fragment (25→24), Ctrl+Z restores (24→25). Narrate: toggles 🔇 ↔ 🔊 cleanly. **0 errors**.
- `node test/views_smoke.mjs`: 7/7 views still under WebGL2.

## v0.7.0 — 2026-05-01
### Photo Wall overlay
- New **WALL** button in topbar — fullscreen grid of every media item across every fragment. Each tile shows the photo / video poster / audio player + the source fragment's title and year on a dark gradient overlay. Click any tile → closes wall, fly-to that fragment.
- Empty state when no media attached yet — explicit instruction to attach via detail panel or `+ FOLDER`.

### Drag-to-link
- **Shift + drag** from any node in the 3D scene to another → creates a `with` connection between them. A dashed accent-colored SVG line follows the cursor during the drag. Releasing over empty space cancels.
- Esc cancels mid-drag.
- Auto-rotate is paused while linking.
- Toast feedback: "Linked: A → B" or "Already linked → B".

### Edge type filter
- 4 chips below the tag-filter row (`with`, `at`, `inspired-by`, `part-of`) showing per-type counts. Toggle any to hide/show edges of that type. Sample data: with=4 + at=3 + inspired-by=3 + part-of=5 = 15 connections.

### Persistent label on selected node
- A pill label hovers above the selected node with `<title> · <year>`, anchored to the node's projected screen position and re-projected every frame. Stays visible during view lerps and orbit changes.

### Verification
- `node test/v07_smoke.mjs`: 4 edge chips render with correct counts (sum = 15), toggling one removes from active set, selected fragment "Childhood" produces label `Childhood · 1995`, wall starts empty + transitions to "1 media · 1 fragments with media" after a synthetic GIF drop. **0 errors.**
- `node test/views_smoke.mjs`: 7/7 views render under WebGL2.

## v0.6.0 — 2026-05-01
### Calendar heatmap (7th view)
- New "Calendar" view in the dropdown — fragments laid out on a year × month grid (`x = month-6.5`, `z = year-relative`). Same-cell fragments stack vertically. Year-axis scale auto-adapts to span. Photos imported via EXIF will eventually carry month, making this view properly informative; for fragments without a month field the layout falls back to a deterministic id-hash bucket.
- View sweep now confirms **7/7 views render under WebGL2**.

### Voice notes (MediaRecorder)
- New **REC** button in the detail-panel actions row. Click → requests mic via `getUserMedia`, starts `MediaRecorder` with the best supported audio MIME (opus/webm preferred, falls back through mp4/ogg). Live timer ticks `MM:SS` on the button while recording. Click again → stops, encodes Blob, drops it into IndexedDB, attaches as an `audio` media item with auto-named `voice-note-<timestamp>.webm`.
- Inline `<audio controls>` playback in the detail panel gallery.

### Fragment counts in chips
- Both kind chips and top-tag chips now show `(N)` count badges. Computed live from `fragments[]`; updates on add/edit/delete/import. Sample data totals: person=4, place=4, event=5, work=4, idea=4, era=4 = 25.

### Tour / story mode
- New **▶ TOUR** button in the topbar. Click → walks through visible fragments chronologically (oldest first), 4.2 s per stop, fly-to + open detail panel for each. Auto-stops at the end. Click again or **Esc** to abort early. Disables auto-spin during tour and restores it after.
- Respects current filters — only tours fragments visible under the active kind/tag/year filters.

### Verification
- `node test/v06_smoke.mjs`: calendar view selectable, 25 total chip-count sum (matches fragments count), REC button present + enabled, tour start changes button to `◼ STOP`, click-again returns to `▶ TOUR`. **0 errors.**
- `node test/views_smoke.mjs`: 7/7 views render under WebGL2.

## v0.5.0 — 2026-05-01
### Globe view
- Map view replaced with a true rotating 3D globe — wireframe sphere (32×24 segments, accent-colored), filled translucent core, ring beneath the south pole holds ungeocoded fragments. `latLonToXYZ()` projects fragments onto the sphere surface; the existing OrbitControls + auto-rotate gives free 3D exploration.
- Globe colors live-sync with theme (`--bg2` for fill, `--accent` for wireframe + ring).
- Sample data: 5 geo coords still seeded (Cape Cod, Philly ×2, NYC, Innsbruck) so the globe has data on first load.

### Multi-result search panel
- Search box now opens a dropdown listing **all** matches (not just first hit). Click any row → fly to that fragment.
- Dropdown auto-hides on Esc, on click outside, and after picking a row.
- Searches title, summary, tags, kind, year, id.

### Backlinks in detail panel
- New "REFERENCED BY" section under "CONNECTED" that lists every fragment whose `connections[]` points to the selected fragment. Reverse navigation that was previously a manual hunt.

### Markdown rendering in summaries
- Tiny inline parser (~10 lines) for `**bold**`, `*italic*`, `_italic_`, `[label](url)`, `` `code` ``, and line breaks. HTML-escaping first so `<script>` etc. stay text. Renders into `#detail-summary innerHTML`.
- Sample fragment "Privacy as a worldview" updated to demonstrate.

### iOS Safari pointer-events fix
- Per memory `feedback_safari_ios_flex_button_bug.md`: paired all flex elements with child spans (`.chip`, `.topbtn`, `.frag-row`, `.conn`, `.sr-row`) with `> * { pointer-events: none }` so taps on inner spans bubble to the parent. Media-tile `.media-x` close button explicitly re-enables to keep working.

### Verification
- `node test/v05_smoke.mjs`: globe screenshot shows wireframe sphere with geo dots projected, multi-result search returns 2 hits for "family", picking one opens detail panel and auto-hides dropdown, "cottage" fragment shows 1 backlink "First memory of the ocean ← at", privacy fragment renders `<strong>` + `<em>` + `<a href>`, chip-span computed pointer-events = `none`. **0 errors**.

## v0.4.0 — 2026-05-01
### New visualization
- **Map view** (6th view) — geographic projection of fragments with EXIF GPS or explicit `lat`/`lon`. Centroid-anchored equirectangular layout — geo cluster sits at world origin, fragments without coordinates land in a strip just below. Sample data updated with 5 real-world coordinates (Cape Cod, Philly, NYC, Innsbruck, Philly) so the new view has data on first load.
- Stats line surfaces `· N geo` count when any fragment carries coordinates.

### PWA install
- `manifest.webmanifest` with full app metadata, two SVG icons (192/512, maskable), `display:standalone`, theme-color sync, Apple-specific meta tags.
- **INSTALL** button in topbar — captures `beforeinstallprompt`, prompts on click, hides on `appinstalled`. Service-worker shell already covers offline.
- SW cache key bumped to `amni-life-v0.4.0`; manifest added to cached SHELL list.

### Image lightbox
- Click any image or video tile in the detail panel → fullscreen overlay with prev/next arrows, Esc-to-close, click-to-dismiss-backdrop. Keyboard: ←/→ navigate, Esc closes.
- Lightbox metadata bar shows filename + GPS coords (when present) + `i/N` counter.

### Year range slider
- Two-thumb slider in topbar bound to `[min(year), max(year)]` of the current map. Filters fragments outside the range; integrates with kind/tag filters and the "shown" stats line.
- Auto-rebound when fragments change.

### Verification
- `node test/v04_smoke.mjs`: map view stats show `5 geo`, manifest serves with 2 icons + `Amni-Life` name + standalone display, year filter goes 25 → 14 shown when min=2010, lightbox opens with metadata `lightbox-test.gif · 1/1`. **0 errors**.
- `node test/views_smoke.mjs`: 6/6 views render under WebGL2.

## v0.3.0 — 2026-05-01
### Fixes from feedback
- **Timeline is now a real straight line** — dropped the kind-based row stacking; same-year fragments stack vertically around y=0 instead of lining up across 6 horizontal swim lanes
- **Era color**: rose-pink → soft parchment (`#dccdb1`); era markers now read as time-period landmarks rather than competing for attention
- **Wise selection**: replaced fixed-threshold raycaster with screen-space pixel picking — every visible point is equally hittable regardless of distance from camera. Hover within ~28 px of any node's screen position selects it.

### Connect to your life
- **+ FOLDER** button → pick a folder of photos (`webkitdirectory`); Amni-Life parses EXIF (DateTimeOriginal + GPS), creates one fragment per image with the photo attached, year extracted from EXIF (or `lastModified` fallback). Tested with synthetic JPEGs.
- Inline minimal EXIF parser (~80 lines, no dependencies) handles JPEG APP1 + TIFF IFD0 + Exif IFD + GPS IFD
- **CONNECT** button → modal with two integrations:
  - **Local folder import** (offline-first, primary path)
  - **Google Photos** (BYO Client ID): user pastes their own OAuth Client ID into a field, app loads Google Identity Services on demand, requests `photoslibrary.readonly` scope, fetches mediaItems, downloads bytes, stores in IndexedDB. Each photo → fragment with `creationTime` year + filename + dimensions in summary. Token cached in LocalStorage with expiry.
- Coming-soon list visible in Connect modal: Apple Photos export ZIP, Google Takeout JSON, Generic timeline JSON, P2P encrypted sharing, multi-device sync

### Misc
- SW cache key bumped to `amni-life-v0.3.0` (invalidates v0.2 cache)
- Topbar buttons tightened (smaller padding, `white-space:nowrap`) to fit 11+ buttons cleanly
- Stats line now shows `· v0.3.0`

### Verification
- `node test/v03_smoke.mjs`: timeline shape verified via screenshot, era chip color = `rgb(220, 205, 177)` ✓, screen-space picking grid-sweep finds 12 hit-cells across 231-cell grid (correct for 25 nodes), folder import goes 25 → 28 fragments with synthetic JPEG, Connect modal opens with Google Photos UI present, Client ID round-trips through LocalStorage. **0 errors.**

## v0.2.0 — 2026-05-01
- **Themes** (4): dark / light / sepia / midnight — CSS variable swap + Three.js scene background sync via MutationObserver
- **Theme-aware blending**: AdditiveBlending on dark themes, NormalBlending on light (so colored nodes pop on white)
- **Tag chip filters**: top 14 tags as toggleable chips beneath the kind chips, click any tag in detail panel to toggle filter
- **Share-as-link**: `CompressionStream('deflate-raw')` + base64url → `#m=…` URL hash; recipient gets read-only restore on load
  - 25 fragments compress 3935 → 1599 bytes (41%); URL stays under 2.2k chars
  - Auto-copies to clipboard on share
- **Media attachments** per fragment: images, videos, audio — IndexedDB-backed (no LocalStorage size limits)
  - Drag-drop anywhere on the page to attach to selected fragment
  - +MEDIA button → file picker (multi-select)
  - Inline gallery in detail panel (image, `<video controls>`, `<audio controls>`)
  - Hover-to-delete per tile
- **Service worker** (`sw.js`) for offline-first: caches app shell + WASM + CDN three.js (9 entries, ~310 KB)
- **Toast notifications** — non-blocking feedback for share, import, attach, theme
- **Keyboard shortcuts**: T (theme), N (new), L (list), E (edges), S (spin), / (search), Esc (close)
- **Filtered stats**: when tag/kind filters hide some fragments, stats line shows "(N shown)"
- **URL hash auto-restore**: paste a `#m=…` link → map loads from hash, not LocalStorage

### Verification
- 4-theme cycle screenshots clean (test/theme_*.png)
- Service worker active with 9 cached entries verified in headless Chrome
- Share-link round-trip: full restoration of 25 fragments through reload
- IndexedDB media: synthetic GIF drag-drop → render in detail panel verified
- 0 page errors, 0 console errors across all flows

## v0.1.0 — 2026-05-01
- Initial scaffold (atex init, workflow docs, guardian council)
- Data model: 6 kinds × 4 edge types, JSON-shaped
- Rust crate (`amni_life`) with 5 layout fns: timeline, constellation, spiral, cluster, radial
- WASM build wired via `wasm-pack --target web`
- Three.js scene with Points + LineSegments, lerp between views
- UI: top bar (logo, view selector, search, +ADD, export, import), detail panel, filter chips
- LocalStorage persistence
- Sample life-map (25 generic fragments)
- Local dev via `python server.py`
- Demo verified in browser
