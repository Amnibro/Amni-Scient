import http.server, socketserver, os, sys
PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 8765
class H(http.server.SimpleHTTPRequestHandler):
    extensions_map = {**http.server.SimpleHTTPRequestHandler.extensions_map, ".wasm": "application/wasm", ".js": "text/javascript", ".mjs": "text/javascript", ".json": "application/json", ".html": "text/html", ".css": "text/css"}
    def end_headers(self):
        self.send_header("Cache-Control", "no-store")
        super().end_headers()
os.chdir(os.path.dirname(os.path.abspath(__file__)))
with socketserver.TCPServer(("127.0.0.1", PORT), H) as s:
    print(f"[amni-life] http://127.0.0.1:{PORT}/")
    try: s.serve_forever()
    except KeyboardInterrupt: print("\n[amni-life] bye")
