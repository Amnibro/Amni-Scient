Braid for macOS
===============

To start Braid:
  1. Double-click Braid.command.
     The first time, macOS can show "from an unidentified developer".
     If it does: right-click (or Control-click) Braid.command, select Open, then Open again.
  2. If macOS offers to install the "command line developer tools", accept.
     That gives you Python 3, the only thing Braid needs. Then open Braid.command again.
  3. Braid opens in your web browser at a local address. Keep the terminal
     window open while you use it. Close it to stop Braid.

Your conversations and settings live in:
  ~/Library/Application Support/Braid

To uninstall: delete this folder and the folder above. Nothing else is touched.
