import os,sys,json,subprocess,time,re,threading,urllib.request,urllib.error
try:
 from delve_proc import run as _run,popen as _popen,check_output as _co
except Exception:
 from subprocess import run as _run,Popen as _popen,check_output as _co
ROOT=os.path.dirname(os.path.abspath(__file__))
def _ai_root():
 """Where Amni-Ai lives. ROOT/../Amni-Ai is only true when Braid runs from its checkout.

 A frozen build's ROOT is the PyInstaller extraction directory under %TEMP%, so the sibling
 lookup resolved to %TEMP%/Amni-Ai, which never exists - `adam_available()` falls back to this
 detection when `adam_enabled` is unset, so Adam silently vanished from the roster and from the
 flow editor the moment Braid ran as an .exe rather than from source. Adam was RUNNING at the
 time; nothing could see it.

 Order: an explicit config path, then beside the .exe, then the checkout layout, then the usual
 places a user keeps it."""
 seen=[]
 try:
  import json as _j
  _ah=os.path.join(os.environ.get("APPDATA") or "","Braid") if os.name=="nt" else os.path.join(os.path.expanduser("~"),"Library","Application Support","Braid") if sys.platform=="darwin" else os.path.join(os.environ.get("XDG_DATA_HOME") or os.path.join(os.path.expanduser("~"),".local","share"),"Braid")
  for base in ({_ah} if (os.name!="nt" or os.environ.get("APPDATA")) else set())|{ROOT}:
   p=os.path.join(base,"delve_config.json")
   if os.path.isfile(p):
    v=str((_j.load(open(p,encoding="utf-8")) or {}).get("adam_repo") or "").strip()
    if v:seen.append(v)
 except Exception:pass
 try:
  if getattr(sys,"frozen",False) or hasattr(sys,"_MEIPASS"):
   seen.append(os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(sys.executable)),"..","Amni-Ai")))
   seen.append(os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(sys.executable)),"..","..","Amni-Ai")))
 except Exception:pass
 seen.append(os.path.normpath(os.path.join(ROOT,"..","Amni-Ai")))
 home=os.path.expanduser("~")
 seen+=[os.path.join(home,"Documents","ai","Amni-Ai"),os.path.join(home,"Documents","Amni-Ai"),os.path.join(home,"Amni-Ai")]
 for c in seen:
  try:
   if c and os.path.isdir(c):return c
  except Exception:continue
 return ""
def _base():
 return "http://"+os.environ.get("ADAM_HOST","127.0.0.1")+":"+os.environ.get("ADAM_PORT","7700")
def _get(path,timeout=2):
 return urllib.request.urlopen(_base()+path,timeout=timeout).read().decode("utf-8","replace")
_UPC=(False,0.0)
def _set_upc(v,exp):
 global _UPC
 _UPC=(v,exp)
def is_up():
 # A busy Adam (GPU mid-generation) answers /healthz late, not never. A 0.35s probe read that as
 # "offline" and sent the room down the restart path, killing a healthy serve mid-answer.
 now=time.time()
 v,exp=_UPC
 if now<exp:return v
 to=float(os.environ.get("AMNI_DELVE_ADAM_PING","1.2"))
 ok=False
 for t in (to,to*2):
  try:json.loads(_get("/healthz",timeout=t));ok=True;break
  except Exception:continue
 _set_upc(ok,now+(4.0 if ok else 1.0));return ok
def health():
 try:return json.loads(_get("/healthz",timeout=5))
 except Exception:return {}
def _post_json(path,payload,timeout):
 data=json.dumps(payload).encode("utf-8")
 req=urllib.request.Request(_base()+path,data=data,headers={"Content-Type":"application/json"},method="POST")
 with urllib.request.urlopen(req,timeout=timeout) as r:
  return json.loads(r.read().decode("utf-8","replace") or "{}")
last_finish=""
def _clip(prompt,max_chars):
 p=(prompt or "").strip()
 if max_chars<=0 or len(p)<=max_chars:return p
 head=int(max_chars*0.25);tail=max_chars-head-80
 return p[:head]+"\n\n…[delve truncated middle for Adam latency]…\n\n"+p[-tail:]
def _transient(err):
 s=str(err).lower()
 keys=("10054","10061","10053","forcibly closed","connection refused","connection reset","timed out","timeout","temporarily unavailable","broken pipe","remote end closed")
 return any(k in s for k in keys)
def _wait_up(budget=None,step=3.0):
 budget=int(budget if budget is not None else os.environ.get("AMNI_DELVE_ADAM_BOOT_WAIT","90"))
 t0=time.time()
 while time.time()-t0<budget:
  if is_up():return True
  if boot_state().get("phase") not in ("booting","thrash"):return is_up()
  time.sleep(step)
 return is_up()
def _ask(prompt,timeout=None,max_chars=None,retries=None,max_tokens=None,system=None,temperature=None,session_id=None):
 def_to=os.environ.get("AMNI_DELVE_ADAM_TIMEOUT","180")
 to=int(timeout if timeout is not None else def_to)
 def_mc=os.environ.get("AMNI_DELVE_ADAM_MAX_CHARS","12000")
 mc=int(max_chars if max_chars is not None else def_mc)
 ntry=int(retries if retries is not None else os.environ.get("AMNI_DELVE_ADAM_RETRIES","3"))
 mt=int(max_tokens if max_tokens is not None else os.environ.get("AMNI_DELVE_ADAM_TOK","2400"))
 temp=float(temperature if temperature is not None else os.environ.get("AMNI_DELVE_ADAM_TEMP","0.15"))
 q=_clip(prompt,mc)
 if not q:return "[adam empty prompt]"
 sys_p=(system or "").strip() or (
  "You are Adam in Amni-Delve. If assigned calculations (RFD, H_dev, σ, ratios), do the math first with equations. "
  "Empty LOCKED/OPEN boards without work fail. Never invent closures or reverse peer corrections. "
  "No misattribution. Board only after substance when work is assigned."
 )
 global last_finish
 last="";last_finish=""
 for i in range(max(1,ntry)):
  if not is_up():
   if boot_state().get("phase") in ("booting","thrash") and _wait_up():pass
   else:
    last="offline (no /healthz on "+_base()+") — boot Adam (Mission Control smart or adam.bat)"
    if i+1<ntry:time.sleep(1.2*(i+1));continue
    return "[adam error] "+last
  try:
   msgs=[{"role":"system","content":sys_p},{"role":"user","content":q}]
   # persona:"off" — a Braid work room is not a Jarvis chat. Without this the serve appends its
   # default persona (Rikku, with full character lore) AFTER the work system prompt, and under an
   # ambiguous prompt a 3B answers the lore instead of the task.
   body={"messages":msgs,"max_tokens":mt,"temperature":temp,"top_p":0.85,"persona":"off"}
   # Without a session id every Braid turn lands in Adam's 'oai_default' bucket, so his own
   # conversation store never attaches and he starts each turn amnesiac.
   if session_id:body["user"]=str(session_id)[:120]
   d=_post_json("/v1/chat/completions",body,to)
   ch=(d.get("choices") or [{}])[0]
   ans=((ch.get("message") or {}).get("content") or "")
   fr=ch.get("finish_reason") or ch.get("finishReason") or ""
   last_finish=str(fr or "")
   if isinstance(ans,str) and ans.strip():return ans.strip()
   if d.get("error"):return "[adam error] "+str(d.get("error"))[:240]
   try:
    d2=_post_json("/ask",{"query":(sys_p+"\n\n"+q)[:mc],"writeback":False},to)
    ans2=(d2.get("answer") or d2.get("text") or d2.get("response") or "")
    if isinstance(ans2,str) and ans2.strip():return ans2.strip()
   except Exception:pass
   return "[adam empty]"
  except urllib.error.HTTPError as e:
   try:body=e.read().decode("utf-8","replace")[:200]
   except Exception:body=""
   last=f"HTTP {e.code} {body}"
   if e.code in (502,503,504) and i+1<ntry:time.sleep(1.5*(i+1));continue
   return "[adam error] "+last
  except Exception as e:
   last=str(e)
   if _transient(e) and i+1<ntry:
    time.sleep(1.5*(i+1))
    if not is_up() and boot_state().get("phase") in ("booting","thrash"):_wait_up()
    continue
   if "timed out" in last.lower() or "timeout" in last.lower():
    return f"[adam error] timed out after {to}s — prompt {len(q)} chars. Retry once Adam is warm, or raise AMNI_DELVE_ADAM_TIMEOUT."
   if "10054" in last or "forcibly closed" in last.lower():
    return "[adam error] connection reset — Adam was restarting or crashed mid-answer. Wait for /healthz then retry."
   if "10061" in last or "refused" in last.lower():
    return "[adam error] connection refused — Adam not listening on "+_base()+". Start Adam serve."
   return "[adam error] "+last
 return "[adam error] "+(last or "unknown")
def intent(text,timeout=6):
 try:
  d=_post_json("/intent",{"text":(text or "")[:600]},timeout)
  return {"label":str(d.get("label") or ""),"conf":float(d.get("confidence") or 0.0),"embedder":bool(d.get("embedder_loaded"))}
 except Exception:return {"label":"","conf":0.0,"embedder":False}
def atlas_record(session_id,user,assistant,timeout=10):
 if not (session_id and user and assistant):return {"recorded":False}
 try:return _post_json("/memory/atlas/record",{"session_id":session_id,"user":user[:4000],"assistant":assistant[:4000]},timeout)
 except Exception as e:return {"recorded":False,"error":str(e)[:120]}
def atlas_recall(session_id,query,k=3,include_global=False,timeout=10):
 if not (session_id and query):return {"own":[],"shared":[]}
 try:
  d=_post_json("/memory/atlas/recall",{"session_id":session_id,"query":query[:2000],"k":int(k),"include_global":bool(include_global)},timeout)
  return {"own":d.get("own") or [],"shared":d.get("shared") or []}
 except Exception:return {"own":[],"shared":[]}
def coding_brief(task,k=5,timeout=8,numeric=True):
 """Pull prior FAILED attempts + brief from Adam's coding_ledger over HTTP (no torch import)."""
 t=(task or "").strip()
 if not t:return ""
 try:
  from urllib.parse import quote
  raw=_get("/memory/coding-attempts?task="+quote(t[:500])+"&limit="+str(max(3,int(k))),timeout=timeout)
  d=json.loads(raw or "{}")
 except Exception:return ""
 hits=d.get("recall") or []
 if not hits:return ""
 def _failed(h):
  if h.get("success") is False:return True
  les=str(h.get("lesson") or h.get("kind") or "").lower()
  return "peer correction" in les or "rejected" in les or h.get("kind")=="peer_corrected"
 fails=[h for h in hits if _failed(h)]
 oks=[h for h in hits if h.get("success") is True]
 lines=["=== CODING/PTEX LEDGER — prior attempts on similar tasks (DO NOT repeat failed approaches) ==="]
 for h in (fails[:max(1,k-1)]+(oks[:1] if oks else []) or hits)[:k]:
  st="FAIL" if _failed(h) else ("OK" if h.get("success") else "?")
  les=(h.get("lesson") or h.get("outcome") or "")[:220]
  ap=(h.get("method") or h.get("approach") or "")[:120]
  lines.append("- ["+st+"] "+(h.get("task") or "")[:100]+((" | tried: "+ap) if ap else "")+((" | lesson: "+les) if les else ""))
 if fails:
  errs=[];seen=set()
  for h in fails:
   for e in (h.get("errors") or [h.get("lesson") or ""]):
    sig=re.sub(r"\d+","N",str(e))[:70].lower()
    if sig and sig not in seen:seen.add(sig);errs.append(str(e)[:140])
  lines.append("SYNTHESIZE: you failed this kind of task "+str(len(fails))+" time(s).")
  if errs:lines.append("  burned failures: "+" | ".join(errs[:5]))
  lines.append("  Change method fundamentally. Prefer approaches marked OK if any.")
  if numeric:
   lines.append("  Use run_python for EVERY arithmetic step. Never invent bpw/bits/GB/N — compute them.")
  else:
   lines.append("  THIS TASK IS NOT NUMERIC. Do not produce arithmetic, do not answer a math question you were not asked, and never reply 'The answer is <number>'.")
 elif oks:
  lines.append("A prior approach WORKED on a similar task — prefer that method shape, still re-compute numbers with tools.")
 return "\n".join(lines)
def coding_record(task,outcome="",lesson="",success=None,session_id="",approach="",errors=None,kind="delve",timeout=8):
 try:
  return _post_json("/memory/coding-attempt",{"task":(task or "")[:500],"outcome":(outcome or "")[:600],"lesson":(lesson or "")[:500],"success":success,"session_id":(session_id or "")[:64],"approach":(approach or "")[:200],"errors":errors or [],"kind":kind},timeout)
 except Exception as e:return {"recorded":False,"error":str(e)[:120]}
def coding_commit(timeout=180):
 try:return _post_json("/api/delve/commit",{},timeout)
 except Exception as e:return {"ok":False,"error":str(e)[:160]}
def _ask_agentic(goal,cwd="",max_steps=None,timeout=None,mode="autonomous",unrestricted=False,roots=None,allow_tools=None):
 to=int(timeout if timeout is not None else os.environ.get("AMNI_DELVE_ADAM_AGENTIC_TIMEOUT","600"))
 ms=int(max_steps if max_steps is not None else os.environ.get("AMNI_DELVE_ADAM_STEPS","8"))
 if not is_up():return {"ok":False,"error":"offline","missing":False}
 unres=bool(unrestricted) and os.environ.get("AMNI_AGENTIC_UNRESTRICTED","0")=="1"
 body={"goal":goal,"cwd":cwd or "","max_steps":ms,"timeout_s":max(30,to-30),"mode":mode,"unrestricted":unres}
 if roots and unres:body["roots"]=list(roots)
 if allow_tools:body["allow_tools"]=list(allow_tools)
 try:
  d=_post_json("/api/delve/agentic",body,to)
  return d if isinstance(d,dict) else {"ok":False,"error":"bad response"}
 except urllib.error.HTTPError as e:
  return {"ok":False,"error":"HTTP "+str(e.code),"missing":e.code in (404,405)}
 except Exception as e:
  return {"ok":False,"error":str(e)[:200],"missing":False}
def _venv_py(r):
 for p in (os.path.join(r,".venv","Scripts","python.exe"),os.path.join(r,".venv","bin","python")):
  if os.path.isfile(p):return p
 return ""
def _resolve_bake(r,mode):
 env_bake=os.environ.get("AMNI_BAKE")
 if env_bake and os.environ.get("AMNI_BAKE_FORCE","0") in ("1","true","yes"):
  abs_b=env_bake if os.path.isabs(env_bake) else os.path.join(r,env_bake)
  if os.path.isdir(abs_b):return os.path.relpath(abs_b,r).replace("\\","/") if abs_b.startswith(r) else env_bake
 cands_heavy=["bakes/granite41_8b_gf17_atex","bakes/granite41_3b_gf17_atex"]
 cands_light=["bakes/granite41_3b_gf17_atex","bakes/granite41_3b_palette"]
 for c in (cands_heavy if mode=="heavy" else cands_light):
  if os.path.isdir(os.path.join(r,c)):return c
 return "bakes/granite41_8b_gf17_atex" if mode=="heavy" else "bakes/granite41_3b_gf17_atex"
def _bake_usable(p):
 try:return os.path.isdir(p) and os.path.isfile(os.path.join(p,"config.json")) and (os.path.isfile(os.path.join(p,"manifest.json")) or os.path.isfile(os.path.join(p,"bake_manifest.json")))
 except Exception:return False
def list_bakes(r=None):
 """Every loadable model on disk, newest-mtime first. Mirrors amni_serve._bake_usable so we
 never offer a directory the serve would refuse (a bake needs config.json + a manifest)."""
 r=r or _ai_root()
 if not r:return []
 out=[]
 for root in (os.path.join(r,"bakes"),os.path.join(os.path.expanduser("~"),"amni-bakes")):
  if not os.path.isdir(root):continue
  for n in sorted(os.listdir(root)):
   p=os.path.join(root,n)
   if not _bake_usable(p):continue
   rel=os.path.relpath(p,r).replace("\\","/")
   sz=0
   try:
    for rt,_dirs,fs in os.walk(p):
     for f in fs:
      try:sz+=os.path.getsize(os.path.join(rt,f))
      except Exception:pass
   except Exception:pass
   out.append({"id":rel,"name":n,"path":p,"size_mb":round(sz/1048576,1),"mtime":os.path.getmtime(p)})
 out.sort(key=lambda x:-x["mtime"])
 return out
def live_bake(r=None):
 """What is ACTUALLY loaded right now, read off the running process argv (authoritative) with
 /healthz as a fallback. Without this a bake swap can silently no-op and you test the old model."""
 try:
  for p in _ps_list_serve():
   c=(p.get("cmd") or "").replace("\\","/")
   m=re.search(r"--bake\s+(\S+)",c)
   if m:return m.group(1).strip().strip('"')
 except Exception:pass
 h=_live_bake_hint()
 return h or ""
def _live_bake_hint():
 try:
  d=health() if is_up() else {}
  if not isinstance(d,dict):return ""
  for k in ("bake","model","amni_bake"):
   v=d.get(k)
   if isinstance(v,str) and v.strip():return v.replace("\\","/").lower()
  g=d.get("gpu") or d.get("vram") or {}
  if isinstance(g,dict):
   for k in ("bake","model"):
    v=g.get(k)
    if isinstance(v,str) and v.strip():return v.replace("\\","/").lower()
 except Exception:pass
 try:
  for p in _ps_list_serve():
   c=(p.get("cmd") or "").replace("\\","/").lower()
   if "granite41_8b" in c or "8b_gf17" in c:return "8b"
   if "granite41_3b" in c or "3b_gf17" in c:return "3b"
   if "nvfp4" in c or "12b" in c:return "12b"
 except Exception:pass
 return ""
def _mode_matches_live(mode,want_bake):
 hint=_live_bake_hint();wb=(want_bake or "").replace("\\","/").lower()
 if not hint:return True
 if mode=="heavy":
  if "8b" in wb or "granite41_8b" in wb:return ("8b" in hint or "granite41_8b" in hint) and "nvfp4" not in hint and "12b" not in hint
  return wb.split("/")[-1] in hint if wb else True
 if mode=="light":
  return ("3b" in hint or "granite41_3b" in hint) and "8b" not in hint and "nvfp4" not in hint
 return True
def _ps_list_serve():
 if os.name!="nt":
  try:out=_co(["ps","-eo","pid=,ppid=,rss=,args="],text=True,timeout=12,stderr=subprocess.DEVNULL)
  except Exception:return []
  rows=[]
  for line in (out or "").splitlines():
   f=line.split(None,3)
   if len(f)<4:continue
   if "python" not in f[3].split(None,1)[0].lower():continue
   if not re.search(r'amni_serve\.py|amni\.cli\s+serve|-m\s+amni\.cli',f[3]):continue
   try:rows.append({"pid":int(f[0]),"ppid":int(f[1]),"ws":int(f[2])*1024,"cmd":f[3]})
   except Exception:continue
  return rows
 cmd=["powershell","-NoProfile","-Command",
  "Get-CimInstance Win32_Process -Filter \"Name='python.exe' OR Name='pythonw.exe'\" | "
  "Where-Object { $_.CommandLine -and ($_.CommandLine -match 'amni_serve\\.py|amni\\.cli\\s+serve|-m\\s+amni\\.cli') } | "
  "ForEach-Object { '{0}|{1}|{2}|{3}' -f $_.ProcessId,$_.ParentProcessId,$_.WorkingSetSize,($_.CommandLine -replace '\\|','/') }"]
 try:
  out=_co(cmd,text=True,timeout=12,stderr=subprocess.DEVNULL)
 except Exception:
  return []
 rows=[]
 for line in (out or "").splitlines():
  line=line.strip()
  if not line or "|" not in line:continue
  parts=line.split("|",3)
  if len(parts)<4:continue
  try:pid=int(parts[0]);ppid=int(parts[1]);ws=int(parts[2])
  except Exception:continue
  rows.append({"pid":pid,"ppid":ppid,"ws":ws,"cmd":parts[3]})
 return rows
def _kill_pid(pid):
 try:
  if os.name=="nt":_run(["taskkill","/PID",str(pid),"/F","/T"],capture_output=True,timeout=8)
  else:
   import signal
   os.kill(int(pid),signal.SIGKILL)
 except Exception:pass
 _set_upc(False,0.0)
def _is_venvish(cmd,venv):
 c=(cmd or "").lower().replace("/","\\")
 return bool(venv) and (".venv\\scripts\\python" in c or ".venv\\bin\\python" in c or venv.lower().replace("/","\\") in c)
def stop_strays(r=None,keep_venv=True):
 r=r or _ai_root();venv=_venv_py(r) if r else "";killed=[];procs=_ps_list_serve()
 venv_pids={p["pid"] for p in procs if _is_venvish(p.get("cmd"),venv)}
 for p in procs:
  ok=_is_venvish(p.get("cmd"),venv) or (p.get("ppid") in venv_pids)
  if keep_venv and ok:continue
  _kill_pid(p["pid"]);killed.append(p["pid"])
 return killed
def _lock_path(r=None):
 r=r or _ai_root();return os.path.join(r,"logs",".launching") if r else ""
def clear_launch_lock(r=None):
 lock=_lock_path(r)
 if lock and os.path.isfile(lock):
  try:os.remove(lock)
  except Exception:pass
def boot_state(r=None):
 up=is_up();r=r or _ai_root();venv=_venv_py(r) if r else "";procs=_ps_list_serve()
 venv_pids={p["pid"] for p in procs if _is_venvish(p.get("cmd"),venv)}
 good=[];bad=[]
 for p in procs:
  ok=_is_venvish(p.get("cmd"),venv) or (p.get("ppid") in venv_pids)
  (good if ok else bad).append(p)
 tops=[p for p in procs if p.get("ppid") not in {x["pid"] for x in procs}]
 lock=_lock_path(r);age=None
 if lock and os.path.isfile(lock):
  age=int(time.time()-os.path.getmtime(lock))
  if age>180 and not up:clear_launch_lock(r);age=None
 if up:
  return {"phase":"up","procs":procs,"good":good,"bad":bad,"tops":tops,"n":len(procs),"lock_age_s":age}
 if bad and not good:return {"phase":"thrash","procs":procs,"bad":bad,"good":good,"tops":tops,"lock_age_s":age}
 if good or bad:return {"phase":"booting","procs":procs,"good":good,"bad":bad,"tops":tops,"lock_age_s":age}
 if age is not None and age<120:return {"phase":"booting","procs":[],"lock_age_s":age}
 if age is not None and age>=120:clear_launch_lock(r)
 return {"phase":"down","procs":[]}
def _safe_env(mode,r,bake,port):
 env=dict(os.environ)
 thr=str(os.environ.get("AMNI_CPU_THREADS") or "4")
 env["AMNI_CPU_THREADS"]=thr
 for k in ("OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS","TORCH_NUM_THREADS"):
  env[k]=thr
 env["AMNI_EMBED_DEVICE"]=os.environ.get("AMNI_EMBED_DEVICE") or "cuda"
 env["AMNI_PORT"]=str(port)
 env["AMNI_NO_CHORD"]="1";env["AMNI_MCQ_SAMPLES"]="1"
 env["AMNI_NO_LEARNING_DAEMON"]=os.environ.get("AMNI_NO_LEARNING_DAEMON") or "1"
 env["AMNI_OAI_REVIEW"]=os.environ.get("AMNI_OAI_REVIEW") or "1"
 env["AMNI_NO_SELF_EVOLVE_BANK"]=os.environ.get("AMNI_NO_SELF_EVOLVE_BANK") or "1"
 env["AMNI_NO_FEDERATION_MOUNT"]=os.environ.get("AMNI_NO_FEDERATION_MOUNT") or "1"
 env["AMNI_CORPUS_PTEX_MOUNT"]=os.environ.get("AMNI_CORPUS_PTEX_MOUNT") or "0"
 env["AMNI_FIT_ON_MOUNT"]=os.environ.get("AMNI_FIT_ON_MOUNT") or "0"
 env["AMNI_CHAT_BRIEF_TOKENS"]=os.environ.get("AMNI_CHAT_BRIEF_TOKENS") or "180"
 env["PYTHONUNBUFFERED"]="1"
 env["AMNI_RESERVE_DISPLAY_GPU"]=os.environ.get("AMNI_RESERVE_DISPLAY_GPU") or "1"
 env["AMNI_NO_NVFP4"]="1"
 env["AMNI_PIN_BAKE"]="1"
 env["AMNI_BAKE"]=os.path.join(r,bake) if not os.path.isabs(bake) else bake
 if mode=="heavy":
  env["AMNI_ADAM_TIER"]="heavy"
  env["AMNI_CHAT_BRIEF_TOKENS"]=os.environ.get("AMNI_CHAT_BRIEF_TOKENS") or "220"
 else:
  env["AMNI_ADAM_TIER"]="light"
 return env
def start(mode="light",bake=None):
 r=_ai_root()
 if not r:return {"ok":False,"reason":"Amni-Ai repo not found"}
 mode=(mode or "light").lower();mode=mode if mode in ("light","heavy") else "light"
 if bake:
  abs_b=bake if os.path.isabs(bake) else os.path.join(r,bake)
  if not _bake_usable(abs_b):return {"ok":False,"reason":"bake not loadable (needs config.json + manifest): "+str(bake)}
  bake=os.path.relpath(abs_b,r).replace("\\","/")
 else:bake=_resolve_bake(r,mode)
 st=boot_state(r);procs=st.get("procs") or [];age=int(st.get("lock_age_s") or 0);killed=[]
 tops=st.get("tops") or [p for p in procs if p.get("ppid") not in {x["pid"] for x in procs}]
 if st.get("phase")=="up" and len(tops)<=1 and not st.get("bad"):
  if _mode_matches_live(mode,bake):
   return {"ok":True,"already":True,"mode":mode,"bake":bake,"phase":"up","n":len(procs)}
  killed=stop_strays(r,keep_venv=False);time.sleep(1.5);clear_launch_lock(r)
 if st.get("phase")=="up" and (len(tops)>1 or st.get("bad")):
  killed=stop_strays(r,keep_venv=False);time.sleep(1.2)
  if is_up() and len([p for p in _ps_list_serve() if p.get("ppid") not in {x["pid"] for x in _ps_list_serve()}])<=1 and _mode_matches_live(mode,bake):
   return {"ok":True,"already":True,"mode":mode,"bake":bake,"phase":"up","cleaned":killed}
 if st.get("phase")=="booting" and (st.get("good") or st.get("procs")) and not st.get("bad") and age and age<150:
  return {"ok":True,"already_booting":True,"mode":mode,"phase":"booting","procs":st.get("procs") or [],"lock_age_s":age,"note":"Adam already loading — wait for /healthz"}
 killed=stop_strays(r,keep_venv=False);clear_launch_lock(r);time.sleep(1.0)
 st=boot_state(r)
 if st.get("phase")=="thrash":
  killed2=stop_strays(r,keep_venv=False);time.sleep(1.0);killed=(killed or [])+(killed2 or [])
  st=boot_state(r)
  if st.get("phase")=="thrash":
   return {"ok":False,"reason":"non-venv Adam serve thrashing (CPU/RAM). killed="+str(killed),"phase":"thrash","procs":st.get("procs")}
 if st.get("phase")=="booting" and (st.get("good") or st.get("procs")) and not st.get("bad"):
  age2=int(st.get("lock_age_s") or 0)
  if age2 and age2<150:
   return {"ok":True,"already_booting":True,"mode":mode,"phase":"booting","procs":st.get("procs") or [],"note":"Adam already loading — wait for /healthz"}
  killed2=stop_strays(r,keep_venv=False);clear_launch_lock(r);time.sleep(1.0);killed=(killed or [])+(killed2 or [])
 py=_venv_py(r)
 if not py:
  return {"ok":False,"reason":"Amni-Ai .venv missing — system Python has no ROCm CUDA and will thrash RAM. Create/fix Amni-Ai/.venv first."}
 try:
  probe=_run([py,"-c","import torch;print('1' if torch.cuda.is_available() else '0')"],cwd=r,capture_output=True,text=True,timeout=45)
 except Exception as e:
  return {"ok":False,"reason":"torch probe failed: "+str(e)[:160],"phase":"down"}
 if (probe.stdout or "").strip()!="1":
  return {"ok":False,"reason":"Amni-Ai .venv torch has no CUDA — refuse CPU boot (RAM thrash). Fix ROCm torch in .venv.","probe":((probe.stderr or probe.stdout) or "")[:300]}
 port=os.environ.get("ADAM_PORT","7700")
 env=_safe_env(mode,r,bake,port)
 logdir=os.path.join(r,"logs");os.makedirs(logdir,exist_ok=True)
 lock=_lock_path(r)
 try:
  fd=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY);os.write(fd,str(time.time()).encode());os.close(fd)
 except FileExistsError:
  return {"ok":True,"already_booting":True,"mode":mode,"phase":"booting","note":"another caller claimed the launch lock this instant - wait for /healthz"}
 except Exception:pass
 out_path=os.path.join(r,"adam_delve_boot.out.log");err_path=os.path.join(r,"adam_delve_boot.err.log")
 serve_py=os.path.join(r,"scripts","amni_serve.py")
 cmd=[py,"-u",serve_py,"--host","127.0.0.1","--port",str(port),"--cors","--seed","--bake",bake] if os.path.isfile(serve_py) else [py,"-m","amni.cli","serve","--host","127.0.0.1","--port",str(port),"--cors","--seed","--bake",bake]
 try:
  out_f=open(out_path,"ab");err_f=open(err_path,"ab")
  kwargs={"cwd":r,"env":env,"stdout":out_f,"stderr":err_f}
  if os.name=="nt":
   kwargs["creationflags"]=getattr(subprocess,"CREATE_NO_WINDOW",0)|getattr(subprocess,"DETACHED_PROCESS",0)
   kwargs["close_fds"]=False
  else:
   kwargs["start_new_session"]=True;kwargs["close_fds"]=True
  proc=_popen(cmd,**kwargs)
 except Exception as e:
  clear_launch_lock(r);return {"ok":False,"error":str(e),"phase":"down"}
 return {"ok":True,"starting":True,"mode":mode,"bake":bake,"pid":proc.pid,"py":py,"phase":"booting","killed":killed,"log_out":out_path,"log_err":err_path,"note":"GPU boot via .venv only — wait ~30-120s for /healthz; do not click Start again"}
def restart(mode="light",wait=True,budget=240,bake=None):
 """Hot restart: kill every serve (venv included), clear the launch lock, relaunch the same
 bake, and by default BLOCK until /healthz answers or the budget runs out. This is the one
 call a Braid seat needs after editing Amni-Ai code — a running serve never re-imports
 patched modules, so disk fixes are inert until the process cycles."""
 r=_ai_root()
 if not r:return {"ok":False,"reason":"Amni-Ai repo not found"}
 killed=stop_strays(r,keep_venv=False)
 deadline=time.time()+20
 while time.time()<deadline and _ps_list_serve():time.sleep(0.6)
 leftovers=_ps_list_serve()
 for p in leftovers:_kill_pid(p["pid"])
 clear_launch_lock(r);time.sleep(1.0)
 res=start(mode,bake=bake)
 res["restarted"]=True;res["killed_prev"]=killed+[p["pid"] for p in leftovers]
 if not res.get("ok"):return res
 if wait:
  t0=time.time()
  while time.time()-t0<budget:
   if is_up():
    res["phase"]="up";res["wait_s"]=round(time.time()-t0,1)
    try:res["health"]=health()
    except Exception:pass
    # Never report a swap that did not happen: a stale serve that survived the kill would
    # answer /healthz with the OLD model and every "new model" probe would be a lie.
    lb=live_bake();res["live_bake"]=lb
    want=(res.get("bake") or "").replace("\\","/").lower()
    if want and lb and os.path.basename(want.rstrip("/"))!=os.path.basename(lb.rstrip("/").lower()):
     res["ok"]=False;res["phase"]="wrong_bake"
     res["reason"]="requested "+want+" but the live serve is running "+lb+" — kill strays and retry"
    return res
   time.sleep(3.0)
  res["ok"]=False;res["phase"]="timeout";res["reason"]="no /healthz within "+str(budget)+"s — check "+os.path.join(r,"adam_delve_boot.err.log")
 return res
def status(mode="light"):
 st=boot_state();up=st.get("phase")=="up"
 h=health() if up else {}
 return {"up":up,"phase":st.get("phase"),"health":h,"mode":mode,"procs":st.get("procs") or [],"bad":st.get("bad") or [],"fallback":True}
GPU=threading.RLock()
def ask(*a,**k):
 with GPU:return _ask(*a,**k)
def ask_agentic(*a,**k):
 with GPU:return _ask_agentic(*a,**k)
