_EXP=[0]*512;_LOG=[0]*256
_x=1
for _i in range(255):
    _EXP[_i]=_x;_LOG[_x]=_i
    _x<<=1
    if _x&0x100:_x^=0x11D
for _i in range(255,512):_EXP[_i]=_EXP[_i-255]
def _mul(a,b):return 0 if (not a or not b) else _EXP[_LOG[a]+_LOG[b]]
def _gen(n):
    g=[1]
    for i in range(n):
        ng=[0]*(len(g)+1)
        for j in range(len(g)):
            ng[j]^=g[j];ng[j+1]^=_mul(g[j],_EXP[i])
        g=ng
    return g
def _ec(data,n):
    g=_gen(n);res=[0]*n
    for d in data:
        f=d^res[0];res=res[1:]+[0]
        if f:
            for j in range(n):res[j]^=_mul(g[j+1],f)
    return res
CAP={1:19,2:34,3:55,4:80,5:108}
ECN={1:7,2:10,3:15,4:20,5:26}
ALIGN={2:18,3:22,4:26,5:30}
FMT=0b111011111000100
def codewords(data):
    v=next((v for v in (1,2,3,4,5) if len(data)+2<=CAP[v]),None)
    if v is None:raise ValueError("payload too long for QR v5-L (%d bytes)"%len(data))
    bits="0100"+format(len(data),"08b")+"".join(format(b,"08b") for b in data)
    cap=CAP[v]*8
    bits+="0"*min(4,cap-len(bits))
    bits+="0"*((8-len(bits)%8)%8)
    cw=[int(bits[i:i+8],2) for i in range(0,len(bits),8)]
    pads=(0xEC,0x11)
    while len(cw)<CAP[v]:cw.append(pads[(len(cw)-len(bits)//8)%2])
    return v,cw+_ec(cw,ECN[v])
def template(v):
    n=17+4*v
    M=[[None]*n for _ in range(n)]
    def finder(r0,c0):
        for r in range(-1,8):
            for c in range(-1,8):
                rr,cc=r0+r,c0+c
                if 0<=rr<n and 0<=cc<n:
                    M[rr][cc]=1 if (0<=r<=6 and 0<=c<=6 and (r in (0,6) or c in (0,6) or (2<=r<=4 and 2<=c<=4))) else 0
    finder(0,0);finder(0,n-7);finder(n-7,0)
    for i in range(8,n-8):M[6][i]=(i+1)%2;M[i][6]=(i+1)%2
    a=ALIGN.get(v)
    if a:
        for r in range(-2,3):
            for c in range(-2,3):
                M[a+r][a+c]=1 if (abs(r)==2 or abs(c)==2 or (r==0 and c==0)) else 0
    M[4*v+9][8]=1
    f=[(FMT>>(14-i))&1 for i in range(15)]
    for i in range(6):M[8][i]=f[i]
    M[8][7]=f[6];M[8][8]=f[7];M[7][8]=f[8]
    for i in range(9,15):M[14-i][8]=f[i]
    for i in range(7):M[n-1-i][8]=f[i]
    for i in range(7,15):M[8][n-15+i]=f[i]
    return M
def walk(n,tmpl):
    col=n-1;up=True
    while col>0:
        if col==6:col-=1
        for i in range(n):
            r=(n-1-i) if up else i
            for c in (col,col-1):
                if tmpl[r][c] is None:yield r,c
        up=not up;col-=2
def matrix(text):
    data=text.encode("utf-8")
    v,cw=codewords(data)
    n=17+4*v
    tmpl=template(v)
    M=[row[:] for row in tmpl]
    bits="".join(format(b,"08b") for b in cw)
    k=0
    for r,c in walk(n,tmpl):
        b=int(bits[k]) if k<len(bits) else 0
        M[r][c]=b^(1 if (r+c)%2==0 else 0)
        k+=1
    return M
def svg(text,scale=6,dark="#14161A",light="#FFFFFF"):
    M=matrix(text);n=len(M);q=4;S=(n+2*q)*scale
    cells="".join('<rect x="%d" y="%d" width="%d" height="%d"/>'%((c+q)*scale,(r+q)*scale,scale,scale) for r in range(n) for c in range(n) if M[r][c])
    return ('<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d" viewBox="0 0 %d %d" shape-rendering="crispEdges">'
     '<rect width="%d" height="%d" fill="%s"/><g fill="%s">%s</g></svg>')%(S,S,S,S,S,S,light,dark,cells)
