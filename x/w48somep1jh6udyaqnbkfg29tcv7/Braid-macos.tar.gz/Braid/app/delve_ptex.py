import os,re,json,time,threading,urllib.request
_LOCK=threading.Lock()
ROOT=os.path.dirname(os.path.abspath(__file__))
def _ai_root():
    """One resolver, in delve_adam. This module already imports it, and two copies of a path
    rule is how the frozen build ended up disagreeing with itself about where Amni-Ai is."""
    try:
        import delve_adam as _A
        return _A._ai_root()
    except Exception:
        c=os.path.normpath(os.path.join(ROOT,"..","Amni-Ai"))
        return c if os.path.isdir(c) else ""
def _base():
    return "http://"+os.environ.get("ADAM_HOST","127.0.0.1")+":"+os.environ.get("ADAM_PORT","7700")
def _adam_up():
    try:
        import delve_adam
        return delve_adam.is_up()
    except Exception:return False
def _post(path,payload,timeout=8):
    data=json.dumps(payload).encode("utf-8")
    req=urllib.request.Request(_base()+path,data=data,headers={"Content-Type":"application/json"},method="POST")
    with urllib.request.urlopen(req,timeout=timeout) as r:return json.loads(r.read().decode("utf-8","replace") or "{}")
def _pairs_path():
    p=(os.environ.get("AMNI_DELVE_PAIRS") or "").strip()
    if p:return p
    r=_ai_root();d=os.path.join(r,"lessons") if r else _data_lessons()
    os.makedirs(d,exist_ok=True);return os.path.join(d,"delve_debates_ptex.json")
def _data_lessons():
    """No Amni-Ai checkout (frozen installs especially): lessons belong in the DATA home,
    never beside the code — a onefile build's ROOT is a temp dir wiped on exit."""
    try:
        from delve import DATA as _dd
        d=os.path.join(_dd,"lessons")
    except Exception:d=os.path.join(ROOT,"lessons")
    os.makedirs(d,exist_ok=True);return d
_PTEX_STOP=set("the a an is are was were what which when where why how this that these those and or but if then else for with from into over under about not no yes can could will would".split())
def recall_local(query,k=3,room=""):
    """Durable memory IS the pairs file. This is the always-available read side: no Adam,
    no HTTP — the same delve_debates_ptex.json that feed() has been appending all along,
    scored by token overlap. Adam's atlas adds semantic recall ON TOP when it is up."""
    toks=[t for t in re.findall(r'[a-z0-9.]{3,}',str(query or "").lower()) if t not in _PTEX_STOP][:12]
    if not toks:return []
    try:
        with _LOCK:pairs=(json.load(open(_pairs_path(),encoding="utf-8")) or {}).get("pairs") or []
    except Exception:return []
    need=2 if len(toks)>=3 else 1
    # Durable memory is still ONE always-available file, and it is no longer room-blind. A
    # pair carries the conversation it was learned in (index 2); a room only reads its own
    # rows plus untagged legacy ones. Token overlap alone put options-desk rows into a model
    # compression room, because generic words ("goal", "ran", "print") match anything.
    rk=str(room or "").strip()
    scored=[]
    for pr in pairs[-4000:]:
        try:q,a=str(pr[0]),str(pr[1])
        except Exception:continue
        if rk:
            tag=str(pr[2]) if (isinstance(pr,(list,tuple)) and len(pr)>2 and pr[2]) else ""
            if tag and tag!=rk:continue
        blob=(q+" "+a).lower()
        sc=sum(1 for t in toks if t in blob)
        if sc>=need:scored.append((sc,re.sub(r'\s+',' ',a).strip()[:300]))
    scored.sort(key=lambda x:-x[0])
    seen=set();out=[]
    for sc,a in scored:
        if a and a not in seen:seen.add(a);out.append(a)
        if len(out)>=k:break
    return out
def _append_pairs(new):
    p=_pairs_path()
    with _LOCK:
        data={"grid":48,"pca_dim":6,"pairs":[]}
        if os.path.exists(p):
            try:data=json.load(open(p,encoding="utf-8"))
            except Exception:data={"grid":48,"pca_dim":6,"pairs":[]}
        data.setdefault("pairs",[]).extend(new)
        json.dump(data,open(p,"w",encoding="utf-8"),ensure_ascii=False)
    return p
def _record(ai,question,kind,first,last,corr,session_id,timeout=8):
    payload={"task":question,"approach":"Amni-Delve "+kind+" — "+ai,"outcome":last[:600],
     "lesson":(("PEER CORRECTION — do not repeat this: "+corr)[:500] if corr else last[:500]),
     "success":(False if corr else None),"session_id":"delve_"+str(session_id),
     "kind":("peer_corrected" if corr else kind),"method":("Amni-Delve "+kind+" — "+ai)[:200],
     "why":(corr[:300] if corr else ""),"errors":([corr[:200]] if corr else None)}
    return bool((_post("/memory/coding-attempt",payload,timeout=timeout) or {}).get("recorded"))
def _SEATS():
    try:
        from delve import AGENTS
        return set(AGENTS)
    except Exception:return {"Claude","Grok","Google","Adam","OpenAI","Copilot","Cursor","OpenCode"}
def feed(question,items,session_id,kind="debate",corrections=None,room=""):
    question=(question or "").strip() or ("[Amni-Delve "+kind+"]")
    corr=corrections if isinstance(corrections,dict) else {}
    by={}
    for who,text in items:
        if who in _SEATS() and (text or "").strip():by.setdefault(who,[]).append(text.strip())
    if not by:return {"ok":False,"reason":"no usable messages"}
    pairs=[];recorded=0;corrected=0;todo=[]
    for ai,msgs in by.items():
        first=msgs[0];last=msgs[-1];c=(corr.get(ai) or "").strip()
        corrected+=1 if c else 0
        rk=str(room or session_id or "")
        pairs.append([question,(("[REJECTED by peers] "+c) if c else last),rk])
        if first!=last:pairs.append(["["+ai+" first take] "+question,first,rk])
        todo.append((ai,first,last,c))
    path=_append_pairs(pairs)
    up=_adam_up();deadline=time.time()+float(os.environ.get("AMNI_DELVE_PTEX_BUDGET","20"));stalled=""
    for ai,first,last,c in (todo if up else []):
        left=deadline-time.time()
        if left<=0.5:stalled=stalled or "budget";break
        try:recorded+=1 if _record(ai,question,kind,first,last,c,session_id,timeout=min(8.0,left)) else 0
        except Exception as e:stalled=str(e)[:120];break
    return {"ok":True,"pairs":len(pairs),"ledger_records":recorded,"corrected":corrected,"file":os.path.basename(path),"adam_repo":bool(_ai_root()),"ledger_skipped":(not up),"ledger_stalled":stalled}
def commit(adam=None):
    if not _adam_up():return {"ok":False,"error":"Adam offline","hint":"lessons are still banked on disk; commit needs Adam up on "+_base()}
    try:return {"ok":True,**(_post("/api/delve/commit",{},timeout=180) or {})}
    except Exception as e:return {"ok":False,"error":str(e)[:200],"hint":"needs Adam up on "+_base()+" (its own encoder does the PTEX fit)"}
