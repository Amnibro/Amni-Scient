"""delve_autoloop — autonomous pair-coding loop over the Amni-Delve subscription CLIs: Claude (CODER) and Grok (REVIEWER) alternate turns on one task inside a git workspace, every turn gated by a verify command; double-fail reverts to the last green commit; stops on VERDICT: DONE with green verify, --cycles cap, or the E-STOP file (.delve_stop in the repo). No API keys — same claude/grok CLIs as delve.py. Run: python delve_autoloop.py --task "build X; acceptance: tests pass" --repo workspace/demo --verify "python -m pytest -q" [--cycles 6] [--claude-model sonnet] [--dry]"""
import sys,os,json,subprocess,tempfile,argparse,datetime,shutil
ROOT=os.path.dirname(os.path.abspath(__file__))
SESS=os.path.join(ROOT,"sessions")
def which(n,fb):
    p=shutil.which(n);return p if p else (fb if os.path.exists(fb) else n)
CLAUDE=which("claude",os.path.expanduser("~/.local/bin/claude.exe" if os.name=="nt" else "~/.local/bin/claude"))
GROK=which("grok",os.path.expanduser("~/.grok/bin/grok.exe" if os.name=="nt" else "~/.grok/bin/grok"))
PERM=["--permission-mode","bypassPermissions"]
ap=argparse.ArgumentParser()
ap.add_argument('--task',default='');ap.add_argument('--task-file',default='')
ap.add_argument('--repo',default=os.path.join(ROOT,'workspace','autoloop'))
ap.add_argument('--verify',required=True)
ap.add_argument('--cycles',type=int,default=6)
ap.add_argument('--claude-model',default='')
ap.add_argument('--grok-model',default='')
ap.add_argument('--timeout',type=int,default=900)
ap.add_argument('--dry',action='store_true')
a=ap.parse_args()
TASK=(open(a.task_file,encoding='utf-8').read() if a.task_file else a.task).strip()
if not TASK:sys.exit('need --task or --task-file')
REPO=os.path.abspath(a.repo);os.makedirs(REPO,exist_ok=True);os.makedirs(SESS,exist_ok=True)
STOP=os.path.join(REPO,'.delve_stop')
LOG=os.path.join(SESS,f'autoloop_{datetime.datetime.now():%Y%m%d_%H%M%S}.md')
def log(who,text):
    line=f'\n## {who} — {datetime.datetime.now():%H:%M:%S}\n{text}\n'
    open(LOG,'a',encoding='utf-8').write(line);print(f'[{who}] {text[:160]}',flush=True)
def sh(cmd,timeout=120):
    if isinstance(cmd,str):
        for dp,dn,_ in os.walk(REPO):
            if '__pycache__' in dn:shutil.rmtree(os.path.join(dp,'__pycache__'),ignore_errors=True)
    try:
        r=subprocess.run(cmd,shell=isinstance(cmd,str),cwd=REPO,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=timeout,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
        return r.returncode,(r.stdout or '')+(r.stderr or '')
    except subprocess.TimeoutExpired:return -1,'[verify timeout]'
    except Exception as e:return -1,f'[verify error] {e}'
def git(*args):
    return sh(['git']+list(args))
def ensure_git():
    if git('rev-parse','--is-inside-work-tree')[0]!=0:
        git('init');git('add','-A');git('-c','user.email=delve@amni.local','-c','user.name=delve','commit','-m','autoloop init','--allow-empty')
def checkpoint(n):
    git('add','-A');git('-c','user.email=delve@amni.local','-c','user.name=delve','commit','-m',f'autoloop cycle {n} green','--allow-empty')
def revert_to_green():
    git('reset','--hard');git('clean','-fd')
def call_claude(prompt,cont):
    cmd=[CLAUDE,'-p','--output-format','text']+PERM+(['--continue'] if cont else [])+(['--model',a.claude_model] if a.claude_model else [])
    try:
        p=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,cwd=REPO,text=True,encoding='utf-8',errors='replace')
        out,err=p.communicate(input=prompt,timeout=a.timeout)
        return (out or '').strip() or ('[claude error] '+(err or 'no output').strip())
    except subprocess.TimeoutExpired:
        p.kill();return '[claude timeout]'
    except Exception as e:return f'[claude error] {e}'
def call_grok(prompt,cont):
    pf=tempfile.NamedTemporaryFile('w',suffix='.txt',delete=False,encoding='utf-8');pf.write(prompt);pf.close()
    cmd=[GROK,'--prompt-file',pf.name,'--output-format','plain']+PERM+(['-c'] if cont else [])+(['--model',a.grok_model] if a.grok_model else [])
    try:
        p=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,cwd=REPO,text=True,encoding='utf-8',errors='replace')
        out,err=p.communicate(timeout=a.timeout)
        return (out or '').strip() or ('[grok error] '+(err or 'no output').strip())
    except subprocess.TimeoutExpired:
        p.kill();return '[grok timeout]'
    except Exception as e:return f'[grok error] {e}'
    finally:
        try:os.unlink(pf.name)
        except Exception:pass
_dry_state={'fixed':False}
def dry_agent(who,prompt):
    tgt=os.path.join(REPO,'add.py')
    if who=='Claude':
        open(tgt,'w',encoding='utf-8').write('def add(a,b):\n    return a-b\n')
        return 'Wrote add.py implementing add().'
    open(tgt,'w',encoding='utf-8').write('def add(a,b):\n    return a+b\n')
    _dry_state['fixed']=True
    return 'Fixed the sign bug in add.py. VERDICT: DONE'
def agent(who,prompt,cont):
    if a.dry:return dry_agent(who,prompt)
    return call_claude(prompt,cont) if who=='Claude' else call_grok(prompt,cont)
def stopped():
    return os.path.exists(STOP)
def verify():
    rc,out=sh(a.verify,timeout=max(120,a.timeout//3))
    return rc==0,out[-1200:]
CODER_SYS=f'''You are the CODER in an autonomous pair-programming loop with a reviewer agent. You have full tools in this workspace ({REPO}).
TASK:
{TASK}
Rules: make the SMALLEST change that advances the task. The verify command is: {a.verify}
After acting, reply with a 3-line summary of what you changed. If the acceptance criteria are fully met, include the exact line "VERDICT: DONE".'''
def main():
    ensure_git()
    log('System',f'task={TASK[:200]} | repo={REPO} | verify={a.verify} | cycles={a.cycles} | claude_model={a.claude_model or "default"} | dry={a.dry}')
    ok0,out0=verify();green=ok0
    if ok0:checkpoint(0)
    log('System',f'baseline verify: {"GREEN" if ok0 else "RED"}')
    feedback=f'Baseline verify output:\n{out0}'
    ccont=gcont=False
    for cyc in range(1,a.cycles+1):
        if stopped():log('System','E-STOP file found — halting');break
        r=agent('Claude',CODER_SYS+f'\n\nCycle {cyc}. Reviewer/verify feedback from last round:\n{feedback}',ccont);ccont=True
        log('Claude',r)
        ok,vout=verify();log('System',f'verify after coder: {"GREEN" if ok else "RED"}')
        if ok:
            checkpoint(cyc);green=True
            if 'VERDICT: DONE' in r:log('System',f'DONE at cycle {cyc} (coder verdict + green verify)');return
            feedback=f'Verify GREEN. Continue toward full acceptance.\n{vout}'
            continue
        if stopped():log('System','E-STOP — halting');break
        diff=git('diff','HEAD')[1][-3000:]
        rr=agent('Grok',f'''You are the REVIEWER in an autonomous pair-programming loop. The coder's change FAILED verification. You have full tools in this workspace ({REPO}).
TASK:
{TASK}
Verify command: {a.verify}
Failure output:
{vout}
Diff since last green:
{diff}
Fix the failure directly with the smallest change. Reply with a 3-line summary. If acceptance criteria are fully met include the exact line "VERDICT: DONE".''',gcont);gcont=True
        log('Grok',rr)
        ok2,vout2=verify();log('System',f'verify after reviewer: {"GREEN" if ok2 else "RED"}')
        if ok2:
            checkpoint(cyc)
            if 'VERDICT: DONE' in rr:log('System',f'DONE at cycle {cyc} (reviewer verdict + green verify)');return
            feedback=f'Reviewer fixed the failure. Verify GREEN.\n{vout2}'
        else:
            if green:revert_to_green();feedback=f'Both agents failed cycle {cyc}; workspace REVERTED to last green. Try a different approach.\nLast failure:\n{vout2}'
            else:feedback=f'Still RED (no green baseline to revert to). Failure:\n{vout2}'
            log('System','double-fail — '+('reverted to last green' if green else 'no green baseline'))
    log('System',f'loop ended without DONE (cycles={a.cycles}) — transcript: {LOG}')
if __name__=='__main__':main()
