"""Child processes that do not flash a console window.

On Windows every `subprocess` call that resolves to a console program gets its OWN console
unless it is told not to. Braid polls constantly - Adam's health, `tasklist`, `taskkill`, the
torch probe, `netsh`, `powershell`, the CLI `--version` checks behind the model lists - so the
default behaviour is a black cmd window blinking on the desktop every few seconds, forever.

Two flags are needed, not one. CREATE_NO_WINDOW covers a console program; STARTUPINFO with
SW_HIDE covers the ones that ask for a window anyway. DETACHED_PROCESS is deliberately NOT in
here: it also detaches the pipes we read the seat's answer from.

Use `run()` / `popen()` in place of `subprocess.run` / `subprocess.Popen` everywhere. On POSIX
the only addition is start_new_session, so a hung seat's whole process group can be killed
with os.killpg - a bare p.kill() leaves node children holding the pipes open.
"""
import os,subprocess
IS_WIN=os.name=="nt"
NO_WINDOW=getattr(subprocess,"CREATE_NO_WINDOW",0) if IS_WIN else 0
def _si():
    if not IS_WIN:return None
    si=subprocess.STARTUPINFO()
    si.dwFlags|=subprocess.STARTF_USESHOWWINDOW
    si.wShowWindow=0
    return si
def hide(kw=None):
    """Merge the hide flags into a kwargs dict without stamping on an explicit choice."""
    kw=dict(kw or {})
    if not IS_WIN:
        kw.setdefault("start_new_session",True)
        return kw
    kw["creationflags"]=int(kw.get("creationflags") or 0)|NO_WINDOW
    if kw.get("startupinfo") is None:kw["startupinfo"]=_si()
    return kw
def run(*a,**kw):return subprocess.run(*a,**hide(kw))
def popen(*a,**kw):return subprocess.Popen(*a,**hide(kw))
def check_output(*a,**kw):return subprocess.check_output(*a,**hide(kw))
