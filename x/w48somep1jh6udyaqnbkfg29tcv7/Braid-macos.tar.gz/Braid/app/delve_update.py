"""Auto-update, without turning Braid into a remote code execution channel.

An updater that downloads and runs a binary is the most dangerous code in the product:
whoever controls the download controls every machine running it. So nothing is trusted
on the strength of where it came from.

  * The release MANIFEST is signed with an Ed25519 key whose private half never
    touches the server. A fully compromised licence Worker still cannot push a build.
  * The manifest names the binary's SHA-256. A compromised CDN cannot swap the file.
  * Downgrades are refused - "update" to an older version is how you get someone back
    onto a build with a known hole.
  * HTTPS only.
  * Nothing is ever installed over a running session.

If any of those checks fail the update is discarded and Braid carries on unchanged.

Three modes, set by config "auto_update":
  off    - never look.
  notify - look, then wait for the user to press "Update and restart".
  auto   - (default) fetch and verify in the background, then swap the binary only while
           Braid is already exiting, so the next launch is the new build. No interruption
           mid-session, no button, and still no unsigned or unhashed byte goes anywhere.
"""
import os,sys,re,json,time,shutil,hashlib,tempfile,subprocess,urllib.request,urllib.error
import delve_crypto as CR
try:
    from delve import VERSION as CURRENT
except Exception:CURRENT="0.0.0"
UA={"User-Agent":"Braid-Updater/1.0"}
def _channel():
    c=os.environ.get("BRAID_CHANNEL")
    if c:return c
    try:c=str((_cfg() or {}).get("update_channel") or "").strip()
    except Exception:c=""
    return c or "beta"
DEFAULT_MODE="auto"
# Baked in on purpose. delve_config.json is deliberately NOT bundled (it would pre-answer
# setup), so without these a fresh install has no feed and no key: it cannot update at all,
# which is exactly how every shipped copy has behaved. Both values are public - and the key
# belonging to the binary rather than to a server is what makes the signature check worth
# anything, since a key fetched from a server can be swapped by whoever controls it.
DEFAULT_FEED="https://braid-license.amnibro7.workers.dev/update/latest"
RELEASE_PUBKEY="f1edf2840456ef4ac2da96cdf1cc13d05e624aaa47427276c4ab2c77b404e557"
def _cfg():
    try:
        import delve
        c=delve.load_cfg()
        return c
    except Exception:return {}
def feed_url(cfg=None):
    c=cfg if cfg is not None else _cfg()
    u=(c.get("update_url") or "").strip()
    if not u:
        base=(c.get("license_url") or "").strip().rstrip("/")
        u=(base+"/update/latest") if base else DEFAULT_FEED
    return u
def release_pubkey(cfg=None):
    c=cfg if cfg is not None else _cfg()
    return (c.get("release_pubkey") or os.environ.get("BRAID_RELEASE_PUBKEY") or RELEASE_PUBKEY).strip()
def vtuple(v):
    return tuple(int(x) for x in re.findall(r'\d+',str(v or "0"))[:4] or [0])
def newer(a,b):
    """Is a strictly newer than b? Equal or older is not an update."""
    return vtuple(a)>vtuple(b)
def frozen():
    return bool(getattr(sys,"frozen",False) or hasattr(sys,"_MEIPASS"))
def exe_path():
    return os.path.abspath(sys.executable if frozen() else sys.argv[0])
def plat():
    import platform as _p
    a=(_p.machine() or "").lower()
    arch="arm64" if a in ("arm64","aarch64") else "x64"
    return ("win" if os.name=="nt" else ("mac" if sys.platform=="darwin" else "linux"))+"-"+arch
def _get(url,timeout=20,binary=False,cap=200*1024*1024):
    if not str(url).lower().startswith("https://"):
        raise ValueError("refusing a non-HTTPS update source")
    req=urllib.request.Request(url,headers=UA)
    with urllib.request.urlopen(req,timeout=timeout) as r:
        data=r.read(cap+1)
    if len(data)>cap:raise ValueError("update is implausibly large - refusing")
    return data if binary else json.loads(data.decode("utf-8","replace") or "{}")
def check(cfg=None):
    """Look for a newer signed release. Never raises - a broken feed must not break Braid."""
    c=cfg if cfg is not None else _cfg()
    if str(c.get("auto_update",DEFAULT_MODE)).lower()=="off":
        return {"ok":True,"update":False,"reason":"updates are switched off"}
    url=feed_url(c);pub=release_pubkey(c)
    if not url:return {"ok":False,"error":"no update feed configured"}
    if not pub:return {"ok":False,"error":"no release public key configured — refusing to trust an unsigned update"}
    try:
        d=_get(url+("?channel="+_channel()))
    except Exception as e:
        return {"ok":False,"error":str(e)[:140]}
    man,sig=d.get("manifest"),d.get("sig")
    if not man or not sig:
        return {"ok":False,"error":"the feed did not return a signed manifest"}
    raw=man.encode("utf-8") if isinstance(man,str) else man
    if not CR.verify_hex(pub,raw,sig):
        return {"ok":False,"error":"the release signature did not verify — ignoring this update"}
    try:m=json.loads(man)
    except Exception:return {"ok":False,"error":"the manifest is not readable"}
    ver=str(m.get("version") or "")
    if not newer(ver,CURRENT):
        return {"ok":True,"update":False,"current":CURRENT,"latest":ver}
    # A manifest may carry per-platform artifacts under "platforms"; the top-level
    # url/sha256/size stay the Windows exe so every already-shipped client keeps working.
    art=(m.get("platforms") or {}).get(plat()) if isinstance(m.get("platforms"),dict) else None
    if art is None and os.name=="nt":art={k:m.get(k) for k in ("url","sha256","size")}
    if not art or not art.get("url"):
        return {"ok":True,"update":False,"current":CURRENT,"latest":ver,
                "reason":"no build published for this platform yet ("+plat()+")"}
    m=dict(m);m.update({k:art[k] for k in ("url","sha256","size") if art.get(k) is not None})
    if not str(m.get("url","")).lower().startswith("https://"):
        return {"ok":False,"error":"the manifest points somewhere that is not HTTPS"}
    if not re.fullmatch(r'[0-9a-f]{64}',str(m.get("sha256") or "")):
        return {"ok":False,"error":"the manifest has no usable sha256"}
    return {"ok":True,"update":True,"current":CURRENT,"latest":ver,"manifest":m,
            "notes":(m.get("notes") or "")[:2000],"size":m.get("size") or 0,
            "mode":str(c.get("auto_update",DEFAULT_MODE)).lower()}
def download(m,progress=None):
    """Fetch the build and prove it is the exact file the signed manifest described."""
    data=_get(m["url"],timeout=180,binary=True)
    got=hashlib.sha256(data).hexdigest()
    if got!=m["sha256"]:
        return {"ok":False,"error":"the download did not match the signed hash — discarded"}
    if m.get("size") and abs(len(data)-int(m["size"]))>1024:
        return {"ok":False,"error":"the download is not the size the manifest declared"}
    d=tempfile.mkdtemp(prefix="braid_update_")
    p=os.path.join(d,"Braid-%s%s"%(re.sub(r'[^0-9A-Za-z._-]','',str(m.get("version") or "new")),".exe" if os.name=="nt" else ""))
    with open(p,"wb") as f:f.write(data)
    if os.name!="nt":
        try:os.chmod(p,0o755)
        except Exception:pass
    return {"ok":True,"path":p,"sha256":got,"bytes":len(data)}
def _sha_file(p):
    h=hashlib.sha256()
    with open(p,"rb") as f:
        for chunk in iter(lambda:f.read(1048576),b""):h.update(chunk)
    return h.hexdigest()
# This script is spawned DETACHED, which means it has no console. Two consequences that
# cost a working updater if you forget them:
#   * `timeout` needs a console handle and returns instantly without one, turning the
#     wait-for-exit loop into a busy spin that gives up before Braid has closed. `ping`
#     sleeps correctly with no console, so it is the sleep here.
#   * `pause` on the failure path would block forever in a window nobody can see, so a
#     failure writes a note next to the staged build instead.
# Everything is called by absolute path: a user whose PATH carries unix tools (git bash
# ships a `find` that does something entirely different) must not shadow tasklist/find.
SWAP=r'''@echo off
rem Braid updater - waits for the running copy to exit, swaps the binary, restarts it.
rem The wait IS the copy: Windows refuses to overwrite a running image, so the copy simply
rem fails until Braid has exited. That needs no tasklist/find parsing to get right.
setlocal
set OLD=%~1
set NEW=%~2
set SYS=%SystemRoot%\System32
for /l %%i in (1,1,180) do (
  copy /y "%NEW%" "%OLD%" >nul 2>&1 && goto :done
  %SYS%\ping.exe -n 2 127.0.0.1 >nul
)
echo could not replace "%OLD%" - the new build is at "%NEW%" > "%~dp0update-failed.txt"
exit /b 1
:done
del "%NEW%" >nul 2>&1
start "" "%OLD%"
del "%~f0" >nul 2>&1
'''
def apply(new_path,sha256=""):
    """Windows will not let a running exe overwrite itself, so hand the swap to a
    detached script that waits for this process to exit first.

    The hash is checked again HERE, off the bytes actually on disk. download() proved the
    bytes it fetched, but between that and this the staged file is just a path - anything
    already running as the user could swap it, and the swap script would install it."""
    if not frozen():
        return {"ok":False,"error":"running from source — pull the repo instead"}
    if not os.path.isfile(new_path):
        return {"ok":False,"error":"the downloaded build is missing"}
    if sha256:
        try:on_disk=_sha_file(new_path)
        except Exception as e:return {"ok":False,"error":"could not re-check the staged build: "+str(e)[:120]}
        if on_disk!=sha256:
            try:os.remove(new_path)
            except Exception:pass
            return {"ok":False,"error":"the staged build changed after it was verified — discarded"}
    old=exe_path()
    if os.name!="nt":
        # POSIX lets a running binary's path be replaced (the live image keeps its inode),
        # so no detached script: copy beside the target, atomic-replace, relaunch delayed
        # so the exiting copy frees its port first.
        r=_posix_swap(new_path,old)
        if not r.get("ok"):return r
        try:subprocess.Popen(["/bin/sh","-c",'sleep 3; exec "$0"',old],start_new_session=True,close_fds=True)
        except Exception as e:
            return {"ok":True,"restarting":False,"old":old,"new":old,"note":"installed, but could not relaunch: "+str(e)[:120]}
        return {"ok":True,"restarting":True,"old":old,"new":old}
    bat=os.path.join(os.path.dirname(os.path.abspath(new_path)),"swap.cmd")
    with open(bat,"w",encoding="ascii",newline="\r\n") as f:f.write(SWAP)
    try:
        subprocess.Popen(["cmd","/c",bat,old,new_path,str(os.getpid())],
                         creationflags=0x00000008|0x00000200,close_fds=True)  # DETACHED|NEW_GROUP
    except Exception as e:
        return {"ok":False,"error":"could not start the updater: "+str(e)[:120]}
    return {"ok":True,"restarting":True,"old":old,"new":new_path}
def update_now(cfg=None):
    c=check(cfg)
    if not c.get("ok") or not c.get("update"):return c
    d=download(c["manifest"])
    if not d.get("ok"):return d
    a=apply(d["path"],d.get("sha256") or "")
    return {**a,"version":c.get("latest"),"staged":d["path"]}
def status(cfg=None):
    c=cfg if cfg is not None else _cfg()
    p=pending()
    return {"ok":True,"version":CURRENT,"frozen":frozen(),"channel":_channel(),
            "mode":str(c.get("auto_update",DEFAULT_MODE)).lower(),
            "feed":feed_url(c),"trusted":bool(release_pubkey(c)),
            "platform":plat(),"pending":(p or {}).get("version") or ""}
# --- "auto" mode: stage quietly now, swap on the way out -----------------------
# The manual path restarts Braid mid-session, which is the wrong trade when someone is
# three seats deep in a conversation. In "auto" the build is fetched and verified in the
# background, then swapped only once the process is already exiting - so the next launch
# is simply the new version and no session is ever interrupted.
SWAP_QUIET=r'''@echo off
rem Braid updater - waits for the closing copy to exit, swaps the binary, does NOT relaunch.
rem Same trick as SWAP: the copy itself is the wait, because Windows will not let a running
rem image be overwritten. Retries for ~6 minutes, then leaves a note and the staged build.
setlocal
set OLD=%~1
set NEW=%~2
set SYS=%SystemRoot%\System32
for /l %%i in (1,1,360) do (
  copy /y "%NEW%" "%OLD%" >nul 2>&1 && goto :done
  %SYS%\ping.exe -n 2 127.0.0.1 >nul
)
echo could not replace "%OLD%" - the new build is at "%NEW%" > "%~dp0update-failed.txt"
exit /b 1
:done
del "%NEW%" >nul 2>&1
del "%~f0" >nul 2>&1
'''
def _posix_swap(src,dst):
    """os.replace must stay on one filesystem (the download lands in /tmp, often tmpfs),
    so the copy goes beside the target first, then swaps atomically."""
    try:
        tmp=dst+".new"
        shutil.copy2(src,tmp);os.chmod(tmp,0o755)
        os.replace(tmp,dst)
        try:os.remove(src)
        except Exception:pass
        return {"ok":True}
    except Exception as e:
        return {"ok":False,"error":"could not swap the binary: "+str(e)[:120]}
def stage_dir():
    if os.name=="nt":
        base=os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
        d=os.path.join(base,"Braid","updates")
    else:
        try:
            from delve import DATA as _dd
        except Exception:_dd=os.path.join(os.path.expanduser("~"),".local","share","Braid")
        d=os.path.join(_dd,"updates")
    os.makedirs(d,exist_ok=True)
    return d
def _pending_file():
    return os.path.join(stage_dir(),"pending.json")
def clear_pending(drop_binary=True):
    try:
        d=json.loads(open(_pending_file(),encoding="utf-8").read() or "{}")
    except Exception:d={}
    if drop_binary:
        f=str(d.get("file") or "")
        if f and os.path.isfile(f):
            try:os.remove(f)
            except Exception:pass
    try:os.remove(_pending_file())
    except Exception:pass
def pending():
    """A staged build waiting for the next exit, or None. Cheap - the hash is re-proved
    at swap time, not here, because this is polled by the UI."""
    try:
        if not os.path.isfile(_pending_file()):return None
        d=json.loads(open(_pending_file(),encoding="utf-8").read() or "{}")
    except Exception:return None
    f=str(d.get("file") or "");ver=str(d.get("version") or "")
    if not f or not ver or not re.fullmatch(r'[0-9a-f]{64}',str(d.get("sha256") or "")):
        clear_pending();return None
    if not os.path.isfile(f):clear_pending();return None
    if not newer(ver,CURRENT):
        clear_pending();return None          # already on it - nothing to install
    return d
def stage(m):
    """Download + prove + park it somewhere the running copy will not touch again."""
    d=download(m)
    if not d.get("ok"):return d
    sd=stage_dir()
    dest=os.path.join(sd,os.path.basename(d["path"]))
    try:
        if os.path.isfile(dest):os.remove(dest)
        shutil.move(d["path"],dest)
    except Exception as e:
        return {"ok":False,"error":"could not park the update: "+str(e)[:120]}
    rec={"version":str(m.get("version") or ""),"sha256":d["sha256"],"file":dest,
         "bytes":d.get("bytes") or 0,"staged":int(time.time())}
    try:
        with open(_pending_file(),"w",encoding="utf-8") as f:json.dump(rec,f)
    except Exception as e:
        return {"ok":False,"error":"could not record the staged update: "+str(e)[:120]}
    return {"ok":True,"staged":dest,**rec}
def auto_tick(cfg=None):
    """One background pass. Only does anything in auto mode; never raises."""
    try:
        c=cfg if cfg is not None else _cfg()
        if str(c.get("auto_update",DEFAULT_MODE)).lower()!="auto":
            return {"ok":True,"update":False,"reason":"not in auto mode"}
        p=pending()
        if p:return {"ok":True,"update":True,"pending":p.get("version"),"already_staged":True}
        r=check(c)
        if not r.get("ok") or not r.get("update"):return r
        s=stage(r["manifest"])
        return {**s,"version":r.get("latest")}
    except Exception as e:
        return {"ok":False,"error":str(e)[:140]}
def apply_pending_on_exit():
    """Called as Braid shuts down. Re-proves the staged bytes, then hands the swap to a
    detached script that waits for this PID to die. No relaunch - the user closed Braid,
    so Braid stays closed; they just get the new build next time they open it."""
    if not frozen():return None
    d=pending()
    if not d:return None
    f=d["file"]
    try:
        if _sha_file(f)!=d["sha256"]:
            clear_pending();return {"ok":False,"error":"staged build changed after verification - discarded"}
    except Exception as e:
        return {"ok":False,"error":"could not re-check the staged build: "+str(e)[:120]}
    if os.name!="nt":
        r=_posix_swap(f,exe_path())
        if not r.get("ok"):return r
        clear_pending(drop_binary=True)
        return {"ok":True,"version":d.get("version"),"installs_on":"exit"}
    bat=os.path.join(stage_dir(),"swap-quiet.cmd")
    try:
        with open(bat,"w",encoding="ascii",newline="\r\n") as fh:fh.write(SWAP_QUIET)
        subprocess.Popen(["cmd","/c",bat,exe_path(),f,str(os.getpid())],
                         creationflags=0x00000008|0x00000200,close_fds=True)
    except Exception as e:
        return {"ok":False,"error":"could not start the updater: "+str(e)[:120]}
    clear_pending(drop_binary=False)          # the swap script owns the file from here
    return {"ok":True,"version":d.get("version"),"installs_on":"exit"}
