"""Files in and out of the room.

Uploads land in the workspace so every seat can actually read them, and anything the
room produces can be pulled back out. Both directions are jailed to the workspace -
an upload that escapes it is arbitrary file write, and a download that escapes it is
arbitrary file read, so the same check guards both.
"""
import os,re,json,time,base64,hashlib,mimetypes
UPLOAD_DIR="uploads"
MAX_BYTES=int(os.environ.get("BRAID_MAX_UPLOAD","33554432"))       # 32 MB
# Extensions that Windows will happily execute on a double-click. Braid has no reason
# to accept them, and a "download" that hands back a fresh .exe is a nasty surprise.
BLOCKED={".exe",".scr",".com",".pif",".bat",".cmd",".ps1",".psm1",".ps1xml",".vbs",".vbe",".js",
         ".jse",".wsf",".wsh",".wsc",".sct",".msi",".msp",".msc",".hta",".cpl",".jar",".lnk",
         ".reg",".dll",".sys",".url",".scf",".chm",".jnlp",".pyw",".pyz",".appref-ms",".application",
         ".gadget",".inf",".iso",".vhd",".vhdx",".desktop",".command",".terminal",".app"}
def _root(hub):
    return os.path.realpath(hub.cfg.get("workspace") or hub.work)
def _jail(hub,rel):
    root=_root(hub)
    p=os.path.realpath(os.path.join(root,str(rel or "").replace("\\","/").lstrip("/")))
    if p!=root and not p.startswith(root+os.sep):raise PermissionError("outside workspace")
    return p
def _rel(hub,p):
    r=os.path.relpath(p,_root(hub)).replace("\\","/")
    return "" if r=="." else r
def safe_name(name):
    """Strip anything that could climb out or collide with a device name."""
    n=os.path.basename(str(name or "").replace("\\","/"))
    n=re.sub(r'[\x00-\x1f<>:"|?*]','',n).strip().strip(".")
    n=re.sub(r'\s+',' ',n)[:120]
    if re.fullmatch(r'(?i)(con|prn|aux|nul|com[1-9]|lpt[1-9])(\..*)?',n or ""):n="_"+n
    return n or "file"
def _unique(path):
    if not os.path.exists(path):return path
    stem,ext=os.path.splitext(path)
    for i in range(2,999):
        p="%s (%d)%s"%(stem,i,ext)
        if not os.path.exists(p):return p
    return "%s-%d%s"%(stem,int(time.time()),ext)
def save(hub,name,data,subdir=UPLOAD_DIR):
    """data is raw bytes. Returns the workspace-relative path every seat can open."""
    if not isinstance(data,(bytes,bytearray)):
        return {"ok":False,"error":"upload was not binary"}
    if len(data)>MAX_BYTES:
        return {"ok":False,"error":"that file is larger than %d MB"%(MAX_BYTES//(1024*1024))}
    if not data:
        return {"ok":False,"error":"that file is empty"}
    n=safe_name(name)
    ext=os.path.splitext(n)[1].lower()
    if ext in BLOCKED:
        return {"ok":False,"error":"%s files are not accepted — Braid will not put an executable in your workspace"%ext}
    try:
        d=_jail(hub,subdir)
    except PermissionError:
        return {"ok":False,"error":"bad destination"}
    os.makedirs(d,exist_ok=True)
    p=_unique(os.path.join(d,n))
    try:
        with open(p,"wb") as f:f.write(data)
    except Exception as e:
        return {"ok":False,"error":"could not write it: "+str(e)[:120]}
    return {"ok":True,"path":_rel(hub,p),"name":os.path.basename(p),"bytes":len(data),
            "sha256":hashlib.sha256(data).hexdigest()[:16],"kind":kind_of(p)}
def kind_of(p):
    ext=os.path.splitext(p)[1].lower()
    if ext in (".png",".jpg",".jpeg",".gif",".webp",".bmp",".svg"):return "image"
    if ext in (".pdf",):return "pdf"
    if ext in (".csv",".tsv",".xlsx",".xls"):return "table"
    if ext in (".zip",".tar",".gz",".7z",".rar"):return "archive"
    if ext in (".md",".txt",".log",".json",".yaml",".yml",".xml",".html",".css"):return "text"
    if ext in (".py",".js",".ts",".rs",".go",".java",".c",".h",".cpp",".sh",".sql"):return "code"
    return "file"
def is_texty(p):
    try:
        with open(p,"rb") as f:head=f.read(8000)
    except Exception:return False
    return b"\x00" not in head
def peek(hub,rel,cap=4000):
    """A short readable excerpt, so a seat can act on an upload without a tool call."""
    try:p=_jail(hub,rel)
    except PermissionError:return ""
    if not os.path.isfile(p) or not is_texty(p):return ""
    try:
        with open(p,"rb") as f:raw=f.read(cap+1)
    except Exception:return ""
    t=raw[:cap].decode("utf-8","replace")
    return t+("\n…(truncated)" if len(raw)>cap else "")
def listing(hub,subdir=UPLOAD_DIR,cap=200):
    """Everything the room has taken in or produced, newest first."""
    out=[]
    try:root=_jail(hub,subdir)
    except PermissionError:return out
    if not os.path.isdir(root):return out
    for base,ds,fs in os.walk(root):
        ds[:]=[d for d in ds if not d.startswith(".")]
        for f in fs:
            if f.startswith("."):continue
            p=os.path.join(base,f)
            try:st=os.stat(p)
            except Exception:continue
            out.append({"path":_rel(hub,p),"name":f,"bytes":st.st_size,"ts":st.st_mtime,
                        "kind":kind_of(p)})
            if len(out)>=cap:break
    return sorted(out,key=lambda x:-x["ts"])
def read_bytes(hub,rel):
    """For download. Jailed, and it will not hand back an executable it refused to store."""
    try:p=_jail(hub,rel)
    except PermissionError:
        return None,"that path is outside the workspace"
    if not os.path.isfile(p):return None,"no such file"
    if os.path.splitext(p)[1].lower() in BLOCKED:
        return None,"Braid will not serve that file type"
    try:
        with open(p,"rb") as f:return f.read(),""
    except Exception as e:
        return None,str(e)[:120]
def ctype_for(p):
    t,_=mimetypes.guess_type(p)
    # never hand back text/html - it would run in the user's browser from our origin
    if not t or t in ("text/html","application/xhtml+xml","image/svg+xml"):
        return "application/octet-stream"
    return t
def delete(hub,rel):
    try:p=_jail(hub,rel)
    except PermissionError:return {"ok":False,"error":"outside workspace"}
    if not os.path.isfile(p):return {"ok":True,"gone":True}
    try:os.remove(p);return {"ok":True,"gone":True,"path":str(rel)}
    except Exception as e:return {"ok":False,"error":str(e)[:120]}
def brief(hub,files):
    """What gets appended to the user's message so every seat knows what arrived."""
    rows=[f for f in (files or []) if f.get("path")]
    if not rows:return ""
    L=["=== FILES ANTHONY ATTACHED (already saved in the workspace — open them by path) ==="]
    for f in rows:
        L.append("  %s  (%s, %s)"%(f["path"],f.get("kind") or "file",_human(f.get("bytes") or 0)))
        ex=peek(hub,f["path"],1200)
        if ex:
            L.append("    first lines:")
            L+=["      "+ln for ln in ex.splitlines()[:12]]
    L.append("Read them from the workspace rather than asking him to paste the contents.")
    return "\n".join(L)
def _human(n):
    n=float(n or 0)
    for u in ("B","KB","MB","GB"):
        if n<1024 or u=="GB":return ("%.0f %s" if u=="B" else "%.1f %s")%(n,u)
        n/=1024
    return "%.1f GB"%n
