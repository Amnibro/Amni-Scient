import os,json,re,time
try:import delve_adam as ADAM
except Exception:ADAM=None
ROOT=os.path.dirname(os.path.abspath(__file__))
# Flows are AUTHORED by the user, so they belong with the config and the conversations, not
# beside the code - a frozen build's code directory is a temp folder that is wiped on exit.
try:
    from delve import DATA as _DATA
except Exception:
    _DATA=ROOT
FLOWS=os.path.join(_DATA,"flows")
try:
    from delve import AGENTS as _A
    AGENTS=tuple(_A)
except Exception:AGENTS=("Claude","Grok","Google","Adam")
try:import delve_flows_builtin as BI
except Exception:BI=None
END_MODES=("rounds","infinite","goal","success")
def _dir():
    os.makedirs(FLOWS,exist_ok=True);return FLOWS
def _path(fid):
    fid=re.sub(r'[^A-Za-z0-9_.-]','',str(fid or ""))[:80]
    return os.path.join(_dir(),fid+".json") if fid else ""
def new_id():
    return "flow_"+str(int(time.time()*1000))
def blank():
    return {"id":new_id(),"label":"New flow","kind":"graph","v":1,"goal":"","start_prompt":"","end_prompt":"","end_mode":"rounds","rounds":3,"judge":"","max_visits":60,"memory":True,"memory_k":3,"start_node":"","nodes":[],"edges":[]}
def validate(g):
    errs=[];warns=[]
    if not isinstance(g,dict):return ["not an object"],[]
    nodes=g.get("nodes") or [];edges=g.get("edges") or []
    ids=[n.get("id") for n in nodes if isinstance(n,dict)]
    if not nodes:errs.append("no nodes")
    if len(set(ids))!=len(ids):errs.append("duplicate node ids")
    for n in nodes:
        if not isinstance(n,dict) or not n.get("id"):errs.append("node missing id");continue
        if n.get("agent") not in AGENTS:errs.append("node "+str(n.get("id"))+": unknown agent "+str(n.get("agent")))
    known=set(ids)
    for e in edges:
        if not isinstance(e,dict):errs.append("bad edge");continue
        if e.get("from") not in known:errs.append("edge from unknown node "+str(e.get("from")))
        if e.get("to") not in known:errs.append("edge to unknown node "+str(e.get("to")))
    sn=g.get("start_node") or (ids[0] if ids else "")
    if sn not in known:errs.append("start_node not a real node")
    roots=[x for x in (g.get("start_nodes") or []) if x in known] or ([sn] if sn in known else [])
    for x in (g.get("start_nodes") or []):
        if x not in known:errs.append("start_nodes lists a node that does not exist: "+str(x))
    mode=(g.get("end_mode") or "rounds").lower()
    if mode not in END_MODES:errs.append("end_mode must be one of "+", ".join(END_MODES))
    if mode in ("goal","success"):
        if g.get("judge") and g.get("judge") not in known:errs.append("judge is not a real node")
        if not g.get("judge"):warns.append("no judge node picked — the last node to speak will rule")
        if mode=="goal" and not (g.get("end_prompt") or g.get("goal") or "").strip():warns.append("goal mode with no goal and no end prompt — nothing to judge against")
    for n in nodes:
        if isinstance(n,dict) and n.get("gather") and not [e for e in edges if isinstance(e,dict) and e.get("to")==n.get("id")]:
            warns.append("review-break seat "+str(n.get("id"))+" has nothing feeding it — it will never see a report")
    if not errs:
        seen=set();stack=list(roots)
        while stack:
            c=stack.pop()
            if c in seen:continue
            seen.add(c);stack.extend(e.get("to") for e in edges if e.get("from")==c)
        orphan=[i for i in ids if i not in seen]
        if orphan:warns.append("unreachable from start: "+", ".join(str(o) for o in orphan[:6]))
    return errs,warns
def save(g):
    g=dict(g or {})
    if BI is not None and BI.is_builtin(g.get("id")):
        # editing a built-in makes your own copy - the shipped one stays put
        g["id"]=new_id()
        g["label"]=(str(g.get("label") or "Flow")+" (my copy)")[:120]
    if not re.sub(r'[^A-Za-z0-9_.-]','',str(g.get("id") or "")):g["id"]=new_id()
    g.setdefault("kind","graph");g.setdefault("v",1)
    g["label"]=str(g.get("label") or "Untitled flow")[:120]
    errs,warns=validate(g)
    p=_path(g["id"])
    if not p:
        g["id"]=new_id();p=_path(g["id"])
    if errs:return {"ok":False,"errors":errs,"warnings":warns}
    g["saved"]=time.time()
    with open(p,"w",encoding="utf-8") as f:json.dump(g,f,indent=1,ensure_ascii=False)
    return {"ok":True,"id":g["id"],"errors":[],"warnings":warns,"flow":g}
def visit_order(g):
    """Who speaks, in the order they FIRST speak, for one lap of this graph.

    The room's relay ribbon and turn-order panel used to paint `roster_all()` — the seat
    list — even while a flow was driving the conversation, so the front end showed
    Claude→Grok→Google→Adam while the backend actually ran Grok→Claude→Google→Grok→Adam.
    This replays `run()`'s frontier loop with no agents attached (every edge taken, review
    breaks deferred exactly as the barrier defers them) so the picture cannot drift from
    the execution. One lap only: a repeat visit is the same seat again, not a new chair."""
    g=g or {}
    nodes={n["id"]:n for n in (g.get("nodes") or []) if isinstance(n,dict) and n.get("id")}
    if not nodes:return []
    out={};inc={}
    for e in (g.get("edges") or []):
        if not isinstance(e,dict):continue
        out.setdefault(e.get("from"),[]).append(e);inc.setdefault(e.get("to"),[]).append(e)
    roots=start_frontier(g,nodes)
    start=roots[0] if roots else next(iter(nodes))
    frontier=list(roots) or [start];seen=[];pend=[];spoke=set();wave=0;since=0
    while frontier and wave<len(nodes)*4:
        wave+=1;since+=1;nxt=[]
        for nid in [x for x in frontier if not is_gather(nodes.get(x))]:
            if nid not in spoke:spoke.add(nid);seen.append(nid)
            nxt.extend(e.get("to") for e in out.get(nid,[]))
        for x in dict.fromkeys(list(frontier)+list(nxt)):
            if is_gather(nodes.get(x)) and x not in pend and x not in spoke:pend.append(x)
        nxt=[x for x in nxt if x in nodes and not is_gather(nodes.get(x))]
        cycled=(not nxt) or (start in nxt and wave>1)
        def _ready(x):
            n=nodes.get(x) or {}
            ra=int(n.get("review_after") or 0)
            if ra>0:return since>=ra
            srcs={e.get("from") for e in inc.get(x,[]) if e.get("from")!=x and e.get("from") in nodes}
            return cycled or (bool(srcs) and srcs.issubset(spoke))
        broke=False
        for gid in [x for x in pend if _ready(x)]:
            spoke.add(gid);seen.append(gid);pend=[x for x in pend if x!=gid];broke=True
            nxt.extend(e.get("to") for e in out.get(gid,[]) if e.get("to") in nodes and not is_gather(nodes.get(e.get("to"))))
        if broke:since=0
        frontier=[x for x in dict.fromkeys(nxt) if x in nodes and x not in spoke and not is_gather(nodes.get(x))]
        # A review break is a BARRIER, not the end of the lap. Breaking on `broke` cut the walk
        # at the first gather, so any seat downstream of a judge (Adam in the Adam Duel flow)
        # never entered the visit order — and under a flow this order IS the roster, which is
        # how a seat the user put in his own flow ended up with no row and no way to be added.
        if not frontier or start in frontier:break
    for x in pend:
        if x not in spoke:spoke.add(x);seen.append(x)
    rows=[]
    for nid in seen:
        n=nodes.get(nid) or {}
        rows.append({"id":nid,"agent":n.get("agent") or "","role":(n.get("role") or "").strip(),
                     "gather":bool(n.get("gather")),"start":nid in roots})
    return rows
def seat_order(g):
    """visit_order() reduced to seat names, deduped — what the ribbon draws."""
    return list(dict.fromkeys(r["agent"] for r in visit_order(g) if r.get("agent")))
def load(fid,avail=None):
    if BI is not None and BI.is_builtin(fid):return BI.get(fid,avail)
    p=_path(fid)
    if not p or not os.path.isfile(p):return None
    try:
        with open(p,encoding="utf-8") as f:return json.load(f)
    except Exception:return None
def delete(fid):
    if BI is not None and BI.is_builtin(fid):return False
    p=_path(fid)
    if p and os.path.isfile(p):
        try:os.remove(p);return True
        except Exception:return False
    return False
def list_flows(avail=None):
    out=list(BI.listing(avail)) if BI is not None else []
    for fn in sorted(os.listdir(_dir())):
        if not fn.endswith(".json"):continue
        g=load(fn[:-5])
        if not isinstance(g,dict) or not g.get("id"):continue
        out.append({"id":g["id"],"label":g.get("label") or g["id"],"nodes":len(g.get("nodes") or []),"edges":len(g.get("edges") or []),"end_mode":g.get("end_mode") or "rounds","goal":(g.get("goal") or "")[:160],"saved":g.get("saved") or 0,"seats":seat_order(g),"order":visit_order(g)})
    mine=[r for r in out if not r.get("builtin")]
    built=[r for r in out if r.get("builtin")]
    return built+sorted(mine,key=lambda x:-(x.get("saved") or 0))
def _up(hub,agent):
    f=getattr(hub,"seat_up",None)
    if callable(f):
        try:return bool(f(agent))
        except Exception:pass
    return hub.adam_up() if agent=="Adam" else (hub.google_up() if agent=="Google" else True)
def _who(nodes,nid):
    n=nodes.get(nid) or {}
    r=(n.get("role") or "").strip()
    return (str(n.get("agent") or "?")+(" ("+r+")" if r else ""))
def _edge_ok(e,reply):
    c=(e.get("cond") or "").strip()
    return True if not c else (c.lower() in (reply or "").lower())
def _brief(g,nodes,nid,incoming,outgoing,steer,criteria,wave,standing=""):
    n=nodes.get(nid) or {}
    L=["=== FLOW: "+str(g.get("label") or "flow")+" · wave "+str(wave)+" ==="]
    if (g.get("goal") or "").strip():L.append("GOAL (the whole graph is working toward this): "+g["goal"].strip())
    if (standing or "").strip():L.append("STANDING BRIEF for this flow (background from the flow setup — NOT a new request): "+standing.strip())
    if criteria:L.append("SUCCESS CRITERIA (locked in earlier by the judge — do not move them): "+criteria)
    role=(n.get("role") or "").strip();brief=(n.get("brief") or "").strip()
    L.append("YOUR SEAT: "+(role or "participant")+(" — "+brief if brief else ""))
    if incoming:
        L.append("HANDED TO YOU BY:")
        for e in incoming:
            lab=(e.get("label") or "").strip()
            L.append("  - "+_who(nodes,e.get("from"))+(": "+lab if lab else ": (no instruction given)"))
    else:
        L.append("You open this flow — nobody handed to you.")
    if outgoing:
        L.append("YOU HAND OFF TO (write your ending so THEY can act on it):")
        for e in outgoing:
            lab=(e.get("label") or "").strip()
            L.append("  - "+_who(nodes,e.get("to"))+(": "+lab if lab else ": (your call what they need)"))
    else:
        L.append("Nothing follows you on this branch — close it out cleanly.")
    if steer:L.append("JUDGE SAID STILL MISSING (fix this, do not repeat the last wave): "+steer)
    own,shared=_mem_read(g,nid,_mem_addr(g,nodes,nid),int(g.get("memory_k") or 3))
    if own:L.append("YOUR OWN MEMORY (this seat only — what YOU concluded on earlier laps; build on it, do not redo it):\n"+own)
    if shared:L.append("SHARED LEARNINGS (what the other seats worked out — reuse, do not re-derive):\n"+shared)
    L.append("Do YOUR seat's job only. No board theatre, no restating the goal back at us.")
    return "\n".join(L)
def _reports_dir():
    d=os.path.join(_dir(),"reports");os.makedirs(d,exist_ok=True);return d
def is_gather(n):
    return bool((n or {}).get("gather"))
def _report(g,nodes,wave,rows,gid):
    d=_reports_dir()
    fn=re.sub(r'[^A-Za-z0-9_.-]','',str(g.get("id") or "flow"))[:60]+"_wave"+str(wave).zfill(2)+".md"
    p=os.path.join(d,fn)
    L=["# "+str(g.get("label") or "flow")+" — wave "+str(wave)+" report-out",""]
    if (g.get("goal") or "").strip():L.append("**Goal:** "+g["goal"].strip()+"\n")
    L.append("Every seat that spoke this wave, in order. This is the single artefact the review seat reads.\n")
    for who,txt in rows:
        L.append("## "+who);L.append((txt or "").strip() or "_(no output)_");L.append("")
    try:
        with open(p,"w",encoding="utf-8") as f:f.write("\n".join(L))
    except Exception:return "",""
    dig=[]
    for who,txt in rows:
        t=re.sub(r'\s+',' ',(txt or "")).strip()
        dig.append("### "+who+"\n"+(t[:1400]+(" …[truncated — full text in the report file]" if len(t)>1400 else "") if t else "(no output)"))
    return p,"\n\n".join(dig)
def _gather_brief(g,nodes,gid,wave,rows,path,digest,criteria,steer,sp):
    n=nodes.get(gid) or {}
    role=(n.get("role") or "").strip() or "reviewer"
    L=["=== REVIEW BREAK — wave "+str(wave)+" ===",
       "The working seats have stopped. Nobody speaks again until you rule. You are the "+role+" and you act alone here.",
       "Everything they produced this wave was collected into ONE report:",
       "  "+(path or "(report file unavailable — the digest below is the whole record)"),
       ""]
    if (g.get("goal") or "").strip():L.append("GOAL: "+g["goal"].strip())
    if (sp or "").strip():L.append("STANDING BRIEF: "+sp.strip())
    if criteria:L.append("SUCCESS CRITERIA (locked in earlier — do not move them): "+criteria)
    if steer:L.append("WHAT YOU SAID WAS MISSING LAST BREAK: "+steer)
    L.append("")
    L.append("REPORT-OUT ("+str(len(rows))+" seat"+("" if len(rows)==1 else "s")+"):")
    L.append(digest or "(nothing came back)")
    L.append("")
    L.append("Your job: read the whole report as one piece of work, not "+str(len(rows))+" separate answers. "
             "Say what is settled, what conflicts between seats, and the ONE thing the next cycle must fix. "
             "Direct the seats by name. Do not redo their work and do not summarise for its own sake.")
    return "\n".join(L)
def seat_key(g,nid):
    return re.sub(r'[^A-Za-z0-9_]','_',"flow_"+str(g.get("id") or "adhoc")+"_"+str(nid))[:90]
_ADAM_OK={"t":0.0,"v":None}
def _adam_ready():
    """Cached liveness. Flow memory is TWO HTTP calls per seat per wave, and with Adam down each
    one blocks until it times out - measured at ~2s a seat, 12s across a six-seat concurrent
    wave, and all of it BEFORE anybody sees an answer. One cached probe replaces twelve
    timeouts; 20s is short enough that starting Adam mid-room is picked up on the next wave."""
    now=time.time()
    if _ADAM_OK["v"] is not None and (now-_ADAM_OK["t"])<20.0:return _ADAM_OK["v"]
    ok=False
    try:
        if ADAM is not None:
            # A socket first. ADAM.is_up() retries 1.2s then 2.4s on purpose - a busy Adam
            # answers /healthz late and must not be read as offline - but that care costs 3.2s
            # every time it is genuinely down. Nothing is listening is an INSTANT answer on
            # loopback, and a wave that skips memory once is a far smaller cost than one that
            # stalls. Only when the port is open do we ask the careful question.
            import socket
            host=os.environ.get("ADAM_HOST","127.0.0.1");port=int(os.environ.get("ADAM_PORT","7700") or 7700)
            with socket.socket() as sk:
                sk.settimeout(0.25)
                if sk.connect_ex((host,port))==0:ok=bool(ADAM.is_up())
    except Exception:ok=False
    _ADAM_OK["t"]=now;_ADAM_OK["v"]=ok
    return ok
def _mem_on(g):
    return (ADAM is not None and hasattr(ADAM,"atlas_recall")
            and (g.get("memory") is not False) and _adam_ready())
def _mem_addr(g,nodes,nid):
    n=(nodes or {}).get(nid) or {}
    return " | ".join(x for x in [(g.get("goal") or "").strip()[:200],str(n.get("agent") or ""),(n.get("role") or "").strip(),(n.get("brief") or "").strip()[:200]] if x)
def _mem_read(g,nid,query,k):
    if not _mem_on(g):return "",""
    try:r=ADAM.atlas_recall(seat_key(g,nid),query,k=k)
    except Exception:return "",""
    def fmt(rows,cap):
        out=[]
        for h in (rows or [])[:cap]:
            a=re.sub(r'\s+',' ',str(h.get("assistant") or "")).strip()
            if a:out.append("  - "+a[:260])
        return "\n".join(out)
    return fmt(r.get("own"),k),fmt(r.get("shared"),k)
def _mem_write(g,nid,query,reply):
    if not _mem_on(g) or not (query and reply):return
    try:ADAM.atlas_record(seat_key(g,nid),query,reply)
    except Exception:pass
def _judge_node(g,nodes,last):
    j=g.get("judge")
    return j if j in nodes else (last if last in nodes else "")
def _seat_turn(hub,agent,extra):
    setattr(hub,"_flow_brief",extra)
    try:return hub.turn(agent,extra=extra)
    finally:setattr(hub,"_flow_brief","")
def _ask(hub,nodes,nid,extra):
    n=nodes.get(nid) or {}
    a=n.get("agent")
    if not a or not _up(hub,a):return ""
    try:
        _,rp=_seat_turn(hub,a,extra)
        return rp or ""
    except Exception:return ""
def _criteria(hub,g,nodes,jid):
    if not jid:return ""
    goal=(g.get("goal") or "").strip() or (g.get("start_prompt") or "").strip()
    x=("=== DEFINE SUCCESS (you are the judge for this flow) ===\n"
       "Before any work starts, state what would make this flow a SUCCESS.\n"
       "GOAL AS GIVEN: "+(goal or "(none stated — infer it from the room)")+"\n"
       "Write 2-5 concrete, checkable criteria. Each must be something you could later answer yes/no about "
       "with evidence from the transcript. No vague aspirations. These get locked in and you will be held to "
       "them for the rest of the run — you cannot move them later to declare victory.\n"
       "Output ONLY the numbered criteria.")
    hub.emit({"type":"status","text":"judge defining success criteria"})
    return (_ask(hub,nodes,jid,x) or "").strip()
def _verdict(hub,g,nodes,jid,criteria,wave):
    if not jid:return {"done":False,"why":"","ok":False}
    end=(g.get("end_prompt") or "").strip()
    goal=(g.get("goal") or "").strip()
    target=criteria or end or goal
    if not target:return {"done":False,"why":"","ok":False}
    x=("=== VERDICT (you are the judge; lap "+str(wave)+" just finished) ===\n"
       "Judge ONLY against this:\n"+target+"\n\n"
       "Answer on the FIRST line exactly one of:\n"
       "  DONE: <what satisfied it>\n"
       "  CONTINUE: <the single most important thing still missing>\n"
       "Be strict. If it is partially met, that is CONTINUE. Do not be generous to your own side. "
       "Your CONTINUE reason is fed straight to the next lap, so make it actionable.")
    hub.emit({"type":"status","text":"judge ruling on wave "+str(wave)})
    r=(_ask(hub,nodes,jid,x) or "").strip()
    if not r:return {"done":False,"why":"","ok":False}
    head=r.strip().splitlines()[0] if r.strip() else ""
    m=re.search(r'(?i)\b(DONE|CONTINUE)\b\s*[:\-—]?\s*(.*)',head)
    if not m:
        m2=re.search(r'(?i)\b(DONE|CONTINUE)\b\s*[:\-—]?\s*([^\n]*)',r)
        m=m2
    if not m:return {"done":False,"why":r[:300],"ok":True}
    return {"done":m.group(1).upper()=="DONE","why":(m.group(2) or "").strip()[:400],"ok":True}
def start_frontier(g,nodes):
    """Which seats open the flow. A single start_node is a relay opening; `start_nodes` lets a
    flow open with several seats at once, which is the only way two rivals can share wave 1 and
    therefore be blind to each other. Ids that are not real nodes are dropped, order is kept."""
    g=g or {}
    many=[x for x in (g.get("start_nodes") or []) if x in nodes]
    if many:return list(dict.fromkeys(many))
    one=g.get("start_node") if g.get("start_node") in nodes else next(iter(nodes),"")
    return [one] if one else []
def is_async(g):
    """Whether the seats sharing a wave work independently. Off by default: a sequential flow is
    a relay and the later seat is SUPPOSED to read the earlier one."""
    return bool((g or {}).get("async"))
def _keep_stub(hub,who,agent):
    txt="["+str(agent).lower()+(" stopped]" if hub.abort.is_set() else " produced nothing]")
    hub.add(who,txt);hub.idx[who]=len(hub.t)
    try:hub.emit({"type":"msg","who":who,"text":txt,"model":hub.seat_model(who),"model_short":hub.seat_model_short(who)})
    except Exception:pass
def _run_wave(hub,g,nodes,runners):
    """One wave. Sequential is the old behaviour and stays the default: each seat speaks into the
    room and the next one reads it. Async runs the whole wave at once and renders every seat from
    the SAME transcript index, so two rivals genuinely cannot see each other's answer this wave -
    which is what makes a duel a duel instead of a relay. Replies are committed in node order so
    the transcript is identical whichever thread finished first."""
    if not runners:return []
    if len(runners)<2 or not is_async(g):
        outp=[]
        for nid,a,extra in runners:
            if hub.abort.is_set():break
            hub.emit({"type":"status","text":"→ "+_who(nodes,nid)})
            who=a
            try:who,rp=_seat_turn(hub,a,extra)
            except Exception as ex:
                hub.emit({"type":"status","text":"node "+_who(nodes,nid)+" failed: "+str(ex)[:100]});rp=None
            if not rp:_keep_stub(hub,who,a)
            outp.append((nid,who,rp))
        return outp
    import threading
    base=len(hub.t)
    hub.emit({"type":"status","text":"independent · "+", ".join(_who(nodes,n) for n,_a,_e in runners)+" answer at the same time and cannot see each other"})
    res={}
    def go(nid,a,extra):
        try:
            setattr(hub,"_flow_brief",extra)
            try:res[nid]=hub.turn(a,start=base,extra=extra,record=False)
            finally:setattr(hub,"_flow_brief","")
        except Exception as ex:
            res[nid]=(a,None)
            try:hub.emit({"type":"status","text":"node "+_who(nodes,nid)+" failed: "+str(ex)[:100]})
            except Exception:pass
    ths=[threading.Thread(target=go,args=(nid,a,extra),daemon=True) for nid,a,extra in runners]
    for t in ths:t.start()
    for t in ths:t.join()
    outp=[]
    for nid,a,_e in runners:
        got=res.get(nid)
        who,rp=(got if isinstance(got,tuple) else (a,None))
        if rp:hub.add(who,rp);hub.idx[who]=len(hub.t)
        else:_keep_stub(hub,who,a)
        outp.append((nid,who,rp))
    return outp
def run(hub,g,start_prompt=None,user_msg="",only=None):
    """`only` is the seats the user left switched on in the sidebar.

    A flow names its own seats, so the picks used to be dropped on the floor: switching ChatGPT,
    Copilot and Cursor OFF and running a roundtable still called all six, including two that were
    switched off because they were broken. A flow decides the ORDER and the SHAPE; the switches
    decide who is at the table at all, and the second is the user's to set.

    It is a filter, never a promoter - a seat that is off cannot be added by it - and if applying
    it would empty the graph the flow runs unfiltered instead, because a silent no-op round is
    worse than an unfiltered one."""
    only=[x for x in (only or []) if isinstance(x,str) and x]
    if only:
        allnodes=list(g.get("nodes") or [])
        keep=[n for n in allnodes if n.get("agent") in only]
        gone=sorted({str(n.get("agent") or "") for n in allnodes if n.get("agent") not in only} - {""})
        if keep and len(keep)<len(allnodes):
            drop={n["id"] for n in allnodes if n.get("agent") not in only}
            g=dict(g)
            g["nodes"]=keep
            g["edges"]=[e for e in (g.get("edges") or []) if e.get("from") not in drop and e.get("to") not in drop]
            sn=[x for x in (g.get("start_nodes") or []) if x not in drop]
            if sn:g["start_nodes"]=sn
            if g.get("start_node") in drop:g["start_node"]=(sn or [keep[0]["id"]])[0]
            if g.get("judge") in drop:g["judge"]=""
            try:hub.emit({"type":"status","text":"sitting out (switched off): "+", ".join(gone)})
            except Exception:pass
        elif gone and not keep:
            try:hub.emit({"type":"status","text":"every seat in this flow is switched off — running it as written"})
            except Exception:pass
    errs,_=validate(g)
    if errs:
        hub.emit({"type":"status","text":"flow invalid: "+"; ".join(errs[:3])});return {"ok":False,"errors":errs}
    nodes={n["id"]:n for n in g.get("nodes") or []}
    edges=g.get("edges") or []
    out={};inc={}
    for e in edges:
        out.setdefault(e.get("from"),[]).append(e);inc.setdefault(e.get("to"),[]).append(e)
    roots=start_frontier(g,nodes)
    start=roots[0] if roots else (g.get("start_node") or next(iter(nodes),""))
    mode=(g.get("end_mode") or "rounds").lower()
    rounds=max(1,int(g.get("rounds") or 3))
    maxv=max(1,min(400,int(g.get("max_visits") or 60)))
    sp=(start_prompt if start_prompt is not None else g.get("start_prompt")) or ""
    goal=(g.get("goal") or "").strip()
    um=(user_msg or "").strip()
    if um:
        hub.add("Anthony",um);hub.emit({"type":"user","who":"Anthony","text":um})
    hub.emit({"type":"status","text":"flow: "+str(g.get("label") or "")+(" — "+goal[:70] if goal else "")})
    hub._watch_start()
    jid=_judge_node(g,nodes,"")
    criteria=_criteria(hub,g,nodes,jid) if mode=="success" else ""
    if mode=="success" and not criteria:hub.emit({"type":"status","text":"judge unavailable — falling back to a "+str(rounds)+"-wave budget"})
    frontier=list(roots) or [start];visits=0;wave=0;loops=0;steer="";items=[];stop="";last=""
    pend=[];prows=[];since=0;spoke=set()
    while frontier and visits<maxv and not hub.abort.is_set():
        wave+=1
        hub.emit({"type":"status","text":"wave "+str(wave)+" · "+", ".join(_who(nodes,n) for n in frontier)})
        nxt=[];since+=1
        runners=[]
        for nid in [x for x in frontier if not is_gather(nodes.get(x))]:
            if hub.abort.is_set() or visits>=maxv:break
            n=nodes.get(nid)
            if not n:continue
            a=n.get("agent")
            if not _up(hub,a):
                hub.emit({"type":"status","text":a+" offline — skipping "+_who(nodes,nid)+" (branch continues)"})
                nxt.extend(e.get("to") for e in out.get(nid,[]))
                continue
            runners.append((nid,a,_brief(g,nodes,nid,inc.get(nid),out.get(nid),steer,criteria,wave,sp)))
        for nid,a,rp in _run_wave(hub,g,nodes,runners):
            if rp is None:continue
            visits+=1;last=nid;spoke.add(nid);items.append((a,rp));prows.append((_who(nodes,nid),rp));hub._drain()
            _mem_write(g,nid,_mem_addr(g,nodes,nid),rp)
            for e in out.get(nid,[]):
                if _edge_ok(e,rp):nxt.append(e.get("to"))
        for x in dict.fromkeys(list(frontier)+list(nxt)):
            if is_gather(nodes.get(x)) and x not in pend:pend.append(x)
        nxt=[x for x in nxt if not is_gather(nodes.get(x))]
        cycled=(not nxt) or (start in nxt and wave>1)
        def _ready(x):
            n=nodes.get(x) or {}
            ra=int(n.get("review_after") or 0)
            if ra>0:return since>=ra
            srcs={e.get("from") for e in inc.get(x,[]) if e.get("from")!=x and e.get("from") in nodes}
            return cycled or (bool(srcs) and srcs.issubset(spoke))
        due=[x for x in pend if _ready(x)]
        broke=False
        for gid in due:
            if hub.abort.is_set() or visits>=maxv:break
            n=nodes.get(gid)
            if not n or not _up(hub,n.get("agent")):
                if n:hub.emit({"type":"status","text":str(n.get("agent"))+" offline — review break skipped"})
                pend=[x for x in pend if x!=gid];nxt.extend(e.get("to") for e in out.get(gid,[]));continue
            rows=list(prows) or [(_who(nodes,x),"(did not speak this wave)") for x in frontier if x!=gid]
            fp,dig=_report(g,nodes,wave,rows,gid)
            hub.emit({"type":"status","text":"review break — "+_who(nodes,gid)+" reading the wave "+str(wave)+" report"+(" ("+os.path.basename(fp)+")" if fp else "")})
            try:sp_,rp=_seat_turn(hub,n.get("agent"),_gather_brief(g,nodes,gid,wave,rows,fp,dig,criteria,steer,sp))
            except Exception as ex:
                hub.emit({"type":"status","text":"review break failed: "+str(ex)[:100]});pend=[x for x in pend if x!=gid];continue
            visits+=1;last=gid;broke=True;items.append((sp_,rp));hub._drain()
            _mem_write(g,gid,_mem_addr(g,nodes,gid),rp)
            pend=[x for x in pend if x!=gid]
            for e in out.get(gid,[]):
                if _edge_ok(e,rp) and not is_gather(nodes.get(e.get("to"))):nxt.append(e.get("to"))
        if broke:prows=[];since=0;spoke=set()
        frontier=[x for x in dict.fromkeys(nxt) if x in nodes and not is_gather(nodes.get(x))]
        if hub.abort.is_set():stop="e-stop";break
        # A lap is a CYCLE — counted when the walk returns to its start or runs dry, never when
        # a gather fires. Counting on `broke` ended the final lap AT the judge, so the seat the
        # judge hands off to (Adam: "merge the winning approach") was skipped on the very lap
        # whose verdict it existed to implement.
        lap=(not frontier) or (start in frontier and wave>1)
        if not lap:continue
        loops+=1
        hub.emit({"type":"status","text":"lap "+str(loops)+" complete ("+str(visits)+" turns so far)"})
        if mode=="rounds" and loops>=rounds:stop="completed "+str(loops)+" lap(s)";break
        if mode in ("goal","success"):
            v=_verdict(hub,g,nodes,_judge_node(g,nodes,last),criteria,loops)
            if v.get("ok") and v.get("done"):stop="judge: DONE";hub.emit({"type":"status","text":"judge: DONE — "+(v.get("why") or "")[:160]});break
            if v.get("ok"):steer=v.get("why") or ""
            elif loops>=rounds:stop="judge offline — fell back to "+str(loops)+" lap(s)";break
        # The whole opening frontier, not just its first seat. A concurrent flow opens with
        # every rival in start_nodes and ends its wave with nothing queued, so resetting to
        # roots[0] ran lap 1 with five seats and every lap after it with one.
        if not frontier:frontier=list(roots) or [start]
    hub._drain();hub._watch_stop()
    if not stop:stop="visit budget" if visits>=maxv else (stop or "ended")
    hub.emit({"type":"status","text":"flow ended ("+stop+") · "+str(wave)+" wave(s), "+str(visits)+" turn(s)"})
    try:hub.maybe_learn(goal or sp or "[flow]",items,"flow")
    except Exception:pass
    return {"ok":True,"waves":wave,"visits":visits,"stop":stop}
