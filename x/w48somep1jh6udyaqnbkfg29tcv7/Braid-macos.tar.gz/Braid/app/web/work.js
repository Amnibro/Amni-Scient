/* The work dock: what the seats are doing to your files, without leaving the conversation.

   Mounted by simple.html and basic.html, which own only their launcher button - everything
   else lives here so the two UIs cannot drift. It overlays the room (a right rail on a
   desktop, a bottom sheet on a phone); the chat behind it is never unmounted, so closing the
   dock costs nothing and the transcript keeps painting while it is open.

   Three tabs: Work is the live feed, Files browses the workspace read-only, Approvals is the
   Edit-mode queue. Every server call it makes already existed for /code except /api/activity,
   so on a Braid that has not been restarted yet the feed says so and the other two tabs still
   work. Single source of truth - web/_bundle.py inlines this into both pages. */
(function(){
if(window.braidWork)return;
const VERB={read:"read",edit:"edited",write:"wrote",create:"created",delete:"deleted",run:"ran",
 find:"searched",list:"listed",plan:"planned",agent:"delegated",web:"fetched",queued:"wants to change",
 discarded:"discarded",applied:"applied",burst:"…",tool:"used a tool",note:""};
/* The watcher cannot know a seat caused a change - it only knows the change happened while that
   seat held the floor, and the workspace here holds every project with other agents running in
   them. Saying "Claude wrote Symphony" about a file Claude never touched is the one thing this
   feed must not do. Watched rows get their own, passive wording. */
const SEEN_VERB={read:"was read",edit:"changed",write:"changed",create:"appeared",delete:"was removed",
 burst:"…",note:""};
const HOT={write:1,edit:1,create:1,delete:1,queued:1,applied:1};
const HUES={Claude:"--claude",Grok:"--grok",Google:"--gemini",Adam:"--adam",OpenAI:"--openai",
 Copilot:"--copilot",Cursor:"--cursor",OpenCode:"--opencode"};
const NAMES={Claude:"Claude",Grok:"Grok",Google:"Gemini",Adam:"Adam",OpenAI:"ChatGPT",
 Copilot:"Copilot",Cursor:"Cursor",OpenCode:"OpenCode"};
const CSS=`
#bwk{position:fixed;inset:0;z-index:120;display:none}
#bwk.on{display:block}
#bwk .wscrim{position:absolute;inset:0;background:rgba(8,10,14,.34);opacity:0;transition:opacity .18s}
#bwk.on .wscrim{opacity:1}
#bwk .wpan{position:absolute;top:0;right:0;bottom:0;width:min(430px,96vw);display:flex;flex-direction:column;
 background:var(--surface,#fff);color:var(--ink,#111);border-left:1px solid var(--rule,rgba(0,0,0,.1));
 box-shadow:var(--shadow,0 10px 40px rgba(0,0,0,.2));transform:translateX(104%);transition:transform .2s ease}
#bwk.on .wpan{transform:none}
#bwk .whd{display:flex;align-items:center;gap:8px;padding:10px 12px;border-bottom:1px solid var(--rule,rgba(0,0,0,.1));flex:none}
#bwk .wtabs{display:flex;gap:2px;background:var(--sunk,#eee);border-radius:9px;padding:2px}
#bwk .wtabs button{border:0;background:none;color:var(--mut,#888);font:inherit;font-size:12.5px;font-weight:600;
 padding:5px 10px;border-radius:7px;cursor:pointer;display:flex;align-items:center;gap:5px}
#bwk .wtabs button[aria-pressed=true]{background:var(--surface,#fff);color:var(--ink,#111);box-shadow:0 1px 2px rgba(0,0,0,.1)}
#bwk .wtabs .n{background:var(--you,#6D28D9);color:#fff;border-radius:9px;padding:0 5px;font-size:10px;line-height:15px;min-width:15px;text-align:center}
#bwk .wx{margin-left:auto;border:0;background:none;color:var(--mut,#888);font-size:15px;cursor:pointer;padding:6px 8px;border-radius:8px}
#bwk .wx:hover{background:var(--sunk,#eee)}
#bwk .wsub{display:flex;align-items:center;gap:8px;padding:6px 12px;font-size:11px;color:var(--mut,#888);
 border-bottom:1px solid var(--rule,rgba(0,0,0,.08));flex:none;min-height:26px}
#bwk .wsub b{font-weight:600;color:var(--ink2,#333)}
#bwk .wsub .dotlive{width:7px;height:7px;border-radius:50%;background:var(--vc,var(--mut,#888));flex:none;
 box-shadow:0 0 0 3px color-mix(in srgb,var(--vc,#888) 22%,transparent)}
#bwk .wsub .path{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;direction:rtl;text-align:left;flex:1;min-width:0}
#bwk .wbody{flex:1;min-height:0;display:flex;flex-direction:column;overflow:hidden}
#bwk .wsec{flex:1;min-height:0;display:none;flex-direction:column;overflow:hidden}
#bwk .wsec.on{display:flex}
#bwk .wfeed{flex:1;min-height:0;overflow-y:auto;-webkit-overflow-scrolling:touch;padding:6px 0 10px}
#bwk .row{display:grid;grid-template-columns:52px 1fr;gap:8px;padding:5px 12px 5px 10px;border-left:3px solid var(--vc,transparent);
 font-size:12.5px;line-height:1.45;align-items:baseline}
#bwk .row:hover{background:var(--sunk,#f2f2f2)}
#bwk .row .t{color:var(--mut,#888);font-size:10.5px;font-variant-numeric:tabular-nums}
#bwk .row .who{font-weight:650;color:var(--vc,var(--ink,#111))}
#bwk .row .vb{color:var(--mut,#888)}
#bwk .row.hot .vb{color:var(--ink2,#333);font-weight:600}
/* A watched row is a coincidence, not a fact, and must not look like one. No seat colour on
   the rail, dimmer, and the verb reads passively. */
#bwk .row.seen{border-left-color:transparent;opacity:.72}
#bwk .row.seen .vb{font-style:italic;font-weight:400}
#bwk .row .p{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:11.5px;
 color:var(--ink,#111);background:var(--sunk,#f0f0f0);border-radius:5px;padding:1px 5px;cursor:pointer;word-break:break-all}
#bwk .row .p:hover{outline:1px solid var(--rule2,#ccc)}
#bwk .row .p.out{color:var(--bad,#dc2626)}
#bwk .row .nt{display:block;color:var(--mut,#888);font-size:11px;font-family:ui-monospace,Menlo,Consolas,monospace;
 white-space:pre-wrap;word-break:break-word;max-height:3.6em;overflow:hidden}
#bwk .empty{padding:22px 16px;color:var(--mut,#888);font-size:12.5px;line-height:1.6;text-align:center}
#bwk .warn{margin:8px 12px;padding:8px 10px;border-radius:9px;font-size:11.5px;line-height:1.5;
 background:color-mix(in srgb,var(--warn,#E8B04B) 14%,transparent);color:var(--ink2,#333)}
#bwk .wfilt{display:flex;gap:6px;padding:6px 12px;border-bottom:1px solid var(--rule,rgba(0,0,0,.08));flex:none}
#bwk .wfilt input{flex:1;min-width:0;border:1px solid var(--rule,#ddd);background:var(--sunk,#f4f4f4);color:var(--ink,#111);
 border-radius:8px;padding:5px 9px;font:inherit;font-size:12px}
#bwk .wfilt button{border:1px solid var(--rule,#ddd);background:var(--sunk,#f4f4f4);color:var(--mut,#888);
 border-radius:8px;padding:5px 9px;font:inherit;font-size:11.5px;font-weight:600;cursor:pointer;white-space:nowrap}
#bwk .wfilt button[aria-pressed=true]{background:var(--you,#6D28D9);border-color:var(--you,#6D28D9);color:#fff}
#bwk .crumb{display:flex;flex-wrap:wrap;gap:2px;align-items:center;padding:7px 12px;font-size:11.5px;flex:none;
 border-bottom:1px solid var(--rule,rgba(0,0,0,.08))}
#bwk .crumb button{border:0;background:none;color:var(--you,#6D28D9);font:inherit;font-size:11.5px;cursor:pointer;padding:2px 3px;border-radius:5px}
#bwk .crumb span{color:var(--mut,#888)}
#bwk .wlist{flex:1;min-height:0;overflow-y:auto;-webkit-overflow-scrolling:touch}
#bwk .it{display:flex;align-items:center;gap:8px;padding:7px 12px;font-size:12.5px;cursor:pointer;border:0;background:none;
 color:var(--ink,#111);width:100%;text-align:left;font-family:inherit}
#bwk .it:hover{background:var(--sunk,#f2f2f2)}
#bwk .it .ic{width:14px;text-align:center;color:var(--mut,#888);flex:none}
#bwk .it .nm{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
#bwk .it .sz{color:var(--mut,#888);font-size:10.5px;font-variant-numeric:tabular-nums;flex:none}
#bwk .it.dir .nm{font-weight:600}
#bwk pre.code{margin:0;flex:1;min-height:0;overflow:auto;-webkit-overflow-scrolling:touch;padding:10px 12px;
 font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:11.5px;line-height:1.55;white-space:pre;tab-size:4}
#bwk pre.code i{color:var(--mut,#888);font-style:normal;user-select:none;display:inline-block;min-width:3.2em;text-align:right;padding-right:10px}
#bwk textarea.edit{flex:1;min-height:0;width:100%;resize:none;border:0;outline:0;padding:10px 12px;box-sizing:border-box;
 background:var(--sunk,#f6f6f6);color:var(--ink,#111);font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;
 font-size:11.5px;line-height:1.55;tab-size:2;white-space:pre;overflow:auto}
#bwk .fhd button:disabled{opacity:.4;cursor:not-allowed}
#bwk pre.code .ad{color:var(--good,#16a34a)}
#bwk pre.code .rm{color:var(--bad,#dc2626)}
#bwk pre.code .hh{color:var(--you,#6D28D9);font-weight:600}
#bwk .fhd{display:flex;align-items:center;gap:6px;padding:6px 12px;border-bottom:1px solid var(--rule,rgba(0,0,0,.08));flex:none;font-size:11.5px}
#bwk .fhd .fp{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-family:ui-monospace,Menlo,Consolas,monospace}
#bwk .fhd button{border:1px solid var(--rule,#ddd);background:var(--sunk,#f4f4f4);color:var(--ink2,#333);border-radius:7px;
 padding:4px 8px;font:inherit;font-size:11px;font-weight:600;cursor:pointer}
#bwk .fhd button[aria-pressed=true]{background:var(--you,#6D28D9);border-color:var(--you,#6D28D9);color:#fff}
#bwk .ask{border-bottom:1px solid var(--rule,rgba(0,0,0,.08));padding:10px 12px}
#bwk .ask h5{margin:0 0 4px;font-size:12.5px;font-weight:650}
#bwk .ask .by{color:var(--mut,#888);font-size:11px;margin-bottom:6px}
#bwk .ask pre{margin:0 0 8px;max-height:210px;overflow:auto;background:var(--sunk,#f4f4f4);border-radius:8px;padding:8px;
 font-family:ui-monospace,Menlo,Consolas,monospace;font-size:11px;line-height:1.5;white-space:pre}
#bwk .ask .btns{display:flex;gap:6px}
#bwk .ask .btns button{flex:1;border:1px solid var(--rule,#ddd);background:var(--sunk,#f4f4f4);color:var(--ink,#111);
 border-radius:8px;padding:7px;font:inherit;font-size:12px;font-weight:600;cursor:pointer}
#bwk .ask .btns .yes{background:var(--good,#16a34a);border-color:var(--good,#16a34a);color:#fff}
#bwk .seg{display:flex;gap:2px;background:var(--sunk,#eee);border-radius:8px;padding:2px}
#bwk .seg button{border:0;background:none;color:var(--mut,#888);font:inherit;font-size:11px;font-weight:600;
 padding:4px 9px;border-radius:6px;cursor:pointer}
#bwk .seg button[aria-pressed=true]{background:var(--surface,#fff);color:var(--ink,#111);box-shadow:0 1px 2px rgba(0,0,0,.1)}
#bwk .seg button[aria-pressed=true][data-m=bypass]{color:var(--bad,#dc2626)}
@media (max-width:900px){
 #bwk .wpan{top:auto;left:0;right:0;bottom:0;width:auto;height:min(82vh,720px);border-left:0;
  border-top:1px solid var(--rule,rgba(0,0,0,.1));border-radius:18px 18px 0 0;transform:translateY(104%)}
 #bwk .whd{padding-top:14px}
 #bwk .whd::before{content:"";position:absolute;top:6px;left:50%;transform:translateX(-50%);width:36px;height:4px;
  border-radius:3px;background:var(--rule2,#ccc)}
 #bwk .row{grid-template-columns:46px 1fr;font-size:13px}
}
@media (prefers-reduced-motion:reduce){#bwk .wpan{transition:none}}`;
const $=s=>document.querySelector(s);
const esc=s=>String(s==null?"":s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const hue=n=>HUES[n]?("var("+HUES[n]+")"):"var(--mut,#888)";
const nice=n=>NAMES[n]||n||"?";
const clock=t=>new Date((t||0)*1000).toTimeString().slice(0,8);
const kb=n=>n==null?"":n<1024?(n+" B"):n<1048576?((n/1024).toFixed(n<10240?1:0)+" K"):((n/1048576).toFixed(1)+" M");
const jget=async u=>{try{const r=await fetch(u);const j=await r.json();return(j&&typeof j==="object")?Object.assign({status:r.status},j):{ok:false,status:r.status}}catch(e){return{ok:false,error:String(e),status:0}}};
const jpost=async(u,b)=>{try{const r=await fetch(u,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(b||{})});return await r.json()}catch(e){return{ok:false,error:String(e)}}};
let EV=[],SEQ=0,TAB="work",OPEN=false,UNSEEN=0,ONLY=false,Q="",MODE="",DIR="",FILE="",DIFF=false,EDIT=false,RAW="",ROOT="",WMODE="",LIVE="",ARMED=false,POLL=null,BADGE=null;
/* Default to what the seat actually DID. The workspace-wide watcher is one toggle away, but it
   is not the first thing you should read, because most of it is somebody else's process. */
let SRC=(function(){try{return localStorage.getItem("braid_work_src")||"tool"}catch(e){return "tool"}})();
function el(){return document.getElementById("bwk")}
function mount(opts){
 if(el())return window.braidWork;
 opts=opts||{};BADGE=opts.badge||null;
 const st=document.createElement("style");st.textContent=CSS;document.head.appendChild(st);
 const d=document.createElement("div");d.id="bwk";d.setAttribute("aria-hidden","true");
 d.innerHTML='<div class="wscrim" data-x="1"></div><div class="wpan" role="dialog" aria-label="What the seats are doing">'+
  '<div class="whd"><div class="wtabs" role="group">'+
   '<button data-t="work" aria-pressed="true">Work</button>'+
   '<button data-t="files" aria-pressed="false">Files</button>'+
   '<button data-t="asks" aria-pressed="false">Approvals<i class="n" id="bwk-n" hidden>0</i></button>'+
  '</div><button class="wx" data-x="1" aria-label="Close">✕</button></div>'+
  '<div class="wsub" id="bwk-sub"></div><div class="wbody">'+
  '<section class="wsec on" data-p="work"><div class="wfilt">'+
    '<input id="bwk-q" placeholder="filter by path or seat" autocomplete="off">'+
    '<button id="bwk-only" aria-pressed="false" title="Hide reads, searches and shell commands">Changes</button>'+
    '<button id="bwk-src" title="Tool calls only, or every change under the workspace">Source</button></div>'+
   '<div class="wfeed" id="bwk-feed"></div></section>'+
  '<section class="wsec" data-p="files"><div class="crumb" id="bwk-crumb"></div>'+
   '<div class="wlist" id="bwk-ls"></div>'+
   '<div class="fhd" id="bwk-fhd" hidden><span class="fp" id="bwk-fp"></span>'+
    '<button id="bwk-diff" aria-pressed="false" title="Show this file\'s uncommitted git diff">Diff</button>'+
    '<button id="bwk-edit" aria-pressed="false" title="Edit this file here (Ctrl+S saves)">Edit</button>'+
    '<button id="bwk-save" hidden title="Save — in Edit mode this queues for your approval">Save</button>'+
    '<button id="bwk-back">Close</button></div>'+
   '<pre class="code" id="bwk-code" hidden></pre>'+
   '<textarea class="code edit" id="bwk-ed" hidden spellcheck="false"></textarea></section>'+
  '<section class="wsec" data-p="asks"><div class="wfilt"><div class="seg" id="bwk-mode" role="group">'+
    '<button data-m="plan" aria-pressed="false" title="Read only — nothing can be written">Plan</button>'+
    '<button data-m="edit" aria-pressed="false" title="Every write waits for you">Edit</button>'+
    '<button data-m="bypass" aria-pressed="false" title="Writes land immediately">Bypass</button></div>'+
    '<button id="bwk-undo" title="Put every file Braid changed back the way it was">Undo all</button></div>'+
   '<div class="wlist" id="bwk-asks"></div></section>'+
  '</div></div>';
 document.body.appendChild(d);
 d.addEventListener("click",e=>{
  const x=e.target.closest("[data-x]");if(x)return close();
  const t=e.target.closest(".wtabs button");if(t)return tab(t.dataset.t);
  const m=e.target.closest("#bwk-mode button");if(m)return setMode(m.dataset.m);
  const p=e.target.closest(".row .p");if(p&&p.dataset.p)return openFile(p.dataset.p);
  const it=e.target.closest(".it");if(it)return it.dataset.d?ls(it.dataset.d):openFile(it.dataset.f);
  const a=e.target.closest(".ask button[data-id]");if(a)return decide(a.dataset.id,a.dataset.allow==="1");
 });
 $("#bwk-q").oninput=e=>{Q=(e.target.value||"").toLowerCase();paintFeed()};
 $("#bwk-only").onclick=e=>{ONLY=!ONLY;e.currentTarget.setAttribute("aria-pressed",ONLY?"true":"false");paintFeed()};
 $("#bwk-src").onclick=cycleSrc;
 paintSrc();
 $("#bwk-back").onclick=()=>{if(!leaveEdit())return;FILE="";DIFF=false;EDIT=false;paintFile()};
 $("#bwk-diff").onclick=()=>{if(EDIT&&!leaveEdit())return;EDIT=false;DIFF=!DIFF;paintFile()};
 $("#bwk-edit").onclick=()=>{EDIT?leaveEdit()&&(EDIT=false,paintFile()):startEdit()};
 $("#bwk-save").onclick=save;
 $("#bwk-ed").addEventListener("keydown",e=>{
  if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==="s"){e.preventDefault();save();return}
  if(e.key==="Tab"){e.preventDefault();const t=e.target,a=t.selectionStart;
   t.value=t.value.slice(0,a)+"  "+t.value.slice(t.selectionEnd);t.selectionStart=t.selectionEnd=a+2}
 });
 $("#bwk-undo").onclick=async()=>{
  const r=await jpost("/api/code/undo",{});say(r&&r.ok?("put back "+(r.reverted||0)+" file"+(r.reverted===1?"":"s")):"could not undo");loadAsks()};
 document.addEventListener("keydown",e=>{if(e.key==="Escape"&&OPEN)close()});
 sync();
 return window.braidWork;
}
function say(t){
 const c=document.getElementById("chip");
 if(!c)return;c.textContent=t;c.classList.add("on");clearTimeout(c._t);c._t=setTimeout(()=>c.classList.remove("on"),2400);
}
function badge(){
 if(BADGE)try{BADGE(UNSEEN)}catch(e){}
}
function open(which){
 if(!el())mount();
 OPEN=true;el().classList.add("on");el().setAttribute("aria-hidden","false");
 UNSEEN=0;badge();
 if(which)tab(which);else tab(TAB);
 sync();
 if(!POLL)POLL=setInterval(()=>{if(OPEN)sync()},9000);
}
function close(){
 OPEN=false;const e=el();if(e){e.classList.remove("on");e.setAttribute("aria-hidden","true")}
 if(POLL){clearInterval(POLL);POLL=null}
}
function toggle(which){OPEN?close():open(which)}
function tab(t){
 /* An unsaved buffer dies by consent or not at all - switching tab used to drop it silently. */
 if(TAB==="files"&&t!=="files"&&EDIT){if(!leaveEdit())return;EDIT=false}
 TAB=t||"work";
 document.querySelectorAll("#bwk .wtabs button").forEach(b=>b.setAttribute("aria-pressed",b.dataset.t===TAB?"true":"false"));
 document.querySelectorAll("#bwk .wsec").forEach(s=>s.classList.toggle("on",s.dataset.p===TAB));
 if(TAB==="files"&&!DIR&&!FILE)ls("");
 if(TAB==="asks")loadAsks();
}
async function sync(){
 const r=await jget("/api/activity?since="+SEQ);
 if(r.status===404||r.status===0){ARMED=false;paintSub();paintFeed();return}
 ARMED=true;
 if(r.seq!=null)SEQ=r.seq;
 ROOT=r.root||ROOT;WMODE=r.mode||"off";LIVE=r.live||"";
 if(r.code_mode)MODE=r.code_mode;
 if(r.events&&r.events.length)r.events.forEach(e=>EV.push(e));
 if(EV.length>1200)EV=EV.slice(-900);
 setAsks(r.pending||0);paintSub();paintFeed();paintMode();
}
function push(d){
 const e=(d&&d.ev)||d;
 if(!e||!e.kind)return;
 EV.push(e);if(e.i>SEQ)SEQ=e.i;
 if(EV.length>1200)EV=EV.slice(-900);
 if(!OPEN){if(HOT[e.kind])UNSEEN++;badge();return}
 paintFeed();
}
function setLive(who){LIVE=who||"";paintSub()}
function setAsks(n){
 const b=document.getElementById("bwk-n");if(!b)return;
 b.hidden=!n;b.textContent=String(n||0);
}
function paintSub(){
 const s=document.getElementById("bwk-sub");if(!s)return;
 const where=ROOT?ROOT.replace(/\\/g,"/"):"";
 s.innerHTML=(LIVE?'<span class="dotlive" style="--vc:'+hue(LIVE)+'"></span><b>'+esc(nice(LIVE))+'</b> has the floor':
   '<span class="dotlive" style="--vc:var(--mut,#888)"></span>nobody is working')+
  (where?'<span class="path" title="'+esc(ROOT)+'">'+esc(where)+'</span>':"");
}
const isTool=e=>(e.src||"tool")==="tool";
function shown(){
 return EV.filter(e=>{
  if(SRC==="tool"&&!isTool(e))return false;
  if(SRC==="watch"&&isTool(e))return false;
  if(ONLY&&!HOT[e.kind])return false;
  if(!Q)return true;
  return((e.path||"")+" "+(e.seat||"")+" "+(e.note||"")+" "+nice(e.seat)).toLowerCase().indexOf(Q)>=0;
 });
}
const SRCLAB={tool:"What the seat did",watch:"Workspace changes",all:"Everything"};
function paintSrc(){
 const b=document.getElementById("bwk-src");if(!b)return;
 b.textContent=SRCLAB[SRC]||SRC;
 b.setAttribute("aria-pressed",SRC==="tool"?"true":"false");
 b.title=SRC==="tool"?"Only this seat's own tool calls — exact"
  :SRC==="watch"?"Every file that changed under the workspace while a seat worked — includes other programs"
  :"Both, mixed";
}
function cycleSrc(){
 SRC=SRC==="tool"?"watch":(SRC==="watch"?"all":"tool");
 try{localStorage.setItem("braid_work_src",SRC)}catch(e){}
 paintSrc();paintFeed();
}
function paintFeed(){
 const f=document.getElementById("bwk-feed");if(!f)return;
 const stick=f.scrollTop+f.clientHeight>=f.scrollHeight-40;
 const rows=shown();
 if(!rows.length){
  f.innerHTML=(!ARMED?'<div class="warn">Braid is running an older build than this page — restart it to switch the live work feed on. Files and Approvals still work.</div>':"")+
   '<div class="empty">'+(EV.length?(SRC==="tool"
     ?"No tool calls from a seat yet.<br>Only Claude streams its tools; for the other seats switch this to <b>Workspace changes</b>."
     :"Nothing matches that filter."):
    "Nothing yet.<br>Ask the room to change something and every file it reads, writes or deletes lands here as it happens.")+"</div>";
  return;
 }
 f.innerHTML=(!ARMED?'<div class="warn">Braid is running an older build than this page — restart it to switch the live work feed on.</div>':"")+
  rows.map(e=>{
  const tool=isTool(e);
  const v=tool?(VERB[e.kind]||e.kind):(SEEN_VERB[e.kind]||VERB[e.kind]||e.kind);
  const p=e.path?'<span class="p'+(e.out?" out":"")+'" data-p="'+esc(e.out?"":e.path)+'" title="'+esc(e.out?"outside the workspace — Braid will not open it here":"Open "+e.path)+'">'+esc(e.path)+'</span>':"";
  const n=e.note?'<span class="nt">'+esc(e.note)+'</span>':"";
  /* Passive voice for a watched row, and the seat name is dropped from it entirely: naming a
     seat next to a file it may not have touched is the whole failure mode. */
  const who=tool?('<span class="who">'+esc(nice(e.seat))+'</span> '):"";
  return '<div class="row'+(HOT[e.kind]?" hot":"")+(tool?"":" seen")+'" style="--vc:'+hue(e.seat)+'">'+
   '<span class="t">'+clock(e.ts)+'</span><span>'+who+p+' '+
   '<span class="vb">'+esc(v)+'</span>'+n+'</span></div>';
 }).join("");
 if(stick)f.scrollTop=f.scrollHeight;
}
async function ls(path){
 DIR=path||"";FILE="";DIFF=false;
 tabTo("files");
 const r=await jget("/api/code/ls?path="+encodeURIComponent(DIR));
 const box=document.getElementById("bwk-ls"),cr=document.getElementById("bwk-crumb");
 paintFile();
 if(!r||!r.ok){box.innerHTML='<div class="empty">'+esc((r&&r.error)||"could not read that folder")+'</div>';return}
 ROOT=r.root||ROOT;
 const parts=(r.path||"").split("/").filter(Boolean);
 cr.innerHTML='<button data-crumb="">workspace</button>'+parts.map((p,i)=>
  '<span>/</span><button data-crumb="'+esc(parts.slice(0,i+1).join("/"))+'">'+esc(p)+'</button>').join("");
 cr.querySelectorAll("[data-crumb]").forEach(b=>b.onclick=()=>ls(b.dataset.crumb));
 const up=parts.length?'<button class="it dir" data-d="'+esc(parts.slice(0,-1).join("/"))+'"><span class="ic">↰</span><span class="nm">..</span></button>':"";
 box.innerHTML=up+(r.dirs||[]).map(n=>'<button class="it dir" data-d="'+esc((r.path?r.path+"/":"")+n)+'"><span class="ic">▸</span><span class="nm">'+esc(n)+'</span></button>').join("")+
  (r.files||[]).map(f=>'<button class="it" data-f="'+esc((r.path?r.path+"/":"")+f.name)+'"><span class="ic">·</span><span class="nm">'+esc(f.name)+'</span><span class="sz">'+kb(f.size)+'</span></button>').join("")+
  ((r.dirs||[]).length+(r.files||[]).length?"":'<div class="empty">This folder is empty.</div>');
}
function tabTo(t){if(TAB!==t)tab(t)}
async function openFile(p){
 if(!p)return;
 if(!leaveEdit())return;
 FILE=p;DIFF=false;EDIT=false;RAW="";
 tabTo("files");
 paintFile();
 const code=document.getElementById("bwk-code");
 code.textContent="opening "+p+"…";
 const r=await jget("/api/code/read?path="+encodeURIComponent(p));
 if(FILE!==p)return;
 if(!r||!r.ok){code.textContent=(r&&r.error)||"could not open that file";
  document.getElementById("bwk-edit").disabled=true;return}
 RAW=r.content||"";
 /* A truncated read is a PREFIX of the file. Saving it back would delete everything past the
    cap, so the editor stays shut on anything the reader had to cut. */
 document.getElementById("bwk-edit").disabled=!!r.truncated;
 code.innerHTML=RAW.split("\n").map((l,i)=>'<i>'+(i+1)+'</i>'+esc(l)).join("\n")+
  (r.truncated?"\n<i></i>… too big to edit here — truncated":"");
 code.scrollTop=0;
}
function paintFile(){
 const hd=document.getElementById("bwk-fhd"),code=document.getElementById("bwk-code"),
  ed=document.getElementById("bwk-ed"),lsb=document.getElementById("bwk-ls");
 if(!hd)return;
 hd.hidden=!FILE;code.hidden=!FILE||EDIT;ed.hidden=!FILE||!EDIT;lsb.style.display=FILE?"none":"";
 document.getElementById("bwk-diff").setAttribute("aria-pressed",DIFF?"true":"false");
 document.getElementById("bwk-edit").setAttribute("aria-pressed",EDIT?"true":"false");
 document.getElementById("bwk-save").hidden=!EDIT;
 if(!FILE)return;
 document.getElementById("bwk-fp").textContent=FILE+(EDIT&&dirty()?" ·  unsaved":"");
 if(DIFF)showDiff();
}
function dirty(){
 const ed=document.getElementById("bwk-ed");
 return!!(ed&&EDIT&&ed.value!==RAW);
}
/* One confirm, one place. Every exit from the editor - Close, Diff, opening another file,
   switching tab - goes through here, so there is no route that drops an unsaved buffer
   silently. Returns false to cancel the exit. */
function leaveEdit(){
 if(!dirty())return true;
 return confirm("You have unsaved changes to "+FILE+". Leave without saving?");
}
function startEdit(){
 const ed=document.getElementById("bwk-ed");
 if(!ed||!FILE)return;
 DIFF=false;EDIT=true;ed.value=RAW;paintFile();
 ed.addEventListener("input",()=>{document.getElementById("bwk-fp").textContent=FILE+(dirty()?" ·  unsaved":"")},{once:true});
 setTimeout(()=>ed.focus(),40);
}
async function save(){
 const ed=document.getElementById("bwk-ed");
 if(!ed||!FILE)return;
 const body=ed.value;
 const r=await jpost("/api/code/write",{path:FILE,content:body,by:"you"});
 if(!r||!r.ok){say((r&&r.error)||"could not save");return}
 RAW=body;paintFile();
 /* Plan/Edit/Bypass applies to a hand edit exactly as it applies to a seat's: in Edit mode
    your own save queues behind your own approval. Saying so beats a silent no-op. */
 if(r.queued){setAsks(r.pending||1);say("queued for your approval — Approvals tab");tab("asks")}
 else say("saved "+FILE);
 sync();
}
async function showDiff(){
 const code=document.getElementById("bwk-code");
 code.textContent="reading git diff…";
 const r=await jget("/api/code/git?op=diff_full");
 if(!DIFF)return;
 if(!r||!r.ok||!(r.out||"").trim()){code.textContent=(r&&r.error)||"No uncommitted changes here — the workspace may not be a git repository.";return}
 /* One `git diff` for the whole repo is one process; slicing the file's section out of it
    client-side beats a process per file, and `git diff -- <path>` would take a user-supplied
    path back to the shell. */
 const secs=("\n"+r.out).split("\ndiff --git ").slice(1);
 const mine=secs.filter(s=>s.split("\n")[0].indexOf(FILE)>=0);
 const body=(mine.length?mine.map(s=>"diff --git "+s).join("\n"):"").trim();
 if(!body){code.textContent="No uncommitted change to "+FILE+".";return}
 code.innerHTML=body.split("\n").map(l=>{
  const c=l[0]==="+"&&l.slice(0,3)!=="+++"?"ad":l[0]==="-"&&l.slice(0,3)!=="---"?"rm":l[0]==="@"?"hh":"";
  return c?'<span class="'+c+'">'+esc(l)+'</span>':esc(l);
 }).join("\n");
 code.scrollTop=0;
}
async function loadAsks(){
 const box=document.getElementById("bwk-asks");if(!box)return;
 const r=await jget("/api/code/pending");
 if(!r||!r.ok){box.innerHTML='<div class="empty">'+esc((r&&r.error)||"could not read the queue")+'</div>';return}
 MODE=r.mode||MODE;paintMode();setAsks((r.pending||[]).length);
 if(!(r.pending||[]).length){
  box.innerHTML='<div class="empty">'+(MODE==="edit"
   ?"Nothing waiting. In Edit mode every file a seat wants to change queues here first."
   :MODE==="plan"?"Plan mode — the seats are read-only, so nothing can queue."
   :"Bypass — writes land straight away, so nothing queues. Undo all still puts them back.")+
   (r.changes?'<br><br>'+r.changes+' change'+(r.changes===1?"":"s")+' applied this session.':"")+'</div>';
  return;
 }
 box.innerHTML=(r.pending||[]).map(p=>'<div class="ask"><h5>'+esc(p.path)+'</h5>'+
  '<div class="by">'+esc(nice(p.by))+' · '+clock(p.ts)+'</div>'+
  '<pre>'+(p.diff||"").split("\n").map(l=>{
   const c=l[0]==="+"&&l.slice(0,3)!=="+++"?"ad":l[0]==="-"&&l.slice(0,3)!=="---"?"rm":l[0]==="@"?"hh":"";
   return c?'<span class="'+c+'">'+esc(l)+'</span>':esc(l)}).join("\n")+'</pre>'+
  '<div class="btns"><button class="yes" data-id="'+p.id+'" data-allow="1">Allow</button>'+
  '<button data-id="'+p.id+'" data-allow="0">Discard</button></div></div>').join("");
}
async function decide(id,allow){
 const r=await jpost("/api/code/approve",{id:+id,allow:!!allow});
 say(r&&r.ok?(allow?"applied":"discarded"):((r&&r.error)||"could not do that"));
 loadAsks();
}
function paintMode(){
 document.querySelectorAll("#bwk-mode button").forEach(b=>b.setAttribute("aria-pressed",b.dataset.m===MODE?"true":"false"));
}
async function setMode(m){
 const r=await jpost("/api/config",{code_mode:m});
 if(r&&r.ok){MODE=m;paintMode();say({plan:"Plan — the seats are read-only",edit:"Edit — writes wait for you",
  bypass:"Bypass — writes land straight away"}[m]||m)}
 else say((r&&r.error)||"could not change that");
 if(window.braidCodeMode)try{window.braidCodeMode(m)}catch(e){}
}
window.braidWork={mount:mount,open:open,close:close,toggle:toggle,push:push,tab:tab,sync:sync,
 setLive:setLive,unseen:()=>UNSEEN,isOpen:()=>OPEN,mode:()=>MODE};
})();
