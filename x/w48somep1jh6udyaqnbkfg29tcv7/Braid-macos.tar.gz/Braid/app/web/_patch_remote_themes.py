from pathlib import Path
import re
remote=Path.home()/".grok"/"plugins"/"grok-remote"/"web"/"index.html"
rt=remote.read_text(encoding="utf-8")
# extract theme CSS from mode dark through :root defaults before *{
m=re.search(r'/\* Surfaces: dark / light[\s\S]*?/\* default if attrs missing \*/\s*:root\{[\s\S]*?--radius:14px\}',rt)
if not m:
 raise SystemExit("could not extract remote theme CSS")
theme_css=m.group(0)
# add delve aliases + seat colors after theme_css
aliases=r'''
/* Delve aliases onto Remote tokens */
html{
  --bubble:var(--panel2);--me:var(--me-bg);--input:var(--in);--focus:var(--acc);
  --shadow:0 8px 24px -12px rgba(0,0,0,.55);--accent2:var(--acc-soft);
  --claude:#a78bfa;--grok:#fbbf24;--adam:#2dd4bf;--google:#4f8cf7;
}
html[data-mode="light"]{--claude:#7c3aed;--grok:#ca8a04;--adam:#0d9488;--google:#2563eb;--shadow:0 8px 24px -12px rgba(0,0,0,.1)}
html[data-variant="grok"][data-mode="dark"]{--claude:#c4b5fd;--grok:#e4e4e7;--adam:#a1a1aa;--google:#d4d4d8}
/* Ambient like Remote */
body{background-image:radial-gradient(min(900px,80vw) min(420px,40vh) at 50% -60px,var(--acc-dim),transparent 60%)!important}
header,footer,.toolbar,.side,.drawer{backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px)}
header{background:color-mix(in srgb,var(--panel) 92%,transparent)!important}
footer{background:color-mix(in srgb,var(--panel) 94%,transparent)!important}
.bub{box-shadow:var(--elev-2,0 8px 24px -12px rgba(0,0,0,.45))}
.row.me .bub{background:var(--me-bg)!important;border-color:var(--me-line)!important}
.send{background:var(--acc)!important;color:#08111f}
html[data-variant="grok"] .send,html[data-mode="light"] .send{color:#fff!important}
html[data-variant="grok"][data-mode="light"] .send{color:#fafafa!important;background:#18181b!important}
html[data-variant="win95"] .bub,html[data-variant="win95"] .sess,html[data-variant="win95"] .iconbtn,html[data-variant="win95"] .mini,html[data-variant="win95"] .tab,html[data-variant="win95"] .dbtn{
  border-radius:0!important;border-width:2px;border-style:solid;border-color:#ffffff #808080 #808080 #ffffff;box-shadow:none}
html[data-variant="win95"] header{background:linear-gradient(90deg,#000080,#1084d0)!important;color:#fff;border:none}
html[data-variant="win95"] header .logo,html[data-variant="win95"] header .logo b,html[data-variant="win95"] header .sub{color:#fff!important}
html[data-variant="matrix"] body{text-shadow:0 0 6px color-mix(in srgb,var(--acc) 35%,transparent)}
html[data-variant="matrix"] .logo b,html[data-variant="matrix"] .send{text-shadow:0 0 10px var(--acc-glow)}
html[data-variant="commodore"] .logo b{text-shadow:2px 2px 0 color-mix(in srgb,var(--acc) 40%,transparent)}
html[data-variant="ubuntu"] .send{border-radius:999px!important;color:#fff!important}
html[data-variant="amiga"] header{background:linear-gradient(180deg,#ffcc66,#ff8800 40%,#cc6600)!important;border:none}
html[data-variant="amiga"] header .logo,html[data-variant="amiga"] header .logo b,html[data-variant="amiga"] header .sub{color:#000!important}
.theme-sep{width:100%;font-size:10px;font-family:var(--font-mono,ui-monospace,monospace);color:var(--mut);letter-spacing:.8px;text-transform:uppercase;margin:10px 0 4px;opacity:.85;grid-column:1/-1}
.theme-grid{display:grid;grid-template-columns:1fr 1fr;gap:7px}
.theme-btn{border:1px solid var(--line);border-radius:var(--radius,10px);padding:10px;cursor:pointer;background:var(--panel2);color:var(--tx);text-align:left;font-size:12px}
.theme-btn.on{border-color:var(--acc);box-shadow:0 0 0 1px var(--acc),0 0 16px var(--acc-dim)}
.theme-btn small{display:block;color:var(--mut);margin-top:3px}
.mode-row{display:flex;gap:6px;margin:0 0 10px}
.mode-row button{flex:1;border:1px solid var(--line);border-radius:999px;padding:7px;background:var(--panel2);color:var(--tx);cursor:pointer;font-size:12px}
.mode-row button.on{border-color:var(--acc);background:color-mix(in srgb,var(--acc) 14%,var(--panel2));color:var(--tx)}
'''
# strip legacy chrome from remote extract that references non-delve classes? keep theme-sep only from remote - we have our own extras
# remove remote's .theme-sep and win95 rules that are incomplete - we added our own
theme_css=re.sub(r'/\* Legacy chrome extras \*/[\s\S]*?\.theme-sep\{[^}]+\}','',theme_css)
# also remove remote :root default at end of extract - we have aliases
# Keep remote :root for defaults
delve=Path("index.html")
t=delve.read_text(encoding="utf-8")
# replace html tag
t=re.sub(r'<html[^>]*>','<html lang="en" data-mode="dark" data-variant="scient">',t,count=1)
# replace old theme block from :root,html[data-theme through high-contrast block
old_theme=re.search(r':root,html\[data-theme="midnight"\]\{[\s\S]*?html\[data-theme="high-contrast"\]\{[^}]+\}',t)
if not old_theme:
 # try alternate
 old_theme=re.search(r':root,html\[data-theme[\s\S]*?html\[data-theme="high-contrast"\]\{[^}]+\}',t)
if not old_theme:
 raise SystemExit("old theme block not found")
t=t[:old_theme.start()]+theme_css+"\n"+aliases+"\n"+t[old_theme.end():]
# map remaining --bubble/--me/--input/--focus usages already aliased
# fix body font to use var(--font)
t=t.replace(
 'body{background:var(--bg);color:var(--tx);font:14.5px/1.5 ui-sans-serif,system-ui,Segoe UI,Roboto,Arial;display:flex;flex-direction:column;overflow:hidden}',
 'body{background:var(--bg);color:var(--tx);font:14.5px/1.5 var(--font,system-ui,sans-serif);display:flex;flex-direction:column;overflow:hidden}'
)
# settings: mode row + theme grid structure
t=t.replace(
 '<h4>Theme</h4>\n<div class="theme-grid" id="theme-grid"></div>',
 '<h4>Theme</h4>\n<div class="mode-row"><button type="button" id="mode-dark" class="on">Dark</button><button type="button" id="mode-light">Light</button></div>\n<div class="theme-grid" id="theme-grid"></div>'
)
# replace THEMES + applyTheme + initThemes
js_old=re.search(r'const THEMES=\[[\s\S]*?function initThemes\(\)\{[\s\S]*?\}\n',t)
if not js_old:
 # looser
 js_old=re.search(r'const THEMES=\[[\s\S]*?function initThemes\(\)\{[\s\S]*?applyTheme\(loadPref\("theme","midnight"\)\)\}\n',t)
new_js=r'''
const PRODUCT_VARIANTS=[
{id:"scient",label:"Amni Scient",desc:"signature green"},
{id:"grok",label:"Grok",desc:"greyscale chrome"},
{id:"ai",label:"Amni Ai",desc:"warm amber"},
{id:"explore",label:"Explore",desc:"sky blue"},
{id:"calc",label:"Calc",desc:"blaze orange"},
{id:"learn",label:"Learn",desc:"leaf green"},
{id:"crypt",label:"Crypt",desc:"signal blue"},
{id:"haven",label:"Haven",desc:"violet"},
{id:"core",label:"Core",desc:"ember red"}
];
const LEGACY_VARIANTS=[
{id:"aim",label:"AIM",desc:"classic messenger"},
{id:"win95",label:"Win95",desc:"grey chrome"},
{id:"commodore",label:"Commodore",desc:"64 vibes"},
{id:"atari",label:"Atari",desc:"sunset fire"},
{id:"ubuntu",label:"Ubuntu",desc:"aubergine"},
{id:"matrix",label:"Matrix",desc:"terminal rain"},
{id:"dos",label:"DOS",desc:"blue screen"},
{id:"amiga",label:"Amiga",desc:"workbench"}
];
const THEME_COLORS={scient:"#00ff9d",grok:"#d4d4d8",ai:"#ffb74d",explore:"#00b4ff",calc:"#ff6b35",learn:"#2ecc71",crypt:"#2979ff",haven:"#7c5cfc",core:"#ef5350",aim:"#ffcc00",win95:"#000080",commodore:"#a4e4fc",atari:"#e25303",ubuntu:"#e95420",matrix:"#00ff41",dos:"#ffff55",amiga:"#ff8800"};
function toast(msg){const el=document.getElementById("toast");if(!el)return;el.textContent=msg;el.classList.add("on");setTimeout(()=>el.classList.remove("on"),2200)}
function loadPref(k,d){try{const v=localStorage.getItem("delve_"+k);return v==null?d:v}catch(e){return d}}
function savePref(k,v){try{localStorage.setItem("delve_"+k,v)}catch(e){}}
function applyTheme(variant,mode){
 variant=variant||loadPref("variant","scient");
 mode=mode||loadPref("mode","dark");
 if(!THEME_COLORS[variant]) variant="scient";
 if(mode!=="light"&&mode!=="dark") mode="dark";
 document.documentElement.setAttribute("data-variant",variant);
 document.documentElement.setAttribute("data-mode",mode);
 document.documentElement.removeAttribute("data-theme");
 savePref("variant",variant);savePref("mode",mode);
 const tc=document.getElementById("themeColor");
 if(tc) tc.setAttribute("content", mode==="light"?"#f7f7f8":(THEME_COLORS[variant]||"#0a0b0e"));
 document.querySelectorAll(".theme-btn").forEach(b=>b.classList.toggle("on",b.dataset.v===variant));
 const md=document.getElementById("mode-dark"),ml=document.getElementById("mode-light");
 if(md) md.classList.toggle("on",mode==="dark");
 if(ml) ml.classList.toggle("on",mode==="light");
}
function initThemes(){
 const g=document.getElementById("theme-grid"); if(!g)return;
 let html='<div class="theme-sep">Product</div>';
 html+=PRODUCT_VARIANTS.map(t=>'<button type="button" class="theme-btn" data-v="'+t.id+'"><b>'+t.label+'</b><small>'+t.desc+'</small></button>').join("");
 html+='<div class="theme-sep">Legacy</div>';
 html+=LEGACY_VARIANTS.map(t=>'<button type="button" class="theme-btn" data-v="'+t.id+'"><b>'+t.label+'</b><small>'+t.desc+'</small></button>').join("");
 g.innerHTML=html;
 g.querySelectorAll(".theme-btn").forEach(b=>b.onclick=()=>applyTheme(b.dataset.v, loadPref("mode","dark")));
 const md=document.getElementById("mode-dark"),ml=document.getElementById("mode-light");
 if(md) md.onclick=()=>applyTheme(loadPref("variant","scient"),"dark");
 if(ml) ml.onclick=()=>applyTheme(loadPref("variant","scient"),"light");
 let v=loadPref("variant","");
 let m=loadPref("mode","");
 const old=loadPref("theme","");
 if(!v && old){
  const map={midnight:"scient",ocean:"explore",ember:"calc",forest:"learn",light:"scient","high-contrast":"grok"};
  v=map[old]||"scient"; m=(old==="light")?"light":"dark";
 }
 applyTheme(v||"scient", m||"dark");
}
'''
if js_old:
 t=t[:js_old.start()]+new_js+t[js_old.end():]
 print("js replaced")
else:
 # try replace from const THEMES to end of initThemes
 m2=re.search(r'const THEMES=\[[\s\S]*?applyTheme\(loadPref\([\'"]theme[\'"],[\'"]midnight[\'"]\)\);\n?\}',t)
 if not m2:
  m2=re.search(r'const THEMES=\[[\s\S]*?function initThemes\(\)\{[\s\S]*?\n\}',t)
 if m2:
  t=t[:m2.start()]+new_js+t[m2.end():]
  print("js replaced loose")
 else:
  print("WARN js not replaced")
  # inject before wireQoL
  if "function applyTheme(id)" in t:
   t=re.sub(r'const THEMES=\[[\s\S]*?function initThemes\(\)\{[\s\S]*?\}',new_js.strip(),t,count=1)
   print("js regex2", "PRODUCT_VARIANTS" in t)
if 'id="themeColor"' not in t:
 t=t.replace('<title>Amni-Delve</title>','<meta name="theme-color" content="#0a0b0e" id="themeColor"/>\n<title>Amni-Delve</title>')
# ensure --in used if some places still use --input - aliases handle it
# bar tracks dark hardcoded #2a3140 - soft fix
t=t.replace('background:#2a3140','background:color-mix(in srgb,var(--line) 80%,var(--bg))')
t=t.replace('background:#333b49','background:color-mix(in srgb,var(--line) 70%,var(--bg))')
Path("index.html").write_text(t,encoding="utf-8")
print("ok", "data-variant" in t, "PRODUCT_VARIANTS" in t, "scient" in t and "matrix" in t)
print("len", len(t))
