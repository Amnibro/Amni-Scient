"""Inline room.js + md.js + ui.js + work.js into the UI pages.

The pages are served straight off disk, but new ROUTES need a server restart. Shipping the
renderer as <script src="/md.js"> therefore breaks every already-running instance the moment
the HTML lands: the tags 404, boot throws, and the app goes blank. Inline the libraries so a
page update is self-contained and needs nothing from the server.

web/md.js and web/room.js stay the single source of truth - the tests run against them.
Re-run this after editing either one:  python web/_bundle.py
"""
import os,re
WEB=os.path.dirname(os.path.abspath(__file__))
PAGES=("simple.html","basic.html")
LIBS=("room.js","md.js","ui.js","work.js")
OPEN,CLOSE="<!--braidlib-->","<!--/braidlib-->"
def bundle():
    body="".join("/* %s */\n%s\n"%(n,open(os.path.join(WEB,n),encoding="utf-8").read()) for n in LIBS)
    block=OPEN+"<script>\n"+body+"</script>"+CLOSE
    for pg in PAGES:
        p=os.path.join(WEB,pg)
        s=open(p,encoding="utf-8").read()
        if OPEN in s and CLOSE in s:
            s=re.sub(re.escape(OPEN)+r"[\s\S]*?"+re.escape(CLOSE),lambda m:block,s,count=1)
        else:
            tags=re.compile(r'[ \t]*<script src="/(?:room|md)\.js"></script>\n?')
            if not tags.search(s):
                raise SystemExit(pg+": no <script src> tags and no braidlib block - nothing to replace")
            s=tags.sub("",s)
            anchor='<script defer src="https://cdn.jsdelivr.net/npm/katex'
            i=s.index(anchor);j=s.index("</script>",i)+len("</script>")
            s=s[:j]+"\n"+block+s[j:]
        open(p,"w",encoding="utf-8").write(s)
        print("bundled %-14s %6.1f KB"%(pg,len(s)/1024))
if __name__=="__main__":bundle()
