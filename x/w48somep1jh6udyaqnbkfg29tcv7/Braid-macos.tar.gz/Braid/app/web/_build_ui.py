# builds index.html — run from Amni-Delve/web
from pathlib import Path
legacy=Path("_legacy_script.js").read_text(encoding="utf-8")
# strip trailing init wait if we re-add
html=r'''<!doctype html>
<html lang="en" data-theme="midnight">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>Amni-Delve</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/katex@0.16.21/dist/katex.min.css" crossorigin="anonymous"/>
<script defer src="https://cdn.jsdelivr.net/npm/katex@0.16.21/dist/katex.min.js" crossorigin="anonymous"></script>
<style>
:root,html[data-theme="midnight"]{
--bg:#0b0e14;--panel:#121722;--panel2:#1a2130;--line:#2a3344;--tx:#e8edf7;--mut:#8b97ab;
--you:#38bdf8;--claude:#a78bfa;--grok:#fbbf24;--adam:#2dd4bf;--google:#4f8cf7;
--ok:#34d399;--bad:#f87171;--acc:#60a5fa;--accent2:#818cf8;--shadow:rgba(0,0,0,.45);
--bubble:#151b28;--me:#0f2433;--input:#161e2c;--focus:#3b82f6}
html[data-theme="ocean"]{
--bg:#07131a;--panel:#0c1c26;--panel2:#123041;--line:#1e4a5c;--tx:#e6f6ff;--mut:#7aa8bc;
--you:#22d3ee;--claude:#a78bfa;--grok:#fbbf24;--adam:#2dd4bf;--google:#38bdf8;
--ok:#34d399;--bad:#fb7185;--acc:#22d3ee;--accent2:#67e8f9;--shadow:rgba(0,20,30,.5);
--bubble:#0e2230;--me:#0a2a38;--input:#0f2533;--focus:#06b6d4}
html[data-theme="ember"]{
--bg:#140c0a;--panel:#1c1210;--panel2:#2a1814;--line:#4a2a22;--tx:#ffefe8;--mut:#b8988c;
--you:#fb923c;--claude:#c084fc;--grok:#fbbf24;--adam:#4ade80;--google:#60a5fa;
--ok:#4ade80;--bad:#f87171;--acc:#fb923c;--accent2:#f97316;--shadow:rgba(30,0,0,.5);
--bubble:#221612;--me:#2a180e;--input:#241612;--focus:#ea580c}
html[data-theme="forest"]{
--bg:#0a120e;--panel:#101a15;--panel2:#18261e;--line:#2a4034;--tx:#e8f5ee;--mut:#8aab98;
--you:#4ade80;--claude:#a78bfa;--grok:#facc15;--adam:#2dd4bf;--google:#60a5fa;
--ok:#22c55e;--bad:#f87171;--acc:#4ade80;--accent2:#86efac;--shadow:rgba(0,20,10,.5);
--bubble:#142019;--me:#0f2418;--input:#15241c;--focus:#16a34a}
html[data-theme="light"]{
--bg:#f4f6fb;--panel:#ffffff;--panel2:#eef2f8;--line:#d5deea;--tx:#1e293b;--mut:#64748b;
--you:#0284c7;--claude:#7c3aed;--grok:#ca8a04;--adam:#0d9488;--google:#2563eb;
--ok:#16a34a;--bad:#dc2626;--acc:#2563eb;--accent2:#6366f1;--shadow:rgba(15,23,42,.12);
--bubble:#ffffff;--me:#e0f2fe;--input:#f8fafc;--focus:#2563eb}
html[data-theme="high-contrast"]{
--bg:#000;--panel:#0a0a0a;--panel2:#141414;--line:#444;--tx:#fff;--mut:#bbb;
--you:#0ff;--claude:#f0f;--grok:#ff0;--adam:#0f8;--google:#4af;
--ok:#0f0;--bad:#f44;--acc:#fff;--accent2:#fff;--shadow:rgba(0,0,0,.8);
--bubble:#111;--me:#002222;--input:#111;--focus:#fff}
*{box-sizing:border-box}
html,body{height:100%;margin:0}
body{background:var(--bg);color:var(--tx);font:14.5px/1.5 ui-sans-serif,system-ui,Segoe UI,Roboto,Arial;display:flex;flex-direction:column;overflow:hidden}
body.compact{font-size:13px}
.app{display:flex;flex:1;min-height:0}
/* side panels */
.side{width:0;overflow:hidden;background:var(--panel);border-right:1px solid var(--line);transition:width .2s ease;display:flex;flex-direction:column}
.side.on{width:300px}
.side-h{display:flex;align-items:center;gap:8px;padding:12px 12px 8px;border-bottom:1px solid var(--line)}
.side-h h3{margin:0;font-size:13px;letter-spacing:.4px;flex:1}
.side-tools{padding:8px 10px;display:flex;gap:6px;flex-wrap:wrap;border-bottom:1px solid var(--line)}
.side-list{flex:1;overflow-y:auto;padding:8px}
.sess{border:1px solid var(--line);background:var(--panel2);border-radius:12px;padding:10px;margin:0 0 8px;cursor:pointer;transition:border-color .15s,transform .1s}
.sess:hover{border-color:var(--acc)}
.sess.cur{border-color:var(--acc);box-shadow:0 0 0 1px var(--acc)}
.sess .t{font-weight:650;font-size:13px;margin:0 0 4px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.sess .p{color:var(--mut);font-size:11.5px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;min-height:2.6em}
.sess .m{display:flex;gap:8px;margin-top:7px;font-size:10.5px;color:var(--mut);flex-wrap:wrap}
.sess .m b{color:var(--tx);font-weight:600}
.chip-sp{display:inline-block;padding:1px 6px;border-radius:999px;background:var(--bg);border:1px solid var(--line);font-size:10px}
.chip-sp.Claude{color:var(--claude)}
.chip-sp.Grok{color:var(--grok)}
.chip-sp.Google{color:var(--google)}
.chip-sp.Adam{color:var(--adam)}
.chip-sp.Anthony,.chip-sp.You{color:var(--you)}
/* main column */
.col{flex:1;display:flex;flex-direction:column;min-width:0;min-height:0}
header{display:flex;align-items:center;gap:10px;padding:10px 14px;border-bottom:1px solid var(--line);background:var(--panel);flex-wrap:wrap}
.logo{font-weight:750;font-size:16px;letter-spacing:.3px}
.logo b{color:var(--acc)}
.sub{color:var(--mut);font-size:11.5px}
.sess-pill{font-size:11px;border:1px solid var(--line);background:var(--panel2);border-radius:999px;padding:3px 10px;max-width:220px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:var(--mut)}
.sess-pill b{color:var(--tx)}
.badge{font-size:10.5px;color:var(--ok);border:1px solid var(--line);border-radius:999px;padding:2px 8px;background:var(--panel2)}
.usage-strip{display:flex;gap:7px;align-items:center;flex-wrap:wrap;font-size:10.5px;color:var(--mut)}
.ub{display:flex;align-items:center;gap:5px;border:1px solid var(--line);border-radius:999px;padding:2px 8px;background:var(--panel2)}
.ub b{color:var(--tx);font-weight:650}
.ubar{width:42px;height:5px;border-radius:999px;background:#2a3140;overflow:hidden}
.ubar>i{display:block;height:100%;border-radius:999px;background:var(--ok)}
.ubar.warn>i{background:var(--grok)}
.ubar.crit>i{background:var(--bad)}
.ub.claude b{color:var(--claude)}.ub.grok b{color:var(--grok)}.ub.google b{color:var(--google)}.ub.adam b{color:var(--adam)}
.seat-dots{display:flex;gap:6px;align-items:center}
.sdot{width:8px;height:8px;border-radius:50%;background:#555;box-shadow:0 0 0 2px var(--panel2)}
.sdot.on{background:var(--ok)}
.sdot.off{background:var(--bad)}
.sdot.Claude.on{background:var(--claude)}.sdot.Grok.on{background:var(--grok)}.sdot.Google.on{background:var(--google)}.sdot.Adam.on{background:var(--adam)}
.spacer{flex:1}
.dot{width:9px;height:9px;border-radius:50%;background:var(--ok)}
.dot.busy{background:var(--grok);animation:pulse 1s infinite}
@keyframes pulse{0%,100%{opacity:.35}50%{opacity:1}}
.iconbtn,.mini{background:var(--panel2);color:var(--tx);border:1px solid var(--line);border-radius:9px;padding:7px 10px;cursor:pointer;font-size:13px}
.iconbtn:hover,.mini:hover{border-color:var(--acc)}
.estop{background:#3a1414;color:var(--bad);border:1px solid #5b1d1d;font-weight:700;border-radius:9px;padding:7px 12px;cursor:pointer;opacity:.5;pointer-events:none}
.estop.on{opacity:1;pointer-events:auto;animation:pulse 1.2s infinite}
.toolbar{display:flex;gap:6px;align-items:center;padding:6px 12px;border-bottom:1px solid var(--line);background:var(--panel);flex-wrap:wrap}
.toolbar input[type=search]{flex:1;min-width:140px;background:var(--input);color:var(--tx);border:1px solid var(--line);border-radius:8px;padding:6px 10px}
.toolbar label{font-size:11px;color:var(--mut);display:flex;align-items:center;gap:4px}
main{flex:1;overflow-y:auto;padding:16px 0;min-height:0}
.wrap{max-width:900px;margin:0 auto;padding:0 16px}
.row{display:flex;gap:10px;margin:12px 0;align-items:flex-start}
.row.me{flex-direction:row-reverse}
.row.hide{display:none}
.av{flex:none;width:30px;height:30px;border-radius:50%;display:grid;place-items:center;font-weight:700;font-size:12px;color:#0e1014}
.av.You{background:var(--you)}.av.Claude{background:var(--claude)}.av.Grok{background:var(--grok)}.av.Adam{background:var(--adam)}.av.Google{background:var(--google)}
.bub{max-width:min(82%,760px);background:var(--bubble);border:1px solid var(--line);border-radius:14px;padding:9px 13px;box-shadow:0 4px 18px var(--shadow)}
.row.me .bub{background:var(--me);border-color:color-mix(in srgb,var(--you) 30%,var(--line))}
.nm{font-size:11.5px;color:var(--mut);margin:0 0 3px;font-weight:650}
.nm.Claude{color:var(--claude)}.nm.Grok{color:var(--grok)}.nm.You{color:var(--you)}.nm.Adam{color:var(--adam)}.nm.Google{color:var(--google)}
.bub .body{white-space:normal;word-wrap:break-word;overflow-wrap:anywhere;line-height:1.55}
.bub .body p{margin:0 0 .55em}.bub .body p:last-child{margin-bottom:0}
.bub .body h2,.bub .body h3,.bub .body h4{margin:.75em 0 .35em;line-height:1.25;font-weight:650}
.bub .body h2{font-size:1.12em}.bub .body h3{font-size:1.05em}.bub .body h4{font-size:1em;color:var(--mut);font-weight:600}
.bub .body ul,.bub .body ol{margin:.35em 0 .6em;padding-left:1.4em}.bub .body li{margin:.18em 0}
.bub .body .sec{margin:.65em 0 .35em}.bub .body .sec .n{color:var(--acc);font-weight:700;margin-right:.25em}
.bub .body hr{border:none;border-top:1px solid var(--line);margin:.8em 0}
.bub .body blockquote{margin:.5em 0;padding:.35em .8em;border-left:3px solid var(--line);color:var(--mut)}
.bub .body .katex-display{margin:.7em 0;overflow-x:auto;overflow-y:hidden;padding:.15em 0}
.bub .body .katex{font-size:1.06em}
.bub .body .math-fallback{font-family:ui-monospace,Consolas,monospace;color:var(--acc);overflow-x:auto}
.bub .body .math-display{display:block;margin:.7em 0;overflow-x:auto}
.bub pre{background:var(--bg);border:1px solid var(--line);border-radius:9px;padding:10px;overflow:auto;margin:7px 0}
.bub code{font-family:ui-monospace,Consolas,monospace;font-size:12.5px}
.bub :not(pre)>code{background:var(--bg);border:1px solid var(--line);border-radius:5px;padding:1px 5px}
.bub a{color:var(--acc)}
.mark{background:color-mix(in srgb,var(--grok) 35%,transparent);border-radius:3px;padding:0 2px}
.chip{text-align:center;color:var(--mut);font-size:11.5px;margin:12px 0;text-transform:uppercase;letter-spacing:.5px}
.chip span{border:1px solid var(--line);border-radius:999px;padding:3px 11px;background:var(--panel)}
.learn{text-align:center;margin:10px 0}
.learn span{border:1px solid color-mix(in srgb,var(--ok) 35%,var(--line));color:var(--ok);background:color-mix(in srgb,var(--ok) 10%,var(--panel));border-radius:999px;padding:4px 12px;font-size:12px}
.think{display:flex;gap:5px;align-items:center;color:var(--mut);font-size:12.5px}
.think i{width:6px;height:6px;border-radius:50%;background:var(--mut);display:inline-block;animation:blink 1.2s infinite}
.think i:nth-child(2){animation-delay:.2s}.think i:nth-child(3){animation-delay:.4s}
@keyframes blink{0%,80%,100%{opacity:.2}40%{opacity:1}}
footer{border-top:1px solid var(--line);background:var(--panel);padding:10px 0}
.composer{max-width:900px;margin:0 auto;padding:0 16px;display:flex;flex-direction:column;gap:8px}
.tabs{display:flex;gap:6px;flex-wrap:wrap;align-items:center}
.tab{background:var(--panel2);color:var(--mut);border:1px solid var(--line);border-radius:999px;padding:5px 12px;cursor:pointer;font-size:12.5px}
.tab.on{color:var(--tx);border-color:var(--acc);background:color-mix(in srgb,var(--acc) 14%,var(--panel2))}
.tab.both.on{border-color:var(--claude)}.tab.adam.on{border-color:var(--adam)}.tab.google.on{border-color:var(--google)}
select{width:100%;background:var(--panel2);color:var(--tx);border:1px solid var(--line);border-radius:8px;padding:8px}
.deb{display:flex;align-items:center;gap:6px;margin-left:auto;color:var(--mut);font-size:12.5px}
.deb input{width:46px;background:var(--panel2);color:var(--tx);border:1px solid var(--line);border-radius:7px;padding:5px;text-align:center}
.deb button{background:var(--panel2);color:var(--tx);border:1px solid var(--line);border-radius:8px;padding:6px 10px;cursor:pointer}
.inrow{display:flex;gap:8px;align-items:flex-end}
textarea{flex:1;resize:none;background:var(--input);color:var(--tx);border:1px solid var(--line);border-radius:11px;padding:10px 12px;font:inherit;max-height:180px;min-height:44px}
textarea:focus{outline:none;border-color:var(--focus)}
.send{background:var(--acc);color:#08111f;border:none;border-radius:11px;padding:0 16px;height:44px;font-weight:750;cursor:pointer}
.send:disabled{opacity:.5;cursor:default}
.send.interject{background:var(--grok)}
.hint{color:var(--mut);font-size:11px}
.drawer{position:fixed;top:0;right:0;height:100%;width:360px;max-width:92vw;background:var(--panel);border-left:1px solid var(--line);transform:translateX(100%);transition:.2s;padding:16px;overflow-y:auto;z-index:30;box-shadow:-8px 0 30px var(--shadow)}
.drawer.on{transform:none}
.drawer h3{margin:4px 0 12px;font-size:14px}
.drawer h4{margin:14px 0 8px;font-size:12px;color:var(--mut);text-transform:uppercase;letter-spacing:.5px}
.fld{margin:11px 0}.fld label{display:block;color:var(--mut);font-size:11.5px;margin-bottom:4px}
.fld input[type=text],.fld select{width:100%;background:var(--panel2);color:var(--tx);border:1px solid var(--line);border-radius:8px;padding:8px}
.sw{display:flex;align-items:center;justify-content:space-between;padding:8px 0;border-bottom:1px solid var(--line);font-size:13px}
.toggle{width:42px;height:23px;border-radius:999px;background:#333b49;position:relative;cursor:pointer;border:1px solid var(--line);flex:none}
.toggle.on{background:var(--ok)}
.toggle::after{content:"";position:absolute;top:2px;left:2px;width:17px;height:17px;border-radius:50%;background:#0e1014;transition:.15s}
.toggle.on::after{left:21px}
.kv{color:var(--mut);font-size:11.5px;word-break:break-all;margin:6px 0}
.kv b{color:var(--tx);font-weight:600}
.dbtn{width:100%;background:var(--panel2);color:var(--tx);border:1px solid var(--line);border-radius:9px;padding:9px;cursor:pointer;margin-top:8px;font-size:13px}
.dbtn:hover{border-color:var(--acc)}.dbtn.danger:hover{border-color:var(--bad);color:var(--bad)}
.theme-grid{display:grid;grid-template-columns:1fr 1fr;gap:7px}
.theme-btn{border:1px solid var(--line);border-radius:10px;padding:10px;cursor:pointer;background:var(--panel2);color:var(--tx);text-align:left;font-size:12px}
.theme-btn.on{border-color:var(--acc);box-shadow:0 0 0 1px var(--acc)}
.theme-btn small{display:block;color:var(--mut);margin-top:3px}
.usage-card{border:1px solid var(--line);border-radius:12px;padding:10px 11px;margin:10px 0;background:var(--panel2)}
.usage-card h4{margin:0 0 7px;font-size:12.5px;display:flex;justify-content:space-between;align-items:center;text-transform:none;letter-spacing:0;color:var(--tx)}
.usage-card h4 span{font-weight:500;color:var(--mut);font-size:11px}
.usage-row{display:flex;align-items:center;gap:8px;margin:6px 0;font-size:12px}
.usage-row .lab{width:80px;color:var(--mut);flex:none}
.usage-row .track{flex:1;height:8px;border-radius:999px;background:#2a3140;overflow:hidden}
.usage-row .track>i{display:block;height:100%;border-radius:999px;background:var(--ok)}
.usage-row .track.warn>i{background:var(--grok)}.usage-row .track.crit>i{background:var(--bad)}
.usage-row .pct{width:40px;text-align:right;font-variant-numeric:tabular-nums}
.usage-meta{font-size:11px;color:var(--mut);margin-top:5px;line-height:1.45}
.scrim{position:fixed;inset:0;background:rgba(0,0,0,.45);opacity:0;pointer-events:none;transition:.2s;z-index:25}
.scrim.on{opacity:1;pointer-events:auto}
.toast{position:fixed;bottom:18px;left:50%;transform:translateX(-50%);background:var(--panel2);border:1px solid var(--line);color:var(--tx);padding:8px 14px;border-radius:999px;font-size:12.5px;z-index:50;opacity:0;transition:.2s;pointer-events:none}
.toast.on{opacity:1}
@media(max-width:820px){
.side.on{position:fixed;left:0;top:0;bottom:0;z-index:28;width:min(88vw,300px)}
.usage-strip{display:none}
.sess-pill{max-width:120px}
}
</style>
</head>
<body>
<div class="app">
<aside class="side" id="side">
<div class="side-h">
<h3>Conversations</h3>
<button class="mini" id="side-close" title="Close">✕</button>
</div>
<div class="side-tools">
<button class="mini" id="btn-new">＋ New</button>
<button class="mini" id="btn-refresh-sess">↻</button>
<input type="search" id="sess-filter" placeholder="Filter…" style="flex:1;min-width:90px;background:var(--input);color:var(--tx);border:1px solid var(--line);border-radius:8px;padding:6px 8px"/>
</div>
<div class="side-list" id="sess-list"><div class="kv">Loading…</div></div>
</aside>
<div class="col">
<header>
<button class="iconbtn" id="btn-convo" title="Conversations">☰</button>
<div class="logo">Amni·<b>Delve</b></div>
<div class="sess-pill" id="sess-pill" title="Current conversation">—</div>
<div class="badge" id="badge">subscription</div>
<div class="seat-dots" id="seat-dots" title="Seat connectivity">
<span class="sdot Claude" id="sd-claude" title="Claude"></span>
<span class="sdot Grok" id="sd-grok" title="Grok"></span>
<span class="sdot Google" id="sd-google" title="Google"></span>
<span class="sdot Adam" id="sd-adam" title="Adam"></span>
</div>
<div class="usage-strip" id="usage-strip">
<div class="ub claude" id="uh-claude"><b>Claude</b><span>—</span></div>
<div class="ub grok" id="uh-grok"><b>Grok</b><span>—</span></div>
<div class="ub google" id="uh-google"><b>Google</b><span>—</span></div>
</div>
<div class="spacer"></div>
<div class="dot" id="dot" title="idle"></div>
<button class="estop" id="estop" title="Esc / e-stop">■ STOP</button>
<button class="iconbtn" id="gear" title="settings">⚙</button>
</header>
<div class="toolbar">
<input type="search" id="q" placeholder="Search transcript…"/>
<label><input type="checkbox" id="f-claude" checked/> Claude</label>
<label><input type="checkbox" id="f-grok" checked/> Grok</label>
<label><input type="checkbox" id="f-google" checked/> Google</label>
<label><input type="checkbox" id="f-adam" checked/> Adam</label>
<label><input type="checkbox" id="f-you" checked/> You</label>
<button class="mini" id="btn-bottom" title="Jump bottom">↓</button>
<button class="mini" id="btn-export" title="Export markdown">⤓</button>
</div>
<main id="main"><div class="wrap" id="feed"></div></main>
<footer>
<div class="composer">
<div class="tabs">
<div class="tab on" data-t="all">All · +Adam</div>
<div class="tab both" data-t="both">Both ⇄</div>
<div class="tab" data-t="claude">Claude</div>
<div class="tab" data-t="grok">Grok</div>
<div class="tab google" data-t="google">Google</div>
<div class="tab adam" data-t="adam">Adam</div>
<div class="deb"><span>debate</span><input id="rounds" type="number" min="1" max="50" value="3"/><button id="debate">start ⟳</button></div>
</div>
<div class="inrow">
<textarea id="box" placeholder="Message the room…  Enter send · Shift+Enter newline · Esc stop"></textarea>
<button class="send" id="send">Send</button>
</div>
<div class="hint" id="hint">Type while they talk to interject · Esc or STOP to halt</div>
</div>
</footer>
</div>
</div>
<div class="scrim" id="scrim"></div>
<div class="drawer" id="drawer">
<h3>Settings</h3>
<h4>Theme</h4>
<div class="theme-grid" id="theme-grid"></div>
<div class="sw"><span>Compact density</span><div class="toggle" id="tg-compact"></div></div>
<div class="sw"><span>Auto-scroll to new messages</span><div class="toggle on" id="tg-autoscroll"></div></div>
<div class="sw"><span>Sound on new reply</span><div class="toggle" id="tg-sound"></div></div>
<div class="sw"><span>Bypass permissions (filesystem)</span><div class="toggle" id="tg-bypass"></div></div>
<div class="sw"><span>Teach Adam (PTEX learning)</span><div class="toggle" id="tg-ptex"></div></div>
<div class="sw"><span>Adam fallback (covers Claude/Grok/Google)</span><div class="toggle" id="tg-adam"></div></div>
<div class="fld"><label>Adam mode</label><select id="adam-mode"><option value="light">light · 3B</option><option value="heavy">heavy</option></select></div>
<div class="kv" id="adam-stat">Adam: …</div>
<button class="dbtn" id="adam-start">Start Adam</button>
<div class="usage-card" id="usage-claude-card"><h4>Claude usage <span id="claude-plan">…</span></h4><div id="usage-claude-body">loading…</div></div>
<div class="usage-card" id="usage-grok-card"><h4>Grok usage <span id="grok-plan">…</span></h4><div id="usage-grok-body">loading…</div></div>
<div class="usage-card" id="usage-google-card"><h4>Google usage <span id="google-plan">…</span></h4><div id="usage-google-body">loading…</div></div>
<button class="dbtn" id="refresh-usage">Refresh usage</button>
<div class="fld"><label>Claude model</label><select id="m-claude"></select></div>
<div class="fld"><label>Grok model</label><select id="m-grok"></select></div>
<div class="fld"><label>Google model</label><select id="m-google"></select></div>
<button class="dbtn" id="save-cfg">Save settings</button>
<button class="dbtn" id="commit">Commit lessons → Adam PTEX</button>
<button class="dbtn" id="resume-last">Resume last rich session</button>
<button class="dbtn" id="btn-new2">＋ New conversation</button>
<button class="dbtn danger" id="clear">Clear / new blank</button>
<div class="kv" id="adam"></div>
<div class="kv" id="paths"></div>
<div class="kv" style="margin-top:14px">Shortcuts: <b>Enter</b> send · <b>Shift+Enter</b> newline · <b>Esc</b> stop · <b>Ctrl/Cmd+K</b> search · <b>Ctrl/Cmd+B</b> conversations</div>
</div>
<div class="toast" id="toast"></div>
<script>
'''
# patch legacy script lightly for new IDs that still exist
extra=r'''
/* === QoL + Conversations + Themes === */
const THEMES=[
{id:"midnight",label:"Midnight",desc:"default dark"},
{id:"ocean",label:"Ocean",desc:"cool teal"},
{id:"ember",label:"Ember",desc:"warm dusk"},
{id:"forest",label:"Forest",desc:"green night"},
{id:"light",label:"Light",desc:"day mode"},
{id:"high-contrast",label:"High contrast",desc:"max pop"}
];
function toast(msg){const el=document.getElementById("toast");el.textContent=msg;el.classList.add("on");setTimeout(()=>el.classList.remove("on"),2200)}
function loadPref(k,d){try{const v=localStorage.getItem("delve_"+k);return v==null?d:v}catch(e){return d}}
function savePref(k,v){try{localStorage.setItem("delve_"+k,v)}catch(e){}}
function applyTheme(id){document.documentElement.setAttribute("data-theme",id||"midnight");savePref("theme",id||"midnight");document.querySelectorAll(".theme-btn").forEach(b=>b.classList.toggle("on",b.dataset.t===id))}
function initThemes(){const g=document.getElementById("theme-grid");g.innerHTML=THEMES.map(t=>'<button type="button" class="theme-btn" data-t="'+t.id+'"><b>'+t.label+'</b><small>'+t.desc+'</small></button>').join("");g.querySelectorAll(".theme-btn").forEach(b=>b.onclick=()=>applyTheme(b.dataset.t));applyTheme(loadPref("theme","midnight"))}
function setSide(on){document.getElementById("side").classList.toggle("on",on);if(window.innerWidth<=820)document.getElementById("scrim").classList.toggle("on",on);if(on)refreshSessions()}
function fmtWhen(ts){try{const d=new Date(ts*1000);return d.toLocaleString()}catch(e){return ""}}
function fmtSize(n){if(n==null)return "";if(n<1024)return n+" B";if(n<1048576)return (n/1024).toFixed(1)+" KB";return (n/1048576).toFixed(1)+" MB"}
let SESSIONS=[],CUR_FILE="";
async function refreshSessions(){
const list=document.getElementById("sess-list");
try{
const r=await fetch("/api/sessions");const d=await r.json();
SESSIONS=d.sessions||[];CUR_FILE=d.current||CUR_FILE;
renderSessList();
updateSessPill();
}catch(e){list.innerHTML='<div class="kv">Failed to load sessions</div>'}
}
function renderSessList(){
const q=(document.getElementById("sess-filter").value||"").toLowerCase();
const list=document.getElementById("sess-list");
const rows=SESSIONS.filter(s=>{
const hay=((s.title||"")+" "+(s.preview||"")+" "+(s.name||"")).toLowerCase();
return !q||hay.includes(q);
});
if(!rows.length){list.innerHTML='<div class="kv">No conversations yet</div>';return}
list.innerHTML=rows.map(s=>{
const cur=s.name===CUR_FILE?" cur":"";
const pin=s.pinned?"📌 ":"";
const sp=(s.speakers||[]).slice(0,5).map(x=>'<span class="chip-sp '+esc(x)+'">'+esc(x)+'</span>').join(" ");
return '<div class="sess'+cur+'" data-name="'+esc(s.name)+'">'
+'<div class="t">'+pin+esc(s.title||s.name)+'</div>'
+'<div class="p">'+esc(s.preview||"")+'</div>'
+'<div class="m"><span><b>'+(s.messages!=null?s.messages:"?")+'</b> msgs</span><span>'+esc(fmtWhen(s.mtime))+'</span><span>'+esc(fmtSize(s.size))+'</span></div>'
+'<div class="m">'+sp+'</div></div>';
}).join("");
list.querySelectorAll(".sess").forEach(el=>{
el.onclick=async()=>{
const name=el.dataset.name;
if(name===CUR_FILE){toast("Already open");return}
const r=await post("/api/sessions/resume",{name:name});
if(r&&r.ok){CUR_FILE=name;await reloadTranscript();refreshSessions();toast("Resumed "+(r.messages||"?")+" messages");if(window.innerWidth<=820)setSide(false)}
else alert((r&&r.error)||"resume failed");
};
el.oncontextmenu=async(ev)=>{
ev.preventDefault();
const name=el.dataset.name;
const title=prompt("Title for conversation", (SESSIONS.find(x=>x.name===name)||{}).title||"");
if(title==null)return;
await post("/api/sessions/meta",{name:name,title:title});
refreshSessions();
};
});
}
function updateSessPill(){
const el=document.getElementById("sess-pill");
const cur=SESSIONS.find(s=>s.name===CUR_FILE);
const title=cur&&cur.title?cur.title:(CUR_FILE||"session");
const n=cur&&cur.messages!=null?cur.messages:(document.querySelectorAll(".row").length||"");
el.innerHTML="<b>"+esc(title)+"</b>"+(n!==""?" · "+n:"");
el.title=CUR_FILE||"";
}
async function newConvo(){
const title=prompt("Optional title / first message for the new conversation","")||"";
const r=await post("/api/sessions/new",{title:title});
if(r&&r.ok){CUR_FILE=r.file||"";await reloadTranscript();refreshSessions();toast("New conversation");setSide(false)}
else alert((r&&r.error)||"failed");
}
function filterSpeakers(){
const map={Claude:document.getElementById("f-claude").checked,Grok:document.getElementById("f-grok").checked,Google:document.getElementById("f-google").checked,Adam:document.getElementById("f-adam").checked,You:document.getElementById("f-you").checked};
document.querySelectorAll("#feed .row").forEach(row=>{
const nm=(row.querySelector(".nm")||{}).textContent||"";
const who=nm.trim();
const show=map[who]!==false;
row.classList.toggle("hide",!show);
});
applySearch();
}
function applySearch(){
const q=(document.getElementById("q").value||"").trim().toLowerCase();
document.querySelectorAll("#feed .row").forEach(row=>{
if(row.classList.contains("hide")&&!q)return;
const body=row.querySelector(".body");
if(!body)return;
if(!q){body.querySelectorAll("mark.mark").forEach(m=>{const t=document.createTextNode(m.textContent);m.replaceWith(t)});return}
const text=body.textContent||"";
if(!text.toLowerCase().includes(q)){row.classList.add("hide");return}
if(!row.classList.contains("hide")){/* keep */}
});
}
function wireQoL(){
initThemes();
document.getElementById("btn-convo").onclick=()=>setSide(!document.getElementById("side").classList.contains("on"));
document.getElementById("side-close").onclick=()=>setSide(false);
document.getElementById("btn-new").onclick=newConvo;
document.getElementById("btn-new2").onclick=newConvo;
document.getElementById("btn-refresh-sess").onclick=refreshSessions;
document.getElementById("sess-filter").oninput=renderSessList;
document.getElementById("btn-bottom").onclick=()=>{main.scrollTop=main.scrollHeight};
document.getElementById("btn-export").onclick=async()=>{
const r=await fetch("/api/export",{method:"POST",headers:{"Content-Type":"application/json"},body:"{}"});
const d=await r.json();
if(!d.ok){alert("export failed");return}
const blob=new Blob([d.markdown||""],{type:"text/markdown"});
const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=(d.file||"delve-session")+".md";a.click();
toast("Exported "+(d.file||"session"));
};
["f-claude","f-grok","f-google","f-adam","f-you"].forEach(id=>document.getElementById(id).onchange=filterSpeakers);
document.getElementById("q").oninput=()=>{filterSpeakers();applySearch()};
const compact=loadPref("compact","0")==="1";
document.getElementById("tg-compact").classList.toggle("on",compact);
document.body.classList.toggle("compact",compact);
document.getElementById("tg-compact").onclick=function(){this.classList.toggle("on");const on=this.classList.contains("on");document.body.classList.toggle("compact",on);savePref("compact",on?"1":"0")};
const auto=loadPref("autoscroll","1")!=="0";
document.getElementById("tg-autoscroll").classList.toggle("on",auto);
document.getElementById("tg-autoscroll").onclick=function(){this.classList.toggle("on");savePref("autoscroll",this.classList.contains("on")?"1":"0")};
const sound=loadPref("sound","0")==="1";
document.getElementById("tg-sound").classList.toggle("on",sound);
document.getElementById("tg-sound").onclick=function(){this.classList.toggle("on");savePref("sound",this.classList.contains("on")?"1":"0")};
document.addEventListener("keydown",e=>{
const mod=e.metaKey||e.ctrlKey;
if(mod&&e.key.toLowerCase()==="k"){e.preventDefault();document.getElementById("q").focus()}
if(mod&&e.key.toLowerCase()==="b"){e.preventDefault();setSide(!document.getElementById("side").classList.contains("on"))}
});
}
// patch scroll behavior for autoscroll pref
const _scroll_old=typeof scroll==="function"?scroll:null;
window.delveShouldScroll=function(){return loadPref("autoscroll","1")!=="0"};
// seat status
function paintSeats(st){
const g=!!(st&&st.google_up);const a=!!(st&&st.adam_up);
const set=(id,on)=>{const el=document.getElementById(id);if(!el)return;el.classList.toggle("on",!!on);el.classList.toggle("off",!on)};
set("sd-claude",true);set("sd-grok",true);set("sd-google",g);set("sd-adam",a);
}
const _reload_old=typeof reloadTranscript==="function"?reloadTranscript:null;
async function reloadTranscript(){
const r=await fetch("/api/state");const st=await r.json();
feed.innerHTML="";(st.transcript||[]).forEach(function(x){bubble(x.who,x.text)});
setBusy(!!st.busy);if(window.katex)typesetAll();
if(st.session&&st.session.file)CUR_FILE=st.session.file;
paintSeats(st);updateSessPill();filterSpeakers();
if(delveShouldScroll())scroll();
return st;
}
// sound on msg
const _handle_msg_hook=true;
(function(){
const _h=handle;
handle=function(m){
_h(m);
if(m&&m.type==="msg"&&loadPref("sound","0")==="1"){
try{const ctx=new (window.AudioContext||window.webkitAudioContext)();const o=ctx.createOscillator();const g=ctx.createGain();o.connect(g);g.connect(ctx.destination);o.frequency.value=880;g.gain.value=0.03;o.start();o.stop(ctx.currentTime+0.05)}catch(e){}
}
if(m&&(m.type==="reload"||m.type==="cleared")){refreshSessions()}
if(m&&m.type==="msg"&&delveShouldScroll())scroll();
};
})();
// boot extras after original init pattern
document.addEventListener("DOMContentLoaded",()=>{});
wireQoL();
const _init=init;
init=async function(){
await _init();
await refreshSessions();
try{const st=await (await fetch("/api/state")).json();if(st.session&&st.session.file)CUR_FILE=st.session.file;paintSeats(st);updateSessPill()}catch(e){}
};
'''
# Fix legacy: scroll() always scrolls - wrap via reassignment after legacy defines scroll
# Also gear already opens drawer - need side scrim not steal settings
# Patch legacy openDrawer for settings only
legacy2=legacy
# replace scrim onclick to close both
legacy2=legacy2.replace(
 'scrim.onclick=()=>openDrawer(false);',
 'scrim.onclick=()=>{openDrawer(false);setSide(false)};'
)
# ensure gear still works - it uses openDrawer true
# After init definition, our extra redefines init - good if extra comes after
out=html+legacy2+"\n"+extra+"\n</script>\n</body>\n</html>\n"
Path("index.html").write_text(out,encoding="utf-8")
print("wrote index.html", len(out))
