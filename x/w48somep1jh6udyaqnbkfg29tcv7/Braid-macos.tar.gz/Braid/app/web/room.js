(function(){
const K="braid_room";
const q=(location.search.match(/[?&]room=([^&#]+)/)||[])[1];
q&&sessionStorage.setItem(K,q==="new"?"r"+Date.now().toString(36)+Math.random().toString(36).slice(2,6):decodeURIComponent(q));
const cur=()=>sessionStorage.getItem(K)||"main";
window.braidRoom=cur;
window.braidSetRoom=r=>{sessionStorage.setItem(K,r||"main");location.href=location.pathname};
window.braidNewRoom=()=>window.braidSetRoom("r"+Date.now().toString(36)+Math.random().toString(36).slice(2,6));
window.braidOpenElsewhere=n=>{sessionStorage.setItem("braid_open",n||"");window.braidNewRoom()};
window.braidPending=async post=>{
 const n=sessionStorage.getItem("braid_open");
 if(!n)return null;
 sessionStorage.removeItem("braid_open");
 const r=await post("/api/sessions/resume",{name:n});
 return r&&r.switch_room?(window.braidSetRoom(r.switch_room),null):r&&r.ok?n:null;
};
const f=window.fetch;
window.fetch=function(u,o){
 const url=String(typeof u==="string"?u:u&&u.url||"");
 if(!/^https?:\/\//i.test(url)||url.indexOf(location.origin)===0){
  o=Object.assign({},o||{});
  const h=new Headers(o.headers||(typeof u!=="string"&&u&&u.headers)||{});
  h.set("X-Braid-Room",cur());o.headers=h;
 }
 return f.call(this,u,o);
};
const ES=window.EventSource;
if(ES){
 const W=function(u,o){
  u=String(u);
  return new ES(u+(u.indexOf("?")<0?"?":"&")+"room="+encodeURIComponent(cur()),o);
 };
 W.prototype=ES.prototype;W.CONNECTING=0;W.OPEN=1;W.CLOSED=2;
 window.EventSource=W;
}
})();
