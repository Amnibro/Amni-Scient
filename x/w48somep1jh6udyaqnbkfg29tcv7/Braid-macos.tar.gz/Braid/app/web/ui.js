(function(){
const KEY="braid_fold";
const load=()=>{try{return JSON.parse(localStorage.getItem(KEY)||"{}")}catch(e){return {}}};
const save=o=>{try{localStorage.setItem(KEY,JSON.stringify(o))}catch(e){}};
const mob=()=>matchMedia("(max-width:860px)").matches;
const slug=t=>String(t||"").toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-+|-+$/g,"").slice(0,28);
const CSS=`
.voice .bd img{max-width:100%;height:auto;border-radius:9px;display:block;margin:6px 0;border:1px solid var(--rule)}
.foldbd{display:grid;grid-template-rows:1fr;transition:grid-template-rows .2s ease}
.foldin{overflow:hidden;min-height:0}
.side .slab.shut+.foldbd,.grp.shut>.foldbd{display:grid;grid-template-rows:0fr}
.side .slab.shut+.foldbd .foldin,.grp.shut>.foldbd .foldin{visibility:hidden}
.side .slab.fold{cursor:pointer;user-select:none;display:flex;align-items:center;gap:6px}
.side .slab.fold::after{content:"\\25be";font-size:9px;color:var(--rule2);margin-left:auto}
.side .slab.fold.shut::after{content:"\\25b8"}
.grp>h3.foldhd{cursor:pointer;user-select:none;display:flex;align-items:center;gap:6px}
.grp>h3.foldhd::after{content:"\\25be";font-size:9px;color:var(--rule2);margin-left:auto}
.grp.shut>h3.foldhd::after{content:"\\25b8"}
.grp.shut>h3.foldhd{margin-bottom:0}
.foldhd:focus-visible{outline:2px solid var(--you);outline-offset:2px;border-radius:7px}
/* hover-revealed controls do not exist on a touchscreen - the archive/rename menu was
   unreachable from a phone even though the server has supported it all along */
@media (hover:none),(max-width:860px){
 .sess .cog,.seatrow .cog,.subrow .add{opacity:.72}
}
@media (max-width:860px){
 .side .slab.fold{min-height:40px;margin-top:6px}
 .grp>h3.foldhd{min-height:36px}
 .mobhide{display:none!important}
}
@media (prefers-reduced-motion:reduce){.foldbd{transition:none}}
/* A row that would clip on a real phone (OS font scaling, rounded corners, narrower CSS
   viewport than any emulator preset) must WRAP, never cut. flex-wrap is a no-op when the row
   fits, so desktop is untouched. */
@media (max-width:520px){
 header.bar,.bar,.topctl .strip,.dock .ask,.loadbar{flex-wrap:wrap;row-gap:6px}
 .bar>*{min-width:0}
 .bar .brand,.mark{flex-shrink:1;min-width:0;overflow:hidden}
 .seg{flex-wrap:wrap}
 .dock>*{min-width:0;max-width:100%}
}
#bsett{padding-right:env(safe-area-inset-right);padding-top:env(safe-area-inset-top)}
#drawer{padding-right:env(safe-area-inset-right);padding-top:env(safe-area-inset-top)}
#slmenu{max-width:calc(100vw - 16px - env(safe-area-inset-right))}
`;
function style(){
 if(document.getElementById("braid-fold-css"))return;
 const el=document.createElement("style");el.id="braid-fold-css";el.textContent="@layer legacy{"+CSS+RS_CSS+PRIV_CSS+SET_CSS+SM_CSS+SLIM_CSS+CHAT_CSS+"}";
 document.head.appendChild(el);
}
function wrapAfter(anchor,stop){
 /* THE sidebar bug: the page hid a shut section with `.side .shut+*`, which reaches exactly
    ONE sibling. Tools has four rows after its heading and Memory three, so collapsing them
    hid the first row and left the rest floating with no heading. Gather every sibling into a
    single box and that same rule becomes correct. */
 const bd=document.createElement("div");bd.className="foldbd";
 const inn=document.createElement("div");inn.className="foldin";
 bd.appendChild(inn);
 let n=anchor.nextSibling;
 while(n&&!(stop&&stop(n))){const next=n.nextSibling;inn.appendChild(n);n=next}
 anchor.parentNode.insertBefore(bd,anchor.nextSibling);
 return bd;
}
/* The left bar is for finding a conversation and seeing who is in it. Conversations and Seats
   earn their space; Also supported, Tools and Memory are link lists that belong one click away.
   The migration runs ONCE so an existing browser actually sees the change, then the user's own
   clicks own the state. */
const QUIET_SLABS=["also supported","tools","memory"];
function seedMobile(slabs){
 const migrated=localStorage.getItem("braid_side_quiet")==="1";
 slabs.forEach((s,i)=>{
  const label=(s.textContent||"").replace(/[+⌸▾▸]/g,"").trim().toLowerCase();
  const quiet=QUIET_SLABS.indexOf(label)>=0;
  const key="delve_fold_"+i;
  if(!migrated){
   s.classList.toggle("shut",quiet||(mob()&&i>0));
   try{localStorage.setItem(key,s.classList.contains("shut")?"1":"0")}catch(e){}
   return;
  }
  if(mob()&&i>0&&localStorage.getItem(key)===null){
   s.classList.add("shut");try{localStorage.setItem(key,"1")}catch(e){}
  }
 });
 if(!migrated)try{localStorage.setItem("braid_side_quiet","1")}catch(e){}
}
function foldSidebar(side){
 const all=[].slice.call(side.querySelectorAll(".slab"));
 if(!all.length)return;
 const host=all[0].parentNode;
 const slabs=all.filter(s=>s.parentNode===host);
 const isSlab=n=>n.nodeType===1&&n.classList&&n.classList.contains("slab");
 slabs.forEach(s=>wrapAfter(s,isSlab));
 slabs.forEach((s,i)=>{
  s.classList.add("fold");
  s.setAttribute("role","button");
  s.setAttribute("tabindex","0");
  if(!s.onclick){
   const key="delve_fold_"+i;
   if(localStorage.getItem(key)==="1")s.classList.add("shut");
   s.onclick=e=>{
    if(e&&e.target!==s&&e.target.closest&&e.target.closest("button,a,select,input"))return;
    s.classList.toggle("shut");
    try{localStorage.setItem(key,s.classList.contains("shut")?"1":"0")}catch(err){}
    s.setAttribute("aria-expanded",s.classList.contains("shut")?"false":"true");
   };
  }
  s.querySelectorAll("button").forEach(b=>b.addEventListener("click",e=>e.stopPropagation()));
  s.addEventListener("keydown",e=>{
   if(e.key==="Enter"||e.key===" "){e.preventDefault();s.click()}
  });
  s.setAttribute("aria-expanded",s.classList.contains("shut")?"false":"true");
 });
 seedMobile(slabs);
}
function foldDrawer(drawer){
 const st=load();
 [].slice.call(drawer.querySelectorAll(".grp")).forEach(grp=>{
  const h=grp.firstElementChild;
  if(!h||h.tagName!=="H3"||h.classList.contains("foldhd"))return;
  wrapAfter(h,null);
  const label=(h.textContent||"").trim(),k="drawer:"+slug(label);
  /^privacy/i.test(label)&&setTimeout(()=>privacyPanel(grp),0);
  /* Desktop used to default every section OPEN, which made the drawer a full-page wall of
     text on first look. Same focused default as the phone now: the two sections you touch
     every day, everything else one click away — and any section you open stays open. */
  const open=k in st?!!st[k]:/hand off|this conversation/i.test(label);
  const notes=[].slice.call(grp.querySelectorAll(".note,.localnote")).filter(n=>!n.closest(".sharebox"));
  if(notes.length&&!h.querySelector(".ghint")){
   const q=document.createElement("span");q.className="ghint";q.textContent="ⓘ";
   q.title="What this section is about";
   q.addEventListener("click",e=>{e.stopPropagation();notes.forEach(n=>n.classList.toggle("show"))});
   h.appendChild(q);
  }
  [].slice.call(grp.querySelectorAll(".dsw>span")).forEach(sp=>{
   const sm=sp.querySelector("small");
   if(!sm||sp.dataset.hint==="1")return;
   sp.dataset.hint="1";
   sp.title=sm.textContent;
   sp.addEventListener("click",()=>sp.parentElement.classList.toggle("show"));
  });
  h.classList.add("foldhd");
  h.setAttribute("role","button");
  h.setAttribute("tabindex","0");
  grp.classList.toggle("shut",!open);
  h.setAttribute("aria-expanded",open?"true":"false");
  const announce=()=>{
   if(grp.classList.contains("shut"))return;
   document.dispatchEvent(new CustomEvent("braid:expand",{detail:{label:label}}));
  };
  const toggle=()=>{
   grp.classList.toggle("shut");
   const s=load();s[k]=!grp.classList.contains("shut");save(s);
   h.setAttribute("aria-expanded",grp.classList.contains("shut")?"false":"true");
   announce();
  };
  /* A section that starts open still needs its data - the page loads each panel lazily off
     this event now that the old "Advanced options" switch is gone. */
  open&&setTimeout(announce,0);
  h.addEventListener("click",toggle);
  h.addEventListener("keydown",e=>{
   if(e.key==="Enter"||e.key===" "){e.preventDefault();toggle()}
  });
 });
}
const ORDER=["this conversation","how they hand off","seats & models","workspace & files",
 "privacy & permissions","context sent to each seat","memory","adam","help"];
const label=g=>{const h=g.firstElementChild;return h?(h.textContent||"").replace(/[▾▸]/g,"").trim():""};
const find=(d,name)=>[].slice.call(d.querySelectorAll(".grp"))
 .filter(g=>label(g).replace(/&/g,"&").toLowerCase()===name)[0];
function mergeInto(dst,src){
 if(!dst||!src)return;
 while(src.children.length>1)dst.appendChild(src.children[1]);
 src.remove();
}
function reorgDrawer(d){
 /* Static surgery on this file is a trap: the page builds markup in JS strings, so anything
    counting <div> in the raw HTML mis-balances and can swallow a <script>. Reshape the DOM,
    where moving a node keeps its id and its listeners. */
 const body=d.querySelector("#advbody");
 if(body){
  const wrap=d.querySelector(".advwrap");
  while(body.firstElementChild)d.appendChild(body.firstElementChild);
  wrap?wrap.remove():body.remove();
 }
 mergeInto(find(d,"this conversation"),find(d,"find"));
 const ws=find(d,"workspace folder");
 if(ws){
  const h=ws.firstElementChild;
  if(h)h.textContent="Workspace & files";
  mergeInto(ws,find(d,"files"));
 }
 /* One setting had two switches in two sections: tg-compact_ctx2 was an alias bound with
    tog("compact_ctx2","compact_ctx"). Keep the canonical one, in the section it belongs to. */
 const alias=d.querySelector("#tg-compact_ctx2"),canon=d.querySelector("#tg-compact_ctx");
 if(alias&&canon){
  const arow=alias.closest(".dsw"),crow=canon.closest(".dsw");
  if(arow&&crow){arow.parentNode.insertBefore(crow,arow);arow.remove()}
 }
 const ctxg=find(d,"context sent to each seat");
 if(ctxg&&!ctxg.querySelector("[data-concise]")){
  const r=document.createElement("div");r.className="dsw";r.dataset.concise="1";
  r.innerHTML="<span>Concise answers<small>Seats write like a group chat — lead with the answer, no essays.</small></span>";
  const t=document.createElement("div");t.className="stg";t.style.cssText="width:34px;height:20px;border-radius:999px;background:var(--rule2);position:relative;cursor:pointer;flex:0 0 34px";
  const k=document.createElement("i");k.style.cssText="position:absolute;top:2px;left:2px;width:16px;height:16px;border-radius:50%;background:#fff;transition:left .18s;font-style:normal";
  t.appendChild(k);r.appendChild(t);
  const paint=on=>{t.style.background=on?"var(--good)":"var(--rule2)";k.style.left=on?"16px":"2px"};
  fetch("/api/config").then(x=>x.json()).then(c=>paint(((c.config||{}).answer_style)!=="full")).catch(()=>paint(true));
  t.onclick=()=>{const on=k.style.left!=="16px";paint(on);
   fetch("/api/config",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({answer_style:on?"concise":"full"})});};
  ctxg.appendChild(r);
 }
 ORDER.forEach(name=>{const g=find(d,name);if(g)d.appendChild(g)});
}
const PRIV_CSS=`
#privpanel{margin-top:10px;font-size:12px}
#privpanel .pvrow{display:flex;align-items:center;gap:9px;padding:7px 0;border-top:1px solid var(--rule)}
#privpanel .pvrow b{font-weight:600}
#privpanel .pvrow small{color:var(--mut)}
#privpanel code{font-family:var(--mono);font-size:10.5px;background:var(--sunk);padding:1px 5px;border-radius:5px}
#privpanel .envline{display:flex;gap:7px;align-items:baseline;padding:2px 0}
#privpanel .envline small{flex:1}
#privpanel .pnote{color:var(--mut);line-height:1.5;margin:7px 0}
#privpanel .pvbtn{border:1px solid var(--rule2);background:transparent;color:var(--ink2);border-radius:8px;
 padding:5px 10px;font-size:11.5px;cursor:pointer}
#privpanel .pvbtn:hover{background:var(--sunk)}
#privpanel .pvon{color:var(--good);font-weight:650}
#privpanel .pvoff{color:var(--bad);font-weight:650}
`;
function privacyPanel(grp){
 if(document.getElementById("privpanel"))return;
 const bd=grp.querySelector(".foldin")||grp;
 const box=document.createElement("div");box.id="privpanel";
 box.innerHTML='<div class="pnote">loading the live privacy report…</div>';
 bd.appendChild(box);
 fetch("/api/privacy").then(r=>{if(!r.ok)throw 0;return r.json()}).then(d=>{
  const esc=t=>String(t==null?"":t).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
  const envRows=Object.keys(d.env).sort().map(k=>
   '<div class="envline"><code>'+esc(k)+"="+esc(d.env[k])+'</code><small>'+esc((d.why||{})[k]||"")+"</small></div>").join("");
  box.innerHTML=
   '<div class="pvrow"><b>Seat telemetry: <span class="'+(d.privacy_mode?"pvon":"pvoff")+'">'+
    (d.privacy_mode?"maximum privacy (default)":"OFF — seats run with their stock telemetry")+"</span></b>"+
    '<span style="flex:1"></span><button class="pvbtn" id="pv-tgl">'+(d.privacy_mode?"Turn off":"Turn on")+"</button></div>"+
   '<div class="pnote">Every seat Braid launches gets this environment, verbatim:</div>'+envRows+
   '<div class="pnote">'+esc(d.adam_note)+"</div>"+
   '<div class="pvrow"><b>Check it yourself</b><span style="flex:1"></span><button class="pvbtn" id="pv-copy">Copy the verify prompt</button></div>'+
   '<div class="pnote">Paste it to any seat: its shell runs INSIDE the environment Braid spawned, so what it prints is what it truly received — not what this panel claims.</div>'+
   '<div class="pnote">'+esc(d.scope_note)+"</div>"+
   '<div class="pnote">'+esc(d.braid_note)+"</div>"+
   (d.cli_configs||[]).map(x=>
    '<div class="envline"><code>'+esc(x.seat)+"</code><small>"+
    (x.hardened===true?'<span class="pvon">config hardened</span>':x.hardened===false?'<span class="pvoff">config NOT hardened</span>':"env-only")+
    (Object.keys(x.found||{}).length?" · "+esc(Object.entries(x.found).map(([k,v])=>k+"="+v).join(", ")):"")+
    " — "+esc(x.note||"")+"</small></div>").join("")+
   ((d.cli_configs||[]).some(x=>x.can_harden&&x.hardened===false)?
    '<div class="pvrow"><b>CLI configs</b><span style="flex:1"></span><button class="pvbtn" id="pv-hard">Harden now</button></div>':"");
  const tg=document.getElementById("pv-tgl");
  tg&&(tg.onclick=()=>fetch("/api/config",{method:"POST",headers:{"Content-Type":"application/json"},
   body:JSON.stringify({privacy_mode:!d.privacy_mode})}).then(()=>{box.remove();privacyPanel(grp)}));
  const cp=document.getElementById("pv-copy");
  cp&&(cp.onclick=()=>{navigator.clipboard&&navigator.clipboard.writeText(d.verify_prompt);cp.textContent="Copied"});
  const hd=document.getElementById("pv-hard");
  hd&&(hd.onclick=()=>fetch("/api/privacy/harden",{method:"POST",headers:{"Content-Type":"application/json"},body:"{}"})
   .then(()=>{box.remove();privacyPanel(grp)}));
 }).catch(()=>{
  box.innerHTML='<div class="pnote">The live privacy report needs a Braid restart to appear '+
   "(new endpoint). Until then: privacy mode defaults ON and injects DO_NOT_TRACK, "+
   "DISABLE_TELEMETRY, DISABLE_ERROR_REPORTING, CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC and "+
   "GEMINI_USAGE_STATISTICS=false into every seat.</div>";
 });
}
const SET_CSS=`
:root{--good:#16a34a;--bad:#dc2626}
#bsett{position:fixed;top:0;right:0;bottom:0;width:min(390px,94vw);background:var(--surface);z-index:70;
 box-shadow:var(--shadow);transform:translateX(105%);transition:transform .22s ease;display:flex;flex-direction:column;
 --good:#16a34a;--bad:#dc2626}
#bsett.on{transform:none}
#bsett .bs-hd{display:flex;align-items:center;gap:10px;padding:14px 16px;border-bottom:1px solid var(--rule);font-weight:650;flex:none}
#bsett .bs-bd{flex:1;overflow-y:auto;padding:4px 16px 20px;-webkit-overflow-scrolling:touch}
#bsett .bs-x{margin-left:auto;border:0;background:none;color:var(--mut);font-size:15px;cursor:pointer;padding:6px}
#bsett .bs-note{font-size:11.5px;color:var(--mut);min-height:1.2em;padding:0 16px 10px;flex:none}
#bsett .bs-note.ok{color:var(--good)}
#bsett .bs-note.err{color:var(--bad)}
#bsettscrim{position:fixed;inset:0;background:rgba(10,12,16,.42);z-index:69;opacity:0;pointer-events:none;transition:opacity .2s}
#bsettscrim.on{opacity:1;pointer-events:auto}
#bsett .grp{border-top:1px solid var(--rule);padding:11px 0 3px}
#bsett .grp:first-child{border-top:0}
#bsett .grp>h3{font-size:10.5px;text-transform:uppercase;letter-spacing:.09em;color:var(--mut);margin:0 0 8px;font-weight:650}
#bsett .grp>.foldbd,#bsett .grp .foldbd{display:block;grid-template-rows:none}
#bsett .grp .foldin{overflow:visible;min-height:0;visibility:visible}
#bsett .grp.shut .foldin{display:none!important}
#bsett .srow{display:flex;align-items:center;gap:9px;padding:8px 0;font-size:13px;cursor:default}
#bsett .srow small{color:var(--mut);font-size:11px;display:block;line-height:1.35;margin-top:2px}
#bsett .srow .sp{flex:1}
#bsett .sbtn{border:1px solid var(--rule2);background:var(--sunk);color:var(--ink2);border-radius:9px;padding:7px 12px;font-size:12px;cursor:pointer;font-weight:550}
#bsett .sbtn:hover{background:color-mix(in srgb,var(--you) 10%,var(--sunk));border-color:color-mix(in srgb,var(--you) 30%,var(--rule2));color:var(--ink)}
#bsett .sbtn:disabled{opacity:.55;cursor:wait}
#bsett input[type=text],#bsett select{flex:1;min-width:0;border:1px solid var(--rule2);border-radius:8px;background:var(--paper);color:var(--ink);padding:7px 9px;font-size:12px}
#bsett .stg{width:40px;height:24px;border-radius:999px;background:var(--rule2);position:relative;cursor:pointer;flex:0 0 40px;transition:background .18s;touch-action:manipulation}
#bsett .stg::after{content:"";position:absolute;top:3px;left:3px;width:18px;height:18px;border-radius:50%;background:#fff;box-shadow:0 1px 2px rgba(0,0,0,.18);transition:left .18s}
#bsett .stg.on{background:var(--good)}
#bsett .stg.on::after{left:19px}
#bsett .stg.busy{opacity:.55;pointer-events:none}
.bs-gear{border:0;background:none;color:var(--mut);cursor:pointer;font-size:15px;padding:7px;border-radius:9px}
.bs-gear:hover{background:var(--sunk);color:var(--ink)}
`;
async function _cfgGet(){
 try{
  const r=await fetch("/api/config",{cache:"no-store"});
  const j=await r.json();
  return (j&&j.config)||{};
 }catch(e){return {}}
}
async function _cfgSet(patch){
 const r=await fetch("/api/config",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(patch||{})});
 let j=null;try{j=await r.json()}catch(e){j=null}
 if(!r.ok||(j&&j.ok===false)){
  const err=new Error((j&&(j.error||j.detail||j.message))||("HTTP "+r.status));
  err.body=j;throw err;
 }
 if(j&&Array.isArray(j.managed_locked)&&j.managed_locked.length){
  const err=new Error("locked by policy: "+j.managed_locked.join(", "));
  err.body=j;throw err;
 }
 return j||{ok:true};
}
function settingsPanel(){
 /* Rebuild body every open so toggles always match server + stay clickable. */
 let scrim=document.getElementById("bsettscrim");
 let p=document.getElementById("bsett");
 if(!p){
  scrim=document.createElement("div");scrim.id="bsettscrim";
  p=document.createElement("div");p.id="bsett";
  p.innerHTML='<div class="bs-hd">Settings<button class="bs-x" type="button" aria-label="Close">✕</button></div><div class="bs-note" id="bs-note"></div><div class="bs-bd"></div>';
  document.body.appendChild(scrim);document.body.appendChild(p);
  const close=()=>{p.classList.remove("on");scrim.classList.remove("on")};
  p.querySelector(".bs-x").onclick=close;scrim.onclick=close;
 }
 const bd=p.querySelector(".bs-bd");
 const noteEl=p.querySelector("#bs-note");
 const note=(msg,kind)=>{if(!noteEl)return;noteEl.textContent=msg||"";noteEl.className="bs-note"+(kind?" "+kind:"");if(msg&&kind==="ok")setTimeout(()=>{if(noteEl.textContent===msg){noteEl.textContent="";noteEl.className="bs-note"}},1800)};
 bd.innerHTML='<div class="pnote" style="color:var(--mut);font-size:12px;padding:8px 0">Loading settings…</div>';
 const oldPriv=document.getElementById("privpanel");if(oldPriv)oldPriv.remove();
 const grp=(title,open)=>{
  const g=document.createElement("div");g.className="grp"+(open?"":" shut");
  const h=document.createElement("h3");h.textContent=title;g.appendChild(h);
  const b=document.createElement("div");b.className="foldbd";
  const inn=document.createElement("div");inn.className="foldin";b.appendChild(inn);g.appendChild(b);
  h.classList.add("foldhd");h.setAttribute("role","button");h.setAttribute("tabindex","0");
  h.onclick=()=>g.classList.toggle("shut");
  h.onkeydown=e=>{(e.key==="Enter"||e.key===" ")&&(e.preventDefault(),h.click())};
  bd.appendChild(g);return inn;
 };
 const row=(host,label,small,ctrl)=>{
  const r=document.createElement("div");r.className="srow";
  r.innerHTML="<span><b style='font-weight:600'>"+label+"</b>"+(small?"<small>"+small+"</small>":"")+"</span><span class='sp'></span>";
  ctrl&&r.appendChild(ctrl);host.appendChild(r);return r;
 };
 const tg=(on,fn)=>{
  const t=document.createElement("div");t.className="stg"+(on?" on":"");t.setAttribute("role","switch");t.setAttribute("aria-checked",on?"true":"false");
  t.tabIndex=0;
  const run=async()=>{
   if(t.classList.contains("busy"))return;
   const next=!t.classList.contains("on");
   t.classList.toggle("on",next);t.setAttribute("aria-checked",next?"true":"false");t.classList.add("busy");
   try{await fn(next);note("Saved","ok")}
   catch(e){t.classList.toggle("on",!next);t.setAttribute("aria-checked",(!next)?"true":"false");note(String(e.message||e).slice(0,120),"err")}
   finally{t.classList.remove("busy")}
  };
  t.onclick=e=>{e.preventDefault();e.stopPropagation();run()};
  t.onkeydown=e=>{(e.key==="Enter"||e.key===" ")&&(e.preventDefault(),run())};
  return t;
 };
 const btn=(label,fn)=>{
  const b=document.createElement("button");b.type="button";b.className="sbtn";b.textContent=label;
  b.onclick=async()=>{
   if(b.disabled)return;b.disabled=true;const prev=b.textContent;
   try{await fn(b);note("Done","ok")}
   catch(e){note(String(e.message||e).slice(0,120),"err")}
   finally{b.disabled=false;b.textContent=prev}
  };
  return b;
 };
 _cfgGet().then(cfg=>{
  bd.innerHTML="";
  note("","");
  const g1=grp("Conversation",true);
  const b1=document.createElement("div");b1.style.cssText="display:flex;gap:7px;flex-wrap:wrap";
  b1.appendChild(btn("New",()=>fetch("/api/sessions/new",{method:"POST",headers:{"Content-Type":"application/json"},body:"{}"}).then(()=>location.reload())));
  b1.appendChild(btn("Export",async()=>{const r=await (await fetch("/api/export",{method:"POST",headers:{"Content-Type":"application/json"},body:"{}"})).json();
   const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([r.markdown||""],{type:"text/markdown"}));a.download=r.file||"braid.md";a.click()}));
  b1.appendChild(btn("Clear",()=>fetch("/api/clear",{method:"POST",headers:{"Content-Type":"application/json"},body:"{}"}).then(()=>location.reload())));
  g1.appendChild(b1);
  const g2=grp("Privacy",true);
  privacyPanel({querySelector:()=>null,appendChild:n=>g2.appendChild(n)});
  const g3=grp("Workspace",true);
  const wrow=document.createElement("div");wrow.style.cssText="display:flex;gap:7px;width:100%";
  const inp=document.createElement("input");inp.type="text";inp.value=cfg.workspace||"";inp.placeholder="folder the seats read & write";
  wrow.appendChild(inp);wrow.appendChild(btn("Use",async()=>{await _cfgSet({workspace:inp.value.trim()});inp.blur()}));
  g3.appendChild(wrow);
  const g4=grp("Memory & context",true);
  row(g4,"Bank lessons (PTEX)","reuse what the room works out",tg(cfg.ptex_learn!==false,v=>_cfgSet({ptex_learn:!!v})));
  row(g4,"Compact long rooms","smaller prompts once a room grows",tg(cfg.compact_ctx!==false,v=>_cfgSet({compact_ctx:!!v})));
  row(g4,"Concise answers","seats write like a group chat, not essays",tg(cfg.answer_style!=="full",v=>_cfgSet({answer_style:v?"concise":"full"})));
  const memActs=document.createElement("div");memActs.style.cssText="display:flex;gap:7px;flex-wrap:wrap;margin:8px 0 2px";
  memActs.appendChild(btn("Open PTEX bank",()=>{location.href="/ptex"}));
  memActs.appendChild(btn("Commit lessons",async()=>{
   const r=await (await fetch("/api/commit",{method:"POST",headers:{"Content-Type":"application/json"},body:"{}"})).json();
   if(!(r&&r.ok))throw new Error((r&&r.error)||"commit failed");
   note("Committed "+(r.committed!=null?r.committed:0)+" lesson(s)","ok");
  }));
  g4.appendChild(memActs);
  const g5=grp("Adam",true);
  const astat=document.createElement("div");astat.className="pnote";astat.id="bs-adamstat";astat.style.cssText="font-size:12px;color:var(--mut);margin:2px 0 8px";astat.textContent="checking Adam…";
  g5.appendChild(astat);
  const arow=document.createElement("div");arow.style.cssText="display:flex;gap:7px;flex-wrap:wrap;align-items:center;margin:0 0 8px";
  const modeSel=document.createElement("select");modeSel.title="Adam mode";
  ["light","heavy"].forEach(m=>{const o=document.createElement("option");o.value=m;o.textContent="mode · "+m;if(String(cfg.adam_mode||"light")===m)o.selected=true;modeSel.appendChild(o)});
  modeSel.onchange=async()=>{try{await _cfgSet({adam_mode:modeSel.value});note("Adam mode saved","ok")}catch(e){note(String(e.message||e),"err")}};
  arow.appendChild(modeSel);
  const postAdam=async(action)=>{
   const r=await fetch("/api/adam",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:action,mode:modeSel.value,wait:action==="restart"})});
   let j=null;try{j=await r.json()}catch(e){j=null}
   if(!r.ok)throw new Error((j&&(j.error||j.reason))||("HTTP "+r.status));
   return j||{};
  };
  const refreshA=async()=>{
   try{
    const r=await postAdam("status");
    if(r.up)astat.textContent="online · "+(r.mode||modeSel.value||"light")+(r.health&&r.health.version?" · "+r.health.version:"");
    else if(r.phase==="booting")astat.textContent="starting up — give it a minute";
    else astat.textContent="offline — Start or Reboot below";
   }catch(e){astat.textContent="status unavailable"}
  };
  arow.appendChild(btn("Start",async()=>{astat.textContent="starting…";await postAdam("start");setTimeout(refreshA,2000);setTimeout(refreshA,8000)}));
  arow.appendChild(btn("Reboot",async()=>{astat.textContent="rebooting Adam…";const r=await postAdam("restart");astat.textContent=r&&r.phase==="up"?("online after reboot · "+(r.live_bake||r.mode||"")):("reboot: "+(r&&(r.reason||r.phase||r.error)||"failed"));setTimeout(refreshA,2500)}));
  g5.appendChild(arow);
  row(g5,"Covers failed seats","answers when a paid seat errors",tg(cfg.adam_fallback!==false,v=>_cfgSet({adam_fallback:!!v})));
  row(g5,"Adam tools","file/code tools on Adam turns",tg(cfg.adam_tools!==false,v=>_cfgSet({adam_tools:!!v})));
  refreshA();
  const g6=grp("App",true);
  row(g6,"Chat layout","bubbles like a messaging app",tg((()=>{try{const v=localStorage.getItem("braid_view");return v===null||v==="chat"||v===""}catch(e){return true}})(),async v=>{
   try{localStorage.setItem("braid_view",v?"chat":"off")}catch(e){}
   document.documentElement.dataset.braidview=v?"chat":"";
   document.querySelectorAll("[data-braidchat]").forEach(b=>b.setAttribute("aria-pressed",String(!!v)));
   if(v&&!window.braidViewOwner){try{window.setLayout&&setLayout("one")}catch(e){}}
  }));
  row(g6,"Advanced controls","full drawer: flows, seats, perms, updates",btn("Open",()=>{location.href="/basic"}));
  row(g6,"Phone access","pair a phone / tablet",btn("Open",()=>{location.href="/remote"}));
 }).catch(e=>{bd.innerHTML='<div class="pnote" style="color:var(--bad)">Could not load settings: '+String(e.message||e)+"</div>"});
 return p;
}
const CHAT_CSS=`
html[data-braidview=chat] .scroll .col{max-width:min(820px,100%)}
html[data-braidview=chat] .ex{background:transparent;border:0;box-shadow:none;padding:0 2px;margin:0 0 18px}
html[data-braidview=chat] .q{display:flex;flex-direction:row-reverse;justify-content:flex-end;align-items:flex-end;gap:8px;background:transparent;border:0;padding:2px 0;margin:0 0 12px}
html[data-braidview=chat] .q .av{display:none}
/* Your own line, in your own accent. 560 weight at 17px was shouting the question back at you,
   and a flat fill next to five gradient-tinted seat bubbles read as the one unfinished surface
   in the room. Weight comes down to 450, the fill becomes a soft diagonal of the accent, and the
   braid itself lights the leading edge - the same three moves the seat cards already use. */
html[data-braidview=chat] .q .txt{position:relative;
 background:linear-gradient(122deg,color-mix(in srgb,var(--you) 20%,var(--surface)),
  color-mix(in srgb,var(--you) 7%,var(--surface)) 62%,color-mix(in srgb,var(--you) 12%,var(--surface)));
 border:1px solid color-mix(in srgb,var(--you) 26%,var(--rule));
 border-radius:18px 18px 6px 18px;padding:10px 14px;max-width:min(84%,560px);margin-left:auto;font-size:var(--fs-you,14.5px);line-height:1.5;
 box-shadow:inset 0 1px 0 var(--edge),0 6px 18px -14px color-mix(in srgb,var(--you) 85%,transparent);
 font-weight:450;letter-spacing:-.005em;overflow:hidden}
html[data-braidview=chat] .q .txt::after{content:"";position:absolute;right:0;top:0;bottom:0;width:3px;
 background:var(--braid);opacity:.5}
html[data-braidview=chat] .q .exfold{align-self:center}
html[data-braidview=chat] [data-body],html[data-braidview=chat] .voices,html[data-braidview=chat] .voices.grid,html[data-braidview=chat] .voices.one,html[data-braidview=chat] .voices.thread{
 display:flex;flex-direction:column;align-items:stretch;gap:8px;grid-template-columns:none;
 background:transparent;border:0;box-shadow:none;padding:0;margin:0;overflow:visible}
html[data-braidview=chat] .voices.thread::before,html[data-braidview=chat] .voices.thread .voice::before{display:none!important}
html[data-braidview=chat] .voices.thread{padding-left:0}
html[data-braidview=chat] .voice{position:relative;border:0;background:transparent;box-shadow:none;
 max-width:min(92%,640px);margin:0;padding:0 0 0 42px;border-radius:0;overflow:visible;width:auto}
html[data-braidview=chat] .voice::before{content:attr(data-av);position:absolute;left:0;top:14px;width:30px;height:30px;border-radius:50%;
 background:color-mix(in srgb,var(--vc) 16%,var(--surface));color:var(--vc);border:1.5px solid var(--vc);
 display:flex;align-items:center;justify-content:center;font-size:10.5px;font-weight:700;letter-spacing:.02em;z-index:1}
html[data-braidview=chat] .voice .hd{background:none;border:0;padding:2px 6px 2px;min-height:0;font-size:var(--fs-small,11px)}
html[data-braidview=chat] .voice .hd b{color:var(--vc);font-size:var(--fs-small,12px);font-weight:650}
html[data-braidview=chat] .voice .hd .sub{font-size:9.5px;display:none}
html[data-braidview=chat] .voice .hd .dt,html[data-braidview=chat] .voice .hd .chev{display:none}
html[data-braidview=chat] .voice .bd{background:var(--surface);border:1px solid var(--rule);border-radius:6px 18px 18px 18px;
 padding:10px 14px;box-shadow:0 1px 3px rgba(20,22,26,.06);font-size:var(--fs-ans,14px);line-height:1.5}
html[data-braidview=chat] .voice .think{background:var(--surface);border:1px solid var(--rule);border-radius:6px 18px 18px 18px;
 width:fit-content;padding:10px 14px;color:var(--mut);font-size:0;gap:3px}
html[data-braidview=chat] .voice.shut .bd{display:none}
html[data-braidview=chat] .sline,html[data-braidview=chat] .tick{padding-left:42px;text-align:left;justify-content:flex-start;font-size:var(--fs-tiny,10px);opacity:.7}
html[data-braidview=chat] .memline{margin-left:42px}
html[data-braidview=chat] .voice .bd[data-cl="1"]{max-height:320px;overflow:hidden;position:relative;cursor:pointer}
html[data-braidview=chat] .voice .bd[data-cl="1"]::after{content:"⋯ tap to expand";position:absolute;left:0;right:0;bottom:0;
 padding:26px 0 8px;text-align:center;font-size:11px;color:var(--mut);
 background:linear-gradient(transparent,var(--surface) 70%)}
html[data-braidview=chat] .hero{display:none}
`;
function chatMode(){
 /* "Reads like a Symphony messaging chain" - the roundtable as a group chat. Overlay on the
    stacked layout: your prompt is a right-hand bubble, every seat answers as a person with
    an avatar monogram in its seat color, thinking becomes a typing bubble. One CSS mode,
    both UIs, zero changes to the exchange machinery. Default ON for simple mode. */
 const KEY2="braid_view";
 const feed=document.getElementById("feed");
 const segs=[].slice.call(document.querySelectorAll("#anslayout,#anslayout2")).filter(Boolean);
 if(!feed||!segs.length)return;
 const deco=()=>{
  feed.querySelectorAll(".voice:not([data-av])").forEach(v=>{
   const n=String(v.dataset.v||"?");
   v.dataset.av=(n==="OpenAI"?"GP":n.slice(0,2));
  });
  /* ONE expander per answer. A page that clamps long bodies itself (basic.html adds a
     "Show the rest" button) must not get this second clamp on top - that is what made it take
     two clicks to read one answer. Pages without their own clamp keep it. */
  if(!window.braidViewOwner&&document.documentElement.dataset.braidview==="chat")
   feed.querySelectorAll(".voice .bd:not([data-cl])").forEach(b=>{
    if(b.scrollHeight>420)b.dataset.cl="1";
   });
 };
 feed.addEventListener("click",e=>{
  const b=e.target.closest&&e.target.closest('.bd[data-cl="1"]');
  if(b){b.dataset.cl="0"}
 });
 new MutationObserver(deco).observe(feed,{childList:true,subtree:true});deco();
 const paint=on=>document.querySelectorAll("[data-braidchat]").forEach(b=>b.setAttribute("aria-pressed",String(on)));
 const apply=on=>{
  document.documentElement.dataset.braidview=on?"chat":"";
  try{localStorage.setItem(KEY2,on?"chat":"off")}catch(e){}
  if(on&&!window.braidViewOwner){try{window.setLayout&&setLayout("one")}catch(e){}}
  paint(on);
  setTimeout(deco,60);
 };
 segs.forEach(seg=>{
  if(seg.querySelector("[data-braidchat]"))return;
  const b=document.createElement("button");
  b.type="button";b.textContent="Chat";b.dataset.braidchat="1";
  b.title="Group-chat view — every seat talks like a person";
  b.setAttribute("aria-pressed","false");
  b.onclick=e=>{e.preventDefault();apply(document.documentElement.dataset.braidview!=="chat")};
  seg.appendChild(b);
  seg.addEventListener("click",e=>{
   const t=e.target.closest("button");
   if(t&&t!==b&&!t.dataset.braidchat&&document.documentElement.dataset.braidview==="chat")apply(false);
  });
 });
 /* A page that declares itself the view owner (basic.html) restores the saved view itself
    through one setLayout call. Applying here as well means two writers racing at boot. */
 if(window.braidViewOwner)return;
 try{
  const v=localStorage.getItem(KEY2);
  if(v===null||v==="chat"||v==="")apply(true);
  else if(v==="off"||v==="0")apply(false);
  else apply(true);
 }catch(e){apply(true)}
}
const SLIM_CSS=`
@media (max-width:640px){
 .bar{gap:10px;justify-content:space-between}
 .bar .viewbar{display:none!important}
}
#bs-quick{display:flex;flex-direction:column;gap:6px;padding:4px 0 10px}
#bs-quick .bs-mv{display:flex;align-items:center;gap:10px;border:1px solid var(--rule);border-radius:10px;
 padding:8px 11px;background:var(--paper);cursor:pointer;font-size:13px;color:var(--ink)}
#bs-quick .bs-mv:hover{background:var(--sunk)}
#bs-quick .bs-mv svg{width:16px;height:16px;flex:0 0 auto}
#bs-quick .bs-mv .mvlab{font-size:13px}
#bs-quick .viewbar{display:flex;margin:2px 0 4px}
`;
function slimHeader(){
 /* "two rows at the top and eh spacing" - wrapping kept buttons reachable but looked like a
    fallback, because it was one. On a phone the bar keeps burger · brand · gear · new chat;
    the action buttons MOVE into the settings panel (a DOM move keeps every listener), each
    dressed with its own label. Desktop never enters this branch. */
 if(!matchMedia("(max-width:640px)").matches)return;
 const bar=document.querySelector("header.bar")||document.querySelector(".bar");
 const flows=document.getElementById("btn-flows");
 if(!bar||!flows)return;
 const p=settingsPanel();
 const bd=p.querySelector(".bs-bd");
 let q=document.getElementById("bs-quick");
 if(!q){q=document.createElement("div");q.id="bs-quick";bd.insertBefore(q,bd.firstChild)}
 [["btn-flows","Flows"],["btn-perms","Permissions"],["btn-remote","Phone access"],["theme","Light / dark"]].forEach(pair=>{
  const el=document.getElementById(pair[0]);
  if(!el||el.closest("#bs-quick"))return;
  el.classList.add("bs-mv");
  const lab=document.createElement("span");lab.className="mvlab";
  lab.textContent=el.title||el.getAttribute("aria-label")||pair[1];
  el.appendChild(lab);
  q.appendChild(el);
 });
 const vb=bar.querySelector(".viewbar")||document.getElementById("viewbar");
 if(vb&&!vb.closest("#bs-quick"))q.appendChild(vb);
}
function gearButton(){
 if(document.querySelector(".bs-gear"))return;
 const anchor=document.getElementById("newchat")||document.getElementById("ctrls");
 if(!anchor)return;
 const b=document.createElement("button");b.className="bs-gear";b.title="Settings";b.setAttribute("aria-label","Settings");
 b.textContent="⚙";
 b.onclick=()=>{const p=settingsPanel();requestAnimationFrame(()=>{p.classList.add("on");const s=document.getElementById("bsettscrim");if(s)s.classList.add("on")})};
 anchor.parentNode.insertBefore(b,anchor);
}
const RS_CSS=`
#roomstrip{display:none!important}
.sess{position:relative;display:flex;align-items:center;gap:8px;padding:8px 10px;border:1px solid var(--rule);border-radius:12px;
 background:var(--surface);cursor:pointer;font-size:12px;color:var(--ink2);text-align:left;width:100%;box-sizing:border-box;margin:0 0 5px}
.sess:hover,.sess.on{background:var(--sunk);border-color:color-mix(in srgb,var(--you) 35%,var(--rule))}
.sess.on{border-color:var(--you);box-shadow:0 0 0 1px color-mix(in srgb,var(--you) 25%,transparent)}
.sess.busy{border-color:color-mix(in srgb,var(--good,#16a34a) 45%,var(--rule))}
.sess .rdot{width:7px;height:7px;border-radius:50%;flex:0 0 7px;background:var(--rule2)}
.sess.busy .rdot{background:var(--good,#16a34a);animation:stpulse 1.3s ease-in-out infinite;box-shadow:0 0 0 3px color-mix(in srgb,var(--good,#16a34a) 18%,transparent)}
.sess .t{flex:1;font-size:12.5px;font-weight:550;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;margin:0}
.sess .m{color:var(--mut);flex:0 0 auto;font-size:10.5px;margin:0;max-height:none;opacity:1}
@keyframes stpulse{0%,100%{opacity:1}50%{opacity:.45}}
`;
let RS_TIMER=null;
function roomStrip(){
 /* Live multi-room state is painted INTO the session list (one style), not a second chip
    strip above it — that was the "nice bubbles + old list below" duplicate. */
 const host=document.getElementById("sess");
 if(!window.braidRoom||!host)return;
 const old=document.getElementById("roomstrip");if(old)old.innerHTML="";
 const annotate=()=>{
  const d=SESSCACHE;if(!d)return;
  const rooms=d.rooms||[];
  const me=typeof braidRoom==="function"?braidRoom():"";
  const byFile={};
  rooms.forEach(r=>{if(r&&r.file)byFile[r.file]=r;if(r&&r.name)byFile[r.name]=r});
  host.querySelectorAll(".sess").forEach(b=>{
   const n=b.dataset.n||"";
   const room=byFile[n]||rooms.find(r=>r&&(r.file===n||r.name===n||(r.file&&n&&String(r.file).indexOf(n)>=0)));
   b.classList.toggle("busy",!!(room&&room.busy));
   if(room&&room.room===me)b.classList.add("on");
   if(!b.querySelector(".rdot")){
    const d=document.createElement("span");d.className="rdot";b.insertBefore(d,b.firstChild);
   }
   const m=b.querySelector(".m");
   if(m&&room){
    if(room.busy)m.textContent="answering";
    else if(room.messages!=null)m.textContent=room.messages+" msgs";
   }
  });
  /* Rooms that are live but not in the short sess list still need a switcher entry. */
  rooms.forEach(r=>{
   if(!r||!r.room||r.room===me)return;
   const key=r.file||r.name||"";
   /* `const CSS` above shadows the global CSS object, so CSS.escape() threw here and killed
      the rest of the room list. Match on the property instead of building a selector. */
   if(key&&[...host.querySelectorAll(".sess")].some(el=>el.dataset.n===key))return;
   if(host.querySelector('.sess[data-room="'+r.room+'"]'))return;
   const b=document.createElement("button");
   b.className="sess"+(r.busy?" busy":"");
   b.dataset.room=r.room;if(key)b.dataset.n=key;
   const title=(r.title||key||r.room).toString().replace(/^session_/,"").slice(0,48);
   b.innerHTML='<span class="rdot"></span><div class="t"></div><div class="m"></div>';
   b.querySelector(".t").textContent=title;
   b.querySelector(".m").textContent=r.busy?"answering":((r.messages!=null?r.messages+" msgs":"live room"));
   b.onclick=()=>braidSetRoom(r.room);
   host.insertBefore(b,host.firstChild);
  });
 };
 const tick=()=>fetch("/api/sessions?include_archived=1").then(r=>r.json()).then(d=>{SESSCACHE=d;annotate()}).catch(()=>{});
 tick();
 RS_TIMER&&clearInterval(RS_TIMER);
 RS_TIMER=setInterval(()=>{document.hidden||tick()},8000);
 new MutationObserver(()=>annotate()).observe(host,{childList:true});
}
const SM_CSS=`
.sess{position:relative}
.scog{position:absolute;top:6px;right:6px;padding:3px 7px;border-radius:7px;color:var(--mut);font-size:13px;line-height:1;cursor:pointer;z-index:2}
.scog:hover{background:var(--sunk);color:var(--ink)}
#slmenu{position:fixed;z-index:80;background:var(--surface);border:1px solid var(--rule);border-radius:12px;
 box-shadow:var(--shadow);min-width:210px;padding:5px;display:flex;flex-direction:column}
#slmenu button{border:0;background:none;text-align:left;padding:9px 11px;border-radius:8px;font-size:13px;color:var(--ink);cursor:pointer}
#slmenu button:hover{background:var(--sunk)}
#slmenu button.danger{color:var(--bad,#dc2626)}
.sess.archrow{opacity:.62}
.sess.archrow .t::after{content:" · archived";color:var(--mut);font-size:10px}
`;
let SESSCACHE=null;
function sessMenuLite(){
 /* simple.html's conversation list had NO archive/rename/delete at all - the server has
    supported them for weeks. Inject a ⋯ on every row and drive the same endpoints. Owned
    entirely here so it ships in the bundle and needs zero page edits. */
 const host=document.getElementById("sess");
 if(!host||document.getElementById("sesslist"))return;
 const post=(u,b)=>fetch(u,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(b||{})}).then(r=>r.json()).catch(()=>null);
 const closeM=()=>{const m=document.getElementById("slmenu");m&&m.remove()};
 const menu=(name,anchor)=>{
  closeM();
  const row=((SESSCACHE&&SESSCACHE.sessions)||[]).find(x=>x.name===name)||{};
  const m=document.createElement("div");m.id="slmenu";
  const arch=!!row.archived;
  m.innerHTML='<button data-a="rename">Rename</button>'+
   '<button data-a="archive">'+(arch?"Unarchive":"Archive")+"</button>"+
   '<button data-a="showarch">'+(localStorage.getItem("braid_showarch")==="1"?"Hide archived":"Show archived")+"</button>"+
   '<button data-a="delete" class="danger">Delete</button>';
  document.body.appendChild(m);
  const r=anchor.getBoundingClientRect();
  m.style.left=Math.max(8,Math.min(innerWidth-m.offsetWidth-8,r.left-160))+"px";
  m.style.top=Math.min(innerHeight-m.offsetHeight-8,r.bottom+4)+"px";
  m.querySelectorAll("[data-a]").forEach(b=>b.onclick=async()=>{
   const a=b.dataset.a;closeM();
   if(a==="rename"){const t=prompt("Name this conversation:",(row.title||"").trim());
    if(t===null)return;await post("/api/sessions/meta",{name:name,title:t.trim()});location.reload()}
   if(a==="archive"){await post("/api/sessions/meta",{name:name,archived:!arch});location.reload()}
   if(a==="showarch"){localStorage.setItem("braid_showarch",localStorage.getItem("braid_showarch")==="1"?"0":"1");location.reload()}
   if(a==="delete"){if(!confirm("Delete this conversation? It moves to sessions/_deleted."))return;
    await post("/api/sessions/delete",{name:name});location.reload()}
  });
  setTimeout(()=>document.addEventListener("click",function off(e){
   if(!m.contains(e.target)){closeM();document.removeEventListener("click",off)}}),0);
 };
 const decorate=()=>{
  [].slice.call(host.querySelectorAll(".sess")).forEach(b=>{
   if(b.querySelector(".scog")||!b.dataset.n)return;
   const c=document.createElement("span");c.className="scog";c.textContent="⋯";
   c.title="Rename, archive or delete";
   c.onclick=e=>{e.stopPropagation();e.preventDefault();menu(b.dataset.n,c)};
   b.appendChild(c);
  });
  if(localStorage.getItem("braid_showarch")==="1"&&SESSCACHE&&!host.querySelector(".archrow")){
   ((SESSCACHE.sessions)||[]).filter(x=>x.archived).forEach(x=>{
    const b=document.createElement("button");b.className="sess archrow";b.dataset.n=x.name;
    b.innerHTML='<div class="t"></div><div class="m">'+(x.messages!=null?x.messages+" msgs":"")+"</div>";
    b.querySelector(".t").textContent=(x.title||x.name.replace(/^session_|\.md$/g,"")).slice(0,48);
    b.onclick=async()=>{const r=await post("/api/sessions/resume",{name:x.name});
     r&&r.switch_room?braidSetRoom(r.switch_room):location.reload()};
    host.appendChild(b);
   });
   decorate();
  }
 };
 new MutationObserver(decorate).observe(host,{childList:true});
 decorate();
}
function dedupeLayout(){
 /* Two identical layout pickers ship on every page - "View" up top and "Layout" above the
    composer. On a phone the dock one just steals height the keyboard already wants. */
 const dup=document.getElementById("anslayout2");
 if(!dup)return;
 dup.classList.add("mobhide");
 const prev=dup.previousElementSibling;
 if(prev&&prev.classList.contains("lb"))prev.classList.add("mobhide");
}
function boot(){
 style();
 const side=document.querySelector(".side");
 if(side&&!side.dataset.folded){side.dataset.folded="1";foldSidebar(side)}
 const sw=document.getElementById("sidewide");
 if(sw&&side){
  const setw=on=>{side.classList.toggle("wide",!!on);sw.setAttribute("aria-pressed",String(!!on));try{localStorage.setItem("braid_side_wide",on?"1":"")}catch(e){}};
  setw(localStorage.getItem("braid_side_wide")==="1");
  sw.onclick=()=>setw(!side.classList.contains("wide"));
 }
 const tmBtn=document.getElementById("topmore"),tm=document.getElementById("topmenu");
 if(tmBtn&&tm){
  const closeTm=()=>{tm.hidden=true;tmBtn.setAttribute("aria-expanded","false")};
  tmBtn.onclick=e=>{e.stopPropagation();
   if(!tm.hidden){closeTm();return}
   const n=document.getElementById("nav-mach-n"),mn=document.getElementById("tm-mach-n");
   if(n&&mn){mn.hidden=n.hidden;mn.textContent=n.textContent}
   const r=tmBtn.getBoundingClientRect();
   tm.hidden=false;tm.style.top=(r.bottom+6)+"px";tm.style.right=Math.max(8,innerWidth-r.right)+"px";tm.style.left="auto";
   tmBtn.setAttribute("aria-expanded","true");
   setTimeout(()=>document.addEventListener("click",function h(e2){if(!tm.contains(e2.target)){closeTm();document.removeEventListener("click",h)}}),30);
  };
  tm.querySelectorAll("[data-tm]").forEach(b=>b.onclick=()=>{
   closeTm();
   const k=b.dataset.tm;
   if(k==="mach"){const m=document.getElementById("nav-mach");if(m)m.click()}
   else if(k==="remote")location.href="/remote";
   else if(k==="sub")location.href="/subscribe";
   else{const el=document.getElementById(k);if(el)el.click()}
  });
 }
 const dr=document.getElementById("drawer");
 if(dr&&!dr.dataset.folded){dr.dataset.folded="1";reorgDrawer(dr);foldDrawer(dr)}
 dedupeLayout();
 roomStrip();
 document.getElementById("drawer")||gearButton();
 document.getElementById("drawer")||slimHeader();
 sessMenuLite();
 chatMode();
}
window.braidFoldBoot=boot;
document.readyState==="loading"?document.addEventListener("DOMContentLoaded",()=>setTimeout(boot,0)):setTimeout(boot,0);
})();
