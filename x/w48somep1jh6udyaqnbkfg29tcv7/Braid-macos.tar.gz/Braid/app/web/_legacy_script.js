
const feed=document.getElementById("feed"),main=document.getElementById("main"),box=document.getElementById("box"),send=document.getElementById("send"),dot=document.getElementById("dot"),estop=document.getElementById("estop"),hint=document.getElementById("hint");
let target="all",busy=false,thinkEl=null,cfg={};
function esc(t){return t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}
function md(t){
t=String(t||"");
const store=[];
const hold=function(s,kind){const i=store.length;store.push({s:s,kind:kind});return "\uE000"+i+"\uE001"};
t=t.replace(/```[^\n`]*\n?([\s\S]*?)```/g,function(m,c){return hold(c.replace(/^\n/,""),"pre")});
t=t.replace(/\$\$([\s\S]+?)\$\$/g,function(m,tex){return hold(tex.trim(),"mathd")});
t=t.replace(/\\\[([\s\S]+?)\\\]/g,function(m,tex){return hold(tex.trim(),"mathd")});
t=t.replace(/\\\(([\s\S]+?)\\\)/g,function(m,tex){return hold(tex.trim(),"mathi")});
t=t.replace(/(^|[^\\$])\$([^\$\n]+?)\$/g,function(m,pre,tex){return pre+hold(tex.trim(),"mathi")});
t=t.replace(/`([^`\n]+)`/g,function(m,c){return hold(c,"code")});
t=esc(t);
t=t.replace(/^######\s+(.+)$/gm,"<h4>$1</h4>");
t=t.replace(/^#####\s+(.+)$/gm,"<h4>$1</h4>");
t=t.replace(/^####\s+(.+)$/gm,"<h4>$1</h4>");
t=t.replace(/^###\s+(.+)$/gm,"<h3>$1</h3>");
t=t.replace(/^##\s+(.+)$/gm,"<h3>$1</h3>");
t=t.replace(/^#\s+(.+)$/gm,"<h2>$1</h2>");
t=t.replace(/^---+$/gm,"<hr/>");
t=t.replace(/^&gt;\s?(.+)$/gm,"<blockquote>$1</blockquote>");
t=t.replace(/\*\*([^*]+)\*\*/g,"<strong>$1</strong>");
t=t.replace(/__([^_]+)__/g,"<strong>$1</strong>");
t=t.replace(/(^|[^\*])\*([^*\n]+)\*(?!\*)/g,"$1<em>$2</em>");
t=t.replace(/\[([^\]]+)\]\((https?:[^)\s]+)\)/g,'<a href="$2" target="_blank" rel="noopener">$1</a>');
t=t.replace(/(^|\n)([\-\*•]\s+.+(?:\n[\-\*•]\s+.+)*)/g,function(m,lead,block){
const items=block.split(/\n/).map(function(l){return "<li>"+l.replace(/^[\-\*•]\s+/,"")+"</li>"}).join("");
return lead+"<ul>"+items+"</ul>"});
t=t.replace(/(^|\n)((?:\d+\.\s+.+\n){2,}(?:\d+\.\s+.+)?)(?=\n|$)/g,function(m,lead,block){
const lines=block.trim().split(/\n/).filter(Boolean);
const items=lines.map(function(l){return "<li>"+l.replace(/^\d+\.\s+/,"")+"</li>"}).join("");
return lead+"<ol>"+items+"</ol>"});
t=t.replace(/^(\d+)\.\s+(.+)$/gm,'<p class="sec"><span class="n">$1.</span> $2</p>');
function wrapBlocks(src){
const lines=src.split(/\n/);
const out=[];let buf=[];
const flush=function(){if(!buf.length)return;const text=buf.join("\n").trim();buf=[];if(text)out.push("<p>"+text.replace(/\n/g,"<br>")+"</p>")};
for(let i=0;i<lines.length;i++){
const line=lines[i];
if(/^(?:<h[2-4]|<ul|<ol|<pre|<hr|<blockquote|<div|<p\b)/.test(line.trim())){flush();out.push(line.trim());continue}
if(!line.trim()){flush();continue}
buf.push(line)}
flush();return out.join("");
}
t=wrapBlocks(t);
t=t.replace(/\uE000(\d+)\uE001/g,function(m,i){
const it=store[+i];if(!it)return "";
const s=it.s,kind=it.kind;
if(kind==="pre")return "<pre><code>"+esc(s)+"</code></pre>";
if(kind==="code")return "<code>"+esc(s)+"</code>";
if(kind==="mathd"||kind==="mathi"){
try{if(window.katex)return katex.renderToString(s,{displayMode:kind==="mathd",throwOnError:false,strict:"ignore",output:"html",trust:false});}catch(e){}
return kind==="mathd"?'<span class="math-fallback math-display">$$'+esc(s)+'$$</span>':'<span class="math-fallback">$'+esc(s)+'$</span>';
}
return esc(s);
});
return t;
}
function typesetAll(){
if(!window.katex)return;
document.querySelectorAll(".bub .body .math-fallback").forEach(function(el){
const raw=el.textContent||"";
const disp=raw.indexOf("$$")===0;
const tex=raw.replace(/^\$\$?/,"").replace(/\$\$?$/,"").trim();
try{el.outerHTML=katex.renderToString(tex,{displayMode:disp,throwOnError:false,strict:"ignore",output:"html"});}catch(e){}
});
}
function atBottom(){return main.scrollHeight-main.scrollTop-main.clientHeight<120}
function scroll(){main.scrollTop=main.scrollHeight}
function bubble(who,text){const me=who==="Anthony"||who==="You";const nm=me?"You":who;const stick=atBottom();const row=document.createElement("div");row.className="row"+(me?" me":"");row.innerHTML='<div class="av '+nm+'">'+nm[0]+'</div><div class="bub"><div class="nm '+nm+'">'+nm+'</div><div class="body">'+md(text)+"</div></div>";feed.appendChild(row);if(!window.katex)setTimeout(typesetAll,80);if(stick)scroll()}
function chip(t){const d=document.createElement("div");d.className="chip";d.innerHTML="<span>"+esc(t)+"</span>";feed.appendChild(d);if(atBottom())scroll()}
function learn(d){const n=d&&d.ok?("Adam learned · "+d.pairs+" pairs · "+d.ledger_records+" ledger"):("Adam: "+((d&&(d.reason||d.error))||"skipped"));const e=document.createElement("div");e.className="learn";e.innerHTML="<span>◆ "+esc(n)+"</span>";feed.appendChild(e);if(atBottom())scroll()}
function showThink(who){clearThink();const stick=atBottom();const row=document.createElement("div");row.className="row";row.innerHTML='<div class="av '+who+'">'+who[0]+'</div><div class="bub"><div class="think">'+who+' is thinking <i></i><i></i><i></i></div></div>';feed.appendChild(row);thinkEl=row;if(stick)scroll()}
function clearThink(){if(thinkEl){thinkEl.remove();thinkEl=null}}
function setBusy(b){busy=b;dot.classList.toggle("busy",b);dot.title=b?"working":"idle";estop.classList.toggle("on",b);send.textContent=b?"Interject":"Send";send.classList.toggle("interject",b);hint.textContent=b?"They're talking — your line will reach them next turn · Esc/STOP halts":"Type while they talk to interject · Esc or STOP to halt"}
const ev=new EventSource("/api/stream");
ev.onmessage=e=>{let m;try{m=JSON.parse(e.data)}catch(x){return}handle(m)};
function handle(m){const ty=m.type;
if(ty==="user"){bubble("You",m.text)}
else if(ty==="thinking"){setBusy(true);showThink(m.who)}
else if(ty==="msg"){clearThink();bubble(m.who,m.text)}
else if(ty==="status"){chip(m.text)}
else if(ty==="ptex"){learn(m.data)}
else if(ty==="estop"){clearThink();chip("e-stop — halted");setBusy(false)}
else if(ty==="idle"){clearThink();setBusy(false)}
else if(ty==="queued"){hint.textContent="queued — reaches them next turn"}
else if(ty==="cleared"){feed.innerHTML="";setBusy(false)}else if(ty==="reload"){reloadTranscript()}
else if(ty==="config"){cfg=m.config;paintCfg()}}
function selTarget(t){target=t;document.querySelectorAll(".tab").forEach(x=>x.classList.toggle("on",x.dataset.t===t))}
document.querySelectorAll(".tab").forEach(x=>x.onclick=()=>selTarget(x.dataset.t));
async function post(url,body){try{const r=await fetch(url,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body||{})});return await r.json()}catch(e){return{ok:false}}}
function doSend(){const t=box.value.trim();if(!t)return;box.value="";box.style.height="auto";post("/api/send",{target:target,text:t})}
function doDebate(){const n=parseInt(document.getElementById("rounds").value)||3;const t=box.value.trim();box.value="";box.style.height="auto";post("/api/send",{target:"debate",rounds:n,text:t})}
send.onclick=doSend;
document.getElementById("debate").onclick=doDebate;
estop.onclick=()=>post("/api/estop",{});
box.addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();doSend()}});
box.addEventListener("input",()=>{box.style.height="auto";box.style.height=Math.min(box.scrollHeight,180)+"px"});
document.addEventListener("keydown",e=>{if(e.key==="Escape"&&busy)post("/api/estop",{})});
const drawer=document.getElementById("drawer"),scrim=document.getElementById("scrim");
function openDrawer(b){drawer.classList.toggle("on",b);scrim.classList.toggle("on",b)}
scrim.onclick=()=>openDrawer(false);
function tog(id,key){const el=document.getElementById(id);el.classList.toggle("on",!!cfg[key]);el.onclick=()=>{cfg[key]=!cfg[key];el.classList.toggle("on",cfg[key]);post("/api/config",{[key]:cfg[key]})}}
function sevClass(s,pct){const p=pct==null?null:Number(pct);const sev=s||(p==null?"unknown":p>=90?"critical":p>=70?"warning":"normal");return sev==="critical"?"crit":sev==="warning"?"warn":""}
function fillSelect(sel,models,cur){const list=models&&models.length?models:[{id:"",label:"(default)"}];const ids=new Set(list.map(m=>m.id));let html="";if(!ids.has(""))html+='<option value="">(CLI default)</option>';list.forEach(m=>{html+='<option value="'+esc(m.id)+'">'+esc(m.label||m.id)+(m.hint?" · "+esc(m.hint):"")+"</option>"});if(cur&&!ids.has(cur))html+='<option value="'+esc(cur)+'">'+esc(cur)+" · pinned</option>";sel.innerHTML=html;sel.value=cur||"";if(cur&&sel.value!==cur){const o=document.createElement("option");o.value=cur;o.textContent=cur+" · pinned";sel.appendChild(o);sel.value=cur}}
function paintCfg(){document.getElementById("tg-bypass").classList.toggle("on",!!cfg.bypass);document.getElementById("tg-ptex").classList.toggle("on",!!cfg.ptex_learn);document.getElementById("tg-adam").classList.toggle("on",cfg.adam_fallback!==false);const mc=document.getElementById("m-claude"),mg=document.getElementById("m-grok");if(mc.options.length)mc.value=cfg.claude_model||"";if(mg.options.length)mg.value=cfg.grok_model||"";const mgo=document.getElementById("m-google");if(mgo&&mgo.options.length)mgo.value=cfg.google_model||"";document.getElementById("adam-mode").value=cfg.adam_mode||"light"}
function barRows(bars){if(!bars||!bars.length)return"";return bars.map(b=>{const pct=b.used_pct==null?"—":(Math.round(b.used_pct)+"%");const w=b.used_pct==null?0:Math.max(0,Math.min(100,b.used_pct));const cls=sevClass(b.severity,b.used_pct);const reset=b.resets_at?(" · reset "+new Date(b.resets_at).toLocaleString()):"";return '<div class="usage-row"><div class="lab">'+esc(b.label||b.id)+'</div><div class="track '+cls+'"><i style="width:'+w+'%"></i></div><div class="pct">'+pct+'</div></div><div class="usage-meta" style="margin:-2px 0 6px 96px">used'+reset+"</div>"}).join("")}
function paintUsage(u){if(!u)return;const c=u.claude||{},g=u.grok||{};const cu=c.usage||{},gu=g.usage||{};const seenB=new Set();const cShow=(cu.bars||[]).filter(b=>{const id=b.id||b.label||"";if(id==="session"||id==="weekly_all")return false;if(seenB.has(id))return false;seenB.add(id);return true});const c5=(cu.bars||[]).find(b=>b.id==="five_hour"||/5-hour|session/i.test(b.label||""));const c7=(cu.bars||[]).find(b=>b.id==="seven_day"||/7-day|weekly_all/i.test(b.label||""));const uhC=document.getElementById("uh-claude");if(cu.ok){const p5=c5&&c5.used_pct!=null?Math.round(c5.used_pct):null;const p7=c7&&c7.used_pct!=null?Math.round(c7.used_pct):null;const cls=sevClass(null,p5!=null?p5:p7);uhC.innerHTML='<b>Claude</b><span class="ubar '+cls+'"><i style="width:'+(p5!=null?p5:0)+'%"></i></span><span>5h '+(p5!=null?p5+"%":"—")+' · 7d '+(p7!=null?p7+"%":"—")+"</span>"}else uhC.innerHTML="<b>Claude</b><span>"+esc(cu.error||"offline")+"</span>";const uhG=document.getElementById("uh-grok");if(gu.ok||gu.logged_in){const tok=gu.local&&gu.local.tokens!=null?gu.local.tokens:null;uhG.innerHTML="<b>Grok</b><span>"+esc(gu.email?gu.email.split("@")[0]:"in")+(tok!=null?(" · "+tok.toLocaleString()+" tok local"):"")+"</span>"}else uhG.innerHTML="<b>Grok</b><span>"+esc(gu.error||"offline")+"</span>";document.getElementById("claude-plan").textContent=(cu.plan||"")+(cu.tier?(" · "+cu.tier):"")+(cu.email?(" · "+cu.email):"");document.getElementById("grok-plan").textContent=(gu.plan||"")+(gu.email?(" · "+gu.email):"");let cBody="";if(cu.ok){cBody=barRows(cShow);if(cu.extra&&cu.extra.disabled_reason)cBody+='<div class="usage-meta">extra usage: '+esc(String(cu.extra.disabled_reason))+(cu.extra.spend_limit_reached?" · spend cap hit":"")+"</div>"}else cBody='<div class="usage-meta">'+esc(cu.error||"unavailable")+"</div>";document.getElementById("usage-claude-body").innerHTML=cBody;let gBody="";if(gu.ok||gu.logged_in){const L=gu.local||{};gBody='<div class="usage-meta"><b style="color:var(--tx)">Local ledger</b> (Grok Build has no public plan-% API yet)</div>';gBody+='<div class="usage-row"><div class="lab">tokens</div><div class="track"><i style="width:'+Math.min(100,(L.tokens||0)/5000)+'%"></i></div><div class="pct">'+(L.tokens!=null?Number(L.tokens).toLocaleString():"—")+"</div></div>";gBody+='<div class="usage-meta">events '+(L.events||0)+(L.cost_usd!=null?(" · ~$"+L.cost_usd):"")+(gu.note?("<br>"+esc(gu.note)):"")+"</div>";if(L.by_model&&L.by_model.length)gBody+='<div class="usage-meta">'+L.by_model.map(m=>esc(m.model)+": "+Number(m.tokens||0).toLocaleString()+" tok").join("<br>")+"</div>"}else gBody='<div class="usage-meta">'+esc(gu.error||"unavailable")+"</div>";document.getElementById("usage-grok-body").innerHTML=gBody;const go=u.google||{},gu2=go.usage||{};const uhGo=document.getElementById("uh-google");if(uhGo){if(gu2.ok||gu2.logged_in){uhGo.innerHTML="<b>Google</b><span>"+esc((gu2.email||"signed in").split("@")[0])+" · agy</span>"}else uhGo.innerHTML="<b>Google</b><span>"+esc(gu2.error||"offline")+"</span>";}const gp=document.getElementById("google-plan");if(gp)gp.textContent=(gu2.plan||"")+(gu2.email?(" · "+gu2.email):"");const gb=document.getElementById("usage-google-body");if(gb){if(gu2.ok||gu2.logged_in){gb.innerHTML='<div class="usage-meta"><b style="color:var(--tx)">Antigravity CLI</b> · Google OAuth</div><div class="usage-meta">cli: '+esc(gu2.cli||"agy")+(gu2.note?("<br>"+esc(gu2.note)):"")+"</div>"}else gb.innerHTML='<div class="usage-meta">'+esc(gu2.error||"offline — run agy and pick Google OAuth")+"</div>";}fillSelect(document.getElementById("m-claude"),c.models||[],cfg.claude_model||"");fillSelect(document.getElementById("m-grok"),g.models||[],cfg.grok_model||"");const mg=document.getElementById("m-google");if(mg)fillSelect(mg,go.models||[],cfg.google_model||"")}
async function refreshUsage(force){try{const r=await fetch("/api/usage"+(force?"?refresh=1":""));const u=await r.json();paintUsage(u);return u}catch(e){return null}}
async function refreshAdam(){const r=await post("/api/adam",{action:"status"});const up=r&&r.up;document.getElementById("adam-stat").innerHTML="Adam: <b style=\"color:"+(up?"var(--adam)":"var(--mut)")+"\">"+(up?"running":"offline")+"</b> · mode "+(cfg.adam_mode||"light")+" · fallback "+(cfg.adam_fallback!==false?"on":"off");return up}
function pollAdamOnline(){let n=0;const iv=setInterval(async()=>{n++;const r=await post("/api/adam",{action:"status"});if((r&&r.up)||n>60){clearInterval(iv);refreshAdam();if(r&&r.up)chip("Adam is online")}},2000)}
document.getElementById("adam-mode").onchange=e=>{cfg.adam_mode=e.target.value;post("/api/config",{adam_mode:cfg.adam_mode}).then(refreshAdam)}
document.getElementById("adam-start").onclick=async()=>{document.getElementById("adam-stat").textContent="Adam: booting "+(cfg.adam_mode||"light")+" … (model load can take a while)";await post("/api/adam",{action:"start",mode:cfg.adam_mode||"light"});pollAdamOnline()}
document.getElementById("save-cfg").onclick=()=>post("/api/config",{claude_model:document.getElementById("m-claude").value.trim(),grok_model:document.getElementById("m-grok").value.trim(),google_model:(document.getElementById("m-google")||{value:""}).value.trim()}).then(r=>{if(r&&r.config){cfg=r.config;chip("settings saved · C "+(cfg.claude_model||"default")+" · G "+(cfg.grok_model||"default")+" · Google "+(cfg.google_model||"default"))}});
document.getElementById("refresh-usage").onclick=()=>refreshUsage(true).then(()=>chip("usage refreshed"));
document.getElementById("m-claude").onchange=e=>{cfg.claude_model=e.target.value;post("/api/config",{claude_model:cfg.claude_model})};
document.getElementById("m-grok").onchange=e=>{cfg.grok_model=e.target.value;post("/api/config",{grok_model:cfg.grok_model})};
document.getElementById("m-google").onchange=e=>{cfg.google_model=e.target.value;post("/api/config",{google_model:cfg.google_model})};
document.getElementById("resume-last").onclick=async function(){const r=await post("/api/sessions/resume",{name:"latest"});if(r&&r.ok){await reloadTranscript();chip("resumed "+(r.messages||"?")+" messages")}else alert((r&&r.error)||"resume failed")};
document.getElementById("clear").onclick=()=>{if(confirm("Clear the conversation?"))post("/api/clear",{})};
document.getElementById("commit").onclick=()=>post("/api/commit",{}).then(r=>learn(r&&r.ok?{ok:true,pairs:r.committed||0,ledger_records:0}:r));
document.getElementById("gear").onclick=()=>{openDrawer(true);refreshAdam();refreshUsage(false)};
async function reloadTranscript(){const r=await fetch("/api/state");const st=await r.json();feed.innerHTML="";(st.transcript||[]).forEach(function(x){bubble(x.who,x.text)});setBusy(!!st.busy);if(window.katex)typesetAll();scroll();return st}
async function init(){const r=await fetch("/api/state");const st=await r.json();cfg=st.config||{};selTarget((cfg.default||"all").toLowerCase()==="claude"?"claude":(cfg.default==="grok"?"grok":"all"));(st.transcript||[]).forEach(x=>bubble(x.who,x.text));tog("tg-bypass","bypass");tog("tg-ptex","ptex_learn");tog("tg-adam","adam_fallback");fillSelect(document.getElementById("m-claude"),(st.models&&st.models.claude)||[],cfg.claude_model||"");fillSelect(document.getElementById("m-grok"),(st.models&&st.models.grok)||[],cfg.grok_model||"");fillSelect(document.getElementById("m-google"),(st.models&&st.models.google)||[],cfg.google_model||"");paintCfg();if(st.usage)paintUsage({claude:{models:(st.models||{}).claude,usage:st.usage.claude},grok:{models:(st.models||{}).grok,usage:st.usage.grok},google:{models:(st.models||{}).google,usage:st.usage.google}});refreshAdam().then(up=>{if(!up){document.getElementById("adam-stat").textContent="Adam: booting "+(cfg.adam_mode||"light")+" … (model load can take a while)";pollAdamOnline()}});refreshUsage(false);document.getElementById("adam").innerHTML="Adam repo: <b>"+(st.adam_repo?"connected — teaching on":"not found (learning skipped)")+"</b>";document.getElementById("paths").innerHTML="claude: <b>"+esc(st.claude||"")+"</b><br>grok: <b>"+esc(st.grok||"")+"</b><br>google: <b>"+esc(st.google||"")+"</b>";setBusy(!!st.busy);scroll();setInterval(()=>refreshUsage(false),60000)}
init();
(function waitKx(){if(window.katex){typesetAll();return}setTimeout(waitKx,80)})();
