import os,sys,time,threading,socket,webbrowser
def _root():
    return os.path.dirname(os.path.abspath(getattr(sys,"_MEIPASS",None) or __file__))
def _free_port(pref):
    for p in [pref]+list(range(pref+1,pref+40)):
        with socket.socket() as s:
            try:s.bind(("127.0.0.1",p));return p
            except OSError:continue
    return pref
def main():
    root=_root()
    os.chdir(root)
    if root not in sys.path:sys.path.insert(0,root)
    port=int(os.environ.get("DELVE_PORT") or 0) or _free_port(8788)
    os.environ["DELVE_PORT"]=str(port)
    os.environ.setdefault("DELVE_NO_ADAM_AUTOSTART","1")
    # Always the local UI. Never open the remote/phone port (8789) — that needs a pairing key.
    url="http://127.0.0.1:%d/"%port
    def open_later():
        for _ in range(60):
            with socket.socket() as s:
                if s.connect_ex(("127.0.0.1",port))==0:break
            time.sleep(0.25)
        try:webbrowser.open(url)
        except Exception:pass
    threading.Thread(target=open_later,daemon=True).start()
    print("Braid starting on "+url+"  (local UI — no pairing key needed)")
    print("Leave this window open while you use it. Close it to stop.")
    try:
        import delve_server
        delve_server.main()
    except SystemExit:raise
    except Exception as e:
        print("\nDelve could not start: %s"%e)
        print("If this keeps happening, run it from a terminal to see the full error.")
        try:input("\nPress Enter to close…")
        except Exception:pass
        sys.exit(1)
if __name__=="__main__":main()
