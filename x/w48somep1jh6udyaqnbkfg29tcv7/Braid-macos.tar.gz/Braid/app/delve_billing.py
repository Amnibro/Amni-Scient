import os,json,time,secrets,urllib.request,urllib.error
import delve_providers as PV
BETA=True
LIST_PRICE=20.0
YEAR_OFF=0.15
TIERS={
 "beta":{"id":"beta","label":"Beta","monthly":10.0,"was":LIST_PRICE,
  "blurb":"Everything, at half list price while Braid is in beta.",
  "why":"You are early. Things will move under you, and the price reflects that.",
  "perks":["Every seat you connect","Workspace editor and phone access","Everything shipped during beta",
           "Your price is locked for as long as you stay subscribed"]},
 "tester":{"id":"tester","label":"Beta tester","monthly":5.0,"was":LIST_PRICE,"requires_feedback":True,
  "blurb":"Half again, for telling us what is broken.",
  "why":"Send one piece of usable feedback a month and the rate holds. Miss a month and it quietly returns to Beta pricing - no charge-back, no lock-out.",
  "perks":["Everything in Beta","Report a problem right from the room","Your reports jump the queue",
           "A monthly note on what your feedback changed"]},
 "team":{"id":"team","label":"Team / Business","monthly":None,"per_seat":7.0,"blurb":"Five seats minimum. More seats, lower per-seat rate — and cheaper tokens.",
  "why":"Priced per seat, billed to one account. Under five seats use Beta individual — team is not a discount on one license.",
  "perks":["One bill, one prepaid pool across every seat","Central key provisioning and revocation",
           "Per-seat spend caps and usage export","Priority support"]}}
TEAM_MIN_SEATS=5
SEAT_BREAKS=[{"min":5,"max":19,"seat":7.0,"token_off":0.05},
             {"min":20,"max":49,"seat":6.0,"token_off":0.10},
             {"min":50,"max":None,"seat":5.0,"token_off":0.15}]
PLAN={"software_fee":10.0,"overage_premium":0.10,"currency":"USD","beta":BETA,
      "list_price":LIST_PRICE,"tier":"beta","year_discount":YEAR_OFF}
def seat_break(n):
    try:n=max(TEAM_MIN_SEATS,int(n))
    except Exception:n=TEAM_MIN_SEATS
    for b in SEAT_BREAKS:
        if n>=b["min"] and (b["max"] is None or n<=b["max"]):return dict(b,seats=n)
    return dict(SEAT_BREAKS[-1],seats=n)
def team_quote(seats,budget=None):
    b=seat_break(seats);n=b["seats"]
    monthly=round(b["seat"]*n,2)
    solo=round(TIERS["beta"]["monthly"]*n,2)
    row={"seats":n,"per_seat":b["seat"],"monthly":monthly,"yearly":round(monthly*12*(1-YEAR_OFF),2),
     "token_off":b["token_off"],"vs_individual":round(solo-monthly,2),"min_seats":TEAM_MIN_SEATS,
     "next":None}
    for nb in SEAT_BREAKS:
        if nb["min"]>n:
            row["next"]={"at":nb["min"],"per_seat":nb["seat"],"token_off":nb["token_off"]};break
    if budget:
        try:
            row["token_budget"]=round(float(budget),2)
            row["token_budget_effective"]=round(float(budget)/(1-b["token_off"]),2)
        except Exception:pass
    return row
def price(tier="beta",period="month",seats=1):
    t=TIERS.get(tier) or TIERS["beta"]
    if t.get("monthly") is None:
        q=team_quote(seats)
        return {"tier":t["id"],"label":t["label"],"period":period,"seats":q["seats"],
                "monthly":q["monthly"],"yearly":q["yearly"],"per_seat":q["per_seat"],
                "token_off":q["token_off"],"min_seats":TEAM_MIN_SEATS,"was":None,
                "save_year":round(q["monthly"]*12-q["yearly"],2)}
    m=t["monthly"];y=round(m*12*(1-YEAR_OFF),2)
    return {"tier":t["id"],"label":t["label"],"period":period,"seats":1,"monthly":m,
            "yearly":y,"monthly_if_yearly":round(y/12,2),"was":t.get("was"),
            "save_year":round(m*12-y,2),"token_off":0.0}
def plans():
    return {"beta":BETA,"list_price":LIST_PRICE,"year_discount":YEAR_OFF,
     "tiers":[dict(t,price=price(t["id"],seats=TEAM_MIN_SEATS if t.get("monthly") is None else 1)) for t in TIERS.values()],
     "seat_breaks":SEAT_BREAKS,"team_min_seats":TEAM_MIN_SEATS,
     "overage_premium":PLAN["overage_premium"],"currency":"USD"}
TOK_EX=1800
BASE="https://openrouter.ai/api/v1"
PROVIDERS={
 "claude":{"label":"Claude","seat":"Claude","hue":"#C96442","mtok":6.00,"model":"anthropic/claude-opus-5"},
 "openai":{"label":"OpenAI","seat":"OpenAI","hue":"#10A37F","mtok":5.00,"model":"openai/gpt-5.2"},
 "grok":{"label":"Grok","seat":"Grok","hue":"#5F6670","mtok":4.00,"model":"x-ai/grok-4.6"},
 "gemini":{"label":"Gemini","seat":"Google","hue":"#3B82F6","mtok":3.00,"model":"google/gemini-3.1-pro"}}
def catalog():
    return {"plans":plans(),"providers":{k:{"label":p["label"],"seat":p["seat"],"hue":p["hue"],"mtok":p["mtok"],"model":p["model"],"overage_mtok":round(p["mtok"]*(1+PLAN["overage_premium"]),4)} for k,p in PROVIDERS.items()},"tok_per_exchange":TOK_EX,"plan":dict(PLAN)}
def quote(budget,providers,tier="beta",seats=1,period="month"):
    try:budget=float(budget)
    except Exception:return {"ok":False,"error":"enter a monthly amount"}
    pr=price(tier,period,seats)
    fee=pr["monthly"] if period!="year" else round(pr["yearly"]/12.0,2)
    toff=pr.get("token_off") or 0.0
    raw={}
    for k,v in (providers or {}).items():
        try:raw[str(k).lower()]=float(v)
        except Exception:pass
    sel={k:v for k,v in raw.items() if k in PROVIDERS and v>0}
    if not sel:return {"ok":False,"error":"pick at least one provider"}
    tot=sum(sel.values());sel={k:v/tot*100.0 for k,v in sel.items()}
    net=budget-fee
    if net<=0:return {"ok":False,"error":"the $%.2f/mo %s fee leaves nothing for tokens"%(fee,pr["label"].lower())}
    net=net/(1-toff) if toff else net
    cost={k:TOK_EX*PROVIDERS[k]["mtok"]/1e6 for k in sel};C=sum(cost.values())
    rows={}
    for k,pct in sel.items():
        a=net*pct/100.0;b=net*cost[k]/C
        rows[k]={"pct":round(pct,2),"usd":round(a,2),"tokens":int(a/PROVIDERS[k]["mtok"]*1e6),"prompts":int(a/cost[k]),"rate_mtok":PROVIDERS[k]["mtok"],"overage_mtok":round(PROVIDERS[k]["mtok"]*(1+PLAN["overage_premium"]),4),"balanced_usd":round(b,2),"delta_usd":round(a-b,2)}
    lim=min(rows,key=lambda k:rows[k]["prompts"])
    return {"ok":True,"budget":round(budget,2),"fee":fee,"price":pr,"token_off":toff,"net":round(net,2),"providers":rows,"room_prompts":rows[lim]["prompts"],"balanced_prompts":int(net/C),"limiting":lim,"tok_per_exchange":TOK_EX}
def _acct_path():return os.path.join(PV._store_dir(),"braid_account.json")
def _mask(k):return ("····"+str(k)[-4:]) if k else ""
def provision_via_server(key,machine,providers):
    """Mint the provider keys ON THE LICENSE SERVER.

    The provisioning key can create unlimited spend against the account, so it must
    never sit in the desktop app - one copy of a shipped binary would be enough. The
    server also knows what was actually paid and caps each key to it."""
    try:
        import delve_license as LC
        url,_=LC._cfg()
    except Exception:url=""
    if not url:return {"ok":False,"error":"no license server configured"}
    body=json.dumps({"key":key,"machine":machine,"providers":providers or {}}).encode("utf-8")
    req=urllib.request.Request(url.rstrip("/")+"/provision",data=body,
        headers={"Content-Type":"application/json","Accept":"application/json"},method="POST")
    try:
        with urllib.request.urlopen(req,timeout=40) as r:
            return json.loads(r.read().decode("utf-8","replace") or "{}")
    except urllib.error.HTTPError as e:
        try:return json.loads(e.read().decode("utf-8","replace") or "{}")
        except Exception:return {"ok":False,"error":"HTTP "+str(e.code)}
    except Exception as e:
        return {"ok":False,"error":str(e)[:140]}
def _mint(name,limit):
    """LOCAL DEV ONLY. In a shipped build BRAID_PROVISIONING_KEY must be absent and
    provisioning must go through the license server - see provision_via_server()."""
    pk=os.environ.get("BRAID_PROVISIONING_KEY")
    if pk:
        try:
            req=urllib.request.Request(BASE+"/keys",data=json.dumps({"name":name,"limit":round(float(limit),2)}).encode("utf-8"),headers={"Authorization":"Bearer "+pk,"Content-Type":"application/json"},method="POST")
            with urllib.request.urlopen(req,timeout=25) as r:j=json.loads(r.read().decode("utf-8","replace") or "{}")
            key=j.get("key") if isinstance(j.get("key"),str) else (((j.get("key") or {}).get("key")) or j.get("api_key") or "")
            if key:return {"key":key,"mode":"live"}
            return {"key":"sk-braid-"+secrets.token_urlsafe(16),"mode":"sandbox","note":"provisioner returned no key"}
        except Exception as e:return {"key":"sk-braid-"+secrets.token_urlsafe(16),"mode":"sandbox","note":str(e)[:120]}
    return {"key":"sk-braid-"+secrets.token_urlsafe(16),"mode":"sandbox"}
def signup(email,budget,providers,tier="beta",seat_count=1,period="month"):
    q=quote(budget,providers,tier,seat_count,period)
    if not q.get("ok"):return q
    email=str(email or "").strip()[:120]
    keys={};seats={}
    for k,row in q["providers"].items():
        p=PROVIDERS[k];m=_mint("braid-"+k+(("-"+email.split("@")[0][:24]) if "@" in email else ""),row["usd"])
        keys[k]={"key":m["key"],"mode":m["mode"],"limit_usd":row["usd"],"minted":time.time(),**({"note":m["note"]} if m.get("note") else {})}
        PV.set_secret(p["seat"],m["key"])
        seats[p["seat"]]={"kind":"openai","preset":"openrouter","base":BASE,"model":p["model"]}
    acct={"email":email,"created":time.time(),"plan":dict(PLAN),"tier":tier,"period":period,"seats":int(seat_count or 1),"price":q.get("price"),"budget":q["budget"],"quote":q,"keys":keys}
    try:
        with open(_acct_path(),"w",encoding="utf-8") as f:json.dump(acct,f,indent=1)
        if os.name!="nt":os.chmod(_acct_path(),0o600)
    except Exception:pass
    return {"ok":True,"account":account(),"seats":seats,"mode":("live" if all(v["mode"]=="live" for v in keys.values()) else "sandbox")}
def account():
    p=_acct_path()
    if not os.path.isfile(p):return None
    try:a=json.load(open(p,encoding="utf-8")) or {}
    except Exception:return None
    ks={k:{"key":_mask((v or {}).get("key")),"mode":(v or {}).get("mode"),"limit_usd":(v or {}).get("limit_usd")} for k,v in (a.get("keys") or {}).items()}
    return {"email":a.get("email"),"created":a.get("created"),"plan":a.get("plan"),"tier":a.get("tier") or "beta","period":a.get("period") or "month","seats":a.get("seats") or 1,"price":a.get("price"),"budget":a.get("budget"),"quote":a.get("quote"),"keys":ks,"feedback":feedback_state()}

# ------------------------------------------------- beta feedback program ---
def _fb_path():return os.path.join(PV._store_dir(),"braid_feedback.json")
def _fb_load():
    p=_fb_path()
    if not os.path.isfile(p):return {"reports":[]}
    try:return json.load(open(p,encoding="utf-8")) or {"reports":[]}
    except Exception:return {"reports":[]}
def _fb_save(d):
    try:
        with open(_fb_path(),"w",encoding="utf-8") as f:json.dump(d,f,indent=1,ensure_ascii=False)
    except Exception:pass
def feedback_add(text,kind="note",where=""):
    t=str(text or "").strip()
    if len(t)<12:return {"ok":False,"error":"a few more words — what were you doing, and what happened?"}
    d=_fb_load()
    d.setdefault("reports",[]).append({"ts":time.time(),"kind":str(kind or "note")[:24],
     "where":str(where or "")[:80],"text":t[:4000]})
    d["reports"]=d["reports"][-500:]
    _fb_save(d)
    return {"ok":True,**feedback_state()}
def feedback_state():
    d=_fb_load();rows=d.get("reports") or []
    now=time.time();month=now-30*86400
    recent=[r for r in rows if (r.get("ts") or 0)>=month]
    return {"total":len(rows),"this_month":len(recent),
     "qualifies":len(recent)>=1,"last":(rows[-1]["ts"] if rows else None),
     "needed":max(0,1-len(recent)),
     "rate":TIERS["tester"]["monthly"] if len(recent)>=1 else TIERS["beta"]["monthly"]}
def feedback_list(limit=50):
    rows=(_fb_load().get("reports") or [])[-int(limit or 50):]
    return {"ok":True,"reports":list(reversed(rows)),**feedback_state()}
