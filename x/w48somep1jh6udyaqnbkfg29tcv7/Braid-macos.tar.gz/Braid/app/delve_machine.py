"""A machine per seat, on demand — the seat's own place to browse and run tools, watched live.

What a "machine" is here, stated plainly: process-level isolation, not hardware virtualization.
Each seat gets its own workspace directory, its own Chrome (separate profile, headless, driven
over CDP on a loopback port), and its own shell processes — all parented here, all tree-killed
on stop. A QEMU VM per seat would be honest virtualization and would also stack seven emulators
on one GPU-loaded box; this is the version that runs today and leaks nothing.

Visibility is the point. The browser is headless but never invisible: a driver thread pulls
JPEG frames over CDP into memory, delve_server streams them as MJPEG, and the UI shows every
machine live in a dock. The user watches the seat browse, in Braid, as it happens.

Seats need no new tool support. Every CLI seat already has a shell; the machine hands it two
commands (machine_ctl.py open/run) that hit Braid's own HTTP API, so "use your browser" is one
bash call away for any seat, and whatever it does shows up on screen.
"""
import os,json,socket,threading,time,shutil,atexit
import delve_proc as PROC
CHROME_CANDIDATES=[r"C:\Program Files\Google\Chrome\Application\chrome.exe",
 r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
 os.path.expanduser(r"~\AppData\Local\Google\Chrome\Application\chrome.exe"),
 "/usr/bin/google-chrome","/usr/bin/chromium","/usr/bin/chromium-browser","/snap/bin/chromium",
 "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
 os.path.expanduser("~/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"),
 "/Applications/Chromium.app/Contents/MacOS/Chromium"]
BASE_PORT=9430
FRAME_EVERY=0.5
SHOT_W,SHOT_H=1160,760
LOG_CAP=400
_LOCK=threading.Lock()
_MACHINES={}
def chrome_path():
    for p in CHROME_CANDIDATES:
        if os.path.isfile(p):return p
    return ""
def _free_port(pref):
    for p in range(pref,pref+60):
        with socket.socket() as s:
            try:s.bind(("127.0.0.1",p));return p
            except OSError:continue
    return pref
class Machine:
    def __init__(m,seat,root):
        m.seat=seat
        m.dir=os.path.join(root,"machines",seat)
        os.makedirs(m.dir,exist_ok=True)
        m.port=0;m.chrome=None;m.driver=None
        m.frame=b"";m.frame_at=0.0;m.url="about:blank";m.title=""
        m.procs=[];m.log=[]
        m.cmds=[];m.cmd_ev=threading.Event()
        m.alive=False;m.err="";m.started=0.0
    def _logline(m,text):
        m.log.append({"t":round(time.time(),1),"line":str(text)[:800]})
        if len(m.log)>LOG_CAP:m.log=m.log[-(LOG_CAP//2):]
    def start(m):
        if m.alive:return {"ok":True,"already":True}
        exe=chrome_path()
        if not exe:m.err="Chrome not found";return {"ok":False,"error":m.err}
        try:import aiohttp
        except Exception:
            m.err="aiohttp not available in this build — the browser view needs it"
            return {"ok":False,"error":m.err}
        m.port=_free_port(BASE_PORT+abs(hash(m.seat))%40)
        prof=os.path.join(m.dir,"chrome-profile")
        os.makedirs(prof,exist_ok=True)
        args=[exe,"--headless=new","--remote-debugging-port=%d"%m.port,
         "--remote-allow-origins=*","--user-data-dir="+prof,
         "--window-size=%d,%d"%(SHOT_W,SHOT_H),"--no-first-run","--no-default-browser-check",
         "--disable-background-networking","--mute-audio","about:blank"]
        try:m.chrome=PROC.popen(args,cwd=m.dir)
        except Exception as e:m.err="chrome launch failed: "+str(e)[:200];return {"ok":False,"error":m.err}
        m.alive=True;m.err="";m.started=time.time()
        m._logline("machine up — browser on CDP :%d, workspace %s"%(m.port,m.dir))
        m.driver=threading.Thread(target=m._drive_thread,daemon=True)
        m.driver.start()
        return {"ok":True,"port":m.port,"dir":m.dir}
    def _drive_thread(m):
        import asyncio
        try:asyncio.run(m._drive())
        except Exception as e:
            m.err=str(e)[:200];m._logline("driver died: "+m.err)
        m.alive=False
    async def _drive(m):
        """One loop owns the CDP socket: it answers queued commands (navigate) and refreshes
        the frame. Request/response matching is by id; unsolicited events are dropped —
        Braid needs the picture and the URL, not the whole protocol."""
        import asyncio,aiohttp
        async with aiohttp.ClientSession() as sess:
            ws_url=""
            for _ in range(60):
                if not m.alive:return
                try:
                    async with sess.get("http://127.0.0.1:%d/json"%m.port,timeout=aiohttp.ClientTimeout(total=2)) as r:
                        tabs=await r.json()
                    pages=[t for t in tabs if t.get("type")=="page" and t.get("webSocketDebuggerUrl")]
                    if pages:ws_url=pages[0]["webSocketDebuggerUrl"];break
                except Exception:pass
                await asyncio.sleep(0.25)
            if not ws_url:
                m.err="CDP never answered";m._logline(m.err);return
            async with sess.ws_connect(ws_url,max_msg_size=64*1024*1024) as ws:
                mid=[0];pend={}
                async def call(method,params=None,timeout=15):
                    mid[0]+=1;i=mid[0]
                    fut=asyncio.get_event_loop().create_future();pend[i]=fut
                    await ws.send_json({"id":i,"method":method,"params":params or {}})
                    try:return await asyncio.wait_for(fut,timeout)
                    finally:pend.pop(i,None)
                async def pump():
                    async for msg in ws:
                        if msg.type!=aiohttp.WSMsgType.TEXT:break
                        try:d=json.loads(msg.data)
                        except Exception:continue
                        f=pend.get(d.get("id"))
                        if f and not f.done():f.set_result(d.get("result") or {})
                task=asyncio.ensure_future(pump())
                try:
                    await call("Page.enable")
                    while m.alive:
                        while m.cmds:
                            cmd=m.cmds.pop(0)
                            try:
                                if cmd.get("op")=="nav":
                                    await call("Page.navigate",{"url":cmd["url"]})
                                    m._logline("→ "+cmd["url"])
                            except Exception as e:m._logline("nav failed: "+str(e)[:120])
                        try:
                            shot=await call("Page.captureScreenshot",{"format":"jpeg","quality":62})
                            data=shot.get("data")
                            if data:
                                import base64
                                m.frame=base64.b64decode(data);m.frame_at=time.time()
                            info=await call("Runtime.evaluate",{"expression":"JSON.stringify({u:location.href,t:document.title})","returnByValue":True})
                            v=(info.get("result") or {}).get("value")
                            if v:
                                try:
                                    o=json.loads(v);m.url=o.get("u") or m.url;m.title=(o.get("t") or "")[:120]
                                except Exception:pass
                        except Exception:pass
                        m.cmd_ev.clear()
                        try:await asyncio.wait_for(asyncio.get_event_loop().run_in_executor(None,m.cmd_ev.wait,FRAME_EVERY),FRAME_EVERY+1)
                        except Exception:pass
                finally:
                    task.cancel()
    def navigate(m,url):
        u=str(url or "").strip()
        if not u:return {"ok":False,"error":"no url"}
        if "://" not in u:u="https://"+u
        m.cmds.append({"op":"nav","url":u});m.cmd_ev.set()
        return {"ok":True,"url":u}
    def exec(m,cmd):
        c=str(cmd or "").strip()
        if not c:return {"ok":False,"error":"no command"}
        m._logline("$ "+c)
        def run():
            try:
                p=PROC.popen(c,shell=True,cwd=m.dir,stdout=-1,stderr=-2,text=True,encoding="utf-8",errors="replace")
                m.procs.append(p)
                for ln in iter(p.stdout.readline,""):
                    m._logline(ln.rstrip())
                p.wait()
                m._logline("[exit %s]"%p.returncode)
            except Exception as e:m._logline("[exec error] "+str(e)[:200])
        threading.Thread(target=run,daemon=True).start()
        return {"ok":True}
    def state(m):
        return {"seat":m.seat,"alive":m.alive,"dir":m.dir,"url":m.url,"title":m.title,
         "port":m.port,"err":m.err,"up_s":int(time.time()-m.started) if m.started else 0,
         "frame_age":round(time.time()-m.frame_at,1) if m.frame_at else None,
         "log":m.log[-30:]}
    def stop(m):
        m.alive=False;m.cmd_ev.set()
        killed=0
        for p in list(m.procs)+([m.chrome] if m.chrome else []):
            # taskkill /T takes the whole tree in one OS call — a psutil child-walk races
            # Chrome's own spawning and left 10 processes alive in testing. psutil stays as
            # the POSIX path and the fallback.
            try:
                if os.name=="nt":
                    PROC.run(["taskkill","/F","/T","/PID",str(p.pid)],capture_output=True,timeout=10)
                    killed+=1;continue
            except Exception:pass
            try:
                if os.name!="nt":
                    import signal
                    os.killpg(os.getpgid(p.pid),signal.SIGKILL);killed+=1;continue
            except Exception:pass
            try:
                import psutil
                pp=psutil.Process(p.pid)
                for ch in pp.children(recursive=True):
                    try:ch.kill();killed+=1
                    except Exception:pass
                pp.kill();killed+=1
            except Exception:
                try:p.kill();killed+=1
                except Exception:pass
        # Chrome's launcher detaches: the pid Braid holds exits after spawning the real browser,
        # so pid-tree kills miss the whole thing. Every real chrome process carries this
        # machine's --user-data-dir in its command line, and that path is unique per machine —
        # sweep by it. This is the kill that actually empties the box.
        tag=os.path.join(m.dir,"chrome-profile")
        try:
            import psutil
            for pp in psutil.process_iter(["cmdline"]):
                try:
                    if any(tag in (a or "") for a in (pp.info.get("cmdline") or [])):
                        pp.kill();killed+=1
                except Exception:pass
        except Exception:
            if os.name!="nt":
                try:PROC.run(["pkill","-9","-f",tag],capture_output=True,timeout=10)
                except Exception:pass
        m.procs=[];m.chrome=None;m.frame=b""
        m._logline("machine stopped — %d process(es) ended"%killed)
        return {"ok":True,"killed":killed}
def get(seat,root=None,create=False):
    with _LOCK:
        mm=_MACHINES.get(seat)
        if mm is None and create:
            mm=Machine(seat,root or os.getcwd());_MACHINES[seat]=mm
        return mm
def start(seat,root):
    return get(seat,root,create=True).start()
def stop(seat):
    mm=get(seat)
    return mm.stop() if mm else {"ok":False,"error":"no machine"}
def state_all():
    with _LOCK:
        return {k:v.state() for k,v in _MACHINES.items()}
def note_for(seat,port):
    """The prompt block that makes the machine usable by ANY seat with a shell tool."""
    mm=get(seat)
    if not (mm and mm.alive):return ""
    ctl=os.path.join(os.path.dirname(os.path.abspath(__file__)),"machine_ctl.py")
    return ("YOUR MACHINE (the user watches it live in Braid — use it for browsing and scratch work):\n"
     "- workspace dir (yours alone): "+mm.dir+"\n"
     '- open a page in YOUR browser:  python "'+ctl+'" '+str(port)+" "+seat+" open <url>\n"
     '- run a command in your machine: python "'+ctl+'" '+str(port)+" "+seat+" run <command>\n"
     "Anything you open or run there is visible to the user in the Machines dock.")
def stop_all():
    with _LOCK:items=list(_MACHINES.values())
    for mm in items:
        try:mm.stop()
        except Exception:pass
atexit.register(stop_all)
