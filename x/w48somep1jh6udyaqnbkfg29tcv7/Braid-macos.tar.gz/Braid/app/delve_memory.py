import os,json,re,time,urllib.request,urllib.error,urllib.parse,threading
import delve_ptex as PX
_LOCK=threading.Lock()
def _base():
    return "http://"+os.environ.get("ADAM_HOST","127.0.0.1")+":"+os.environ.get("ADAM_PORT","7700")
class Down(Exception):pass
def _friendly(e):
    t=str(e)
    if "10061" in t or "refused" in t.lower() or "URLError" in type(e).__name__:
        return "Adam is not running — start it from Controls → Advanced → Adam, and memory comes back."
    if "timed out" in t.lower():return "Adam did not answer in time — it may still be loading."
    return t[:160]
def _get(path,timeout=25):
    try:
        with urllib.request.urlopen(_base()+path,timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8","replace") or "{}")
    except urllib.error.HTTPError:raise
    except Exception as e:raise Down(_friendly(e))
def _post(path,body,timeout=30):
    req=urllib.request.Request(_base()+path,data=json.dumps(body).encode("utf-8"),
        headers={"Content-Type":"application/json"})
    try:
        with urllib.request.urlopen(req,timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8","replace") or "{}")
    except urllib.error.HTTPError as e:
        try:d=json.loads(e.read().decode("utf-8","replace") or "{}")
        except Exception:d={}
        return {"ok":False,"error":d.get("error") or d.get("detail") or ("HTTP "+str(e.code))}
    except Exception as e:
        return {"ok":False,"error":_friendly(e)}
SORTS=("recent","oldest","longest","shortest","az","za","slot")
def _key(row,how):
    q=(row.get("q") or "");a=(row.get("a") or "")
    return {"recent":-(row.get("ts") or 0),"oldest":(row.get("ts") or 0),
     "longest":-(len(q)+len(a)),"shortest":(len(q)+len(a)),
     "az":q.lower(),"za":"","slot":(row.get("slot") or "")}.get(how,-(row.get("ts") or 0))
def sort_rows(rows,how="recent"):
    how=how if how in SORTS else "recent"
    if how=="za":return sorted(rows,key=lambda r:(r.get("q") or "").lower(),reverse=True)
    return sorted(rows,key=lambda r:_key(r,how))
def cells(slot="__global__",limit=600,sort="recent"):
    d=_get("/memory/atlas/cells?slot="+urllib.parse.quote(slot)+"&limit="+str(int(limit)))
    rows=d.get("cells") or []
    for r in rows:r.setdefault("slot",slot)
    d["cells"]=sort_rows(rows,sort);d["ok"]=True;d["sort"]=sort
    return d
def recent(limit=120,prefer=None):
    """Newest memories across durable seats + global — what people expect when they open Memory."""
    prefer=list(prefer or [])
    if not prefer:
        prefer=["__global__","__local_user__","delve_Claude","delve_Grok","delve_Google","delve_Adam","delve_OpenAI","delve_Copilot","delve_Cursor","delve_OpenCode"]
        try:
            st=_get("/memory/atlas/stats")
            tops=sorted(((k,(v or {}).get("entries",0)) for k,v in (st.get("slots") or {}).items()),key=lambda x:-x[1])
            for k,_n in tops:
                if k and k not in prefer and (k.startswith("delve_") or k.startswith("2026")):prefer.append(k)
                if len(prefer)>=40:break
        except Exception:pass
    hits=[];scanned=0;used=[]
    for sl in prefer:
        try:
            rows=_get("/memory/atlas/cells?slot="+urllib.parse.quote(sl)+"&limit=200",timeout=12).get("cells") or []
        except Exception:continue
        used.append(sl);scanned+=len(rows)
        for c in rows:
            c=dict(c);c["slot"]=sl;hits.append(c)
    hits=sort_rows(hits,"recent")
    return {"ok":True,"hits":hits[:max(1,int(limit))],"cells":hits[:max(1,int(limit))],"scanned":scanned,"slots":used,"sort":"recent","slot":"__recent__"}
def stats():
    try:d=_get("/memory/atlas/stats")
    except Exception as e:return {"ok":False,"error":_friendly(e)}
    slots=d.get("slots") or {}
    tot=sum((v or {}).get("entries",0) for v in slots.values())
    uniq=sum((v or {}).get("unique_cells",0) for v in slots.values())
    pers=sum((v or {}).get("personal",0) for v in slots.values())
    top=sorted(((k,(v or {}).get("entries",0)) for k,v in slots.items()),key=lambda x:-x[1])[:40]
    return {"ok":True,"slots":len(slots),"entries":tot,"unique_cells":uniq,"personal":pers,
     "federable":tot-pers,"top":[{"slot":k,"entries":n} for k,n in top if n]}
def search(q,limit=400,slot="",sort="recent"):
    """Find memories by text across every slot - the thing you need before you can clean up."""
    ql=str(q or "").strip().lower()
    if not ql:return {"ok":False,"error":"type what you are looking for"}
    slots=[slot] if slot else []
    if not slots:
        try:slots=list((_get("/memory/atlas/stats").get("slots") or {}).keys())
        except Exception as e:return {"ok":False,"error":_friendly(e)}
        slots=["__global__"]+[s for s in slots if s!="__global__"]
    hits=[];seen=0
    def pull(sl):
        try:return sl,(_get("/memory/atlas/cells?slot="+urllib.parse.quote(sl)+"&limit=600",timeout=12).get("cells") or [])
        except Exception:return sl,[]
    from concurrent.futures import ThreadPoolExecutor
    with ThreadPoolExecutor(max_workers=12) as ex:
        for sl,rows in ex.map(pull,slots):
            for c in rows:
                seen+=1
                if ql in (str(c.get("q") or "")+" "+str(c.get("a") or "")).lower():
                    c["slot"]=sl;hits.append(c)
    trunc=len(hits)>limit
    return {"ok":True,"hits":sort_rows(hits,sort)[:limit],"scanned":seen,"slots":len(slots),"truncated":trunc,"query":q}
def edit(slot,question,answer):
    """Correct a memory in place: re-record at the same address so recall returns the fixed text."""
    q=str(question or "").strip();a=str(answer or "").strip()
    if not q or not a:return {"ok":False,"error":"a memory needs both a question and an answer"}
    r=_post("/memory/atlas/record",{"slot":slot or "__global__","question":q,"answer":a})
    if r.get("ok") is False:return r
    return {"ok":True,"slot":slot or "__global__","recorded":True,"result":r}
def forget(pattern,atlas="personal"):
    p=str(pattern or "").strip()
    if len(p)<3:return {"ok":False,"error":"give at least 3 characters — a blanket delete is not what you want"}
    r=_post("/memory/forget",{"atlas":atlas,"pattern":p,"query":p,"confirm":True})
    if r.get("ok") is False:return r
    n=r.get("forgot")
    n=0 if n in ("none",None,False) else (int(n) if str(n).isdigit() else n)
    return {"ok":True,"forgot":n,"atlas":atlas,"pattern":p,"detail":r}
# ---------------------------------------------------------------- ledger ---
def ledger(limit=40,task=""):
    try:d=_get("/memory/coding-attempts?limit="+str(int(limit))+("&task="+urllib.parse.quote(task) if task else ""))
    except Exception as e:return {"ok":False,"error":_friendly(e)}
    d["ok"]=True;return d
# ------------------------------------------------------------ rejections ---
REJ_MARK="[REJECTED by peers]"
def _pairs():
    p=PX._pairs_path()
    if not os.path.isfile(p):return p,{"grid":48,"pca_dim":6,"pairs":[]}
    try:
        with open(p,encoding="utf-8") as f:return p,(json.load(f) or {})
    except Exception:return p,{"grid":48,"pca_dim":6,"pairs":[]}
def _write_pairs(p,data):
    tmp=p+".tmp"
    with open(tmp,"w",encoding="utf-8") as f:json.dump(data,f,ensure_ascii=False)
    os.replace(tmp,p);return True
def rejections(q="",limit=300,sort="recent"):
    p,d=_pairs();rows=d.get("pairs") or []
    ql=str(q or "").strip().lower();out=[]
    for i,pr in enumerate(rows):
        if not isinstance(pr,(list,tuple)) or len(pr)<2:continue
        question,answer=str(pr[0]),str(pr[1])
        if REJ_MARK not in answer:continue
        if ql and ql not in (question+" "+answer).lower():continue
        who=""
        m=re.match(r'\[(\w+) first take\]\s*',question)
        if m:who=m.group(1)
        out.append({"i":i,"q":question[:800],"a":answer[:1200],"who":who,
         "why":answer.split(REJ_MARK,1)[1].strip()[:600]})
    out=out[::-1] if sort=="recent" else (out if sort=="oldest" else
        sorted(out,key=lambda r:len(r["q"])+len(r["a"]),reverse=(sort=="longest")))
    return {"ok":True,"rejections":out[:limit],"total":sum(1 for pr in rows
     if isinstance(pr,(list,tuple)) and len(pr)>1 and REJ_MARK in str(pr[1])),"file":p,"pairs":len(rows)}
def rejections_drop(idxs=None,q="",all_of_them=False):
    """A rejection that was never really wrong should not keep steering the room away from a good idea."""
    with _LOCK:
        p,d=_pairs();rows=d.get("pairs") or []
        keep=[];dropped=0
        want=set(int(i) for i in (idxs or []) if str(i).strip().lstrip("-").isdigit())
        ql=str(q or "").strip().lower()
        for i,pr in enumerate(rows):
            bad=isinstance(pr,(list,tuple)) and len(pr)>1 and REJ_MARK in str(pr[1])
            hit=bad and (all_of_them or (i in want) or (ql and ql in (str(pr[0])+" "+str(pr[1])).lower()))
            if hit:dropped+=1;continue
            keep.append(pr)
        if not dropped:return {"ok":True,"dropped":0,"total":len(rows)}
        d["pairs"]=keep;_write_pairs(p,d)
        return {"ok":True,"dropped":dropped,"total":len(keep),"file":p}
def wipe(what="rejections",pattern=""):
    what=str(what or "").lower()
    if what=="rejections":return rejections_drop(all_of_them=True)
    if what=="pairs":
        with _LOCK:
            p,d=_pairs();n=len(d.get("pairs") or []);d["pairs"]=[];_write_pairs(p,d)
            return {"ok":True,"dropped":n,"total":0,"file":p}
    if what=="memories":
        if not str(pattern or "").strip():
            return {"ok":False,"error":"clearing every memory needs a pattern — search for what you mean first"}
        return forget(pattern,"personal")
    return {"ok":False,"error":"unknown target"}
