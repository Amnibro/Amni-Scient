"""Ed25519 signature VERIFICATION only, in pure Python (RFC 8032).

Braid ships the public key. The private key lives on the licence server and never
leaves it, so a cached entitlement on disk can be read but not forged: editing
"expires" or "tier" invalidates the signature.

Verify-only on purpose - this module cannot sign anything, so there is nothing here
worth stealing.
"""
import hashlib
_P=2**255-19
_L=2**252+27742317777372353535851937790883648493
_D=(-121665*pow(121666,_P-2,_P))%_P
_I=pow(2,(_P-1)//4,_P)
def _inv(x):return pow(x,_P-2,_P)
def _recover_x(y,sign):
    if y>=_P:return None
    xx=(y*y-1)*_inv(_D*y*y+1)
    x=pow(xx,(_P+3)//8,_P)
    if (x*x-xx)%_P!=0:x=(x*_I)%_P
    if (x*x-xx)%_P!=0:return None
    if (x&1)!=sign:x=_P-x
    return x
# points as (X,Y,Z,T) extended coordinates
_G=None
def _point_add(p,q):
    A=((p[1]-p[0])*(q[1]-q[0]))%_P
    B=((p[1]+p[0])*(q[1]+q[0]))%_P
    C=(2*p[3]*q[3]*_D)%_P
    D2=(2*p[2]*q[2])%_P
    E,F,G,H=B-A,D2-C,D2+C,B+A
    return ((E*F)%_P,(G*H)%_P,(F*G)%_P,(E*H)%_P)
def _point_mul(s,p):
    q=(0,1,1,0)
    while s>0:
        if s&1:q=_point_add(q,p)
        p=_point_add(p,p);s>>=1
    return q
def _point_eq(p,q):
    return (p[0]*q[2]-q[0]*p[2])%_P==0 and (p[1]*q[2]-q[1]*p[2])%_P==0
def _decompress(b):
    if len(b)!=32:return None
    y=int.from_bytes(b,"little");sign=y>>255;y&=(1<<255)-1
    x=_recover_x(y,sign)
    if x is None:return None
    return (x,y,1,(x*y)%_P)
def _base():
    global _G
    if _G is None:
        gy=(4*_inv(5))%_P;gx=_recover_x(gy,0)
        _G=(gx,gy,1,(gx*gy)%_P)
    return _G
def verify(public_key,message,signature):
    """True only if `signature` is a genuine Ed25519 signature of `message`."""
    try:
        if len(public_key)!=32 or len(signature)!=64:return False
        A=_decompress(public_key)
        if A is None:return False
        Rs,s=signature[:32],int.from_bytes(signature[32:],"little")
        if s>=_L:return False
        R=_decompress(Rs)
        if R is None:return False
        h=int.from_bytes(hashlib.sha512(Rs+public_key+message).digest(),"little")%_L
        sB=_point_mul(s,_base())
        RhA=_point_add(R,_point_mul(h,A))
        return _point_eq(sB,RhA)
    except Exception:
        return False
def verify_hex(public_hex,message,sig_hex):
    try:
        return verify(bytes.fromhex(public_hex),
                      message if isinstance(message,bytes) else str(message).encode("utf-8"),
                      bytes.fromhex(sig_hex))
    except Exception:
        return False
