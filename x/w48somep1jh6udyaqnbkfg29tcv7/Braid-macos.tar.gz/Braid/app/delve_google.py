import json,os,shutil,subprocess,time
try:
 from delve_proc import run as _run,popen as _popen,check_output as _co
except Exception:
 from subprocess import run as _run,Popen as _popen,check_output as _co
ROOT=os.path.dirname(os.path.abspath(__file__))
MODELS_CACHE=os.path.join(ROOT,"google_models_cache.json")
CANDIDATES=[
 os.path.expandvars(r"%LOCALAPPDATA%\agy\bin\agy.exe"),
 os.path.expanduser(r"~\AppData\Local\agy\bin\agy.exe"),
 os.path.expanduser(r"~/.local/bin/agy"),
 os.path.expanduser(r"~/.local/bin/agy.exe"),
 "/usr/local/bin/agy",
 "/opt/homebrew/bin/agy",
]
FALLBACK_MODELS=[
{"id":"gemini-3.1-pro-high","label":"Gemini 3.1 Pro · High","hint":"best reasoning"},
{"id":"gemini-3.1-pro-low","label":"Gemini 3.1 Pro · Low","hint":"lighter pro"},
{"id":"gemini-3.6-flash-high","label":"Gemini 3.6 Flash · High","hint":"fast frontier"},
{"id":"gemini-3.6-flash-medium","label":"Gemini 3.6 Flash · Medium","hint":"balanced"},
{"id":"gemini-3.6-flash-low","label":"Gemini 3.6 Flash · Low","hint":"cheapest flash"},
{"id":"gemini-3.5-flash-high","label":"Gemini 3.5 Flash · High","hint":""},
{"id":"gemini-3.5-flash-medium","label":"Gemini 3.5 Flash · Medium","hint":""},
{"id":"gemini-3.5-flash-low","label":"Gemini 3.5 Flash · Low","hint":""},
]
def resolve():
 p=shutil.which("agy")
 if p:return p
 for c in CANDIDATES:
  if c and os.path.exists(c):return c
 return ""
def installed():return bool(resolve())
def email():
 for rel in (os.path.join("~",".gemini","google_accounts.json"),os.path.join("~",".gemini","antigravity-cli","settings.json")):
  p=os.path.expanduser(rel)
  if not os.path.exists(p):continue
  try:d=json.load(open(p,encoding="utf-8"))
  except Exception:continue
  if isinstance(d,dict):
   if d.get("active"):return str(d["active"])
   if d.get("email"):return str(d["email"])
 return ""
def signed_in():
 if email():return True
 for rel in (os.path.join("~",".gemini","oauth_creds.json"),os.path.join("~",".gemini","antigravity-cli","oauth_creds.json")):
  p=os.path.expanduser(rel)
  if os.path.exists(p):
   try:
    d=json.load(open(p,encoding="utf-8"))
    if d.get("access_token") or d.get("refresh_token"):return True
   except Exception:pass
 return False
def models(fast=False):
 """`agy models` spawns a CLI (seconds) and used to run inside the /api/state request —
 that was most of the page-boot stall. Cache the answer on disk for 12h; `fast` never
 spawns and falls back to the static list so a request thread is never blocked."""
 try:
  c=json.load(open(MODELS_CACHE,encoding="utf-8"))
  if isinstance(c,dict) and (time.time()-float(c.get("t") or 0))<43200 and c.get("models"):return c["models"]
 except Exception:pass
 if fast:return list(FALLBACK_MODELS)
 exe=resolve();out=[];seen=set()
 if exe:
  try:
   r=_run([exe,"models"],capture_output=True,text=True,timeout=6)
   for line in (r.stdout or "").splitlines():
    mid=line.strip()
    if not mid or mid.lower().startswith("available") or mid.startswith("-"):continue
    mid=mid.lstrip("* ").split()[0] if mid.startswith("*") else mid
    if mid and mid not in seen:out.append({"id":mid,"label":mid,"hint":"agy models"});seen.add(mid)
  except Exception:pass
 live=bool(out)
 for m in FALLBACK_MODELS:
  if m["id"] not in seen:out.append(m);seen.add(m["id"])
 if live:
  try:json.dump({"t":time.time(),"models":out},open(MODELS_CACHE,"w",encoding="utf-8"))
  except Exception:pass
 return out
def usage():
 exe=resolve();ok=installed() and signed_in()
 return {"provider":"google","ok":ok,"logged_in":signed_in(),"installed":installed(),"cli":exe or "","email":email(),"plan":"Google · Antigravity" if signed_in() else "","tier":"agy" if exe else "missing","bars":[],"models":models(),"error":(None if ok else ("not signed in — run: agy  (pick Google OAuth)" if installed() else "install Antigravity CLI: irm https://antigravity.google/cli/install.ps1 | iex")),"note":"Uses agy (Antigravity CLI) with Google OAuth — not Gemini CLI (blocked for individuals)."}
def _print_timeout_arg(timeout):
 to=max(30,int(timeout or 300))
 m,s=divmod(to,60)
 return f"{m}m{s}s" if m else f"{s}s"
def _classify_blob(blob):
 low=(blob or "").lower()
 if any(k in low for k in ("rate limit","rate_limit","quota","429","resource_exhausted","resource exhausted","too many requests","usage limit","limit exceeded","exhausted your","daily limit","rpm","tpm")):return "rate"
 if any(k in low for k in ("not signed","oauth","unauthorized","401","login required","authentication","auth failed","invalid_grant")):return "auth"
 if any(k in low for k in ("not found","not installed","agy not found","no such file","command not found")):return "missing"
 if any(k in low for k in ("timed out","timeout","deadline")):return "timeout"
 if any(k in low for k in ("permission","approval","waiting for","interactive")):return "permission"
 return ""
def _tag(kind,msg):
 m=(msg or "").strip()
 if kind=="rate":return "[google rate-limit] "+(m or "quota/rate exhausted — cool down, then retry")
 if kind=="auth":return "[google auth] "+(m or "not signed in — run: agy  (Google OAuth)")
 if kind=="missing":return "[google missing] "+(m or "agy not found — install Antigravity CLI")
 if kind=="timeout":return "[google timeout] "+(m or "print-timeout")
 if kind=="permission":return "[google error] "+(m or "blocked on permission prompt — headless needs skip-permissions")
 return "[google error] "+(m or "unknown")
def ask(prompt,model="",bypass=True,cont=False,timeout=300,proc_sink=None,cwd=None,effort="",session=None,sid_sink=None):
 exe=resolve()
 if not exe:return _tag("missing","install Antigravity CLI (https://antigravity.google/cli)")
 if not signed_in():return _tag("auth","open a terminal and run: agy  (choose Google OAuth)")
 # timeout=0 means the room's wall-clock cap is OFF — it must not collapse to the old 300s
 # default, which quietly killed long judge turns while every other seat ran uncapped.
 to=int(timeout or 0)
 to=max(30,to) if to>0 else 3600
 body=str(prompt or "")
 tmp=None
 try:
  # Huge -p argv blows past Windows limits and also stalls agy; point at a file instead.
  if len(body)>2800:
   import tempfile
   fd,tmp=tempfile.mkstemp(prefix="braid_agy_",suffix=".txt");os.close(fd)
   open(tmp,"w",encoding="utf-8").write(body)
   body=("Read the UTF-8 task file at this absolute path and complete it fully. "
    "Reply with only your answer text (no meta about the file):\n"+tmp)
  cmd=[exe,"-p",body,"--print-timeout",_print_timeout_arg(to),"--output-format","json"]
  if cwd:cmd+=["--add-dir",cwd]
  if effort in ("low","medium","high") and not str(model or "").rstrip("-").endswith(("-low","-medium","-high")):cmd+=["--effort",effort]
  # Always non-interactive: plan mode without skip-permissions waits forever with no TTY.
  if bypass:cmd+=["--dangerously-skip-permissions","--mode","accept-edits"]
  else:cmd+=["--dangerously-skip-permissions","--mode","plan"]
  if session:cmd+=["--conversation",session]
  if model:cmd+=["--model",model]
  try:
   p=_popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,cwd=cwd or os.getcwd(),text=True,encoding="utf-8",errors="replace")
   if proc_sink:proc_sink(p)
   out,err=p.communicate(timeout=to+15)
  except subprocess.TimeoutExpired:
   try:
    if os.name=="nt":_run(["taskkill","/PID",str(p.pid),"/T","/F"],capture_output=True,timeout=15)
    else:p.kill()
   except Exception:
    try:p.kill()
    except Exception:pass
   return _tag("timeout","after "+str(to)+"s")
  except Exception as e:
   kind=_classify_blob(str(e))
   return _tag(kind or "error",str(e)[:240])
  text=(out or "").strip();err_s=(err or "").strip()
  if text:
   try:
    d=json.loads(text)
    cid=str(d.get("conversation_id") or "")
    if cid and sid_sink:
     try:sid_sink(cid)
     except Exception:pass
    resp=(d.get("response") or "").strip()
    if resp:return resp
    st=str(d.get("status") or d.get("error") or d.get("message") or "")
    blob=st+" "+err_s+" "+text[:400]
    kind=_classify_blob(blob)
    if kind:return _tag(kind,st or err_s or text[:200])
    if st.upper() not in ("","SUCCESS"):return _tag("error",st+" "+err_s[:160])
   except ValueError:
    kind=_classify_blob(text+" "+err_s)
    if kind:return _tag(kind,text[:240])
    return text
  kind=_classify_blob(err_s)
  return _tag(kind or "error",err_s or "no output")
 finally:
  if tmp:
   try:os.remove(tmp)
   except Exception:pass
