"""Licensing, without a back door.

A key is issued by the license server when Stripe reports a payment. The server
returns a SIGNED entitlement bound to the key and to this machine; Braid ships only
the Ed25519 public key, so the cached entitlement on disk can be read but not forged.

There is deliberately no offline "checksum" key format. The previous one accepted any
key matching an algorithm that shipped inside the app - `BRAID-FREE123452` unlocked
the product permanently, and revalidate() short-circuited on it so the server was
never consulted again.
"""
import os,json,time,hashlib,socket,uuid,urllib.request,urllib.error
import delve_providers as PV
import delve_crypto as CR
TRIAL_DAYS=int(os.environ.get("BRAID_TRIAL_DAYS","14"))
RECHECK_S=int(os.environ.get("BRAID_RECHECK_S","43200"))     # try the server twice a day
SERVER=(os.environ.get("BRAID_LICENSE_URL") or "").rstrip("/")
PUBKEY=(os.environ.get("BRAID_LICENSE_PUBKEY") or "").strip()
try:
    import delve_billing as _BB
    PRICE="$%g/month"%_BB.TIERS["beta"]["monthly"]
    LIST_PRICE="$%g/month"%_BB.LIST_PRICE
    BETA=_BB.BETA
except Exception:
    PRICE="$10/month";LIST_PRICE="$20/month";BETA=True
def _path():return os.path.join(PV._store_dir(),"braid_license.json")
def _load():
    try:return json.load(open(_path(),encoding="utf-8")) or {}
    except Exception:return {}
def _save(d):
    try:
        with open(_path(),"w",encoding="utf-8") as f:json.dump(d,f,indent=1)
        if os.name!="nt":os.chmod(_path(),0o600)
    except Exception:pass
    return d
def _cfg():
    """Server URL and public key may also come from Braid's config, so pointing at a
    different license service does not need a rebuild."""
    try:
        import delve
        c=delve.load_cfg()
        return ((c.get("license_url") or SERVER or "").rstrip("/"),
                (c.get("license_pubkey") or PUBKEY or "").strip())
    except Exception:
        return SERVER,PUBKEY
def machine_id():
    raw=(socket.gethostname()+"|"+str(uuid.getnode())).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()[:24]
def machine_name():
    try:return socket.gethostname()[:60] or "this computer"
    except Exception:return "this computer"
def key_fp(key):
    """What the server signs over - never the key itself, so a leaked entitlement
    file does not hand anyone a working key."""
    return hashlib.sha256(("braid|"+(key or "").strip()).encode("utf-8")).hexdigest()[:32]
def _post(url,payload,timeout=15):
    d=json.dumps(payload).encode("utf-8")
    req=urllib.request.Request(url,data=d,headers={"Accept":"application/json",
        "Content-Type":"application/json","User-Agent":"Braid/1.0"},method="POST")
    with urllib.request.urlopen(req,timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8","replace") or "{}")
# ------------------------------------------------------------- entitlement ---
def check_ent(ent_json,sig_hex,key,pub):
    """An entitlement counts only if the signature is real, it names THIS key and
    THIS machine, and it has not expired."""
    if not (ent_json and sig_hex and pub):return None,"no signed entitlement"
    raw=ent_json.encode("utf-8") if isinstance(ent_json,str) else ent_json
    if not CR.verify_hex(pub,raw,sig_hex):
        return None,"the entitlement signature does not check out"
    try:e=json.loads(ent_json)
    except Exception:return None,"the entitlement is not readable"
    if e.get("k")!=key_fp(key):return None,"that entitlement belongs to a different key"
    if e.get("m") and e.get("m")!=machine_id():return None,"that entitlement was issued to another computer"
    if float(e.get("exp") or 0)<=time.time():return None,"the entitlement has expired"
    return e,""
def first_run():
    d=_load()
    if not d.get("first_seen"):
        d["first_seen"]=time.time();_save(d)
    return d["first_seen"]
def trial_left():
    return max(0.0,round((first_run()+TRIAL_DAYS*86400-time.time())/86400.0,2))
def activate(key="",bootstrap=""):
    key=(key or "").strip();boot=(bootstrap or "").strip()
    if not key and not boot:return {"ok":False,"error":"paste your license key first"}
    url,pub=_cfg()
    if not url or not pub:
        return {"ok":False,"error":"no license server configured yet — set license_url and license_pubkey"}
    d=_load()
    body={"machine":machine_id(),"name":machine_name()}
    if boot:body["bootstrap"]=boot
    if key:body["key"]=key
    try:
        j=_post(url+"/activate",body)
    except Exception as e:
        return {"ok":False,"error":"could not reach the license server ("+str(e)[:90]+")"}
    if not j.get("ok"):
        return {"ok":False,"error":str(j.get("error") or "that key was refused")[:180]}
    use_key=(j.get("key") or key or "").strip()
    if not use_key:return {"ok":False,"error":"activation succeeded but no key was returned"}
    ent,why=check_ent(j.get("ent"),j.get("sig"),use_key,pub)
    if not ent:return {"ok":False,"error":"the server's answer did not verify — "+why}
    d.update(key=use_key,ent=j.get("ent"),sig=j.get("sig"),checked=time.time(),last_error="",bootstrap_used=bool(boot))
    _save(d)
    return {"ok":True,"status":"active","tier":ent.get("tier") or "beta",
            "until":ent.get("exp"),"source":"braid"}
def revalidate(force=False):
    d=_load();key=d.get("key")
    if not key:return d
    if not force and (time.time()-float(d.get("checked") or 0))<RECHECK_S:return d
    url,_=_cfg()
    if not url:return d
    try:
        j=_post(url+"/verify",{"key":key,"machine":machine_id()},timeout=8)
        if j.get("ok") and j.get("ent"):
            d["ent"]=j["ent"];d["sig"]=j.get("sig") or "";d["checked"]=time.time();d["last_error"]=""
        elif j.get("revoked"):
            # the server says this key is gone - stop honouring the cached entitlement
            d.pop("ent",None);d.pop("sig",None);d["last_error"]="this license was revoked"
        else:
            d["last_error"]=str(j.get("error") or "")[:120]
    except Exception as e:
        d["last_error"]=str(e)[:120]      # offline: the cached entitlement stands until it expires
    return _save(d)
def deactivate():
    d=_load();key=d.get("key");url,_=_cfg()
    if key and url:
        try:_post(url+"/deactivate",{"key":key,"machine":machine_id()},timeout=8)
        except Exception:pass
    for k in ("key","ent","sig","checked","last_error"):d.pop(k,None)
    _save(d);return {"ok":True}
def status(force=False):
    d=revalidate(force) if _load().get("key") else _load()
    first_run()
    left=trial_left()
    url,pub=_cfg()
    ent,why=check_ent(d.get("ent"),d.get("sig"),d.get("key"),pub) if d.get("key") else (None,"")
    lic=bool(ent)
    out={"licensed":bool(lic),
         "state":("active" if lic else ("trial" if left>0 else "expired")),
         "trial_days_left":left,"trial_days":TRIAL_DAYS,"price":PRICE,"list_price":LIST_PRICE,
         "beta":BETA,"machine":machine_name(),"has_key":bool(d.get("key")),
         "tier":(ent or {}).get("tier") or "","until":(ent or {}).get("exp") or 0,
         "source":"braid" if lic else "","configured":bool(url and pub),
         "last_error":d.get("last_error") or (why if d.get("key") and not lic else "")}
    if not out["licensed"] and left>0:out["licensed"]=True
    out["key_masked"]=("••••-"+str(d.get("key"))[-5:]) if d.get("key") else ""
    return out
def allowed():
    s=status()
    return bool(s.get("licensed")),s
