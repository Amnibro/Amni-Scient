"""How full each seat's CLI session is, in that model's OWN context window.

A pinned CLI session re-loads its whole conversation on every turn, so it grows without
limit until something drops the pin. The old rule was "mint a fresh session every 2 turns",
which is blind in both directions: two turns of a 300-word chat throws away a session that
cost 27k cache-creation tokens to build, and two turns of a tool-heavy build can already be
past half the window.

The rule here is a FRACTION of the model's real window, so it means the same thing on a
200k Claude session and a 1M Gemini one.

Windows come from models.dev (`limit.context`), which Braid already fetches daily for the
model lists - not from a table in this file that goes stale the week a model ships. FALLBACK
is only for the offline case and for seats models.dev does not carry.
"""
import re
DEFAULT_PCT=0.20
FALLBACK={"Claude":200000,"Grok":256000,"Google":1000000,"OpenAI":400000,
 "Copilot":128000,"Cursor":200000,"OpenCode":200000,"Adam":32768}
PROVIDER={"Claude":"anthropic","Grok":"xai","Google":"google","OpenAI":"openai",
 "Copilot":"github-copilot","Cursor":"anthropic","OpenCode":"anthropic"}
FLOOR=8000
def _norm(m):
    return re.sub(r'[^a-z0-9.\-]','',str(m or "").strip().lower())
def window(seat,model=""):
    """Tokens this seat's model can hold. models.dev first, exact id then longest prefix."""
    seat=str(seat or "");mid=_norm(model)
    try:
        import delve_models as DM
        rows=DM.modelsdev_list(PROVIDER.get(seat,""),fast=True) or []
        if mid:
            for r in rows:
                if _norm(r.get("id"))==mid and int(r.get("ctx") or 0)>0:return int(r["ctx"])
            best=0
            for r in rows:
                rid=_norm(r.get("id"))
                if rid and (mid.startswith(rid) or rid.startswith(mid)) and int(r.get("ctx") or 0)>0:
                    if len(rid)>best:best=len(rid);hit=int(r["ctx"])
            if best:return hit
        wins=[int(r.get("ctx") or 0) for r in rows if int(r.get("ctx") or 0)>0]
        if wins:return max(wins)
    except Exception:pass
    return int(FALLBACK.get(seat,200000))
def from_usage(u):
    """Everything the model had to hold for that call. cache_read is NOT free context - it is
    the conversation, served from cache; leaving it out reports a 90k session as 3k."""
    if not isinstance(u,dict):return 0
    def g(*k):
        for x in k:
            try:
                v=u.get(x)
                if v is not None:return int(v)
            except Exception:pass
        return 0
    tot=g("total_tokens","total")
    if tot:return tot
    return (g("input_tokens","prompt_tokens","input")+g("cache_creation_input_tokens","cache_creation")
     +g("cache_read_input_tokens","cache_read")+g("output_tokens","completion_tokens","output"))
def est(chars):
    """~4 chars a token. Only used for seats that report no usage at all; it is a floor for
    the refresh decision, never a billing number."""
    try:return max(0,int(chars)//4)
    except Exception:return 0
def pct(used,win):
    try:return (float(used)/float(win)) if win else 0.0
    except Exception:return 0.0
def _k(n):
    n=int(n or 0)
    return (str(round(n/1000000.0,2)).rstrip("0").rstrip(".")+"M") if n>=1000000 else \
           ((str(round(n/1000.0,1)).rstrip("0").rstrip(".")+"k") if n>=1000 else str(n))
def fmt(used,win):
    """`12.4k / 200k ctx · 6%` - the number, the budget and the fraction, because any one of
    the three alone is unreadable across a 200k and a 1M seat."""
    p=pct(used,win)
    return _k(used)+" / "+_k(win)+" ctx · "+str(int(round(p*100)))+"%"
def should_refresh(used,win,limit=DEFAULT_PCT):
    """True once the session has grown past the share of the window we are willing to re-send
    every turn. FLOOR stops a tiny-window seat refreshing on its own system prompt."""
    try:limit=float(limit)
    except Exception:limit=DEFAULT_PCT
    if limit<=0:return False
    if limit>=1:return False
    return int(used)>=max(FLOOR,int(float(win)*limit))
