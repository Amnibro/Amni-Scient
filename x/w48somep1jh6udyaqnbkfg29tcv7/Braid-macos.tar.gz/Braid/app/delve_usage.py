import json,os,re,sqlite3,subprocess,time,urllib.request,urllib.error,urllib.parse
from datetime import datetime,timezone
import re as _re
try:
 from delve_proc import run as _run,popen as _popen,check_output as _co
except Exception:
 from subprocess import run as _run,Popen as _popen,check_output as _co
_DEFUNCT=_re.compile(r"^(gpt-[34](?![0-9])|gpt-4o|o[134](-|$)|davinci|curie|babbage|text-|claude-[123](?![0-9.])|claude-instant|claude-3|claude-2|gemini-1|gemini-2\.0|gemini-exp|grok-[123](?![0-9.])|grok-beta|palm|bard)",_re.I)
def defunct(mid):
 """Provider caches and old session files keep retired ids alive forever - a model list is
 only useful if what it offers still answers. Deny-list the known-dead families."""
 return bool(_DEFUNCT.match(str(mid or "").strip()))
def prune(models):
 return [m for m in (models or []) if not defunct((m or {}).get("id"))]
CLAUDE_MODELS=[
{"id":"claude-fable-5","label":"Fable 5","hint":"latest Mythos-class / Claude 5"},
{"id":"claude-fable-5[1m]","label":"Fable 5 · 1M context","hint":"long context"},
{"id":"claude-opus-5","label":"Opus 5","hint":"Claude 5 family"},
{"id":"claude-opus-5[1m]","label":"Opus 5 · 1M context","hint":"long context"},
{"id":"claude-opus-4-8","label":"Opus 4.8","hint":"previous flagship"},
{"id":"claude-sonnet-5","label":"Sonnet 5","hint":"fast daily driver"},
{"id":"claude-haiku-4-5","label":"Haiku 4.5","hint":"cheapest / fastest"},
]
_ALIAS_FAMS={"fable","opus","sonnet","haiku"}
def _dedupe_claude(models):
 out=[];seen=set()
 for m in models or []:
  i=str((m or {}).get("id") or "").strip()
  if not i:continue
  base=re.sub(r'\[1m\]$','',i)
  if base.lower() in _ALIAS_FAMS and any(base.lower() in str(x.get("id","")) for x in models if "-" in str(x.get("id",""))):continue
  if i in seen:continue
  seen.add(i)
  lab=str(m.get("label") or "").strip() or i
  if i!=base and "1M" not in lab:lab=lab.replace("[1m]","").strip()+" · 1M context"
  d={"id":i,"label":lab}
  if m.get("hint"):d["hint"]=m["hint"]
  out.append(d)
 return out
def _read_json(p,default=None):
 try:return json.load(open(p,encoding="utf-8"))
 except Exception:return default if default is not None else {}
def _get(url,headers,timeout=12):
 req=urllib.request.Request(url,headers=headers,method="GET")
 with urllib.request.urlopen(req,timeout=timeout) as r:return r.status,json.loads(r.read().decode("utf-8","replace") or "{}")
def _claude_oauth():
 p=os.path.expanduser(os.path.join("~",".claude",".credentials.json"))
 return (_read_json(p).get("claudeAiOauth") or {}) if os.path.exists(p) else {}
def _claude_account():
 p=os.path.expanduser(os.path.join("~",".claude.json"))
 d=_read_json(p) if os.path.exists(p) else {}
 oa=d.get("oauthAccount") or {}
 extras=d.get("additionalModelOptionsCache") or []
 return oa,extras
def claude_models():
 oa,extras=_claude_account()
 out=list(CLAUDE_MODELS)
 seen={m["id"] for m in out}
 for e in extras:
  vid=(e.get("value") or "").strip();lab=(e.get("label") or vid).strip()
  if vid and vid not in seen:out.append({"id":vid,"label":lab or vid,"hint":(e.get("description") or "")[:80]});seen.add(vid)
 settings=_read_json(os.path.expanduser(os.path.join("~",".claude","settings.json")),{})
 sm=(settings.get("model") or "").strip()
 if sm and sm not in seen:out.insert(0,{"id":sm,"label":sm+" · settings","hint":"from ~/.claude/settings.json"});seen.add(sm)
 return prune(_dedupe_claude(out))
def claude_usage():
 oauth=_claude_oauth();tok=oauth.get("accessToken") or ""
 acct,_=_claude_account()
 base={"provider":"claude","ok":False,"logged_in":bool(tok),"email":acct.get("emailAddress") or "","plan":oauth.get("subscriptionType") or acct.get("organizationType") or "","tier":oauth.get("rateLimitTier") or acct.get("organizationRateLimitTier") or "","bars":[],"limits":[],"extra":None,"fetched_at":None,"error":None}
 if not tok:base["error"]="not logged in (run claude auth login)";return base
 exp=oauth.get("expiresAt") or 0
 if exp and exp<int(time.time()*1000)-5000:base["error"]="oauth token expired — open Claude Code once to refresh";base["logged_in"]=True;return base
 try:
  st,data=_get("https://api.anthropic.com/api/oauth/usage",{"Authorization":"Bearer "+tok,"anthropic-beta":"oauth-2025-04-20","User-Agent":"Amni-Delve/1.4","Accept":"application/json"})
 except urllib.error.HTTPError as e:
  base["error"]="HTTP "+str(e.code);return base
 except Exception as e:
  base["error"]=str(e)[:160];return base
 bars=[]
 for key,label in (("five_hour","5-hour"),("seven_day","7-day")):
  b=data.get(key) or {}
  if not b:continue
  util=b.get("utilization");util=float(util) if util is not None else None
  bars.append({"id":key,"label":label,"used_pct":util,"remaining_pct":(None if util is None else max(0.0,100.0-util)),"resets_at":b.get("resets_at"),"severity":_sev(util)})
 for lim in (data.get("limits") or []):
  pct=lim.get("percent");scope=lim.get("scope") or {};model=((scope.get("model") or {}).get("display_name") if isinstance(scope,dict) else None)
  bars.append({"id":str(lim.get("kind") or "limit"),"label":(str(lim.get("kind") or "limit")+((" · "+model) if model else "")),"used_pct":float(pct) if pct is not None else None,"remaining_pct":(None if pct is None else max(0.0,100.0-float(pct))),"resets_at":lim.get("resets_at"),"severity":lim.get("severity") or _sev(pct)})
 extra=data.get("extra_usage") or data.get("spend")
 base.update({"ok":True,"bars":bars,"limits":data.get("limits") or [],"extra":extra,"fetched_at":datetime.now(timezone.utc).isoformat(),"raw_keys":list(data.keys())})
 return base
def _sev(util):
 if util is None:return "unknown"
 u=float(util)
 return "critical" if u>=90 else ("warning" if u>=70 else "normal")
def _grok_auth():
 p=os.path.expanduser(os.path.join("~",".grok","auth.json"))
 d=_read_json(p) if os.path.exists(p) else {}
 if not d:return {}
 return next(iter(d.values())) if isinstance(d,dict) else {}
def grok_models(fast=False):
 out=[];cache=os.path.expanduser(os.path.join("~",".grok","models_cache.json"))
 mc=_read_json(cache) if os.path.exists(cache) else {}
 models=mc.get("models") or {}
 for mid,meta in models.items():
  info=(meta.get("info") if isinstance(meta,dict) else None) or (meta if isinstance(meta,dict) else {})
  out.append({"id":mid,"label":info.get("name") or mid,"hint":(info.get("description") or "")[:80],"default":mid=="grok-4.6"})
 if out:return prune(out) or out[:1]
 if fast:return [{"id":"grok-4.6","label":"Grok 4.6","hint":"subscription default"}]
 auth=_grok_auth();tok=auth.get("key") or ""
 if tok:
  try:
   st,data=_get("https://cli-chat-proxy.grok.com/v1/models",{"Authorization":"Bearer "+tok,"User-Agent":"Amni-Delve/1.4","Accept":"application/json"},timeout=6)
   for m in (data.get("data") or []):
    mid=m.get("id") or m.get("model");out.append({"id":mid,"label":m.get("name") or mid,"hint":(m.get("description") or "")[:80]})
  except Exception:pass
 if not out:
  try:
   r=_run(["grok","models"],capture_output=True,text=True,timeout=6)
   for line in (r.stdout or "").splitlines():
    s=line.strip()
    if s.startswith("*"):out.append({"id":s.lstrip("* ").split()[0],"label":s.lstrip("* ").split()[0],"hint":"from grok models"})
  except Exception:pass
 return prune(out) or [{"id":"grok-4.6","label":"Grok 4.6","hint":"subscription default"}]
def _grok_local_usage():
 db=os.path.expanduser(os.path.join("~",".grok","grok.db"))
 if not os.path.exists(db):return {"events":0,"tokens":0,"cost_usd":0.0,"by_model":[]}
 try:
  con=sqlite3.connect(db);cur=con.cursor()
  tot=cur.execute("SELECT COUNT(*),COALESCE(SUM(total_tokens),0),COALESCE(SUM(cost_micros),0) FROM usage_events").fetchone()
  by=cur.execute("SELECT model,COUNT(*),COALESCE(SUM(total_tokens),0),COALESCE(SUM(cost_micros),0) FROM usage_events GROUP BY model ORDER BY 3 DESC").fetchall()
  recent=cur.execute("SELECT model,total_tokens,created_at FROM usage_events ORDER BY id DESC LIMIT 5").fetchall()
  con.close()
  return {"events":int(tot[0] or 0),"tokens":int(tot[1] or 0),"cost_usd":round((tot[2] or 0)/1_000_000.0,4),"by_model":[{"model":m,"events":int(n),"tokens":int(t),"cost_usd":round((c or 0)/1_000_000.0,4)} for m,n,t,c in by],"recent":[{"model":m,"tokens":int(t or 0),"at":a} for m,t,a in recent]}
 except Exception as e:return {"events":0,"tokens":0,"cost_usd":0.0,"error":str(e)[:120]}
def grok_usage():
 auth=_grok_auth();email=auth.get("email") or "";logged=bool(auth.get("key"))
 local=_grok_local_usage()
 return {"provider":"grok","ok":logged,"logged_in":logged,"email":email,"plan":"grok.com" if logged else "","tier":auth.get("auth_mode") or "","bars":[],"local":local,"fetched_at":datetime.now(timezone.utc).isoformat(),"error":(None if logged else "not logged in (run grok login)"),"note":"Live plan % not exposed by Grok Build API yet — showing login + local token ledger from ~/.grok/grok.db"}
def google_models(fast=False):
 try:
  import delve_google as G,delve_models as DM
  md=DM.modelsdev_list("google",fast=bool(fast))
  cli=prune(G.models(fast=bool(fast)))
  return DM._merge(md,cli) if md else cli
 except Exception:
  return [{"id":"gemini-3.1-pro-high","label":"Gemini 3.1 Pro · High","hint":"Antigravity"}]
def google_usage():
 try:
  import delve_google as G
  u=G.usage();u["fetched_at"]=datetime.now(timezone.utc).isoformat();return u
 except Exception as e:
  return {"provider":"google","ok":False,"logged_in":False,"error":str(e)[:160],"bars":[]}
def snapshot(usage=True,fast=False):
 off={"ok":False,"off":True,"error":"usage checks are off — turn them on under Controls → Privacy"}
 return {"claude":{"models":claude_models(),"usage":claude_usage() if usage and not fast else off},"grok":{"models":grok_models(fast=fast),"usage":grok_usage() if usage and not fast else off},"google":{"models":google_models(fast=fast),"usage":google_usage() if usage and not fast else off},"fetched_at":datetime.now(timezone.utc).isoformat(),"usage_off":not usage,"fast":bool(fast)}
