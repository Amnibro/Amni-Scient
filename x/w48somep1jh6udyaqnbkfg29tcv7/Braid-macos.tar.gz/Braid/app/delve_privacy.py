"""Per-CLI privacy: read what each seat's own config REALLY says, and write the documented
opt-outs. The env Braid injects (delve.PRIVACY_ENV) covers the launch; this covers the tools'
persistent settings, which survive outside Braid too. Everything reported here is read off
disk at call time - nothing is asserted that was not just observed."""
import os,json,time,shutil

def _read_json(p):
    try:return json.load(open(p,encoding="utf-8"))
    except Exception:return None

def _claude():
    p=os.path.expanduser(os.path.join("~",".claude","settings.json"))
    st=_read_json(p) or {}
    env=st.get("env") or {}
    found={k:env.get(k) for k in ("DISABLE_TELEMETRY","DISABLE_ERROR_REPORTING",
        "CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC","DISABLE_BUG_COMMAND") if k in env}
    return {"seat":"Claude","config":p,"exists":os.path.isfile(p),"found":found,
        "hardened":all(str(env.get(k,""))=="1" for k in ("DISABLE_TELEMETRY","DISABLE_ERROR_REPORTING")),
        "can_harden":True,
        "note":"telemetry=Statsig, errors=Sentry; both off via the env block. Prompt training for consumer accounts is controlled at claude.ai -> Settings -> Privacy."}

def _gemini():
    p=os.path.expanduser(os.path.join("~",".gemini","settings.json"))
    st=_read_json(p) or {}
    v=st.get("usageStatisticsEnabled")
    return {"seat":"Google","config":p,"exists":os.path.isfile(p),
        "found":({"usageStatisticsEnabled":v} if v is not None else {}),
        "hardened":v is False,"can_harden":True,
        "note":"usageStatisticsEnabled:false stops usage stats. For free personal Google accounts, prompt use for training is an ACCOUNT setting (Google account data controls), not a CLI flag."}

def _grok():
    d=os.path.expanduser(os.path.join("~",".grok"))
    found={}
    try:
        for fn in os.listdir(d):
            if not fn.endswith(".json"):continue
            st=_read_json(os.path.join(d,fn)) or {}
            for k,v in (st.items() if isinstance(st,dict) else []):
                if any(t in k.lower() for t in ("telemetry","analytic","tracking","statistic")):
                    found[fn+":"+k]=v
    except Exception:pass
    return {"seat":"Grok","config":d,"exists":os.path.isdir(d),"found":found,
        "hardened":None,"can_harden":False,
        "note":"no documented CLI telemetry switch found in its config; Braid's DO_NOT_TRACK/OTEL_SDK_DISABLED env applies. Training/retention is an xAI account data-controls setting."}

def _codex():
    p=os.path.expanduser(os.path.join("~",".codex","config.toml"))
    found={}
    try:
        for ln in open(p,encoding="utf-8"):
            l=ln.strip()
            if any(t in l.lower() for t in ("telemetry","analytics","otel","disable_response_storage")) and "=" in l:
                k,_,v=l.partition("=");found[k.strip()]=v.strip()
    except Exception:pass
    return {"seat":"OpenAI","config":p,"exists":os.path.isfile(p),"found":found,
        "hardened":None,"can_harden":False,
        "note":"OTEL export is off unless configured; OTEL_SDK_DISABLED=1 backstops it. Training opt-out is the OpenAI account data-controls setting."}

def report():
    rows=[_claude(),_gemini(),_grok(),_codex()]
    rows.append({"seat":"Adam","config":"","exists":True,"found":{},"hardened":True,"can_harden":False,
        "note":"runs entirely on this machine - no telemetry to disable."})
    return rows

def _backup(p):
    if os.path.isfile(p):
        try:shutil.copy2(p,p+".braid_"+time.strftime("%Y%m%d_%H%M%S")+".bak")
        except Exception:pass

def harden():
    """Write the documented opt-outs the CLIs themselves honour. Backs up first, merges -
    never clobbers unrelated settings."""
    out=[]
    p=os.path.expanduser(os.path.join("~",".claude","settings.json"))
    st=_read_json(p) or {}
    env=dict(st.get("env") or {})
    want={"DISABLE_TELEMETRY":"1","DISABLE_ERROR_REPORTING":"1",
          "CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC":"1","DISABLE_BUG_COMMAND":"1"}
    if any(str(env.get(k))!=v for k,v in want.items()):
        _backup(p);env.update(want);st["env"]=env
        try:
            os.makedirs(os.path.dirname(p),exist_ok=True)
            json.dump(st,open(p,"w",encoding="utf-8"),indent=2)
            out.append({"seat":"Claude","wrote":p,"set":want})
        except Exception as e:out.append({"seat":"Claude","error":str(e)[:120]})
    else:out.append({"seat":"Claude","already":True})
    p=os.path.expanduser(os.path.join("~",".gemini","settings.json"))
    st=_read_json(p) or {}
    if st.get("usageStatisticsEnabled") is not False:
        _backup(p);st["usageStatisticsEnabled"]=False
        try:
            os.makedirs(os.path.dirname(p),exist_ok=True)
            json.dump(st,open(p,"w",encoding="utf-8"),indent=2)
            out.append({"seat":"Google","wrote":p,"set":{"usageStatisticsEnabled":False}})
        except Exception as e:out.append({"seat":"Google","error":str(e)[:120]})
    else:out.append({"seat":"Google","already":True})
    return out
