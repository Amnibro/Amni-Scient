import os,sys,re,json,time,shutil,urllib.parse,urllib.request,urllib.error
KINDS=("cli","anthropic","openai","google","ollama","adam")
_ANTHROPIC_MODELS=["claude-opus-5","claude-sonnet-5","claude-haiku-4-5","claude-opus-4-8"]
_OPENAI_PRESETS={
 "openai":{"label":"OpenAI","base":"https://api.openai.com/v1","models":["gpt-5.2","gpt-5.2-mini"]},
 "xai":{"label":"xAI (Grok)","base":"https://api.x.ai/v1","models":["grok-4.6","grok-4"]},
 "openrouter":{"label":"OpenRouter","base":"https://openrouter.ai/api/v1","models":[]},
 "lmstudio":{"label":"LM Studio (local)","base":"http://127.0.0.1:1234/v1","models":[]},
 "custom":{"label":"Custom OpenAI-compatible","base":"","models":[]}}
_CLI_SEATS={
 "Claude":{"exe":"claude","label":"Claude Code","hint":"Sign in with your Claude subscription",
  "paths":["~/.local/bin/claude.exe","~/.local/bin/claude","~/AppData/Local/Programs/claude/claude.exe",
   "~/AppData/Roaming/npm/claude.cmd","/usr/local/bin/claude","/opt/homebrew/bin/claude"],
  "get":"claude.com/download"},
 "Grok":{"exe":"grok","label":"Grok CLI","hint":"Sign in with your xAI account",
  "paths":["~/.grok/bin/grok.exe","~/.grok/bin/grok","~/AppData/Roaming/npm/grok.cmd",
   "/usr/local/bin/grok","/opt/homebrew/bin/grok"],
  "get":"npm i -g @vibe-kit/grok-cli"},
 "Google":{"exe":"agy","label":"Antigravity","hint":"Sign in with your Google account",
  "paths":["~/AppData/Local/agy/bin/agy.exe","~/.agy/bin/agy","/usr/local/bin/agy","/opt/homebrew/bin/agy"],
  "get":"antigravity.google"},
 "OpenAI":{"exe":"codex","label":"Codex CLI","hint":"Sign in with your ChatGPT subscription",
  "paths":["~/.codex/bin/codex.exe","~/AppData/Roaming/npm/codex.cmd","~/.local/bin/codex",
   "/usr/local/bin/codex","/opt/homebrew/bin/codex"],
  "get":"npm i -g @openai/codex","argv":["exec","--skip-git-repo-check","{prompt}"]},
 "Copilot":{"exe":"copilot","label":"GitHub Copilot CLI","hint":"Sign in with your GitHub Copilot subscription",
  "paths":["~/AppData/Roaming/npm/copilot.cmd","~/.local/bin/copilot","/usr/local/bin/copilot","/opt/homebrew/bin/copilot"],
  "get":"npm i -g @github/copilot","argv":["-p","{prompt}"]},
 "Cursor":{"exe":"cursor-agent","label":"Cursor CLI",
  # Post-acquisition collision: Grok Build also ships an `agent` binary and wins PATH, so
  # `agent login` opens Grok OAuth. Only the full `cursor-agent` name is unambiguous.
  "hint":"run `cursor-agent login` in a terminal — NOT `agent login` (that opens Grok Build since the Cursor acquisition) — or set CURSOR_API_KEY",
  "paths":["~/AppData/Local/cursor-agent/cursor-agent.cmd","~/.cursor/bin/cursor-agent.exe","~/.local/bin/cursor-agent","/usr/local/bin/cursor-agent","/opt/homebrew/bin/cursor-agent"],
  "get":"cursor.com/cli","argv":["-p","{prompt}"],"login_argv":["login"]},
 "OpenCode":{"exe":"opencode","label":"OpenCode","hint":"Free and model-agnostic — bring any provider",
  "paths":["~/.opencode/bin/opencode.exe","~/AppData/Roaming/npm/opencode.cmd","~/.local/bin/opencode",
   "/usr/local/bin/opencode","/opt/homebrew/bin/opencode"],
  "get":"npm i -g opencode-ai","argv":["run","{prompt}"]}}
SEATS=("Claude","Grok","Google","OpenAI","Copilot","Cursor","OpenCode","Adam")
CORE=("Claude","Grok","Google","Adam")
def _store_dir():
    if os.name=="nt":base=os.environ.get("APPDATA") or os.path.expanduser("~")
    elif sys.platform=="darwin":base=os.path.join(os.path.expanduser("~"),"Library","Application Support")
    else:base=os.environ.get("XDG_CONFIG_HOME") or os.path.join(os.path.expanduser("~"),".config")
    d=os.environ.get("AMNI_DELVE_HOME") or os.path.join(base,"AmniDelve")
    os.makedirs(d,exist_ok=True);return d
def _cred_path():return os.path.join(_store_dir(),"credentials.json")
def _load_creds():
    p=_cred_path()
    if not os.path.isfile(p):return {}
    try:return json.load(open(p,encoding="utf-8")) or {}
    except Exception:return {}
def _save_creds(c):
    p=_cred_path()
    try:
        with open(p,"w",encoding="utf-8") as f:json.dump(c,f,indent=1)
        if os.name!="nt":os.chmod(p,0o600)
    except Exception:pass
    return p
def set_secret(seat,value):
    c=_load_creds()
    v=(value or "").strip()
    c.pop(seat,None) if not v else c.update({seat:{"secret":v,"saved":time.time()}})
    _save_creds(c);return {"ok":True,"seat":seat,"stored":bool(v)}
def _secret(seat,cfg):
    # key_env names an environment variable whose value is shipped to the provider. Config
    # is remote-writable, so an arbitrary name here is "read me any secret in this process".
    env=str((cfg or {}).get("key_env") or "")
    if env and re.match(r"^[A-Z][A-Z0-9_]{0,63}$",env) and os.environ.get(env):return os.environ[env]
    return ((_load_creds().get(seat) or {}).get("secret") or "")
def has_secret(seat,cfg=None):return bool(_secret(seat,cfg))
_LOOPBACK=("127.0.0.1","localhost","::1","[::1]")
def safe_base(base):
    """Is this a URL we are willing to send an API key to?

    `cfg["base"]` for an openai-compatible seat is the address the seat's secret is posted
    to with `Authorization: Bearer`. Provider config is persisted and is writable by a
    paired remote device, so an unvalidated base turns "pick your endpoint" into "mail my
    key anywhere". Rules: https, or plain http ONLY to loopback (LM Studio, Ollama, llama
    .cpp all live there); no credentials in the URL; no query or fragment, because the base
    is concatenated with /chat/completions and a `?` would swallow the path."""
    b=str(base or "").strip()
    if not b:return True,""
    try:
        u=urllib.parse.urlparse(b)
    except Exception:return False,"that endpoint is not a URL"
    host=(u.hostname or "").lower()
    if u.scheme not in ("http","https"):return False,"the endpoint must be an http(s) URL"
    if not host:return False,"that endpoint has no host"
    if u.username or u.password:return False,"put the key in the key field, not in the URL"
    if u.query or u.fragment:return False,"the endpoint must be a plain base URL — no query string"
    if u.scheme=="http" and host not in _LOOPBACK and not host.startswith("127."):
        return False,"plaintext http is only allowed to 127.0.0.1 — a key sent over http can be read in transit"
    return True,""
class _NoRedirect(urllib.request.HTTPRedirectHandler):
    """A 302 from a provider base to another host makes urllib re-send the Authorization
    header to whoever it was pointed at. Nothing legitimate needs it, so it does not happen."""
    def redirect_request(s,req,fp,code,msg,headers,newurl):return None
_OPENER=urllib.request.build_opener(_NoRedirect)
def _which(n):
    return shutil.which(n) or shutil.which(n+".exe") or shutil.which(n+".cmd") or ""
def _find_cli(spec):
    p=_which(spec.get("exe") or "")
    if p:return p,"PATH"
    for cand in (spec.get("paths") or []):
        c=os.path.expandvars(os.path.expanduser(cand))
        if os.path.isfile(c):return c,"known location"
    ev=os.environ.get("DELVE_"+(spec.get("exe") or "").upper()+"_PATH")
    if ev and os.path.isfile(ev):return ev,"environment override"
    return "",""
def _probe(url,timeout=1.5):
    try:
        with urllib.request.urlopen(url,timeout=timeout) as r:return r.status==200
    except Exception:return False
_AUTH_FILES={"Claude":"~/.claude/.credentials.json","OpenAI":"~/.codex/auth.json"}
_NPM_PKGS={"Grok":"@vibe-kit/grok-cli","OpenAI":"@openai/codex","Copilot":"@github/copilot"}
def _spawn_terminal(cmdline):
    import subprocess,sys
    win=os.name=="nt"
    if win:
        subprocess.Popen(["cmd","/k",cmdline],creationflags=getattr(subprocess,"CREATE_NEW_CONSOLE",0))
        return "console"
    if sys.platform=="darwin":
        subprocess.Popen(["osascript","-e",'tell application "Terminal" to activate',"-e",'tell application "Terminal" to do script "'+cmdline.replace('"','\\"')+'"'])
        return "terminal"
    for term in (["x-terminal-emulator","-e"],["gnome-terminal","--"],["konsole","-e"],["xterm","-e"]):
        if shutil.which(term[0]):
            subprocess.Popen(term+["bash","-c",cmdline+"; exec bash"])
            return "terminal"
    raise FileNotFoundError("no terminal emulator found")
def setup_assist(seat,act):
    import subprocess,webbrowser
    spec=_CLI_SEATS.get(seat) or {}
    win=os.name=="nt"
    if act=="install":
        cmd=""
        if seat=="Claude":
            cmd=("powershell -NoProfile -Command \"irm https://claude.ai/install.ps1 | iex\"" if win
                 else "curl -fsSL https://claude.ai/install.sh | bash")
        elif seat in _NPM_PKGS:
            if not shutil.which("npm"):
                webbrowser.open("https://nodejs.org")
                return {"ok":True,"mode":"browser","note":"this seat needs Node.js first — download page opened; press Install again once Node is in"}
            cmd="npm i -g "+_NPM_PKGS[seat]
        elif seat=="Google":
            webbrowser.open("https://antigravity.google")
            return {"ok":True,"mode":"browser","note":"download page opened — run the installer, I am watching for it"}
        else:
            return {"ok":False,"error":"no guided install for "+str(seat)}
        try:
            _spawn_terminal(cmd)
            return {"ok":True,"mode":"console","note":"official installer opened in its own window — let it finish, I am watching for the CLI","cmd":cmd}
        except Exception as e:
            return {"ok":False,"error":"could not open a terminal ("+str(e)[:80]+") — paste this yourself:","cmd":cmd}
    if act=="login":
        p,_=_find_cli(spec)
        if not p:return {"ok":False,"error":"the CLI is not on this machine yet — install first"}
        # login_argv: some CLIs (Cursor) need an explicit `login` subcommand — launching the
        # bare binary drops into the interactive TUI instead of the OAuth flow.
        cmd=('"'+p+'"' if " " in p else p)+"".join(" "+a for a in (spec.get("login_argv") or []))
        try:
            _spawn_terminal(cmd)
            return {"ok":True,"mode":"console","note":"sign-in opened in its own window — approve in the browser it launches, then you can close that window","cmd":cmd}
        except Exception as e:
            return {"ok":False,"error":"could not open a terminal ("+str(e)[:80]+") — run this yourself:","cmd":cmd}
    return {"ok":False,"error":"unknown action"}
def detect():
    out={"cli":{},"ollama":{"up":False,"models":[]},"anthropic_sdk":False,"presets":_OPENAI_PRESETS,
     "anthropic_models":_ANTHROPIC_MODELS,"store":_cred_path()}
    for seat,spec in _CLI_SEATS.items():
        p,how=_find_cli(spec)
        af=_AUTH_FILES.get(seat)
        out["cli"][seat]={"exe":spec["exe"],"label":spec["label"],"hint":spec["hint"],"get":spec.get("get",""),
         "path":p,"installed":bool(p),"found_via":how,"argv":spec.get("argv") or [],
         "authed":(os.path.isfile(os.path.expanduser(af)) if af else None)}
    base=os.environ.get("OLLAMA_HOST") or "http://127.0.0.1:11434"
    if not base.startswith("http"):base="http://"+base
    try:
        with urllib.request.urlopen(base+"/api/tags",timeout=1.5) as r:
            d=json.loads(r.read().decode("utf-8","replace") or "{}")
            out["ollama"]={"up":True,"base":base,"models":[m.get("name") for m in (d.get("models") or []) if m.get("name")]}
    except Exception:out["ollama"]={"up":False,"base":base,"models":[]}
    try:
        import anthropic  # noqa: F401
        out["anthropic_sdk"]=True
    except Exception:out["anthropic_sdk"]=False
    return out
def _post(url,payload,headers,timeout):
    d=json.dumps(payload).encode("utf-8")
    h={"Content-Type":"application/json"};h.update(headers or {})
    req=urllib.request.Request(url,data=d,headers=h,method="POST")
    with _OPENER.open(req,timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8","replace") or "{}")
def _err(e):
    if isinstance(e,urllib.error.HTTPError):
        try:body=e.read().decode("utf-8","replace")[:300]
        except Exception:body=""
        return "HTTP "+str(e.code)+" "+body
    return str(e)[:300]
_ANTHROPIC_MAX={"claude-haiku-4-5":64000}
def _anthropic_cap(model):return _ANTHROPIC_MAX.get(model,128000)
def _sse_text(url,body,headers,timeout):
    d=json.dumps(body).encode("utf-8")
    h={"Content-Type":"application/json","Accept":"text/event-stream"};h.update(headers or {})
    req=urllib.request.Request(url,data=d,headers=h,method="POST")
    parts=[];stop=""
    # Same NoRedirect opener as _post — a 302 would re-send x-api-key to a new host.
    with _OPENER.open(req,timeout=timeout) as r:
        for raw in r:
            line=raw.decode("utf-8","replace").strip()
            if not line.startswith("data:"):continue
            try:ev=json.loads(line[5:].strip() or "{}")
            except Exception:continue
            t=ev.get("type")
            if t=="content_block_delta":
                dl=ev.get("delta") or {}
                if dl.get("type")=="text_delta":parts.append(dl.get("text") or "")
            elif t=="message_delta":stop=((ev.get("delta") or {}).get("stop_reason")) or stop
            elif t=="error":return "[anthropic error] "+str((ev.get("error") or {}).get("message"))[:200]
    if stop=="refusal":return "[refused] the model declined this request"
    return "".join(parts).strip() or "[empty reply]"
def _ask_anthropic(seat,cfg,prompt,system,max_tokens,timeout):
    key=_secret(seat,cfg)
    if not key:return "[no key] add your Anthropic API key for "+seat
    model=(cfg.get("model") or "claude-opus-5").strip()
    mt=min(int(max_tokens or 0) or _anthropic_cap(model),_anthropic_cap(model))
    try:
        import anthropic
    except Exception:
        anthropic=None
    if anthropic is not None:
        try:
            c=anthropic.Anthropic(api_key=key,timeout=float(timeout))
            kw=dict(model=model,max_tokens=mt,messages=[{"role":"user","content":prompt}])
            if system:kw["system"]=system
            with c.messages.stream(**kw) as st:
                r=st.get_final_message()
            if getattr(r,"stop_reason","")=="refusal":
                return "[refused] the model declined this request ("+str(getattr(getattr(r,"stop_details",None),"category","") or "policy")+")"
            return "".join(b.text for b in r.content if getattr(b,"type","")=="text").strip() or "[empty reply]"
        except Exception as e:return "[anthropic error] "+_err(e)
    body={"model":model,"max_tokens":mt,"stream":True,"messages":[{"role":"user","content":prompt}]}
    if system:body["system"]=system
    try:
        return _sse_text("https://api.anthropic.com/v1/messages",body,
         {"x-api-key":key,"anthropic-version":"2023-06-01"},timeout)
    except Exception as e:return "[anthropic error] "+_err(e)
def _ask_openai(seat,cfg,prompt,system,max_tokens,timeout,base=None,key=None):
    key=key if key is not None else _secret(seat,cfg)
    preset=_OPENAI_PRESETS.get(cfg.get("preset") or "custom") or {}
    base=(base or cfg.get("base") or preset.get("base") or "").rstrip("/")
    if not base:return "[not configured] set the API base URL for "+seat
    # Checked at write time too. Checked again here because config on disk predates the
    # check, and this is the line that actually hands the key over.
    ok,why=safe_base(base)
    if not ok:return "[refused] "+why+" — "+seat+" was not called"
    if not key and "127.0.0.1" not in base and "localhost" not in base:return "[no key] add your API key for "+seat
    msgs=([{"role":"system","content":system}] if system else [])+[{"role":"user","content":prompt}]
    _old={"gpt-5":"gpt-5.2","o3":"gpt-5.2","o4-mini":"gpt-5.2-mini","gpt-4o":"gpt-5.2","gpt-4o-mini":"gpt-5.2-mini"}
    _m=(cfg.get("model") or "").strip() or "gpt-5.2"
    body={"model":_old.get(_m,_m),"messages":msgs}
    if max_tokens:body["max_tokens"]=int(max_tokens)
    try:
        az=".azure.com" in base.lower()
        url=base+"/chat/completions"+("?api-version=2024-10-21" if az and "api-version=" not in base else "")
        d=_post(url,body,({"api-key":key} if az and key else ({"Authorization":"Bearer "+key} if key else {})),timeout)
        ch=(d.get("choices") or [{}])[0];m=ch.get("message") or {}
        txt=(m.get("content") or "").strip()
        if txt:return txt
        if ch.get("finish_reason")=="length" or (m.get("reasoning") or "").strip():
            return "[truncated] the model spent its whole budget reasoning — raise max tokens for this seat"
        return "[empty reply]"
    except Exception as e:return "[api error] "+_err(e)
def _ask_google(seat,cfg,prompt,system,max_tokens,timeout):
    key=_secret(seat,cfg)
    if not key:return "[no key] add your Google AI Studio key for "+seat
    model=(cfg.get("model") or "gemini-3.1-pro").strip()
    body={"contents":[{"role":"user","parts":[{"text":prompt}]}]}
    if max_tokens:body["generationConfig"]={"maxOutputTokens":int(max_tokens)}
    if system:body["systemInstruction"]={"parts":[{"text":system}]}
    url="https://generativelanguage.googleapis.com/v1beta/models/"+model+":generateContent"
    try:
        d=_post(url,body,{"x-goog-api-key":key},timeout)
        cands=d.get("candidates") or []
        if not cands:return "[empty reply]"
        parts=((cands[0].get("content") or {}).get("parts") or [])
        return "".join(p.get("text") or "" for p in parts).strip() or "[empty reply]"
    except Exception as e:return "[google error] "+_err(e)
def _ask_ollama(seat,cfg,prompt,system,max_tokens,timeout):
    base=(cfg.get("base") or os.environ.get("OLLAMA_HOST") or "http://127.0.0.1:11434").rstrip("/")
    if not base.startswith("http"):base="http://"+base
    model=(cfg.get("model") or "").strip()
    if not model:
        av=(detect().get("ollama") or {}).get("models") or []
        if not av:return "[no model] Ollama is reachable but has no models pulled — run `ollama pull <name>` first"
        return "[no model] pick an Ollama model for "+seat+" — available: "+", ".join(av[:6])
    return _ask_openai(seat,dict(cfg,model=model),prompt,system,max_tokens,timeout,base=base+"/v1",key="")
def ask(seat,cfg,prompt,system="",max_tokens=None,timeout=None):
    cfg=cfg or {}
    kind=(cfg.get("kind") or "cli").lower()
    mt=int(max_tokens if max_tokens is not None else (cfg.get("max_tokens") or 0))
    to=int(timeout or cfg.get("timeout") or 900)
    if kind=="anthropic":return _ask_anthropic(seat,cfg,prompt,system,mt,to)
    if kind=="openai":return _ask_openai(seat,cfg,prompt,system,mt,to)
    if kind=="google":return _ask_google(seat,cfg,prompt,system,mt,to)
    if kind=="ollama":return _ask_ollama(seat,cfg,prompt,system,mt,to)
    return "[unsupported] seat "+seat+" is configured as '"+kind+"', which this bridge does not call directly"
def test(seat,cfg):
    cfg=cfg or {}
    kind=(cfg.get("kind") or "cli").lower()
    if kind=="off":return {"ok":True,"reply":"off","seat":seat,"kind":kind}
    if kind=="cli":
        spec=_CLI_SEATS.get(seat) or {}
        if not spec:return {"ok":False,"reply":"no sign-in app known for this seat","seat":seat,"kind":kind}
        p,how=_find_cli(spec)
        return ({"ok":True,"reply":"found via "+how,"seat":seat,"kind":kind,"path":p} if p else
                {"ok":False,"reply":"not installed — "+(spec.get("get") or "see vendor"),"seat":seat,"kind":kind})
    if kind=="adam":
        try:
            import urllib.request as _u
            with _u.urlopen("http://"+os.environ.get("ADAM_HOST","127.0.0.1")+":"+os.environ.get("ADAM_PORT","7700")+"/healthz",timeout=4) as r:
                return {"ok":r.status==200,"reply":"Adam is running","seat":seat,"kind":kind}
        except Exception:return {"ok":False,"reply":"Adam is not running — start it from the room","seat":seat,"kind":kind}
    r=ask(seat,cfg,"Reply with exactly: ok","",max_tokens=512,timeout=120)
    bad=r.startswith("[")
    return {"ok":not bad,"reply":r[:200],"seat":seat,"kind":kind}
def public(seat,cfg):
    cfg=dict(cfg or {})
    cfg.pop("secret",None);cfg.pop("key",None);cfg.pop("api_key",None)
    cfg["has_key"]=has_secret(seat,cfg)
    return cfg
