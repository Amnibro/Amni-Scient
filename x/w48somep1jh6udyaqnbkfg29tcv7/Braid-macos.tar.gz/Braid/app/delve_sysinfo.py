import os,sys,re,json,shutil,ctypes,subprocess,platform
try:
 from delve_proc import run as _run,popen as _popen,check_output as _co
except Exception:
 from subprocess import run as _run,Popen as _popen,check_output as _co
_BYTES_PER_W={"q4":0.55,"q5":0.68,"q8":1.06,"fp16":2.0}
_OVERHEAD=1.18
_FALLBACK=[{"id":"adam-3b","label":"Adam 3B (GF17)","family":"Adam","params":3.0,"quant":"q4","first":True,
 "why":"The right first step — small enough that it never fights your machine, and the only seat that keeps working with no internet and no subscription."}]
def _catalog():
    p=os.path.join(os.path.dirname(os.path.abspath(__file__)),"models_catalog.json")
    try:
        d=json.load(open(p,encoding="utf-8"))
        m=[x for x in (d.get("models") or []) if x.get("id") and x.get("params")]
        return m or _FALLBACK
    except Exception:return _FALLBACK
CATALOG=_catalog()
def need_gb(params,quant="q4"):
    return round(params*_BYTES_PER_W.get(quant,0.55)*_OVERHEAD,1)
class _MEMSTAT(ctypes.Structure):
    _fields_=[("dwLength",ctypes.c_ulong),("dwMemoryLoad",ctypes.c_ulong),
     ("ullTotalPhys",ctypes.c_ulonglong),("ullAvailPhys",ctypes.c_ulonglong),
     ("ullTotalPageFile",ctypes.c_ulonglong),("ullAvailPageFile",ctypes.c_ulonglong),
     ("ullTotalVirtual",ctypes.c_ulonglong),("ullAvailVirtual",ctypes.c_ulonglong),
     ("ullAvailExtendedVirtual",ctypes.c_ulonglong)]
def _ram():
    if os.name=="nt":
        try:
            m=_MEMSTAT();m.dwLength=ctypes.sizeof(_MEMSTAT)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
            return round(m.ullTotalPhys/1073741824,1),round(m.ullAvailPhys/1073741824,1)
        except Exception:pass
    try:
        pg=os.sysconf("SC_PHYS_PAGES");sz=os.sysconf("SC_PAGE_SIZE")
        tot=round(pg*sz/1073741824,1)
    except Exception:return 0.0,0.0
    avail=0.0
    try:
        for line in open("/proc/meminfo"):
            if line.startswith("MemAvailable:"):avail=round(int(line.split()[1])*1024/1073741824,1);break
    except Exception:
        try:
            o=_co(["vm_stat"],text=True,timeout=5)
            ps=int(re.search(r'page size of (\d+)',o).group(1))
            pages=sum(int(m.group(1)) for m in re.finditer(r'Pages (?:free|inactive):\s+(\d+)',o))
            avail=round(pages*ps/1073741824,1)
        except Exception:pass
    return tot,avail
def _ps(cmd,timeout=14):
    try:
        r=_run(["powershell","-NoProfile","-Command",cmd],capture_output=True,text=True,
         timeout=timeout,creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
        return r.stdout or ""
    except Exception:return ""
def _gpus_posix():
    gs=[]
    try:
        for line in _co(["nvidia-smi","--query-gpu=name,memory.total","--format=csv,noheader,nounits"],text=True,timeout=10).splitlines():
            if "," not in line:continue
            n,v=line.rsplit(",",1)
            try:gs.append({"name":n.strip(),"vram_gb":round(int(v.strip())/1024,1),"integrated":False})
            except Exception:continue
    except Exception:pass
    if not gs and sys.platform=="darwin":
        try:
            d=json.loads(_co(["system_profiler","SPDisplaysDataType","-json"],text=True,timeout=15))
            for g in (d.get("SPDisplaysDataType") or []):
                n=g.get("sppci_model") or g.get("_name") or ""
                vs=str(g.get("spdisplays_vram") or g.get("spdisplays_vram_shared") or "")
                m=re.search(r'(\d+)',vs);v=float(m.group(1)) if m else 0.0
                if v and "MB" in vs.upper():v=round(v/1024,1)
                if n:gs.append({"name":n,"vram_gb":v,"integrated":"apple" in n.lower()})
        except Exception:pass
    if not gs:
        try:names=[l.split(":",2)[-1].strip() for l in _co(["lspci"],text=True,timeout=8).splitlines() if re.search(r'VGA|3D controller',l)]
        except Exception:names=[]
        import glob as _g
        vr=[]
        for p in sorted(_g.glob("/sys/class/drm/card*/device/mem_info_vram_total")):
            try:vr.append(round(int(open(p).read().strip())/1073741824,1))
            except Exception:continue
        for i,n in enumerate(names or (["GPU"]*len(vr))):
            v=vr[i] if i<len(vr) else 0.0
            gs.append({"name":n,"vram_gb":v,"integrated":bool(re.search(r'(?i)integrated|iris|uhd|vega\s*\d',n)) and v<=3.0})
    gs=[g for g in gs if not g["integrated"]] or gs
    gs.sort(key=lambda x:-(x.get("vram_gb") or 0))
    return gs
def _gpus():
    if os.name!="nt":return _gpus_posix()
    out=_ps("Get-CimInstance Win32_VideoController | ForEach-Object { $n=$_.Name; $k='HKLM:\\SYSTEM\\CurrentControlSet\\Control\\Video\\'+$_.PNPDeviceID; '{0}|{1}' -f $n,$_.AdapterRAM }")
    reg=_ps("Get-ChildItem 'HKLM:\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}' -EA 0 | ForEach-Object { $p=Get-ItemProperty $_.PSPath -EA 0; if($p.'HardwareInformation.qwMemorySize'){ '{0}|{1}' -f $p.DriverDesc,$p.'HardwareInformation.qwMemorySize' } }")
    vram={}
    for line in (reg or "").splitlines():
        if "|" not in line:continue
        n,v=line.rsplit("|",1)
        try:vram[n.strip()]=round(int(v.strip())/1073741824,1)
        except Exception:pass
    import re as _re
    gs=[];seen=set()
    for line in (out or "").splitlines():
        if "|" not in line:continue
        n,v=line.rsplit("|",1);n=n.strip()
        if not n or n in seen:continue
        seen.add(n)
        g=vram.get(n)
        if g is None:
            try:g=round(int(v.strip())/1073741824,1)
            except Exception:g=0.0
            if g and 3.9<=g<=4.1:g=0.0
        integrated=bool(_re.search(r"(?i)(radeon\W*(\(tm\)\W*)?graphics|uhd|iris|vega\s*\d|integrated|igpu)",n)) and (g or 0)<=3.0
        gs.append({"name":n,"vram_gb":g or 0.0,"integrated":integrated})
    for k,val in vram.items():
        if k not in seen:gs.append({"name":k,"vram_gb":val,"integrated":val<=3.0})
    gs=[g for g in gs if not g["integrated"]] or gs
    gs.sort(key=lambda x:-(x.get("vram_gb") or 0))
    return gs
def snapshot():
    tot,avail=_ram()
    gs=_gpus()
    best=gs[0] if gs else None
    try:du=shutil.disk_usage(os.path.abspath(os.sep))
    except Exception:du=None
    return {"os":platform.system()+" "+platform.release(),"cpu_threads":os.cpu_count() or 0,
     "ram_gb":tot,"ram_free_gb":avail,"gpus":gs,
     "vram_gb":(best or {}).get("vram_gb") or 0.0,"gpu_name":(best or {}).get("name") or "",
     "disk_free_gb":round(du.free/1073741824,1) if du else 0.0}
def _moe_note(m):
    a=m.get("active")
    if not (m.get("moe") and a):return ""
    return (" It is a mixture-of-experts model: all %.0fB parameters must be in memory, but only about %.1fB are used per word, so it is faster than its size suggests."%(m.get("params",0),a))
def verdict(model,sys_=None):
    s=sys_ or snapshot()
    need=need_gb(model.get("params",0),model.get("quant","q4"))
    vram=s.get("vram_gb") or 0.0;ram=s.get("ram_gb") or 0.0
    moe=_moe_note(model)
    if need<=vram*0.85:
        return {"tier":"great","need_gb":need,"headline":"Runs on your graphics card","detail":
         "About %.1f GB of your %.1f GB of video memory — fast, and it leaves your system RAM alone."%(need,vram)+moe}
    if need<=ram*0.60:
        return {"tier":"ok","need_gb":need,"headline":"Runs, but on system memory",
         "detail":("Needs about %.1f GB, more than the %.1f GB on your graphics card, so it runs on the CPU instead. Expect several seconds per reply rather than instant."%(need,vram)
          if vram else "Needs about %.1f GB and you have no dedicated graphics card, so it runs on the CPU. Expect several seconds per reply rather than instant."%need)+moe}
    if need<=ram*0.90:
        return {"tier":"tight","need_gb":need,"headline":"Very tight — expect stalls",
         "detail":"Needs about %.1f GB against %.1f GB of RAM. Little room left for anything else; close other apps, and expect long pauses."%(need,ram)+moe}
    return {"tier":"no","need_gb":need,"headline":"Too big for this machine",
     "detail":"Needs about %.1f GB but you have %.1f GB of RAM. Your computer would page it to disk, which is not slow so much as unusable — replies can take many minutes and the machine may stop responding until you kill it."%(need,ram)+moe}
def advise(sys_=None):
    s=sys_ or snapshot()
    rows=[]
    for m in CATALOG:
        v=verdict(m,s);rows.append(dict(m,**{"verdict":v}))
    fits=[r for r in rows if r["verdict"]["tier"] in ("great","ok")]
    first=next((r for r in rows if r.get("first")),None)
    best=None
    for r in rows:
        if r["verdict"]["tier"]=="great":best=r
    rec=first
    note=("Start with %s. It is the smallest thing that still does real work, so you can see the room "
      "running before you commit to a bigger download.")%(first or {}).get("label","Adam 3B")
    if first and first["verdict"]["tier"]=="no":
        rec=None;note=("This machine does not have the memory to run a model locally. That is completely fine — "
         "use any sign-in you already have — Claude Code, Codex, Grok, Gemini, Copilot, Cursor, OpenCode — "
         "or an API key, and leave the local seat switched off.")
    elif best and best is not first:
        note+=" Your hardware could also handle %s comfortably once you are settled."%best["label"]
    return {"system":s,"models":rows,"recommended":(rec or {}).get("id"),"note":note,
     "can_run_local":bool(fits),
     "summary":"%s · %.0f GB RAM · %s"%(s.get("os"),s.get("ram_gb") or 0,
       (("%s (%.0f GB)"%(s.get("gpu_name"),s.get("vram_gb"))) if s.get("vram_gb") else "no dedicated graphics card"))}
