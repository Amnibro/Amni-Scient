"""Improving Adam, on purpose only.

Braid's memory is LOCAL. PTEX cells, the coding ledger, rejections and your
transcripts live on this machine and are never sent anywhere as a side effect of
using the product. This module is the ONLY path off the machine, it is off by
default, and it does nothing at all until the user turns it on and presses send.
"""
import os,json,re,time,zipfile,io as _io,urllib.parse
import delve_ptex as PX
TO=os.environ.get("BRAID_SHARE_TO") or "amnibro7@gmail.com"
ORG="Amniscient"
CFG_KEY="share_improve"          # False unless the user opts in
CONSENT_KEY="share_consent_ts"
def _store():
    try:
        import delve_providers as PV
        return PV._store_dir()
    except Exception:
        d=os.path.join(os.path.expanduser("~"),".braid");os.makedirs(d,exist_ok=True);return d
def enabled(cfg):
    return bool((cfg or {}).get(CFG_KEY))
# ------------------------------------------------------------------ scrub ---
_EMAIL=re.compile(r'[\w.+-]+@[\w-]+\.[\w.-]+')
_KEYS=re.compile(r'\b(sk-[A-Za-z0-9_\-]{12,}|ghp_[A-Za-z0-9]{20,}|xai-[A-Za-z0-9_\-]{12,}|AIza[A-Za-z0-9_\-]{20,}|Bearer\s+[A-Za-z0-9._\-]{16,})')
_WINPATH=re.compile(r'[A-Za-z]:\\[^\s"\'<>|,;)\]]+')
_NIXPATH=re.compile(r'(?:/home|/Users)/[^\s"\'<>|,;)\]]+')
_IP=re.compile(r'\b(?:\d{1,3}\.){3}\d{1,3}\b')
def scrub(text):
    """Strip the things nobody meant to share even when they meant to share the file."""
    t=str(text or "")
    t=_KEYS.sub("[key]",t)
    t=_EMAIL.sub("[email]",t)
    t=_WINPATH.sub(lambda m:"[path]/"+m.group(0).replace("\\","/").rstrip("/").split("/")[-1],t)
    t=_NIXPATH.sub(lambda m:"[path]/"+m.group(0).rstrip("/").split("/")[-1],t)
    t=_IP.sub(lambda m:"[ip]" if not m.group(0).startswith(("127.","0.")) else m.group(0),t)
    user=os.environ.get("USERNAME") or os.environ.get("USER") or ""
    if len(user)>2:t=re.sub(re.escape(user),"[user]",t,flags=re.I)
    return t
def _scrub_obj(o,depth=0):
    if depth>8:return o
    if isinstance(o,str):return scrub(o)
    if isinstance(o,list):return [_scrub_obj(x,depth+1) for x in o]
    if isinstance(o,dict):return {k:_scrub_obj(v,depth+1) for k,v in o.items()}
    return o
# ------------------------------------------------------------------ parts ---
def _ptex_pairs(cap=400):
    p=PX._pairs_path()
    if not os.path.isfile(p):return None
    try:d=json.load(open(p,encoding="utf-8")) or {}
    except Exception:return None
    rows=(d.get("pairs") or [])[-cap:]
    return {"file":os.path.basename(p),"pairs":_scrub_obj(rows),"count":len(rows)}
def _atlas(cap=300):
    try:
        import delve_memory as MEM
        d=MEM.cells("__global__",cap,"recent")
        if not d.get("ok"):return None
        rows=[{"q":c.get("q"),"a":c.get("a"),"cell":c.get("cell"),"ts":c.get("ts")} for c in (d.get("cells") or [])]
        return {"slot":"__global__","cells":_scrub_obj(rows),"count":len(rows)}
    except Exception:return None
def _ledger():
    try:
        import delve_memory as MEM
        d=MEM.ledger(60)
        return _scrub_obj({k:v for k,v in d.items() if k!="recall"}) if d.get("ok") else None
    except Exception:return None
def _usage(cfg):
    keep=("path_preset","code_mode","adam_mode","adam_tools","ptex_learn","compact_ctx","ui_mode","basic_layout")
    return {k:(cfg or {}).get(k) for k in keep if k in (cfg or {})}
PARTS={"ptex":("PTEX lesson pairs",_ptex_pairs),"atlas":("Adam's memory cells",_atlas),
       "ledger":("coding attempt statistics",_ledger)}
def preview(cfg,parts=None):
    """Exactly what would leave this machine, so it can be read before it is sent."""
    want=[p for p in (list(PARTS) if parts is None else list(parts)) if p in PARTS]
    out={"to":TO,"when":None,"parts":{},"config":_usage(cfg),"enabled":enabled(cfg)}
    for k in want:
        label,fn=PARTS[k]
        try:v=fn()
        except Exception:v=None
        out["parts"][k]={"label":label,"present":v is not None,
         "size":len(json.dumps(v,ensure_ascii=False)) if v is not None else 0}
    return out
def _bundle(cfg,parts,note):
    payload={"braid_share":1,"sent":time.time(),"note":scrub(note)[:2000],"config":_usage(cfg)}
    for k in parts:
        label,fn=PARTS[k]
        try:v=fn()
        except Exception:v=None
        if v is not None:payload[k]=v
    raw=json.dumps(payload,ensure_ascii=False,indent=1).encode("utf-8")
    buf=_io.BytesIO()
    with zipfile.ZipFile(buf,"w",zipfile.ZIP_DEFLATED) as z:
        z.writestr("braid_share.json",raw)
    return payload,buf.getvalue()
def build(cfg,parts=None,note=""):
    """Write the bundle to disk and hand back a mailto so the user presses send.
    Nothing is transmitted by Braid itself - the mail client is the user's hand on
    the wheel, and the file is right there to inspect first."""
    if not enabled(cfg):
        return {"ok":False,"error":"Sharing is off. Turn it on in Controls → Privacy first — nothing leaves this machine until you do."}
    # an explicit empty selection means NOTHING, never "everything"
    sel=list(PARTS) if parts is None else list(parts)
    want=[p for p in sel if p in PARTS]
    if not want:return {"ok":False,"error":"pick at least one thing to send"}
    payload,zbytes=_bundle(cfg,want,note)
    d=os.path.join(_store(),"share");os.makedirs(d,exist_ok=True)
    stamp=time.strftime("%Y%m%d_%H%M%S")
    zp=os.path.join(d,"braid_share_"+stamp+".zip")
    jp=os.path.join(d,"braid_share_"+stamp+".json")
    try:
        open(zp,"wb").write(zbytes)
        with open(jp,"w",encoding="utf-8") as f:json.dump(payload,f,ensure_ascii=False,indent=1)
    except Exception as e:
        return {"ok":False,"error":"could not write the bundle: "+str(e)[:120]}
    body=("Attached: "+", ".join(PARTS[p][0] for p in want if p in payload)+".\n\n"
          "Sent from Braid to help improve Adam at "+ORG+". Keys, emails, absolute paths and IPs were "
          "stripped before packaging.\n\nThe file to attach is:\n"+zp+"\n\n"+(note or ""))
    mailto=("mailto:"+TO+"?subject="+urllib.parse.quote("Braid — Adam improvement data")
            +"&body="+urllib.parse.quote(body[:1600]))
    return {"ok":True,"zip":zp,"json":jp,"bytes":len(zbytes),"to":TO,"org":ORG,"mailto":mailto,
            "parts":[p for p in want if p in payload],
            "note":"Nothing has been sent yet — attach the zip and press send in your mail client."}
def history(limit=10):
    d=os.path.join(_store(),"share")
    if not os.path.isdir(d):return []
    rows=[]
    for fn in sorted(os.listdir(d),reverse=True):
        if not fn.endswith(".zip"):continue
        p=os.path.join(d,fn)
        try:rows.append({"file":fn,"path":p,"bytes":os.path.getsize(p),"ts":os.path.getmtime(p)})
        except Exception:pass
        if len(rows)>=limit:break
    return rows
