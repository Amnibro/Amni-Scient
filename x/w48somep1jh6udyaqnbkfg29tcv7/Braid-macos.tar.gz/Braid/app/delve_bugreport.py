import os,re,json,time,platform,urllib.parse,urllib.request
TO=os.environ.get("DELVE_BUG_TO") or "amnibro7@gmail.com"
_SECRET_PAT=[
 re.compile(r'(?i)\b(sk-[A-Za-z0-9_\-]{12,}|sk-ant-[A-Za-z0-9_\-]{12,})'),
 re.compile(r'(?i)\bAIza[A-Za-z0-9_\-]{20,}'),
 re.compile(r'(?i)\b(gh[pousr]_[A-Za-z0-9]{20,})'),
 re.compile(r'(?i)\bxai-[A-Za-z0-9_\-]{12,}'),
 re.compile(r'(?i)\bBearer\s+[A-Za-z0-9._\-]{16,}'),
 re.compile(r'(?i)\b(api[_-]?key|secret|token|password|passwd)\s*[:=]\s*\S+'),
 re.compile(r'(?i)[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}'),
]
def scrub(t):
    s=str(t or "")
    for p in _SECRET_PAT:s=p.sub("[removed]",s)
    s=re.sub(r'(?i)([A-Za-z]:\\Users\\)[^\\\s"]+',r'\1<user>',s)
    s=re.sub(r'(?i)(/(?:home|Users)/)[^/\s"]+',r'\1<user>',s)
    return s
def diagnostics(hub=None):
    d={"when":time.strftime("%Y-%m-%d %H:%M"),"os":platform.system()+" "+platform.release(),
       "python":platform.python_version()}
    try:
        import delve_sysinfo as S
        s=S.snapshot()
        d["machine"]="%.0f GB RAM · %s · %d threads"%(s.get("ram_gb") or 0,
          (("%s %.0f GB"%(s.get("gpu_name"),s.get("vram_gb"))) if s.get("vram_gb") else "no dedicated GPU"),
          s.get("cpu_threads") or 0)
    except Exception:pass
    try:
        import delve_providers as PV
        det=PV.detect()
        d["installed"]=", ".join(sorted(k for k,v in (det.get("cli") or {}).items() if v.get("installed"))) or "none"
        d["ollama"]="running" if (det.get("ollama") or {}).get("up") else "not running"
    except Exception:pass
    if hub is not None:
        try:
            provs=(hub.cfg.get("providers") or {})
            d["seats"]=", ".join("%s=%s"%(k,(v or {}).get("kind") or "cli") for k,v in sorted(provs.items())) or "defaults"
            d["mode"]=hub.cfg.get("ui_mode") or "basic"
            d["turns"]=len(getattr(hub,"t",[]) or [])
            last=[x for w,x in (getattr(hub,"t",[]) or []) if isinstance(x,str) and x.strip().startswith("[")]
            if last:d["last_error"]=last[-1][:300]
        except Exception:pass
    return d
def build(message,hub=None,include_diag=True,contact=""):
    diag=diagnostics(hub) if include_diag else {}
    lines=["What happened:","",scrub(message).strip() or "(no description given)",""]
    c=(contact or "").strip()
    if c:
        for p in _SECRET_PAT[:-1]:c=p.sub("[removed]",c)
        lines+=["Reply to: "+c[:120],""]
    if diag:
        lines.append("--- diagnostics (automatic, secrets removed) ---")
        for k,v in diag.items():lines.append("%-11s %s"%(k+":",scrub(v)))
    body="\n".join(lines)
    subject="Amni-Delve bug report"
    return {"to":TO,"subject":subject,"body":body,
     "mailto":"mailto:"+TO+"?"+urllib.parse.urlencode({"subject":subject,"body":body},quote_via=urllib.parse.quote)}
def send(message,hub=None,include_diag=True,contact="",webhook=None):
    r=build(message,hub,include_diag,contact)
    url=(webhook or os.environ.get("DELVE_BUG_WEBHOOK") or "").strip()
    r["posted"]=False
    if url:
        try:
            data=json.dumps({"subject":r["subject"],"body":r["body"],"to":r["to"]}).encode("utf-8")
            req=urllib.request.Request(url,data=data,headers={"Content-Type":"application/json"},method="POST")
            with urllib.request.urlopen(req,timeout=12) as resp:r["posted"]=200<=resp.status<300
        except Exception as e:r["post_error"]=str(e)[:160]
    return r
