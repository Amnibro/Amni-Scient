"""What the seats are actually doing to your files, as it happens.

Two sources, deliberately unequal:

* **Tool events** are the truth. Claude runs with `--output-format stream-json`, so every
  Read/Write/Edit/Bash block arrives named, with its arguments, BEFORE the tool runs.
  Nothing else on the table streams tools - grok, agy, codex, copilot, cursor and opencode
  all return one final blob - so for those seats this source is silent.
* **The watcher** is the fallback and it is CIRCUMSTANTIAL. It reports that a path under the
  workspace changed while a seat held the floor; it cannot know the seat caused it. Say
  "changed while X was working", never "X wrote this". Anything else on the machine writing
  into the workspace lands in the same feed.

Why `ReadDirectoryChangesW` and not a snapshot diff: the real workspace here is
C:\\Users\\antho\\Documents\\ai - 335,107 files, 4-6 s per full walk and ~50 MB per snapshot.
Diffing two of those per turn is seconds of I/O and a hundred megabytes for a sidebar. RDCW is
kernel-side, needs no admin, and costs one handle. The POSIX fallback is the walk, and it is
time-boxed and only runs while a turn is live.

The feed is gated on a live turn. Between turns the workspace still churns (editors, builds,
Adam) and attributing that to a seat would be a lie with a colour on it.
"""
import os,re,json,time,threading,collections
MAX=800
DEBOUNCE=1.6
TOOL_WINDOW=4.0
# A file rewritten in a loop (a heartbeat, an append-only .jsonl) is ONE fact, not four hundred.
# Measured on a live room: tos-learn/data/heartbeat.json produced 438 of the 800 rows in the
# ring and evicted everything anyone wanted to read. After this many rows for one path in one
# turn the feed says so once and stops repeating itself.
CHURN_CAP=5
POLL_EVERY=20.0
POLL_BUDGET=3.0
SKIPDIR={"__pycache__","node_modules","target","venv",".git",".venv","dist","build",".mypy_cache",".pytest_cache",".ruff_cache"}
IGNORE=re.compile(r'(?i)(?:^|/)(?:\.|~\$)|(?:^|/)(?:__pycache__|node_modules|\.git|\.venv|venv|dist|build)/|\.(?:pyc|pyo|pyd|tmp|temp|swp|swx|part|crdownload|lock|log|bak)$|(?:^|/)session_\d{8}_\d{6}\.md$')
KIND={"Read":"read","NotebookRead":"read","Write":"write","Edit":"edit","MultiEdit":"edit",
 "NotebookEdit":"edit","Bash":"run","BashOutput":"run","Glob":"find","Grep":"find","LS":"list",
 "Task":"agent","TodoWrite":"plan","WebFetch":"web","WebSearch":"web","ExitPlanMode":"plan",
 # The changes tab was Claude-only because only Claude's tool names were classified. Grok
 # (Anthropic-wire tool_use since v3.9.2) and Adam (structured steps pushed after the run)
 # use their own names for the same verbs.
 "read_file":"read","write_file":"write","search_replace":"edit","edit_file":"edit",
 "run_command":"run","bash":"run","shell":"run","list_files":"list","grep":"find","glob":"find",
 "web_search":"web","web_fetch":"web",
 "file_read":"read","file_write":"write","code_edit":"edit","run_python":"run","calc":"run"}
ARGKEY=("file_path","path","notebook_path","filePath","file")
_EV=collections.deque(maxlen=MAX)
_LOCK=threading.RLock()
_SEQ=[0]
_SINK=[None]
_DEF=[None]
_LIVE=[""]
_T0=[0.0]
_ROOT=[""]
_MODE=["off"]
_SEEN={}
_TOOLSEEN={}
_W=[None]
def attach(sink):
    """The default route for events that belong to no turn - a UI-driven write, say, which
    already runs on a request thread bound to the right conversation. A live turn overrides
    it with that Hub's own emit, because the sniff and the watcher run on threads the
    server's thread-local room binding never reaches, and a broadcast from there would land
    in whichever room happened to be 'main'."""
    _DEF[0]=sink
    if _SINK[0] is None:_SINK[0]=sink
def _emit(ev):
    fn=_SINK[0]
    if not fn:return
    try:fn({"type":"activity","ev":ev})
    except Exception:pass
def _rel(p):
    root=_ROOT[0]
    if not p:return ""
    q=str(p).replace("\\","/").rstrip("/")
    if not root:return q
    r=root.replace("\\","/").rstrip("/")
    low,rlow=q.lower(),r.lower()
    return q[len(r)+1:] if low.startswith(rlow+"/") else ("" if low==rlow else q)
def _outside(p):
    root=_ROOT[0]
    if not (root and p):return False
    q=str(p).replace("\\","/").rstrip("/").lower();r=root.replace("\\","/").rstrip("/").lower()
    return not (q==r or q.startswith(r+"/"))
ABS=re.compile(r'^(?:[A-Za-z]:[\\/]|[\\/]{2}|/)')
def record(seat,kind,path="",note="",tool="",ok=True,src="tool"):
    """One row in the feed. `path` is workspace-relative when it can be; a path outside the
    workspace keeps its absolute form and is flagged, because that is exactly the case a
    reader needs to see.

    Only an ABSOLUTE path can be outside. The watcher reports names relative to the root it is
    watching, so running those through _outside() compared a relative path against an absolute
    root and every single watched file came back flagged - painted red in the dock and refusing
    to open, which is the opposite of what the flag is for."""
    p=str(path or "")
    rel=_rel(p)
    ev={"i":0,"ts":time.time(),"seat":str(seat or "")or"?","kind":str(kind or "note"),
     "path":rel or p,"note":str(note or "")[:400],"tool":str(tool or ""),
     "ok":bool(ok),"out":bool(ABS.match(p)) and _outside(p),"src":str(src or "tool")}
    with _LOCK:
        _SEQ[0]+=1;ev["i"]=_SEQ[0];_EV.append(ev)
    _emit(ev)
    return ev
def turn_start(seat,root="",emit=None):
    if root:set_root(root)
    if emit is not None:_SINK[0]=emit
    _LIVE[0]=str(seat or "");_T0[0]=time.time()
    with _LOCK:_TOOLSEEN.clear();_SEEN.clear()
def turn_end(seat=None):
    _LIVE[0]="";_T0[0]=0.0
    if _DEF[0] is not None:_SINK[0]=_DEF[0]
def live():
    return _LIVE[0]
def since(n=0):
    with _LOCK:
        rows=[e for e in _EV if e["i"]>int(n or 0)]
        return {"ok":True,"events":rows,"seq":_SEQ[0],"root":_ROOT[0],"mode":_MODE[0],
         "live":_LIVE[0],"kept":len(_EV),"max":MAX}
def clear():
    with _LOCK:_EV.clear()
def _toolpath(args):
    if not isinstance(args,dict):return ""
    for k in ARGKEY:
        v=args.get(k)
        if isinstance(v,str) and v.strip():return v.strip()
    return ""
def _toolnote(name,args):
    if not isinstance(args,dict):return ""
    if name in ("Bash","BashOutput"):return str(args.get("command") or args.get("description") or "")[:400]
    if name in ("Glob","Grep"):return (str(args.get("pattern") or "")+(" in "+str(args.get("path")) if args.get("path") else ""))[:400]
    if name in ("WebFetch","WebSearch"):return str(args.get("url") or args.get("query") or "")[:400]
    if name=="Task":return str(args.get("description") or args.get("subagent_type") or "")[:400]
    if name=="TodoWrite":
        todos=args.get("todos")
        return ("; ".join(str((t or {}).get("content") or "") for t in todos[:3]) if isinstance(todos,list) else "")[:400]
    if name in ("Edit","MultiEdit"):
        e=args.get("edits")
        return (str(len(e))+" edits") if isinstance(e,list) else ""
    if name=="Write":
        c=args.get("content")
        return (str(len(c))+" chars") if isinstance(c,str) else ""
    return ""
def sniff(seat,line):
    """One NDJSON line from a stream-json CLI. Only `assistant` messages carry finished
    tool_use blocks - `stream_event`/`content_block_start` names the tool but its arguments
    are still arriving as partial JSON, so reading those gives rows with no path on them."""
    ln=(line or "").strip()
    if not ln.startswith("{") or '"tool_use"' not in ln:return 0
    try:d=json.loads(ln)
    except Exception:return 0
    if not isinstance(d,dict) or d.get("type")!="assistant":return 0
    blocks=((d.get("message") or {}).get("content") or [])
    n=0
    for b in blocks if isinstance(blocks,list) else []:
        if not (isinstance(b,dict) and b.get("type")=="tool_use"):continue
        name=str(b.get("name") or "tool")
        args=b.get("input") if isinstance(b.get("input"),dict) else {}
        p=_toolpath(args)
        record(seat,KIND.get(name,"tool"),p,_toolnote(name,args),tool=name)
        if p:
            with _LOCK:_TOOLSEEN[_rel(p).lower() or p.lower()]=time.time()
        n+=1
    return n
def _drop(rel):
    """Every part, not just the parents: the kernel reports the creation of `__pycache__`
    itself as a change, and a rule that only looks at parent directories lets that row
    through while correctly hiding everything inside it."""
    if not rel or IGNORE.search(rel):return True
    if any(x in SKIPDIR for x in rel.split("/")):return True
    # A DIRECTORY change is never news. The kernel reports the parent every time a file inside
    # it is touched, so "wrote Symphony" and "wrote Amni-Browse/docs" are echoes of a file event
    # we already have - with a project name on them, which reads as the seat having worked on
    # that project. Deleted directories no longer exist to test, so fall back to "no extension".
    full=os.path.join(_ROOT[0],rel.replace("/",os.sep)) if _ROOT[0] else rel
    try:
        if os.path.isdir(full):return True
    except Exception:pass
    return "." not in rel.rsplit("/",1)[-1]
def _fs(kind,rel):
    """Saving a new file is a create AND a write within microseconds, and most editors write
    twice more on top of that. Collapse a repeat of the same path inside DEBOUNCE - but never
    swallow a delete, which is the one kind that is never redundant noise.

    Past CHURN_CAP rows for one path in one turn, stop repeating it. A heartbeat file
    alternating create/delete defeats the debounce (a delete always gets through, and the next
    create is a different kind), and one such file took 438 of the 800 rows in a live room and
    evicted everything worth reading. The cap is ANNOUNCED, once, and never silent: a feed that
    quietly drops rows is worse than a noisy one."""
    seat=_LIVE[0]
    if not seat or not rel or _drop(rel):return
    now=time.time();k=rel.lower();say=""
    with _LOCK:
        if now-_TOOLSEEN.get(k,0)<TOOL_WINDOW:return
        prev=_SEEN.get(k)
        n=(prev[2] if prev and len(prev)>2 else 0)+1
        if prev and now-prev[1]<DEBOUNCE and (kind==prev[0] or (kind=="write" and prev[0]=="create")):
            _SEEN[k]=(prev[0],prev[1],n);return
        _SEEN[k]=(kind,now,n)
        if n>CHURN_CAP:return
        if n==CHURN_CAP:say="rewritten in a loop — further changes to this file are not listed for the rest of this turn"
    record(seat,kind,rel,say,"",True,src="watch")
class _Win(threading.Thread):
    """ReadDirectoryChangesW over the whole workspace subtree. A zero-length return is the
    kernel telling us the 64 KB buffer overflowed - that is a burst, not an error, and the
    only honest thing to report is that some changes were dropped."""
    daemon=True
    def __init__(s,root):
        threading.Thread.__init__(s,daemon=True);s.root=root;s.h=None;s.on=True;s.ready=threading.Event()
    def run(s):
        import ctypes
        from ctypes import wintypes
        k32=ctypes.WinDLL("kernel32",use_last_error=True)
        k32.CreateFileW.restype=wintypes.HANDLE
        k32.CreateFileW.argtypes=[wintypes.LPCWSTR,wintypes.DWORD,wintypes.DWORD,ctypes.c_void_p,wintypes.DWORD,wintypes.DWORD,wintypes.HANDLE]
        h=k32.CreateFileW(s.root,1,7,None,3,0x02000000,None)
        if h==wintypes.HANDLE(-1).value or not h:
            _MODE[0]="off";return
        s.h=h;_MODE[0]="rdcw"
        buf=ctypes.create_string_buffer(65536);got=wintypes.DWORD(0)
        FLT=1|2|8|16
        acts={1:"create",2:"delete",3:"write",4:"delete",5:"create"}
        while s.on:
            s.ready.set()
            ok=k32.ReadDirectoryChangesW(h,buf,ctypes.sizeof(buf),True,FLT,ctypes.byref(got),None,None)
            if not s.on:break
            if not ok:break
            if not got.value:
                record(_LIVE[0] or "?","burst","","too many file changes at once — some were dropped");continue
            off=0
            while True:
                base=ctypes.addressof(buf)+off
                nxt=ctypes.c_ulong.from_address(base).value
                act=ctypes.c_ulong.from_address(base+4).value
                nlen=ctypes.c_ulong.from_address(base+8).value
                try:nm=ctypes.wstring_at(base+12,nlen//2)
                except Exception:nm=""
                if nm:_fs(acts.get(act,"write"),nm.replace("\\","/"))
                if not nxt:break
                off+=nxt
                if off>=ctypes.sizeof(buf):break
        _MODE[0]="off"
        try:
            if s.h:k32.CloseHandle(s.h)
        except Exception:pass
    def stop(s):
        s.on=False
        try:
            import ctypes
            if s.h:ctypes.WinDLL("kernel32").CancelIoEx(ctypes.c_void_p(s.h),None)
        except Exception:pass
class _Poll(threading.Thread):
    """Everything that is not Windows. A full walk of a real workspace is seconds, so it only
    runs while a seat holds the floor, no more than once per POLL_EVERY, and abandons the walk
    at POLL_BUDGET rather than letting a deep tree stall the thread."""
    daemon=True
    def __init__(s,root):
        threading.Thread.__init__(s,daemon=True);s.root=root;s.on=True;s.mark=time.time()
    def run(s):
        _MODE[0]="poll"
        while s.on:
            time.sleep(2.0)
            if not _LIVE[0] or time.time()-s.mark<POLL_EVERY:continue
            cut=s.mark;s.mark=time.time();t0=time.time();cap=False
            for base,ds,fs in os.walk(s.root):
                ds[:]=[d for d in ds if not (d.startswith(".") or d in SKIPDIR)]
                for f in fs:
                    p=os.path.join(base,f)
                    try:m=os.stat(p).st_mtime
                    except Exception:continue
                    if m>=cut:_fs("write",_rel(p))
                if time.time()-t0>POLL_BUDGET:cap=True;break
            if cap:record(_LIVE[0] or "?","burst","","workspace too large to scan fully — showing what was reached in "+str(POLL_BUDGET)+"s")
        _MODE[0]="off"
    def stop(s):s.on=False
def set_root(root):
    r=os.path.realpath(str(root or "")) if root else ""
    if not r or not os.path.isdir(r):return _MODE[0]
    if _W[0] is not None and _ROOT[0]==r:return _MODE[0]
    stop()
    _ROOT[0]=r
    try:
        w=_Win(r) if os.name=="nt" else _Poll(r)
        w.start();_W[0]=w
        # Block until the thread is about to make its first call. Anything written before
        # that is not late, it is GONE - the kernel only reports changes that happen while a
        # read is outstanding - and arming the watcher is the last thing that happens before
        # a turn is allowed to start.
        if getattr(w,"ready",None) is not None:
            w.ready.wait(1.5);time.sleep(0.03)
    except Exception:
        _W[0]=None;_MODE[0]="off"
    return _MODE[0]
def stop():
    w=_W[0]
    if w is None:return
    try:w.stop()
    except Exception:pass
    _W[0]=None;_MODE[0]="off"
def status():
    return {"ok":True,"root":_ROOT[0],"mode":_MODE[0],"live":_LIVE[0],"seq":_SEQ[0],"kept":len(_EV)}
