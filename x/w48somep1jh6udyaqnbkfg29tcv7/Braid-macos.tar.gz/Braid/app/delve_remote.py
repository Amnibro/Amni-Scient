import os,sys,time,threading,hmac,socket,secrets
import delve_providers as PV
import delve_qr as QR
try:
 from delve_proc import run as _run,popen as _popen,check_output as _co
except Exception:
 from subprocess import run as _run,Popen as _popen,check_output as _co
COOKIE="braid_key"
COOKIE_AGE=2592000
LIMIT=8;WINDOW=600
FAILS={}
LISTENER={"srv":None,"port":None}
def _secret_path():return os.path.join(PV._store_dir(),"remote_secret.txt")
def secret():
    p=_secret_path()
    try:
        s=open(p,encoding="utf-8").read().strip()
        if len(s)>=32:return s
    except Exception:pass
    s=secrets.token_hex(16)
    try:
        with open(p,"w",encoding="utf-8") as f:f.write(s)
        if os.name!="nt":os.chmod(p,0o600)
    except Exception:pass
    return s
def ok_key(k):return bool(k) and hmac.compare_digest(str(k),secret())
MAX_TRACKED=4096
def _prune(now):
    """Only the current window matters, and the table must not become the attack. Spraying
    from a botnet would otherwise grow FAILS one entry per source address, forever."""
    for k in [k for k,v in FAILS.items() if not v or now-v[-1]>=WINDOW]:FAILS.pop(k,None)
    if len(FAILS)>MAX_TRACKED:
        for k in sorted(FAILS,key=lambda k:FAILS[k][-1])[:len(FAILS)-MAX_TRACKED]:FAILS.pop(k,None)
def rate_limited(ip):
    now=time.time();_prune(now)
    FAILS[ip]=[t for t in FAILS.get(ip,[]) if now-t<WINDOW]
    if not FAILS[ip]:FAILS.pop(ip,None);return False
    return len(FAILS[ip])>=LIMIT
def fail(ip):
    now=time.time();_prune(now);FAILS.setdefault(ip,[]).append(now)
    FAILS[ip]=FAILS[ip][-LIMIT*2:]
def lan_ip():
    try:
        sk=socket.socket(socket.AF_INET,socket.SOCK_DGRAM);sk.connect(("8.8.8.8",80));ip=sk.getsockname()[0];sk.close();return ip
    except Exception:return "127.0.0.1"
def classify(ip):
    p=str(ip or "").split(".")
    try:a,b=int(p[0]),int(p[1])
    except Exception:return "other"
    if a==127:return "loopback"
    if a==100 and 64<=b<=127:return "meshnet"
    if a==192 and b==168 and p[2] in ("56","99"):return "virtual"
    if a==10 or (a==172 and 16<=b<=31) or (a==192 and b==168):return "lan"
    return "other"
KIND_LABEL={"meshnet":"Meshnet / VPN — works anywhere","lan":"This Wi-Fi network","virtual":"Virtual adapter — usually not reachable","loopback":"This computer only","other":"Other network"}
def all_ips():
    ips=[]
    try:ips=sorted({i[4][0] for i in socket.getaddrinfo(socket.gethostname(),None,socket.AF_INET)})
    except Exception:pass
    l=lan_ip()
    if l and l not in ips:ips.insert(0,l)
    rank={"lan":0,"meshnet":1,"other":2,"virtual":3,"loopback":4}
    rows=[{"ip":i,"kind":classify(i),"label":KIND_LABEL.get(classify(i),"Network")} for i in ips if not i.startswith("127.")]
    rows.sort(key=lambda r:(rank.get(r["kind"],9),r["ip"]))
    return rows
def best_host(pref=""):
    rows=all_ips()
    if pref and any(r["ip"]==pref for r in rows):return pref
    return rows[0]["ip"] if rows else lan_ip()
RULE="Braid remote access"
def _fw_cmd(port):
    return ["netsh","advfirewall","firewall","add","rule","name="+RULE,"dir=in","action=allow","protocol=TCP","localport="+str(int(port)),"profile=private,domain"]
def _fw_display(port):
    return 'netsh advfirewall firewall add rule name="%s" dir=in action=allow protocol=TCP localport=%d profile=private,domain'%(RULE,int(port))
def _fw_covers(txt,port):
    """The rule may list a RANGE (LocalPort: 8788-8800) or a comma list, so a substring test on
    the port number reports "not allowed" for a port that is in fact open."""
    import re as _re
    m=_re.search(r"LocalPort:\s*(.+)",txt)
    if not m:return False
    spec=m.group(1).strip()
    if spec.lower() in ("any","*"):return True
    for part in spec.split(","):
        part=part.strip()
        if "-" in part:
            a,_,b=part.partition("-")
            try:
                if int(a)<=port<=int(b):return True
            except ValueError:pass
        elif part.isdigit() and int(part)==port:return True
    return False
def fw_status(port):
    if os.name!="nt":
        return {"platform":"mac" if sys.platform=="darwin" else "linux","allowed":None,
                "cmd":"" if sys.platform=="darwin" else "sudo ufw allow %d/tcp"%int(port)}
    import subprocess
    try:
        r=_run(["netsh","advfirewall","firewall","show","rule","name="+RULE],capture_output=True,text=True,timeout=12)
        txt=(r.stdout or "")
        return {"platform":"nt","allowed":bool(r.returncode==0 and _fw_covers(txt,int(port))),"rule":RULE,"cmd":_fw_display(port)}
    except Exception as e:return {"platform":"nt","allowed":None,"error":str(e)[:140],"cmd":_fw_display(port)}
def fw_open(port):
    if os.name!="nt":
        return ({"ok":True,"cmd":"","out":"macOS asks with its own permission prompt the first time Braid listens — allow it there"}
                if sys.platform=="darwin" else
                {"ok":False,"needs_admin":True,"cmd":"sudo ufw allow %d/tcp"%int(port),
                 "out":"run this once in a terminal (only needed if ufw is enabled)"})
    import subprocess
    cmd=_fw_cmd(port);disp=_fw_display(port)
    try:
        r=_run(cmd,capture_output=True,text=True,timeout=20)
        if r.returncode==0:return {"ok":True,"cmd":disp,"elevated":False,"out":(r.stdout or "").strip()[:160]}
        out=((r.stdout or "")+(r.stderr or "")).strip()
    except Exception as e:out=str(e)[:160]
    try:
        args=",".join("'"+a.replace("'","''")+"'" for a in cmd[1:])
        ps=_run(["powershell","-NoProfile","-Command",
         "$p=Start-Process netsh -ArgumentList @(%s) -Verb RunAs -WindowStyle Hidden -Wait -PassThru; exit $p.ExitCode"%args],
         capture_output=True,text=True,timeout=90)
        if ps.returncode==0:return {"ok":True,"cmd":disp,"elevated":True,"out":"allowed via Windows permission prompt"}
        return {"ok":False,"needs_admin":True,"cmd":disp,"out":(out or "the permission prompt was declined")[:200]}
    except Exception as e:return {"ok":False,"needs_admin":True,"cmd":disp,"out":(out or str(e))[:200]}
def running():return LISTENER["srv"] is not None
DEFAULT_PORT=8790
def _port_free(port):
    """True if we can bind exclusively. Windows SO_REUSEADDR lies; probe with reuse off."""
    try:
        sk=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
        if os.name=="nt":
            try:sk.setsockopt(socket.SOL_SOCKET,socket.SO_EXCLUSIVEADDRUSE,1)
            except Exception:pass
        else:
            sk.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,0)
        sk.bind(("0.0.0.0",int(port)));sk.close();return True
    except OSError:
        try:sk.close()
        except Exception:pass
        return False
def start(handler,port=None,tries=8):
    """Bind phone LAN listener sharing THIS process's Hub.

    Must use exclusive bind on Windows. Multiple Braids (and Symphony on 8789) used to
    all LISTEN on the same port; the phone randomly hit an empty demo hub while the
    desktop room had hundreds of messages."""
    if running():return status()
    from http.server import ThreadingHTTPServer
    class _RSrv(ThreadingHTTPServer):
        allow_reuse_address=False
    want=int(port or DEFAULT_PORT)
    last_err=""
    for i in range(max(1,int(tries))):
        p=want+i
        if not _port_free(p):
            last_err="port %d already listening (another Braid, Symphony, or zombie)"%p
            continue
        try:
            srv=_RSrv(("0.0.0.0",p),handler)
        except OSError as e:
            last_err=str(e)[:160];continue
        srv.braid_remote=True
        threading.Thread(target=srv.serve_forever,daemon=True).start()
        LISTENER.update(srv=srv,port=int(p))
        r=status()
        if i and p!=want:
            r["port_moved"]=True;r["wanted"]=want
            try:print("[braid] remote wanted :%d but it was taken — using :%d"% (want,p),flush=True)
            except Exception:pass
        try:print("[braid] phone URL  ->  "+(r.get("url") or pair_url()),flush=True)
        except Exception:pass
        return r
    return {"ok":False,"on":False,"error":last_err or "could not bind remote port","port":want,
            "hint":"Kill zombie Braid/Symphony on that port, or set remote_port in config (default %d)"%DEFAULT_PORT}
SINGLE="single"
def adopt(port):
    """Single-port mode: the MAIN listener is already bound to 0.0.0.0, so the phone needs no
    second socket. Record the port so status()/pair_url() point at the real one."""
    LISTENER.update(srv=SINGLE,port=int(port))
    return status()
def stop():
    srv=LISTENER["srv"]
    if srv is not None and srv is not SINGLE:
        try:srv.shutdown();srv.server_close()
        except Exception:pass
    LISTENER.update(srv=None,port=None)
    try:
        p=connect_path()
        if os.path.isfile(p):os.remove(p)
    except Exception:pass
    return status()
def pair_url(host=""):
    return "http://"+(host or lan_ip())+":"+str(LISTENER["port"] or DEFAULT_PORT)+"/?key="+secret()+"&auto=1"
def connect_path():
    frozen=bool(getattr(sys,"frozen",False) or hasattr(sys,"_MEIPASS"))
    return os.path.join(PV._store_dir() if frozen else os.path.dirname(os.path.abspath(__file__)),"connect.url")
def write_connect(url=""):
    u=(url or "").strip()
    if not u and running():u=pair_url()
    if not u:return ""
    p=connect_path()
    try:
        open(p,"w",encoding="utf-8").write(u.strip()+"\n")
    except Exception:pass
    return u
def status(port_hint=None,host_pref=""):
    host=best_host(host_pref)
    out={"ok":True,"on":running(),"ip":host,"hosts":all_ips(),"host_kind":classify(host),"port":LISTENER["port"]}
    out["firewall"]=fw_status(LISTENER["port"] or port_hint or DEFAULT_PORT)
    if running():
        u=pair_url(host);out["url"]=u;write_connect(u)
        try:out["qr"]=QR.svg(u)
        except Exception as e:out["qr"]="";out["qr_error"]=str(e)[:120]
    return out
def cookie_header():return COOKIE+"="+secret()+"; Max-Age="+str(COOKIE_AGE)+"; HttpOnly; SameSite=Lax; Path=/"
def key_from(headers,query):
    k=(query.get("key") or [""])[0]
    if k:return k,"query"
    for part in (headers.get("Cookie") or "").split(";"):
        n,_,v=part.strip().partition("=")
        if n==COOKIE and v:return v,"cookie"
    h=headers.get("X-Braid-Key") or ""
    return (h,"header") if h else ("","")
