import sys,os,json,subprocess,threading,time,itertools,datetime,tempfile,shutil,re,uuid
try:
    from delve_proc import run as _run,popen as _popen,check_output as _co
except Exception:
    from subprocess import run as _run,Popen as _popen,check_output as _co
try:import msvcrt
except Exception:msvcrt=None
try:import delve_ptex as PTEX
except Exception:PTEX=None
try:import delve_adam as ADAM
except Exception:ADAM=None
try:import delve_providers as PROV
except Exception:PROV=None
try:import delve_sysinfo as SYSINFO
except Exception:SYSINFO=None
try:import delve_google as GOOGLE
except Exception:GOOGLE=None
try:import delve_activity as ACT
except Exception:ACT=None
try:import delve_ctx as CTX
except Exception:CTX=None
ROOT=os.path.dirname(os.path.abspath(__file__))
def _data_home():
    """Where things that must OUTLIVE the process live.

    A onefile PyInstaller build unpacks itself to %TEMP%\\_MEIxxxxx and DELETES that directory
    on exit. ROOT is inside it, so a frozen Braid was writing delve_config.json, sessions/ and
    flows/ into a folder Windows removed the moment the window closed: every launch opened at
    the setup screen and every conversation died with it. Measured, not theorised - a probe
    build wrote to %TEMP%\\_MEI470562\\ and the whole tree was gone after the process ended.

    Running from source, ROOT is the checkout and nothing changes. A `delve_config.json` sitting
    beside the .exe still wins, because that is how a portable install is moved.

    DELVE_DATA_DIR overrides everything. A test that builds a real Hub writes a real session file,
    and tests/ was dropping stub rooms ("Anthony: q" / "answer from Claude") straight into the
    checkout's sessions/ — 23 of them by 2026-08-17, all over Anthony's own conversation list.
    Point probes at a temp directory instead of teaching each one to clean up after itself."""
    d=(os.environ.get("DELVE_DATA_DIR") or "").strip()
    if d:
        try:os.makedirs(d,exist_ok=True)
        except Exception:pass
        return os.path.abspath(d)
    if not (getattr(sys,"frozen",False) or hasattr(sys,"_MEIPASS")):return ROOT
    try:
        side=os.path.dirname(os.path.abspath(sys.executable))
        if os.path.isfile(os.path.join(side,"delve_config.json")):return side
    except Exception:pass
    if os.name=="nt":base=os.environ.get("APPDATA") or os.path.join(os.path.expanduser("~"),"AppData","Roaming")
    elif sys.platform=="darwin":base=os.path.join(os.path.expanduser("~"),"Library","Application Support")
    else:base=os.environ.get("XDG_DATA_HOME") or os.path.join(os.path.expanduser("~"),".local","share")
    d=os.path.join(base,"Braid")
    try:os.makedirs(d,exist_ok=True)
    except Exception:pass
    return d
DATA=_data_home()
CFG=os.path.join(DATA,"delve_config.json")
SESS=os.path.join(DATA,"sessions")
def _default_work():
    """A frozen build runs from a temp extraction directory that is wiped on exit, so
    anything written there is gone when the tester closes Braid. Keep the workspace in
    a real user folder for packaged builds."""
    if getattr(sys,"frozen",False) or hasattr(sys,"_MEIPASS"):
        home=os.path.expanduser("~")
        # On POSIX the frozen binary is plain "Braid", so ~/Braid/workspace collides with
        # the executable when it sits in the home dir - skip any base where that happens.
        for docs in (os.path.join(home,"Documents"),home):
            if os.path.isdir(docs) and not os.path.isfile(os.path.join(docs,"Braid")):
                return os.path.join(docs,"Braid","workspace")
        return os.path.join(home,"Braid-workspace")
    return os.path.join(ROOT,"workspace")
WORK=_default_work()
VERSION="3.10.1"
PRIVACY_ENV={"DO_NOT_TRACK":"1","DISABLE_TELEMETRY":"1","DISABLE_ERROR_REPORTING":"1",
 "DISABLE_BUG_COMMAND":"1","OTEL_SDK_DISABLED":"1",
 "CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC":"1","GEMINI_USAGE_STATISTICS":"false"}
PRIVACY_ENV_WHY={"DO_NOT_TRACK":"universal opt-out honoured by many CLIs",
 "DISABLE_TELEMETRY":"analytics/usage telemetry off (Claude Code: Statsig)",
 "DISABLE_ERROR_REPORTING":"crash reporting off (Claude Code: Sentry)",
 "DISABLE_BUG_COMMAND":"Claude Code /bug uploader off",
 "OTEL_SDK_DISABLED":"OpenTelemetry export off for any CLI that uses it",
 "CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC":"Claude Code skips every non-inference call",
 "GEMINI_USAGE_STATISTICS":"Gemini CLI usage statistics off"}
RST="\033[0m";DIM="\033[2m";BOLD="\033[1m"
COL={"Anthony":"\033[96m","Claude":"\033[95m","Grok":"\033[93m","Google":"\033[94m","System":"\033[90m"}
CORE_AGENTS=["Claude","Grok","Google","Adam"]
EXTRA_AGENTS=["OpenAI","Copilot","Cursor","OpenCode"]
AGENTS=CORE_AGENTS+EXTRA_AGENTS
SEAT_HUE={"Claude":"#C96442","Grok":"#3A4048","Google":"#3B82F6","Adam":"#00915C",
 "OpenAI":"#10A37F","Copilot":"#8957E5","Cursor":"#0EA5E9","OpenCode":"#D97706"}
SEAT_LABEL={"Google":"Gemini","Adam":"Adam (local)","OpenAI":"ChatGPT","Copilot":"Copilot",
 "Cursor":"Cursor","OpenCode":"OpenCode"}
SEAT_MODEL_KEY={"Claude":"claude_model","Grok":"grok_model","Google":"google_model","Adam":"adam_mode"}
SEAT_MODEL_DEFAULTS={
 "OpenAI":[{"id":"gpt-5.6-terra","label":"GPT-5.6 terra"},{"id":"gpt-5.4","label":"GPT-5.4"},{"id":"gpt-5.2","label":"GPT-5.2"},{"id":"gpt-5.2-mini","label":"GPT-5.2 mini"}],
 "Copilot":[{"id":"auto","label":"auto"},{"id":"gpt-5.4","label":"GPT-5.4"},{"id":"gpt-5.2","label":"GPT-5.2"},{"id":"claude-sonnet-5","label":"Claude Sonnet 5"}],
 "Cursor":[{"id":"gpt-5.2","label":"gpt-5.2"},{"id":"sonnet-5","label":"sonnet-5"},{"id":"gemini-3.1-pro","label":"gemini-3.1-pro"}],
 "OpenCode":[{"id":"","label":"(CLI default)"}],
 "Adam":[{"id":"light","label":"light · 3B"},{"id":"heavy","label":"heavy · 8B"}]}
KNOWN_SPEAKERS=("Anthony","Claude","Grok","Google","Adam","OpenAI","Copilot","Cursor","OpenCode","System","You")
PATH_PRESETS={
"roles":{
"id":"roles","label":"Roles · Captain / Labor / QA / Docs",
"desc":"Division of labor: project lead, implementer, quality check, documentation.",
"order":["Claude","Grok","Google","Adam"],
"roles":{"Claude":"Captain / project lead","Grok":"Labor / builder","Google":"Quality check / adversarial review","Adam":"Documentation / proof-tree / status"},
"protocol":(
"PATH: ROLES (division of tasks).\n"
"Roles: Claude = Captain/project lead (scope, priorities, go/no-go). "
"Grok = Labor (write the actual math/code leaf). "
"Google = Quality check (attack gaps, circularity, constants). "
"Adam = Documentation & proof-tree; when handed a concrete calc/numerical test, execute it then update the board.\n"
"Every turn: (1) ONE-line synopsis of the prior round, (2) do YOUR role’s work only, "
"(3) handoff with what you advanced + exact ask for the next role. "
"Do not steal another role’s job. No Clay victory claims. Adam empty board with no math = fail when assigned work."
)},
"sequential":{
"id":"sequential","label":"Sequential peers (same role)",
"desc":"Each seat continues the same job where the previous left off.",
"order":["Claude","Grok","Google","Adam"],
"roles":{"Claude":"Peer","Grok":"Peer","Google":"Peer","Adam":"Peer — execute handoff, then short board"},
"protocol":(
"PATH: SEQUENTIAL PEERS (same role).\n"
"Order: Claude → Grok → Google → Adam. "
"Each speaker continues the SAME kind of work as the predecessor (extend the leaf, don’t restart). "
"Adam is a peer: if the predecessor hands Adam a concrete calculation/numerical test, DO that work first "
"(formulas, numbers, sign conclusions). Empty LOCKED/OPEN boards with only generic NEXT bullets = fail. "
"Every turn: (1) one-line synopsis of the last round, (2) pick up handoff and push the next concrete step, "
"(3) end with handoff for the next speaker. No pure meta-stall; work from transcript if docs are thin."
)},
"adversarial":{
"id":"adversarial","label":"Adversarial teams",
"desc":"Builders vs attackers; Adam is neutral referee/board.",
"order":["Claude","Grok","Google","Adam"],
"roles":{"Claude":"Builder team (propose constructions)","Grok":"Builder team (strengthen constructions)","Google":"Red team (break / circularity / counterexamples)","Adam":"Neutral referee / board"},
"protocol":(
"PATH: ADVERSARIAL TEAMS.\n"
"Blue (Claude, Grok): propose and fortify concrete constructions/estimates. "
"Red (Google): attack — find circularity, missing hyps, wrong inequalities, textbook restatements. "
"Adam: neutral board — LOCKED/OPEN/OWNERS only; no new math unless Anthony asks.\n"
"Every turn: (1) one-line synopsis of prior-round errors, (2) play your team role hard, (3) handoff. "
"Builders must answer Red’s last attack. Red must cite a specific flaw, not vibes."
)},
"socratic":{
"id":"socratic","label":"Socratic drill",
"desc":"Question → attempt → critique → synthesis.",
"order":["Claude","Grok","Google","Adam"],
"roles":{"Claude":"Questioner","Grok":"Attempted solution","Google":"Critique","Adam":"Synthesis / board"},
"protocol":(
"PATH: SOCRATIC DRILL.\n"
"Claude: pose the sharpest next question / missing definition. "
"Grok: attempt a concrete answer (inequality or definition). "
"Google: critique the attempt (gaps, circularity). "
"Adam: synthesize status board only.\n"
"Stay in role. No skipping to ‘we’re done’."
)},
"steelman":{
"id":"steelman","label":"Steelman relay",
"desc":"Each seat restates the prior best case stronger, then adds one step.",
"order":["Claude","Grok","Google","Adam"],
"roles":{"Claude":"Steelman + step","Grok":"Steelman + step","Google":"Steelman + step","Adam":"Board of steelmanned claims"},
"protocol":(
"PATH: STEELMAN RELAY.\n"
"Before adding new work: restate the previous speaker’s best claim stronger in ONE line. "
"Then add exactly one new concrete step. Adam only catalogs steelmanned LOCKED vs OPEN claims. "
"No weak-man. No strawman."
)},
"free":{
"id":"free","label":"Free roundtable",
"desc":"Light structure; still review + handoff.",
"order":["Claude","Grok","Google","Adam"],
"roles":{"Claude":"Voice","Grok":"Voice","Google":"Voice","Adam":"Board"},
"protocol":(
"PATH: FREE ROUNDTABLE.\n"
"Speak in order Claude → Grok → Google → Adam. "
"Still do a one-line review of the last round and end with a handoff. "
"Prefer substance over process theater."
)},
}
CLAUDE_TOOLS=["Task","Bash","PowerShell","Edit","Write","NotebookEdit","Glob","Grep","Read","WebFetch","WebSearch","LSP","Workflow","Skill","ToolSearch","Monitor","TaskCreate","TaskUpdate","TaskStop"]
CLAUDE_WRITE_TOOLS=["Edit","Write","NotebookEdit","Task","Workflow"]
HARNESS_PROFILES={
"chat":{"id":"chat","label":"Chat — one pass, no tools","desc":"Answers from reasoning only. Fast and cheap; the seat cannot read or edit files.",
 "tools":"none","permission":"plan","timeout":600,"max_turns":6,"mcp":False,"stream":True},
"review":{"id":"review","label":"Review — reads, never writes","desc":"Full read/search access so the seat can check real code, but it cannot modify anything.",
 "tools":"read","permission":"plan","timeout":900,"max_turns":10,"mcp":False,"stream":True},
"build":{"id":"build","label":"Build — full agentic harness","desc":"Real multi-pass tool loop: reads, edits, runs code and tests. Slowest and most capable.",
 "tools":"write","permission":"bypass","timeout":2400,"max_turns":28,"mcp":True,"stream":True},
}
HARNESS_ORDER=["chat","review","build"]
# Per-mode defaults. "*" is the fallback for seats not named. Conversational paths stay capped
# so a roundtable cannot stall on one seat compiling; work paths give the seat a real harness.
HARNESS_BY_MODE={
"free":{"*":"chat"},
"steelman":{"*":"chat"},
"socratic":{"*":"chat"},
"adversarial":{"*":"review","Adam":"chat"},
"sequential":{"*":"review","Claude":"build","Grok":"build","Google":"build"},
"roles":{"*":"build","Google":"review","Adam":"chat"},
}
def harness_profile(pid=None):
    return HARNESS_PROFILES.get(str(pid or "").strip().lower()) or None
def list_harness_profiles():
    return [{k:HARNESS_PROFILES[p][k] for k in ("id","label","desc","tools","permission","timeout","max_turns","mcp")} for p in HARNESS_ORDER]
def path_preset(pid=None):
    pid=(pid or "sequential").strip().lower()
    return PATH_PRESETS.get(pid) or PATH_PRESETS["sequential"]
def list_path_presets():
    return [{"id":p["id"],"label":p["label"],"desc":p["desc"],"roles":p["roles"]} for p in PATH_PRESETS.values()]
def which(n,fb):
    p=shutil.which(n);return p if p else (fb if os.path.exists(fb) else n)
def parse_session_md(text):
    known="|".join(KNOWN_SPEAKERS)
    parts=re.split(rf"(?:\r?\n){{2}}(?=\*\*(?:{known}):\*\*)",(text or "").strip())
    out=[]
    for part in parts:
        part=part.strip()
        if not part or part.startswith("# "):continue
        m=re.match(rf"\*\*({known}):\*\*[ \t]*",part)
        if not m:continue
        who=m.group(1);who="Anthony" if who=="You" else who
        body=part[m.end():].strip()
        if body:out.append((who,body))
    return out
META_PATH=os.path.join(DATA,"sessions_meta.json")
def load_sessions_meta():
    if not os.path.exists(META_PATH):return {}
    try:return json.load(open(META_PATH,encoding="utf-8")) or {}
    except Exception:return {}
def save_sessions_meta(m):
    try:
        os.makedirs(SESS,exist_ok=True)
        json.dump(m,open(META_PATH,"w",encoding="utf-8"),indent=2)
    except Exception:pass
def session_preview(path,max_chars=160):
    try:
        raw=open(path,encoding="utf-8",errors="replace").read(12000)
    except Exception:return "",0,[],""
    entries=parse_session_md(raw)
    n=len(entries)
    speakers=[]
    for w,_ in entries:
        if w not in speakers:speakers.append(w)
    title="";preview=""
    for w,t in entries:
        if w=="Anthony" and t.strip():
            title=re.sub(r'\s+',' ',t.strip())[:80]
            preview=re.sub(r'\s+',' ',t.strip())[:max_chars]
            break
    if not preview and entries:
        preview=re.sub(r'\s+',' ',(entries[0][1] or "").strip())[:max_chars]
        title=title or (preview[:60] if preview else "")
    if not title:
        base=os.path.basename(path)
        title=base.replace("session_","").replace(".md","")
    return title,n,speakers,preview
def list_sessions(limit=30,rich=False):
    if not os.path.isdir(SESS):return []
    meta=load_sessions_meta();files=[]
    for name in os.listdir(SESS):
        if not (name.startswith("session_") and name.endswith(".md")):continue
        path=os.path.join(SESS,name)
        try:st=os.stat(path)
        except Exception:continue
        row={"name":name,"path":path,"size":st.st_size,"mtime":st.st_mtime}
        if rich or st.st_size<400000:
            try:
                title,msgs,speakers,preview=session_preview(path)
                row.update({"title":(meta.get(name) or {}).get("title") or title,"messages":msgs,"speakers":speakers,"preview":preview,"pinned":bool((meta.get(name) or {}).get("pinned")),"archived":bool((meta.get(name) or {}).get("archived"))})
            except Exception:
                row.update({"title":name,"messages":None,"speakers":[],"preview":"","pinned":False,"archived":False})
        else:
            row.update({"title":(meta.get(name) or {}).get("title") or name,"messages":None,"speakers":[],"preview":"(large session)","pinned":bool((meta.get(name) or {}).get("pinned")),"archived":bool((meta.get(name) or {}).get("archived"))})
        files.append(row)
    files.sort(key=lambda x:(not x.get("pinned",False),-x["mtime"]))
    return files[:limit]
def new_session_stamp():
    """A stamp nobody is already using, including the recycle bin.

    The stamp is second-resolution, so two conversations minted inside the same second got
    the SAME filename. Harmless-looking until you delete the open conversation and the
    replacement is handed the name that was just recycled - now a flush writes a file the
    user thought they had deleted. Walk the seconds until the name is genuinely free."""
    base=datetime.datetime.now()
    trash=os.path.join(SESS,"_deleted")
    for i in range(3600):
        st=(base+datetime.timedelta(seconds=i)).strftime("%Y%m%d_%H%M%S")
        n="session_"+st+".md"
        if not os.path.exists(os.path.join(SESS,n)) and not os.path.exists(os.path.join(trash,n)):
            return st
    return base.strftime("%Y%m%d_%H%M%S")+"_"+os.urandom(2).hex()
def latest_session(min_bytes=400,prefer_rich=True,rich_bytes=8000):
    cand=[s for s in list_sessions(80) if s["size"]>=min_bytes]
    if not cand:return None
    if prefer_rich:
        rich=[s for s in cand if s["size"]>=rich_bytes]
        if rich:
            rich.sort(key=lambda x:x["mtime"],reverse=True);return rich[0]
    cand.sort(key=lambda x:x["mtime"],reverse=True);return cand[0]
CLAUDE=which("claude",os.path.expanduser("~/.local/bin/claude.exe" if os.name=="nt" else "~/.local/bin/claude"))
GROK=which("grok",os.path.expanduser("~/.grok/bin/grok.exe" if os.name=="nt" else "~/.grok/bin/grok"))
def _google_exe():
    return (GOOGLE.resolve() if GOOGLE else "") or which("agy",os.path.expandvars(r"%LOCALAPPDATA%\agy\bin\agy.exe") if os.name=="nt" else os.path.expanduser("~/.local/bin/agy"))
def load_cfg():
    base={"claude_model":"fable","grok_model":"grok-4.6","google_model":"gemini-3.1-pro-high","seat_models":{},"default":"all","path_preset":"sequential","workspace":WORK,"bypass":False,"code_mode":"edit","license_buy_url":"https://buy.stripe.com/8x25kw7ek2qY6p59Rd3cc00","ptex_learn":True,"ptex_commit_every":3,"usage_poll":False,"privacy_asked":False,"privacy_mode":True,"user_name":"","board_style":False,"adam_fallback":True,"adam_mode":"light","adam_ctx_turns":12,"adam_msg_chars":1800,"adam_timeout":180,"adam_max_chars":16000,"adam_max_tokens":2400,"adam_tools":True,"adam_steps":14,"adam_intent":True,"adam_agentic_timeout":600,"compact_ctx":True,"compact_k":6,"compact_recap_chars":600,"compact_min_chars":8000,"compact_every":4,"compact_max_chars":12000,"compact_delta_chars":5000,"seat_max_prompt_chars":48000,"seat_limits":{},"seat_api_keys":{},"adam_bake":"","harness_default":"review","harness_by_mode":{},"harness_overrides":{},"cli_mcp":False,"cli_stream":True,"cli_session_mode":"refresh","cli_session_refresh_every":2,"ui_mode":"simple","basic_layout":"side","seat_backends":{},"update_channel":"","session_retention_days":0}
    disk={}
    if os.path.exists(CFG):
        try:disk=json.load(open(CFG,encoding="utf-8")) or {}
        except Exception:disk={}
        base.update(disk)
    # ptex_learn is ON by default. Only an explicit false in config turns it off.
    if "ptex_learn" not in disk:base["ptex_learn"]=True
    if "adam_tools" not in disk:base["adam_tools"]=True
    cm=str(base.get("code_mode") or "").strip().lower()
    if cm in ("review","open"):base["code_mode"]={"review":"edit","open":"bypass"}[cm]
    elif cm and cm not in ("plan","edit","bypass"):base.pop("code_mode",None)
    managed={};mpath=""
    _mngd=os.path.join(os.environ.get("PROGRAMDATA") or r"C:\ProgramData","Braid","managed_config.json") if os.name=="nt" else ("/Library/Application Support/Braid/managed_config.json" if sys.platform=="darwin" else "/etc/braid/managed_config.json")
    for mp in (_mngd,os.path.join(ROOT,"managed_config.json")):
        try:
            if os.path.isfile(mp):
                managed=json.load(open(mp,encoding="utf-8")) or {};mpath=mp;break
        except Exception:managed={}
    if managed:
        managed={k:v for k,v in managed.items() if not str(k).startswith("_")}
        base.update(managed)
        base["_managed_keys"]=sorted(managed.keys());base["_managed_path"]=mpath
    return base
def save_cfg(c):
    # Never persist the managed overlay: _managed_* are runtime facts from the IT policy file.
    # Writing them would keep settings locked after the admin removes managed_config.json, and
    # would bake policy values into the user's own config.
    mk=set(c.get("_managed_keys") or [])
    out={k:v for k,v in c.items() if not str(k).startswith("_") and k not in mk}
    json.dump(out,open(CFG,"w",encoding="utf-8"),indent=2)
def say(who,text):
    print((COL.get(who,"")+BOLD+who+":"+RST+" "+text+"\n"))
def run_spin(name,fn):
    res={}
    def w():
        try:res["v"]=fn()
        except Exception as e:res["v"]="["+name+" launch error] "+str(e)
    if not sys.stdout.isatty():
        sys.stdout.write(DIM+name+" is thinking…"+RST+"\n");sys.stdout.flush();w();return res.get("v","")
    th=threading.Thread(target=w);th.start()
    for c in itertools.cycle("|/-\\"):
        if not th.is_alive():break
        sys.stdout.write("\r"+DIM+name+" is thinking "+c+RST);sys.stdout.flush();time.sleep(0.1)
    th.join();sys.stdout.write("\r"+" "*42+"\r");sys.stdout.flush();return res.get("v","")
BRAID=("⠋","⠙","⠹","⠸","⠼","⠴","⠦","⠧","⠇","⠏")
BRAID_ASCII=("-","\\","|","/")
def _braid_frames():
    try:
        enc=(getattr(sys.stdout,"encoding","") or "").lower()
        "".join(BRAID).encode(enc or "ascii");return BRAID
    except Exception:return BRAID_ASCII
_TICK={"on":False,"g":None}
def _tick_clear():
    if _TICK["on"]:
        try:sys.stdout.write("\r\033[2K");sys.stdout.flush()
        except Exception:pass
        _TICK["on"]=False
def _term_sink(ev):
    ty=ev.get("type")
    if ty!="tick":_tick_clear()
    if ty=="tick":
        if not sys.stdout.isatty():return
        if _TICK["g"] is None:_TICK["g"]=_braid_frames()
        g=_TICK["g"]
        try:
            sys.stdout.write("\r\033[2K"+DIM+g[int(ev.get("frame") or 0)%len(g)]+" "+ev["text"]+RST);sys.stdout.flush();_TICK["on"]=True
        except UnicodeEncodeError:
            _TICK["g"]=BRAID_ASCII
            try:sys.stdout.write("\r\033[2K"+DIM+BRAID_ASCII[int(ev.get("frame") or 0)%4]+" "+ev["text"].encode("ascii","replace").decode("ascii")+RST);sys.stdout.flush();_TICK["on"]=True
            except Exception:pass
        except Exception:pass
    elif ty=="msg":say(ev["who"],ev["text"])
    elif ty=="status":print(DIM+"-- "+ev["text"]+" --"+RST)
    elif ty=="ptex":print(DIM+"↳ Adam/PTEX learned: "+json.dumps(ev["data"])+RST+"\n")
    elif ty=="system":print(DIM+ev["text"]+RST+"\n")
    elif ty=="estop":
        try:sys.stdout.write("\n"+BOLD+"\033[91m*** E-STOP - halting exchange ***\033[0m\n");sys.stdout.flush()
        except Exception:pass
class Hub:
    def __init__(s,sink=None,spinner=True):
        s.cfg=load_cfg();s.work=s.cfg.get("workspace") or WORK
        os.makedirs(s.work,exist_ok=True);os.makedirs(SESS,exist_ok=True)
        s.t=[];s.idx={a:0 for a in AGENTS};s.started={a:False for a in AGENTS}
        s.stamp=datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        s.file=os.path.join(SESS,"session_"+s.stamp+".md")
        s.abort=threading.Event();s.proc=None;s._procs=set();s._proclk=threading.Lock();s._tls=threading.local();s.interjects=[];s.pending=[];s._watch=False;s.fyi=[];s.sid={}
        # How full each seat's PINNED CLI session is, in tokens. Per room: two rooms hold two
        # different sessions for the same seat. _ctx_live is the in-flight estimate for the
        # progress line, thrown away when the real usage arrives.
        s.ctx={};s._ctx_live={}
        s._auto_seed=False
        s.files_note=""
        s.sink=sink or _term_sink;s.spinner=spinner
    def emit(s,ev):
        try:s.sink(ev)
        except Exception:pass
    def seed_add(s,who,text):
        """The opening prompt Braid seeds itself with is not a conversation. Held in memory
        only, so merely starting the app does not leave another identical dated file in the
        session picker - which is how nine of them accumulated."""
        s.t.append((who,text));s._auto_seed=True
    def add(s,who,text):
        s.t.append((who,text));s._auto_seed=False;s.flush()
    def flush(s):
        """Session files are minted by CONTENT, not by launch.

        `_auto_seed` used to be the whole guard, which worked only because the forced
        seed.md turn was always there to set it. With seeding off by default an empty
        transcript flushes a 74-byte header-only file — thirty of them accumulated in one
        afternoon of testing, which is the exact "nine identical dated files" problem the
        v3.5.2 note exists to prevent. Guard on the transcript itself so it cannot come back
        whatever else changes."""
        if getattr(s,"_auto_seed",False) or not s.t:return
        open(s.file,"w",encoding="utf-8").write("# Amni-Delve session "+s.stamp+"\n\n"+"\n\n".join("**"+w+":** "+x for w,x in s.t)+"\n")
    def reset_cli_pins(s):
        s.sid={};s.fyi=[];s.files_note=""
        s.interjects=[];s.pending=[]
        for a in AGENTS:s.started[a]=False
    def load_session(s,path,keep_file=True):
        path=os.path.abspath(path)
        if not os.path.isfile(path):return {"ok":False,"error":"missing file","path":path}
        try:raw=open(path,encoding="utf-8").read()
        except Exception as e:return {"ok":False,"error":str(e),"path":path}
        entries=parse_session_md(raw)
        if not entries:return {"ok":False,"error":"no messages parsed","path":path}
        s.t=list(entries);s.reset_cli_pins()
        for a in AGENTS:s.idx[a]=len(s.t);s.started[a]=False
        base=os.path.basename(path)
        if keep_file and base.startswith("session_") and base.endswith(".md"):
            s.file=path;s.stamp=base[len("session_"):-len(".md")]
            try:
                if s.cfg.get("last_session")!=base:s.cfg["last_session"]=base;save_cfg(s.cfg)
            except Exception:pass
        else:
            s.stamp=datetime.datetime.now().strftime("%Y%m%d_%H%M%S");s.file=os.path.join(SESS,"session_"+s.stamp+".md");s.flush()
        return {"ok":True,"path":s.file,"messages":len(s.t),"stamp":s.stamp}
    _INJ=re.compile(r'={2,}\s*(anthony\s+standing\s+orders|conversational\s+path\s+preset|immediate\s+predecessor\s+handoff|previous\s+full\s+round|system|end\s+of)[^=\n]*={2,}',re.I)
    _INJ2=re.compile(r'(?i)\b(system|assistant|user|anthony)\s*:\s*(?=\S)')
    _INJ3=re.compile(r'(?i)\b(ignore|disregard|override)\s+(all\s+|any\s+|the\s+)?(previous|prior|above|earlier|preceding)\s+(instructions?|orders?|prompts?|rules?)')
    def _defang(s,text):
        t=(text or "")
        t=s._INJ.sub('[peer-frame removed]',t)
        t=s._INJ2.sub(r'\1․ ',t)
        t=s._INJ3.sub('[peer-directive removed]',t)
        return t.replace('===','═══')
    def _clip_txt(s,text,n,trusted=False):
        body=re.sub(r'\s+',' ',(text or "").strip())
        body=re.sub(r'```[\s\S]*?```','[code omitted]',body)
        if not trusted:body=s._defang(body)
        return body if len(body)<=n else (body[:n//2]+" … "+body[-(n//2):])
    def _anthony_orders(s,max_msgs=4,max_chars=1400):
        msgs=[(w,x) for w,x in s.t if w=="Anthony"]
        if not msgs:return "(no Anthony orders yet)"
        chunks=[]
        for w,x in msgs[-max_msgs:]:
            chunks.append(s._clip_txt(x,max_chars,trusted=True))
        return "\n---\n".join(chunks)
    def active_path(s):
        """Resolved path for prompts + ribbon fallback.

        A `flow:<id>` config value is NOT a PATH_PRESETS key — path_preset() used to
        quietly fall through to sequential, so chain_rules and roster_all painted
        Claude→Grok→… while delve_graph.run actually walked the flow. Resolve the
        flow's visit order here so every consumer agrees."""
        pid=str(s.cfg.get("path_preset") or "sequential").strip()
        if pid.startswith("flow:"):
            try:
                import delve_graph as GR
                fg=GR.load(pid[5:],s.seats_available())
            except Exception:fg=None
            if fg:
                rows=GR.visit_order(fg)
                order=list(dict.fromkeys(r["agent"] for r in rows if r.get("agent")))
                roles={}
                for r in rows:
                    a=r.get("agent")
                    if a and a not in roles:
                        roles[a]=r.get("role") or ("review break" if r.get("gather") else "seat")
                return {"id":pid,"label":fg.get("label") or pid,"flow":True,"order":order or list(CORE_AGENTS),
                        "roles":roles,"protocol":(fg.get("goal") or "").strip(),"desc":(fg.get("goal") or "").strip()}
            pid="sequential"
        p=dict(path_preset(pid))
        so=[n for n in (s.cfg.get("seat_order") or []) if n in AGENTS]
        if so:
            base=list(p.get("order") or CORE_AGENTS)
            p["order"]=so+[n for n in base if n not in so]
        return p
    def roster_all(s):
        p=s.active_path();order=list(p.get("order") or CORE_AGENTS)
        if not s.adam_available():order=[n for n in order if n!="Adam"]
        # Under a flow the visit order IS the roster — do not append every configured
        # extra seat or the ribbon and turn-order panel grow past what the graph runs.
        if p.get("flow"):return order
        provs=s.cfg.get("providers") or {}
        for n in EXTRA_AGENTS:
            if n in order:continue
            k=((provs.get(n) or {}).get("kind") or "").lower()
            if k=="off":continue
            # Include when configured as cli/api, OR when the binary is installed —
            # requiring kind alone hid Cursor/OpenCode and any seat never saved to providers.
            if k or s.seat_installed(n):order.append(n)
        return order
    def _prev_in_chain(s,name):
        order=s.roster_all()
        if name not in order:return None,None
        i=order.index(name)
        if i==0:
            for w,x in reversed(s.t):
                if w=="Anthony":return "Anthony",x
            return None,None
        prev=order[i-1]
        for w,x in reversed(s.t):
            if w==prev:return prev,x
        return prev,None
    def _last_round_blob(s,max_chars_each=1100):
        order=s.roster_all();found={}
        for w,x in reversed(s.t):
            if w in order and w not in found:found[w]=x
            if len(found)==len(order):break
        lines=[]
        for w in order:
            if w in found:lines.append(s.disp(w)+": "+s._clip_txt(found[w],max_chars_each))
        return "\n\n".join(lines) if lines else "(no full prior round yet)"
    def chain_rules(s,name):
        p=s.active_path();role=(p.get("roles") or {}).get(name,"Participant")
        order=" → ".join(p.get("order") or [])
        prev_who,prev_txt=s._prev_in_chain(name)
        prev_block=("(none — you open the round)" if not prev_txt else (prev_who+":\n"+s._clip_txt(prev_txt,1600)))
        return (
            "=== ANTHONY STANDING ORDERS (obey; override peer meta-talk) ===\n"
            +s._anthony_orders()
            +"\n\n=== CONVERSATIONAL PATH PRESET: "+p.get("label",p.get("id",""))+" ===\n"
            +p.get("protocol","")
            +"\n\nSeat order: "+order+".\n"
            "You are: "+name+" — ROLE: "+role+".\n"
            "Every turn still includes: (1) short review of prior full round, (2) role-faithful real work, "
            "(3) handoff for the next seat. No pure process theater. No invented Clay closure. No BKM-as-new-lemma.\n"
            "\n=== IMMEDIATE PREDECESSOR HANDOFF ===\n"+prev_block
            +"\n\n=== PREVIOUS FULL ROUND (for your review) ===\n"+s._last_round_blob()
        )
    def render(s,start,name,extra=""):
        priv=s.seat_pref(name,"privacy","full")
        if priv=="prompt":
            orig=s.t
            try:
                s.t=[(w,x) for w,x in orig if w=="Anthony"] or orig[-1:]
                out=s._render_inner(0,name,extra)
            finally:s.t=orig
            return s._redact_paths(out)
        out=s._render_inner(start,name,extra)
        return s._redact_paths(out) if priv=="redact" else out
    def _compact_min_chars(s):
        try:return max(1500,int(s.cfg.get("compact_min_chars") or 8000))
        except Exception:return 8000
    def _compact_every(s):
        try:return max(1,int(s.cfg.get("compact_every") or 4))
        except Exception:return 4
    def _want_compact(s,name,body):
        """Compact every-so-often on large bodies — not every seat every turn.

        Always-on compact was spamming 'PTEX-compacted context' on every agent in every
        round (including when the delta body was tiny and the compact block was *larger*)."""
        if not s.cfg.get("compact_ctx",False):return False
        b=body or ""
        if len(b)<s._compact_min_chars():return False
        n=len(s.t);last=int(getattr(s,"_cc_at",{}).get(name,0) or 0)
        if len(b)>=s._compact_min_chars()*2:return True
        return (n-last)>=s._compact_every()
    def _compact_max_chars(s):
        try:return max(4000,int(s.cfg.get("compact_max_chars") or 12000))
        except Exception:return 12000
    def _compact_delta_chars(s):
        try:return max(1500,int(s.cfg.get("compact_delta_chars") or 5000))
        except Exception:return 5000
    def _mechanical_compact(s,name):
        L=["=== COMPACTED CONTEXT (mechanical) — transcript replaced. Use only what is below. ==="]
        goal=s._goal_line()
        if goal:L.append("GOAL: "+goal)
        r=s._recap(name)
        if r:L.append("MOST RECENT TURN:\n  "+r)
        rej=s._rejections_for(name,cap=4)
        if rej:L.extend(["ALREADY REJECTED:"]+["  - "+x for x in rej])
        L.append("RECENT TAIL (clipped):")
        for w,x in s.t[-4:]:
            L.append("  "+s.disp(w)+": "+s._clip_txt(x,int(s.cfg.get("compact_recap_chars") or 600)))
        L.append("Do not re-derive rejected claims. Prefer numbers from peers over inventing.")
        out="\n".join(L);mx=s._compact_max_chars()
        return out if len(out)<=mx else out[:mx]+"\n…[mechanical compact truncated]"
    def _apply_compact(s,name,body,start=0):
        if not s._want_compact(name,body):return None
        c=s.compact_ctx(name) or s._mechanical_compact(name)
        if not c:return None
        mx=s._compact_max_chars()
        if len(c)>mx:c=c[:mx]+"\n…[compact bank truncated]"
        if start and start>0 and (body or "").strip() and (body or "").strip()!="(nothing new)":
            dmax=s._compact_delta_chars();delta=body if len(body)<=dmax else (body or "")[:dmax]+"\n…[delta truncated]"
            c=c+"\n\n=== NEW SINCE YOUR LAST TURN (verbatim, clipped) ===\n"+delta
        elif not start and (body or "").strip():
            # A from-the-top render (fresh CLI session after a refresh) still needs the CURRENT
            # ask verbatim — the recap clips every turn to ~600 chars, and a re-briefed seat
            # answering a paraphrase of the question is how boards drift. Tail, not head: the
            # newest messages live at the end of the body.
            dmax=s._compact_delta_chars()
            tail=(body or "")[-dmax:]
            c=c+"\n\n=== LATEST MESSAGES (verbatim, clipped tail) ===\n"+tail
        bl=len(body or "")
        if bl and len(c)>=int(bl*0.85):
            c2=s._mechanical_compact(name)
            if start and start>0 and (body or "").strip() and (body or "").strip()!="(nothing new)":
                dmax=min(s._compact_delta_chars(),3000);delta=(body or "")[:dmax]
                c2=c2+"\n\n=== NEW SINCE YOUR LAST TURN (verbatim, clipped) ===\n"+delta
            c=c2 if len(c2)<len(c) else c
        if bl and len(c)>=int(bl*0.9):
            keep=max(2000,int(bl*0.45));c="=== HARD TAIL (overflow) ===\n"+(body or "")[-keep:]
        if bl and len(c)>=bl:return None
        d=getattr(s,"_cc_at",None)
        if not isinstance(d,dict):d={};s._cc_at=d
        d[name]=len(s.t)
        wave=len(s.t)
        if getattr(s,"_cc_wave",None)!=wave:
            s._cc_wave=wave;s._cc_wave_n=0
        if int(getattr(s,"_cc_wave_n",0) or 0)<1:
            s._cc_wave_n=1
            saved=max(0,bl-len(c))
            s.emit({"type":"status","text":"PTEX compact · ~"+str(len(c)//4)+" tok (was ~"+str(bl//4)+", saved ~"+str(saved//4)+") — next in "+str(s._compact_every())+" turns or when context is large"})
        return c
    def _render_inner(s,start,name,extra=""):
        head=("Conversation so far:" if start==0 else "New messages since your last turn:")
        body="\n".join(s.disp(w)+": "+x for w,x in s.t[start:]) or "(nothing new)"
        rules=s.chain_rules(name);p=s.active_path();role=(p.get("roles") or {}).get(name,"Participant")
        sysmsg=("You are "+name+" in Amni-Delve ("+p.get("label","path")+"). Your role: "+role+". "
        "Follow the PATH PRESET and "+s.disp("Anthony")+"'s orders first. Reply ONLY as "+name+", no name prefix. "
        "Be concrete — not board-template noise.")
        if str(s.cfg.get("answer_style") or "concise")!="full":
            # The room reads like a group chat; essays in bubbles read like lectures. This is
            # the one place every seat's prompt passes through, so the style contract lives here.
            sysmsg+=("\nSTYLE: write like a sharp person in a group chat. Lead with the answer. "
             "No preamble, no restating the question, no sign-off, no headers unless asked. "
             "Bullets only when they genuinely compress. A few tight sentences is the default; "
             "go long only when the substance demands it (code, data, proofs) — never to narrate.")
        tail=("\n\n"+extra) if extra else ""
        mem=s._ptex_recall_block(name,s._last_user_q())
        memblk=("\n\n"+mem) if mem else ""
        endline=("\n\nReply now as "+name+" (review → role work → handoff):" if s.cfg.get("board_style")
         else "\n\nReply now as "+name+". Answer directly and naturally — no review or round-recap preamble, no handoff headers. If peers answered before you, silently build on or correct them in the answer itself:")
        c=s._apply_compact(name,body,start)
        if c:
            return sysmsg+"\n\n"+rules+memblk+"\n\n"+c+tail+endline
        return sysmsg+"\n\n"+rules+memblk+"\n\n"+head+"\n"+body+tail+endline
    def _adam_board(s,scan_n=36):
        rows=s.t[-max(1,scan_n):]
        locked=[];open_items=[];corrections=[];assigns=[];demotions=[];undefined=[]
        lock_re=re.compile(r'(?i)\b(locked|closed|done this cycle|algebraically closed|verified bound|exactly correct)\b')
        open_re=re.compile(r'(?i)\b(open|not done|unproved|unproven|still open|not closed|hypothesis|hyps?|local-only|not progress|do not treat|not a closure)\b')
        corr_re=re.compile(r'(?i)\b(correction|backwards|wrong|incorrect|mix-?up|circular|trap|instead|correct (is|facts)|owe a correction|stale|template noise|reject(s|ed|ion)?|refut(e|ed|es|ing)|retract(ed)?|disproven|overturn(ed)?|unbacked|unsupported|conflat(e|ed|es|ing)|mis-?attribut\w*|do(es)? not (give|measure|hold|apply|follow|map)|not a valid|no valid map|already (closed|rejected|settled|corrected)|resurfac\w*|(second|third|fourth) time|again builds|rebuilds the error|do not (use|build|explore|cite|propose)|don.t (use|build|explore|cite|propose)|must not)\b')
        demote_re=re.compile(r'(?i)\b(demote|option 1|unproven|local-only|release( any)? claim|withdrawn|not closure|stop (\"|“)deriving|keep the board honest|no clay|not progress)\b')
        undef_re=re.compile(r'(?i)\b(undefined|no (precise )?definition|empty labels?|glosses only|not a real manuscript|labels only)\b')
        own_re=re.compile(r'(?i)\b(I\'ll take|I will take|taking lead|releasing|ownership|work split|next split|ball is in)\b')
        h_omega_status="OPEN / UNPROVEN (status unknown — check latest peers)"
        h_x_status="OPEN / UNDEFINED until formal statement exists"
        h_coup_status="OPEN / UNDEFINED until formal statement exists"
        algebra="LOCKED: fixed-ε algebra (local structural package only) — not a regularity theorem"
        for w,x in rows:
            if w=="Adam":continue
            txt=x or ""
            low=txt.lower()
            if demote_re.search(txt) and re.search(r'(?i)H\s*[_\\]?\s*ω|H\s*_?\s*omega|Hω|vorticity',txt):
                h_omega_status="OPEN / UNPROVEN (local-only) — demoted; classical energy/enstrophy ≠ global closure"
                demotions.append(f"{w}: demoted/refused H_ω closure path")
            if re.search(r'(?i)releasing any claim|release.*ownership|withdrawn',txt) and re.search(r'(?i)H\s*[_\\]?\s*ω|Hω|omega',txt):
                h_omega_status="OPEN / UNPROVEN (local-only) — no owner for closure"
                demotions.append(f"{w}: released H_ω ownership")
            if undef_re.search(txt) and re.search(r'(?i)H\s*_?\s*X|H_X|uniform',txt):
                h_x_status="OPEN / UNDEFINED — no precise statement in workspace"
            if undef_re.search(txt) and re.search(r'(?i)H\s*_?\s*coup|coupling',txt):
                h_coup_status="OPEN / UNDEFINED — no precise statement in workspace"
            if re.search(r'(?i)circular|BKM.*(trap|equivalent|re-?skin|disguise)|restating the whole',txt):
                corrections.append(f"{w}: circularity warning — do not restate BKM/global regularity as a leaf")
            for line in re.split(r'[\n•]+',txt):
                line=re.sub(r'\s+',' ',line).strip()
                if len(line)<12 or len(line)>300:continue
                if corr_re.search(line) or demote_re.search(line):
                    corrections.append(f"{w}: {line[:230]}")
                elif open_re.search(line):
                    open_items.append(f"{w}: {line[:230]}")
                elif lock_re.search(line) and "algebra" in line.lower():
                    locked.append(f"{w}: {line[:230]}")
                if own_re.search(line):
                    assigns.append(f"{w}: {line[:230]}")
        def dedupe(xs,cap=8):
            out=[];seen=set()
            for x in reversed(xs):
                k=x.lower()[:130]
                if k in seen:continue
                seen.add(k);out.append(x)
                if len(out)>=cap:break
            return list(reversed(out))
        return {
            "algebra":algebra,
            "h_omega":h_omega_status,
            "h_x":h_x_status,
            "h_coup":h_coup_status,
            "locked":dedupe(locked,6),
            "open":dedupe(open_items,8),
            "corrections":dedupe(corrections,12),
            "assigns":dedupe(assigns,8),
            "demotions":dedupe(demotions,8),
        }
    def seat_key(s,name):
        st=re.sub(r'[^A-Za-z0-9_]','_',str(getattr(s,"stamp","") or "room"))
        nm=re.sub(r'[^A-Za-z0-9_]','_',str(name or "shared"))
        return "delve_"+st+"_"+nm
    def seat_model(s,name):
        if name=="Adam":return str(s.cfg.get("adam_bake") or s.cfg.get("adam_mode") or "light").strip() or "light"
        k=SEAT_MODEL_KEY.get(name)
        if k:return str(s.cfg.get(k) or "").strip()
        sm=(s.cfg.get("seat_models") or {}).get(name)
        if sm is not None and str(sm).strip()!="":return str(sm).strip()
        return str((s.seat_cfg(name).get("model") or "")).strip()
    def seat_model_short(s,name,mid=None):
        mid=mid if mid is not None else s.seat_model(name)
        if not mid:
            # "default" told the user nothing - resolve what the CLI will actually run
            try:
                import delve_models as DM
                d=DM.default_model(name)
                if d:return d+" · default"
            except Exception:pass
            return "CLI default"
        if name=="Adam":return "light · 3B" if mid=="light" else ("heavy · 8B" if mid=="heavy" else mid)
        m=str(mid)
        if len(m)<=28:return m
        return m[:12]+"…"+m[-12:]
    def seat_effort(s,name):
        return str(s.seat_pref(name,"effort","") or "").strip().lower()
    def set_seat_effort(s,name,level):
        level=str(level or "").strip().lower()
        try:import delve_models as DM;spec=DM.effort_spec(name);allowed=set(spec.get("levels") or [""])
        except Exception:allowed={"" ,"low","medium","high","xhigh","max","none","minimal"}
        if level and level not in allowed:return False,"unknown effort for "+name
        sp=dict(s.cfg.get("seat_prefs") or {});row=dict(sp.get(name) or {})
        if level:row["effort"]=level
        else:row.pop("effort",None)
        if row:sp[name]=row
        else:sp.pop(name,None)
        s.cfg["seat_prefs"]=sp;return True,""
    def set_seat_model(s,name,mid):
        mid=str(mid or "").strip()
        if mid and (len(mid)>120 or mid.startswith("-") or not re.match(r"^[A-Za-z0-9][A-Za-z0-9._:/\-@+\[\]=,]*$",mid)):
            return False,"model must be a plain model id"
        if name=="Adam":
            # light/heavy are aliases; an explicit bake path selects a specific model to test.
            if mid.startswith("bakes/"):
                ok=False
                try:ok=ADAM is not None and any(b["id"]==mid for b in ADAM.list_bakes())
                except Exception:ok=False
                if not ok:return False,"unknown bake (needs config.json + manifest): "+mid
                s.cfg["adam_bake"]=mid;return True,""
            if mid not in ("","light","heavy"):return False,"adam_mode must be light, heavy, or a bakes/... path"
            s.cfg["adam_mode"]=mid or "light";s.cfg.pop("adam_bake",None);return True,""
        k=SEAT_MODEL_KEY.get(name)
        if k:s.cfg[k]=mid;return True,""
        sm=dict(s.cfg.get("seat_models") or {})
        if mid:sm[name]=mid
        else:sm.pop(name,None)
        s.cfg["seat_models"]=sm
        pc=dict(s.seat_cfg(name));pc["model"]=mid
        provs=dict(s.cfg.get("providers") or {});provs[name]=pc;s.cfg["providers"]=provs
        return True,""
    def resolved_seats(s):
        live=set(s.live_roster());roster=set(s.roster_all());out=[]
        try:import delve_models as DM
        except Exception:DM=None
        for n in AGENTS:
            pc=s.seat_cfg(n);kind=(pc.get("kind") or "").lower()
            mid=s.seat_model(n);eff=s.seat_effort(n)
            spec=(DM.effort_spec(n) if DM else {"levels":["","low","medium","high"],"default":"medium","flag":"--effort","hint":""})
            out.append({"name":n,"label":SEAT_LABEL.get(n,n),"model":mid,"model_short":s.seat_model_short(n,mid),
             "effort":eff or (spec.get("default") or ""),"effort_levels":list(spec.get("levels") or [""]),
             "effort_flag":spec.get("flag") or "","effort_hint":spec.get("hint") or "",
             "cfg_key":SEAT_MODEL_KEY.get(n) or ("adam_mode" if n=="Adam" else "seat_models"),
             "enabled":kind!="off","active":n in roster,"live":n in live,"limit":s.limit_info(n),
             "kind":kind or ("adam" if n=="Adam" else "cli")})
        return out
    def _goal_line(s):
        for w,x in s.t:
            if w in ("Anthony","You") and len((x or "").strip())>20:return re.sub(r'\s+',' ',x).strip()[:400]
        return ""
    def _last_user_q(s,min_len=1):
        for w,x in reversed(s.t[-24:] if isinstance(getattr(s,"t",None),list) else []):
            if w in ("Anthony","You"):
                t=re.sub(r'\s+',' ',(x or "").strip())
                if len(t)>=min_len:return t[:400]
        return s._goal_line()
    def _recap(s,name):
        for w,x in reversed(s.t):
            if w!=name and w!="System" and (x or "").strip():
                return s.disp(w)+": "+re.sub(r'\s+',' ',x).strip()[:s._compact_recap_chars()]
        return ""
    def _compact_recap_chars(s):
        return int(s.cfg.get("compact_recap_chars") or 600)
    def _durable_slot(s,name):return "delve_"+re.sub(r'[^A-Za-z0-9_]','_',str(name or "shared"))
    def _ptex_toks(s,q):
        return [t for t in re.findall(r'[a-z0-9.]{3,}',str(q or "").lower()) if t not in Hub._PTEX_STOP][:12]
    def _ptex_noise_mem(s,text):
        low=re.sub(r'\s+',' ',str(text or "")).strip().lower()
        if not low or len(low)<12:return True
        if re.search(r'(?i)\b(weather in [a-z]+|gstreamer|cross.?domain transfer|looked it up|thinking process|thought process|sources do not contain|compaction|segment_\d+|unrelated memor)\b',low):return True
        if re.search(r'(?i)^\s*(\[looked it up\]|the provided sources do not|i previously searched)',low):return True
        if re.search(r'(?i)\b(boston weather|dll was gone|symbol files)\b',low):return True
        return False
    def _ptex_relevant(s,query,text,min_hits=None):
        if s._ptex_noise_mem(text):return False
        toks=s._ptex_toks(query)
        if not toks:return False
        blob=str(text or "").lower()
        hits=sum(1 for t in toks if t in blob)
        need=min_hits if min_hits is not None else (2 if len(toks)>=3 else 1)
        return hits>=need
    def _ptex_cells(s,name,query,k,include_global=False):
        if ADAM is None or not hasattr(ADAM,"atlas_recall"):return [],[]
        def _take(rows):
            out=[]
            for h in (rows or []):
                a=re.sub(r'\s+',' ',str(h.get("assistant") or "")).strip()[:300]
                u=str(h.get("user") or "")
                if not a or s._ptex_noise_mem(a) or s._ptex_noise_mem(u):continue
                if not (s._ptex_relevant(query,a) or s._ptex_relevant(query,u+" "+a)):continue
                if a not in out:out.append(a)
            return out
        own=[];shared=[]
        for sid in (s.seat_key(name),s._durable_slot(name)):
            try:
                try:r=ADAM.atlas_recall(sid,query,k=k,include_global=include_global)
                except TypeError:r=ADAM.atlas_recall(sid,query,k=k)
            except Exception:continue
            for x in _take(r.get("own")):
                if x not in own:own.append(x)
            for x in _take(r.get("shared")):
                if x not in shared and x not in own:shared.append(x)
        return own,shared
    _PTEX_STOP=set("the a an is are was were be been being do does did done what which who whom whose when where why how this that these those there here i you he she it we they me him her us them my your his its our their of in on at to for with as by from about into over under after before between during without within against among through and or but nor if then else so than too very not no yes can could will would shall should may might must have has had having".split())
    def _ptex_scan(s,name,q,cap=3):
        if ADAM is None:return []
        toks=s._ptex_toks(q)
        if not toks:return []
        need=2 if len(toks)>=3 else 1
        out=[]
        try:
            import urllib.request as _u
            base="http://"+os.environ.get("ADAM_HOST","127.0.0.1")+":"+os.environ.get("ADAM_PORT","7700")
            for slot in (s._durable_slot(name),s.seat_key(name)):
                try:
                    with _u.urlopen(base+"/memory/atlas/cells?slot="+slot+"&limit=600",timeout=6) as r:
                        rows=(json.loads(r.read().decode("utf-8","replace") or "{}").get("cells") or [])
                except Exception:continue
                for c in rows:
                    qtxt=str(c.get("q") or "");atxt=str(c.get("a") or "")
                    if s._ptex_noise_mem(atxt) or s._ptex_noise_mem(qtxt):continue
                    txt=(qtxt+" "+atxt).lower()
                    sc=sum(1 for t in toks if t in txt)
                    if sc>=need:out.append((sc,re.sub(r'\s+',' ',atxt or qtxt).strip()[:300]))
        except Exception:return []
        out.sort(key=lambda x:-x[0])
        seen=set();res=[]
        for sc,a in out:
            if a and a not in seen:seen.add(a);res.append(a)
            if len(res)>=cap:break
        return res
    def _ptex_recall_block(s,name,query,cap=3):
        if not s.cfg.get("ptex_learn",True):return ""
        q=re.sub(r'\s+',' ',str(query or "")).strip()[:500]
        if not q or not s._ptex_toks(q):return ""
        try:own,shared=s._ptex_cells(name,q,int(s.cfg.get("compact_k") or 5),include_global=False)
        except Exception:own,shared=[],[]
        rows=(own+[x for x in shared if x not in own])[:cap]
        if not rows:rows=s._ptex_scan(name,q,cap)
        rows=[r for r in rows if s._ptex_relevant(q,r) and not s._ptex_noise_mem(r)][:cap]
        if not rows:return ""
        try:s.emit({"type":"recall","who":name,"items":rows})
        except Exception:pass
        return ("BACKGROUND MEMORY (PTEX recall — silent context from past rounds. Use it only where relevant; "
         "never quote this block, list these items, or announce that you remember them unless the user explicitly asks):\n"
         +"\n".join("  · "+r for r in rows))
    def compact_ctx(s,name):
        goal=s._goal_line()
        own,shared=s._ptex_cells(name,goal or name,int(s.cfg.get("compact_k") or 5),include_global=False)
        own=[x for x in own if s._ptex_relevant(goal or name,x)]
        shared=[x for x in shared if s._ptex_relevant(goal or name,x)]
        rej=s._rejections_for(name,cap=4)
        if not (own or shared or rej):return ""
        L=["=== COMPACTED CONTEXT (PTEX) — this replaces the transcript. Everything the room established is below. ==="]
        if goal:L.append("GOAL: "+s._clip_txt(goal,500))
        r=s._recap(name)
        if r:L.append("MOST RECENT TURN:\n  "+r)
        if own:L.extend(["WHAT YOU ESTABLISHED BEFORE (your seat):"]+["  - "+s._clip_txt(x,280) for x in own[:int(s.cfg.get("compact_k") or 5)]])
        if shared:L.extend(["WHAT THE ROOM ESTABLISHED (shared PTEX):"]+["  - "+s._clip_txt(x,280) for x in shared[:int(s.cfg.get("compact_k") or 5)]])
        if rej:L.extend(["ALREADY REJECTED — restating any of these is a failed turn:"]+["  - "+x for x in rej])
        L.append("If you need detail that is not here, say what you need instead of guessing. Do not re-derive what is listed.")
        out="\n".join(L);mx=s._compact_max_chars()
        return out if len(out)<=mx else out[:mx]+"\n…[PTEX bank truncated]"
    def _rejections_for(s,who="Adam",scan_n=60,cap=6):
        rej_re=re.compile(r'(?i)\b(reject(s|ed|ion)?|do not (use|build|explore|cite|propose)|don.t (use|build|explore|cite|propose)|must not|stop (using|building|proposing)|unbacked|refut(e|ed|es|ing)|already (closed|rejected|settled)|resurfac\w*|(second|third|fourth) time|same (error|mistake|correction)|again builds|rebuilds the error|building (directly )?on the error|do(es)? not (give|measure|hold|apply|follow|map)|not a valid|no valid map|unsupported|disproven|overturn(ed)?)\b')
        who_re=re.compile(r'(?i)\b'+re.escape(who)+r'\b')
        imp_re=re.compile(r'(?i)^(do not|don.t|never|stop|must not)\b')
        out=[]
        for w,x in s.t[-max(1,scan_n):]:
            if w==who or not (x or "").strip():continue
            for line in re.split(r'(?<=[.;!?])\s+|[\n•]+',x):
                line=re.sub(r'\s+',' ',line).strip()
                if len(line)<14 or len(line)>320 or not rej_re.search(line):continue
                if not who_re.search(line) and not imp_re.match(line):continue
                out.append(s.disp(w)+": "+line)
        seen=set();ded=[]
        for x in reversed(out):
            k=re.sub(r'[^a-z0-9]+','',x.lower())[:110]
            if k in seen:continue
            seen.add(k);ded.append(x)
            if len(ded)>=cap:break
        return list(reversed(ded))
    def _corrections_by_agent(s,items):
        out={}
        for w in {w for w,_ in items if w in AGENTS}:
            r=s._rejections_for(w,scan_n=max(12,len(items)*3),cap=3)
            if r:out[w]=" | ".join(x[:220] for x in r)[:600]
        return out
    def _update_adam_handoff_summary(s):
        summary_path=os.path.join(s.work,"adam_handoff_summary.txt")
        board=s._adam_board(scan_n=40)
        last_who,last_text=s.t[-1] if s.t else ("System","(empty)")
        dp=os.path.join(s.work,"adam_peer_directives.txt")
        try:drx=open(dp,encoding="utf-8",errors="replace").read().strip() if os.path.isfile(dp) else ""
        except Exception:drx=""
        lines=[
            "CANONICAL BOARD (auto; LATEST demotions/corrections win over older optimism)",
            f"Last non-board speaker signal: {last_who}",
            s._clip_txt(last_text,260),
            "",
            *((["PEER DIRECTIVES (persistent; do these FIRST, before board talk; echo any required tokens):",s._clip_txt(drx,900),""]) if drx else []),
            "STATUS FIELDS (copy these exactly unless a NEWER peer message overrides):",
            f"- {board['algebra']}",
            f"- H_ω: {board['h_omega']}",
            f"- H_X^unif: {board['h_x']}",
            f"- H_coup: {board['h_coup']}",
            "- IN PROGRESS: none unless a speaker posted a concrete new inequality this round",
            "- OWNERS for closure: none unless someone both claimed AND was not withdrawn",
        ]
        if board["demotions"]:
            lines.append("DEMOTIONS (must appear under CORRECTIONS HONORED):")
            lines.extend("- "+x for x in board["demotions"][:6])
        if board["corrections"]:
            lines.append("CORRECTIONS:")
            lines.extend("- "+x for x in board["corrections"][:8])
        if board["assigns"]:
            lines.append("RECENT ASSIGNS / RELEASES:")
            lines.extend("- "+x for x in board["assigns"][:6])
        lines.append("ANTHONY ORDERS:")
        lines.append(s._anthony_orders(max_msgs=2,max_chars=500))
        lines.append("ADAM JOB: if assigned concrete calc/numerical tests, do that work first; board second. Never repost stale 'candidate for closure' or 'NEXT: derive H_ω' after demotion. Empty LOCKED/OPEN without work = fail when a handoff exists.")
        summary="\n".join(lines)
        if len(summary)>3200:summary=summary[:3197]+"…"
        try:
            with open(summary_path,"w",encoding="utf-8") as f:f.write(summary+"\n")
        except Exception:pass
        try:
            with open(os.path.join(s.work,"delve_board.json"),"w",encoding="utf-8") as f:
                json.dump(board,f,indent=2)
        except Exception:pass
        return summary
    _WORK_VERB=re.compile(r'(?i)\b(?:write|create|build|implement|generate|save|add|append|refactor|fix|patch|edit|run|execute|call|make|scaffold|rename|delete)\b')
    _WORK_ARTIFACT=re.compile(r'(?i)(?:\b[\w./\\-]+\.(?:py|pyw|js|mjs|ts|tsx|jsx|json|md|txt|html|css|rs|go|c|h|cpp|java|rb|sh|ps1|toml|yaml|yml|ini|cfg)\b|\bfile_write\b|\bfile_read\b|\brun_python\b|\bcode_edit\b|\bcode_diff\b|\btest_run\b|\bshell\b|\byour tools\b|\bthe workspace\b)')
    @staticmethod
    def _is_code_work(txt):
        t=(txt or "").strip()
        return bool(t) and bool(Hub._WORK_ARTIFACT.search(t)) and bool(Hub._WORK_VERB.search(t))
    _STYLE_RULES=(
     (r'(?i)\b(more compact|compact|shorter|brief(?:er)?|concise|tl;?dr|less text|trim it|keep it short)\b',
      'FORMAT: keep it SHORT — a few sentences or tight bullets. No headings, no preamble, no restating the question.'),
     (r'(?i)\b(more detail|greater detail|expand|elaborate|thorough|in.depth|deeper|explain more|walk me through|show your work)\b',
      'FORMAT: go DEEPER — explain the reasoning step by step and show the working.'),
     (r'(?i)\b(bullets?|list form|as a list|bullet.?point)\b','FORMAT: answer as a flat bullet list.'),
     (r'(?i)\b(just the code|code only|only the code|no explanation|no commentary)\b',
      'FORMAT: reply with the code only, in one fenced block, no commentary.'),
     (r'(?i)\b(table|tabular|side by side compar)\w*\b','FORMAT: present the answer as a markdown table.'),
     (r'(?i)\b(plain english|simple terms|like i.?m five|eli5|non.?technical|no jargon)\b',
      'FORMAT: use plain language — short sentences, no jargon.'),
     (r'(?i)\b(no headings?|no headers?|without headings?|stop using headings?|drop the headings?)\b',
      'FORMAT: do NOT use section headings of any kind.'),
     (r'(?i)\b(prose|paragraphs?|not bullets|stop bulleting)\b','FORMAT: write in prose paragraphs, not bullets.'))
    _PROOF_RX=re.compile(r'(?i)(H_ω|H_omega|H_dev|H_X|H_coup|\bRFD\b|Vieillefosse|\bClay\b|proof tree|LOCKED:|axisym|Navier|Hou.?Luo|vorticity)')
    _STYLE_UI_RX=re.compile(r'(?i)^[\s\-_]*(?:the\s+|a\s+|all\s+|every\s+)?(?:response|answer|reply|message|button|control|toggle|switch|mode|panel|menu|drawer|dialog|modal|indicator|selector|dropdown|drop.?down|picker|card|row|section|view|tab|rail|strip|bar|icon|pane|chip|flow|chain|chunk|thread|layout|setting|feature|option|field|box|window|column|grid|header|footer|sidebar)s?\b')
    _STYLE_WEAK=("expand","compact","deeper","thorough","brief","briefer","concise","table","bullet","bullets","list form")
    @staticmethod
    def _style_hits(x):
        """A format directive is about the REPLY. Anthony's "expand responses" and "compact view"
        are feature nouns — the old `re.search` read them as "go DEEPER" and pinned that hint on
        every seat for the rest of the session, which is why Adam kept titling turns
        "go DEEPER - Reasoning & Working" and planning work instead of doing it. A weak single-word
        trigger now only counts when the next word is not a UI object."""
        out=[]
        for rx,rule in Hub._STYLE_RULES:
            for m in re.finditer(rx,x or ""):
                if m.group(0).strip().lower() in Hub._STYLE_WEAK and Hub._STYLE_UI_RX.match((x or "")[m.end():m.end()+40]):continue
                out.append(rule);break
        return out
    def _style_pref(s):
        for w,x in reversed(s.t[-16:]):
            if w!="Anthony":continue
            hits=Hub._style_hits(x)
            if hits:return hits
            # A newer Anthony message with no directive CLEARS the old one. Walking further back
            # let a directive from ten turns ago outlive the request that produced it.
            if len((x or "").strip())>40:return []
        return []
    def _proofish(s):
        return any(Hub._PROOF_RX.search(x or "") for w,x in s.t[-14:])
    def _adam_direct_ask(s):
        for w,x in reversed(s.t):
            if w=="Anthony":return (x or "").strip()
            if w=="Adam" or w in AGENTS:return ""
        return ""
    def _adam_answer_mode(s,txt):
        t=(txt or "").strip()
        if not t or len(t)>1200:return ""
        if ADAM is not None and s.cfg.get("adam_intent",True):
            try:
                r=ADAM.intent(t)
                if r.get("embedder") and r.get("conf",0)>=float(os.environ.get("AMNI_DELVE_INTENT_FLOOR","0.45")):
                    lab=r.get("label") or ""
                    if lab in ("build_request","scan_ingest","math_calc"):return ""
                    if lab in ("memory_recall","introspection","profile_about_me","greeting","persona_character"):return "answer"
            except Exception:pass
        if re.search(r'(?i)(recap|summar[iy]|catch me up|status update|in your own words|what did (we|you)|any (errors|mistakes)|made (any )?(errors|mistakes)|were you wrong|what went wrong|self-?audit|admit|apolog|do you (know|remember|have)|explain (yourself|what))',t):return "answer"
        return "answer" if (t.endswith("?") or re.match(r'(?i)^(who|what|why|when|where|how|do|did|does|are|is|can|could|should|have|has|was|were|will|would)\b',t)) else ""
    _MATH_RX=re.compile(
        r'(?i)(compute|calculat|numerical|stress-?test|derive|integrate|'
        r'tr\s*\(|sigma|σ|RFD|H_dev|Γ|Gamma|depletion|amplif|'
        r'\bbpw\b|bits?\s*per|bit-?rate|vram|mipmap|texel|GB|TB|N\s*[=≈]|'
        r'quantiz|codebook|entropy|occupanc|Galois|GF\s*\(?\d|'
        r'\d+\s*[x×]\s*\d+|how many|how much|'
        r'equation|formula|algebra|theorem|inequal|asymptot|log_?\d|log2|log10|'
        r'\\frac|\\sum|\\int|\$\$|≈|≤|≥|±|√|∞|matrix|eigen|gradient|'
        r'\d+\s*%|\d+\.\d+|e[+-]?\d+|mantissa|exponent|fp16|fp32|int4|int8|nvfp4)')
    _PROSE_GATE_RX=re.compile(r'(?i)(\b(no calc(ulation)?s?|no math( execution)?|no new (math|calculations?|arithmetic)|no numbers?|zero numbers?|prose only|plain prose|prose bullets|in (two|three|2|3) sentences?|no tool calls?|zero tools?|text.shaped)\b|\bdo not (run|perform|do|execute)\b[^\n.]{0,30}\b(math|arithmetic|calculations?|numbers?|tools?)\b|\b(zero|no)\b[^\n.]{0,40}\b(board|digits?|numbers?|template)\b|\b(braid|rikku|shop|plain)\s+prose\b|\btemplate noise\b)')
    _NUMDEMAND_RX=re.compile(
        r'(?i)(report the number|give me the number|\bbpw\b|compute|calculat|how many|how much|'
        r'\d\s*[+*^×]\s*\d|\d\s+[-/]\s+\d|=\s*-?\d|log\s*[₂2]?\s*\(|\bsolve\b|\bevaluate\b\s+(the\s+)?(expr|integral|sum|formula))')
    _DEGEN_RX=re.compile(r'(?i)^\W*((the\s+)?(final\s+)?(answer|value|result)\s+(of\s[\s\S]{0,60}?)?is\b[^\n]{0,40}|-?\d[\d,. ]{0,12})\W*$')
    _LEDGER_RX=re.compile(r'(?im)^\W{0,12}(?:\*\*)?(?:LOCK|STATUS|OWNERS?|VERDICT|BOARD|CATALOG)(?:\*\*)?\s*[:—]|=\s*\**\s*(?:LIVE|DEAD|OPEN|CLOSED|SUPERSEDED|UNMEASURED|PROVEN|VERIFIED|MEASURED)\b')
    _SYNTH_RX=re.compile(r"(?i)^\W{0,4}the answer is\b.{0,80}\(from [\w, ]+\)|\bIntermediate values:\s|\bI could not complete this goal\b|\bI stopped before finishing \(")
    _SIT_RX=re.compile(r'(?i)^\W{0,12}(?:\*\*)?\s*(?:sit|sit tight|stand[- ]down|stand down|hold off|stay out|do not (?:run|act|post|reply|respond)|no (?:action|reply|response) (?:needed|required))\b')
    _CLI_NOISE_RX=re.compile(r'(?im)^\s*(?:openai\s+codex\s+v[\d.]+|codex\s+v[\d.]+|--------+|workdir\s*:|model\s*:|provider\s*:|approval\s*:|sandbox\s*:|reasoning\s+(?:effort|summaries)\s*:|session\s+id\s*:|tokens?\s+used\s*:|user\s*$|thinking\s*$)[^\n]*\n?')
    def _mathish(s,txt):
        t=txt or ""
        if Hub._MATH_RX.search(t):return True
        return bool(len(re.findall(r'\d',t))>=4 and re.search(r'(?i)\d\s*[=+*^×]\s*\d|\d\s+[-/]\s+\d|\d+\s*(bits?|bytes?|bpw)\b',t))
    _QUOTED_Q_RX=re.compile(r'(?s)["“”*]\s*([A-Za-z][^*"“”\n]{6,200}\?)\s*["“”*]')
    def _hoist_q(s,t):
        m=Hub._QUOTED_Q_RX.search(t or "")
        return (m.group(1).strip()+" — context: "+re.sub(r'\s+',' ',(t or "").strip()))[:1200] if m else (t or "")[:1200]
    def _adam_relay(s,prev_who):
        return prev_who=="prose_gate" and (getattr(s,"_pg_src","")=="peer" or not s._adam_direct_ask())
    def _adam_prose_gate(s):
        s._pg_src=""
        direct=s._adam_direct_ask()
        if direct and Hub._PROSE_GATE_RX.search(direct):
            s._pg_src="anthony";return s._hoist_q(direct)
        for w,x in reversed(s.t[-8:]):
            if w=="Adam" or not x:continue
            mm=s._adam_hdr(x)
            if mm:
                head=mm.group(1).strip()[:1200]
                if Hub._PROSE_GATE_RX.search(head):
                    s._pg_src="peer";return s._hoist_q(head)
            if Hub._PROSE_GATE_RX.search(x) and re.search(r'(?i)(?:hand-?off|next\s+seat|then)\b[^\n]{0,60}\bAdam\b|\bAdam\b[^\n]{0,40}(?:[:—]|should|next)',x):
                aq=re.search(r'(?is)(?:Assignment|ask|query)\**\s*[:—]\s*(.+?)(?:\n\s*[-*]|\n\s*\*\*|$)',x)
                s._pg_src="peer"
                if aq:return s._hoist_q((aq.group(1).strip()+" "+(re.search(r'(?is)Requirements?\**\s*[:—]\s*(.+)$',x).group(1).strip() if re.search(r'(?is)Requirements?\**\s*[:—]\s*(.+)$',x) else ""))[:1200])
                qq=re.search(r'(?s)[\*"“]([^*"”]{8,200}\?)[\*"”]',x)
                if qq:return (qq.group(1).strip()+" "+x)[:1200]
                return re.sub(r'\s+',' ',x.strip())[:1200]
        return ""
    _ADAM_HDR_RX=re.compile(r'(?im)^[\s>*_\-–—#0-9.)\]|]{0,10}(?:\*\*)?Adam\b(?:\*\*)?(?:\s*[\(\[][^\n)\]]{0,80}[\)\]])?(?:\*\*)?[^\n:—]{0,30}(?:\*\*)?\s*[:—]\s*')
    _ADAM_TAIL_RX=re.compile(r'(?is)(?:\*\*)?Adam(?:\*\*)?\s*[:\-—]\s*(.+)$')
    _ADAM_HANDOFF_RX=re.compile(r'(?im)^[\s>*_#0-9.)\]]{0,10}(?:\*\*)?\s*(?:hand-?off|handoff)\b[^\n]{0,80}\bAdam\b|^[\s>*_#0-9.)\]]{0,10}(?:\*\*)?(?:Next\s+seat|Then)\b[^\n]{0,40}\bAdam\b|(?:\*\*)?(?:Then\s+Adam|Next\s+seat\s*[:—]?\s*(?:\*\*)?Adam)')
    _ADAM_TASKISH_RX=re.compile(r'(?is)^\s*[\*"\'`>\-\d.)\]]{0,12}(why|what|how|when|where|who|catalog|record|board|restate|summar|prefer|hydrogen|prose only|no tool|answer|explain|compute|calculate|respond|assignment|fryd|\*)')
    _ADAM_REVIEWISH_RX=re.compile(r'(?is)^\s*(blanked|still blanks|failed|did not|couldn|routed|inherited|misclass|soft-?sold|re-?audit)')
    def _adam_hdr(s,x):
        t=x or ""
        hs=[m for m in Hub._ADAM_HDR_RX.finditer(t)]
        ho=[m for m in Hub._ADAM_HANDOFF_RX.finditer(t)]
        if hs and ho:
            hs=[m for m in hs if m.start()>=ho[-1].start()]
            if not hs:return None
        if not hs:
            if ho:return re.compile(r'(?is)\s*(.+)$').search(t,ho[-1].end())
            return Hub._ADAM_TAIL_RX.search(t) if re.search(r'(?i)\bAdam\b\s*[:—]',t) else None
        def _tail(m):
            return re.compile(r'(?is)\s*(.+)$').search(t,m.end())
        def _head_txt(m):
            g=_tail(m);return (g.group(1) if g else "")[:240]
        def _head_line(m):
            return _head_txt(m).split("\n",1)[0]
        alive=[m for m in hs if not Hub._ADAM_REVIEWISH_RX.match(_head_line(m)) or "?" in _head_line(m)]
        if not alive:return None
        task=[m for m in alive if Hub._ADAM_TASKISH_RX.match(_head_txt(m)) or "?" in _head_txt(m)[:400]]
        pick=(task or alive)[-1]
        return _tail(pick)
    def _adam_assigned_work(s):
        pg=s._adam_prose_gate()
        if pg:return False,"prose_gate",pg,pg
        fb=getattr(s,"_flow_brief","")
        if fb:return True,"flow",fb,""
        direct=s._adam_direct_ask()
        # Anthony math/compute/code → WORK (tools). Pure chat → DIRECT.
        if direct and (s._is_code_work(direct) or s._mathish(direct)):
            return True,"Anthony",direct,""
        if direct and s._adam_answer_mode(direct) and not s._is_code_work(direct) and not s._mathish(direct):
            return False,"Anthony",direct,direct
        prev_who,prev_txt=s._prev_in_chain("Adam")
        assign="";m=None
        # A handoff to Adam can come from ANY seat, not just the one before it in the chain —
        # when the intermediate seat times out, prev_txt is empty and the real "Adam: Catalog…"
        # instruction two turns back was invisible. Scan recent non-Adam turns, newest first.
        for w,x in reversed(s.t[-8:]):
            if w=="Adam" or not x:continue
            mm=s._adam_hdr(x)
            if mm:m=mm;prev_who=prev_who or w;assign=mm.group(1).strip();break
        if not assign and prev_txt:
            m=s._adam_hdr(prev_txt)
            if m:assign=m.group(1).strip()
            elif re.search(r'(?i)handoff\s*(→|->|to|for)\s*(next\s+seat\s*)?\(?\s*Adam|Adam\s*:\s*Proceed|for Adam|Adam should|Adam next|next\s+seat\s*[:—]?\s*\**Adam|Then\s+Adam',prev_txt):
                assign=prev_txt.strip()
        for w,x in reversed(s.t[-16:]):
            if w=="Anthony" and (s._mathish(x) or s._is_code_work(x) or re.search(r'(?i)\bAdam\b.*(compute|calculate|run|test|numerical|math)',x or "")):
                assign=((assign+"\n\n") if assign else "")+s.disp("Anthony")+": "+(x or "").strip()
                break
        if not assign and prev_txt and (s._mathish(prev_txt) or s._is_code_work(prev_txt)):
            assign=prev_txt.strip()
        # Room is mid-math debate: last few peer posts are numerical → Adam does WORK too
        if not assign:
            recent="\n".join((x or "") for w,x in s.t[-6:] if w not in ("Adam",))
            if s._mathish(recent) and Hub._NUMDEMAND_RX.search(recent) and re.search(r'(?i)\bAdam\b',recent):
                assign=recent[-3500:]
                prev_who=prev_who or "room"
        mathish=s._mathish(assign)
        # The DIRECT Adam instruction (text right after "Adam:") outranks the rest of the
        # assign blob. "Adam: Catalog X" must route to prose even when the surrounding round
        # is full of "count how many" phrases — that mismatch produced calc noise on
        # explicit board handoffs ("The answer is 18 (from file_read, calc)").
        head=(m.group(1).strip() if prev_txt and m else (assign or ""))[:220]
        s._sit=bool(head) and bool(Hub._SIT_RX.match(head))
        explicit_board=s._sit or bool(re.search(r'(?i)^\W*(catalog|record|board|restate|summari[sz]e|lock|status|owners?)\b',head)) or bool(re.search(r'(?i)\bno calc( output)?\b|\bno numbers?\b|\bprose (bullets|only)\b',assign or ""))
        catalogish=explicit_board or bool(Hub._LEDGER_RX.search(assign or "")) or (bool(re.search(r'(?i)\b(catalog|steelman|locked vs\.? open|board state|restate|handoff|seat role|relay protocol)\b',assign or "")) and not Hub._NUMDEMAND_RX.search(assign or ""))
        workish=bool(assign) and not catalogish and (mathish or Hub._is_code_work(assign) or s._mathish(assign))
        return workish,prev_who or "",assign,""
    def _seat_dump(s,sys_p,workish,direct,assign,prompt,sid,stage):
        try:
            _td=os.path.join(os.path.dirname(os.path.abspath(__file__)),"tmap");os.makedirs(_td,exist_ok=True)
            _pt=(prompt or "");_blob_q=_pt+" "+(assign or "")
            _has_q=bool(re.search(r'(?i)LIVE TASK THIS TURN|YOUR ASSIGNED TASK|ANTHONY ASKED YOU DIRECTLY|ANTHONY\'S QUESTION, RELAYED|RELAYED QUESTION|hydrogen embrittlement|prefer the HAZ|bipolar plate|fryd goes wrong',_blob_q))
            _safe=re.sub(r'[^\w.\-]+','_',str(sid or "na"))[:80]
            _dump={"stage":stage,"sys_p":sys_p,"prompt_head":_pt[:400],"prompt_tail":_pt[-600:],"len_prompt":len(_pt),"session_id":sid,"workish":bool(workish),"direct":bool(direct),"assign_head":(assign or direct or "")[:400],"has_live_task":_has_q,"style_pref":s._style_pref(),"sys_p_len":len(sys_p or ""),"code_ver":"v6.20.236","relay":bool(re.search(r'(?i)RELAYED QUESTION|ANTHONY\'S QUESTION, RELAYED',_pt+" "+(sys_p or "")))}
            _blob=__import__("json").dumps(_dump,indent=1,ensure_ascii=False)
            open(os.path.join(_td,"adam_seat_dump_"+_safe+".json"),"w",encoding="utf-8").write(_blob)
            open(os.path.join(_td,"adam_seat_dump_stage_"+re.sub(r'[^\w]+','_',str(stage or "na"))[:24]+".json"),"w",encoding="utf-8").write(_blob)
            open(os.path.join(_td,"adam_seat_dump.json"),"w",encoding="utf-8").write(_blob)
        except Exception:pass
    def _adam_workspace_pack(s,max_chars=4500):
        docs=os.path.join(s.work,"docs")
        names=["clay_ns_rfd_vieillefosse_sign_v1.md","clay_ns_hdev_sign_axisym_gamma_v1.md","clay_ns_kt_onsager_anisotropic_v1.md"]
        chunks=[]
        for nm in names:
            p=os.path.join(docs,nm)
            if not os.path.isfile(p):continue
            try:txt=open(p,encoding="utf-8",errors="replace").read()
            except Exception:continue
            if not txt.strip():continue
            chunks.append("### FILE "+nm+"\n"+s._clip_txt(txt,max_chars//max(1,len(names))))
        if not chunks:return "(no workspace math docs found under workspace/docs/)"
        return "\n\n".join(chunks)
    def render_adam(s,extra=""):
        n=int(s.cfg.get("adam_ctx_turns") or os.environ.get("AMNI_DELVE_ADAM_CTX","14") or 14)
        mc=int(s.cfg.get("adam_msg_chars") or os.environ.get("AMNI_DELVE_ADAM_MSG_CHARS","1400") or 1400)
        board=s._adam_board(scan_n=max(28,n*2))
        summary=s._update_adam_handoff_summary()
        workish,prev_who,assign,direct=s._adam_assigned_work()
        rows=s.t[-max(1,n):]
        lines=[]
        for w,x in rows:
            if w=="Adam":
                lines.append("Adam (YOU, previously — peers are replying to THIS; do not repeat or re-template it): "+s._clip_txt(x,700))
            else:
                lines.append(s.disp(w)+": "+s._clip_txt(x,mc if w!=prev_who else max(mc,2400)))
        p=s.active_path();role=(p.get("roles") or {}).get("Adam","Peer / proof-tree")
        pack=s._adam_workspace_pack() if workish else ""
        # Pull durable ledger + atlas cells into EVERY Adam turn (this was the missing half of PTEX learn).
        goal_q=(assign or direct or s._goal_line() or "roundtable")[:500]
        numeric=bool(workish and Hub._NUMDEMAND_RX.search(assign or direct or goal_q or ""))
        led=""
        if ADAM is not None and hasattr(ADAM,"coding_brief") and s.cfg.get("ptex_learn",True) and workish:
            try:led=ADAM.coding_brief(goal_q,k=int(s.cfg.get("compact_k") or 5),numeric=numeric) or ""
            except TypeError:
                try:led=ADAM.coding_brief(goal_q,k=int(s.cfg.get("compact_k") or 5)) or ""
                except Exception:led=""
            except Exception:led=""
        atl=""
        # Atlas recall is CONVERSATION memory, not coding lessons — it must run on every turn or
        # Adam is write-only: _ptex_write stores each reply but nothing is ever read back, so it
        # answers "NOT STORED" to facts it demonstrably holds. The ledger brief (led) stays
        # gated on workish; relevance is enforced Amni-Ai-side by learn_hygiene.rel_ok.
        if s.cfg.get("ptex_learn",True):
            try:
                # Recall must be keyed on what was ACTUALLY ASKED. Prefer last user turn.
                rq=s._last_user_q(1) or ""
                if not rq:
                    for w,x in reversed(s.t[-6:]):
                        if w!="Adam" and (x or "").strip():rq=re.sub(r'\s+',' ',x).strip()[:300];break
                own,shared=s._ptex_cells("Adam",rq or goal_q,int(s.cfg.get("compact_k") or 5))
                bits=[]
                for h in (own or [])[:3]:
                    bits.append("own: "+s._clip_txt(str(h),280))
                for h in (shared or [])[:3]:
                    bits.append("shared: "+s._clip_txt(str(h),280))
                if bits:atl="=== PTEX ATLAS RECALL ===\n"+"\n".join("- "+b for b in bits)
            except Exception:atl=""
        mem_block=("\n\n".join(x for x in (led,atl) if x)).strip()
        if direct:
            relay=s._adam_relay(prev_who)
            audit=bool(re.search(r'(?i)(error|mistake|wrong|went wrong|audit|admit|apolog|correct(ed|ion)?)',direct))
            sysmsg=(
                "You are Adam (Amni-Ai), ROLE: "+role+" under path "+p.get("label",p.get("id",""))+".\n"
                +("MODE: RELAYED QUESTION — a peer seat is passing you Anthony's question, quoted verbatim below. "
                  "It IS the question. Do not ask for it to be repeated; answer it.\n" if relay else
                  "MODE: DIRECT ANSWER TO ANTHONY — he is talking to YOU, right now, not handing you a math task.\n")
                +"HARD RULES:\n"
                "1) Answer the question below, in plain prose. Nothing else is the task this turn.\n"
                "2) FORBIDDEN this turn: LOCKED / OPEN / IN PROGRESS / CORRECTIONS HONORED / NEXT headings, board "
                "templates, bullet status dumps, and restating old math he did not ask about. A board reply here is a FAILED turn.\n"
                +("3) The quoted question is the whole task. Asking Anthony to restate it, or saying you lack context, "
                  "is a FAILED turn — the question is right there.\n"
                  "4) Be honest and specific. If you don't know the ANSWER, say that plainly — but answer the question asked.\n"
                  if relay else
                  "3) Do not answer the previous speaker's handoff — that is stale. Anthony's message overrides it.\n"
                  "4) Be honest and specific. 'I don't know' or 'I don't have that' is a valid, respected answer.\n")
                +("5) He is asking you to audit yourself. Read the REPEATED-ERROR GUARD below: those are YOUR errors, "
                  "already established by peers. Name them plainly as your own, say what was wrong and what the correct "
                  "position is. Do NOT claim a clean record while that guard is non-empty. If the guard is empty, say so "
                  "honestly rather than inventing a confession.\n" if audit else ""))
            assign_block=("=== ANTHONY'S QUESTION, RELAYED BY A PEER SEAT — ANSWER THIS ===\n" if relay else "=== ANTHONY ASKED YOU DIRECTLY — THIS IS YOUR TASK THIS TURN ===\n")+direct[:1200]
            end=("Reply as Adam — answer the quoted question now, in prose, no board, and do not ask for it to be repeated:" if relay else "Reply as Adam — answer Anthony's question directly, in prose, no board:")
        elif workish:
            sysmsg=(
                "You are Adam (Amni-Ai), ROLE: "+role+" under path "+p.get("label",p.get("id",""))+".\n"
                +p.get("protocol","")+"\n"
                "MODE: ASSIGNED WORK (not board-only).\n"
                "The previous speaker handed you a CONCRETE task. Execute THAT task — the one quoted below — and nothing else.\n"
                "HARD RULES:\n"
                "1) Section WORK first (required): restate the assigned ask in 1–2 lines IN YOUR OWN WORDS, then do it.\n"
                "   - Match the task's domain. If it is math, show equations. If it is code, show code. If it is a "
                "catalog/review/design task, write prose or a table. Do NOT force numbers onto a non-numeric task.\n"
                "   - A bare number, a bare 'The answer is X', or one sentence with no reasoning is a FAILED turn.\n"
                "   - You have FULL PEER TOOLS in the shared workspace — same as Claude/Grok/Google. Read, search, "
                "write and RUN files. LOOK before you claim: never say DATA MISSING for something you did not actually "
                "try to open. Only after checking may you say DATA MISSING, and then state the exact path you looked for. "
                "Do NOT invent measured numbers — run them or mark them unmeasured.\n"
                "   - If you cannot finish every part, finish at least one fully; list the rest as blocked with the reason.\n"
                "2) Forbidden as your entire reply: empty LOCKED/OPEN, only generic NEXT bullets, template scrapes, "
                "a claim with no supporting work behind it.\n"
                "3) After WORK, short BOARD (headings LOCKED / OPEN / IN PROGRESS / CORRECTIONS HONORED / NEXT) "
                "that reflects THIS turn's work only. LOCKED = peer-verified this session; everything else is OPEN.\n"
                "4) No victory claims you cannot point at work for. No copying old Adam templates.\n"
                "5) LATEST demotions/corrections still win over optimism."
            )
            assign_block=(
                "=== YOUR ASSIGNED TASK (from "+(prev_who or "predecessor")+") ===\n"
                +(assign[:3500] if assign else "(see predecessor handoff in transcript)")
                +(("\n\n=== WORKSPACE DOCS (use these; do not ignore) ===\n"+pack) if (pack and "no workspace math docs" not in pack) else "")
            )
            end="Reply as Adam: WORK (execute the assigned task, with reasoning shown) first, then short BOARD:"
        elif not s._proofish():
            _st=s._style_pref()
            sysmsg=(
                "You are Adam (Amni-Ai) at a round table with other AIs. ROLE: "+role+".\n"
                "Answer what was actually asked, directly and usefully.\n"
                "SHAPE THE REPLY TO THE REQUEST — prose for an explanation, ONE fenced block for code, "
                "bullets for a list, a table for a comparison, a short paragraph for a simple question.\n"
                "NEVER impose a fixed template. Do NOT emit BOARD / LOCKED / OPEN / IN PROGRESS / OWNERS / "
                "CORRECTIONS HONORED / NEXT / 'Task Executed' headings — those belong to a proof board and this is not one.\n"
                "No preamble, no restating the question back, no self-congratulation, no status theatre.\n"
                "If you ran tools, say plainly what you did and what came back."
                +(("\n"+"\n".join(_st)) if _st else ""))
            assign_block=(
                "=== YOUR ASSIGNED TASK (from "+(prev_who or "predecessor")+") — answer THIS, nothing else ===\n"
                +assign[:3500]
            ) if (assign or "").strip() else ""
            end="Reply as Adam:"
        else:
            sysmsg=(
                "You are Adam (Amni-Ai), ROLE: "+role+" under path "+p.get("label",p.get("id",""))+".\n"
                +p.get("protocol","")+"\n"
                "MODE: BOARD UPDATE (no new computational assignment detected).\n"
                "HARD RULES:\n"
                "1) LATEST peer consensus beats any older board scrape or your previous template.\n"
                "2) If peers demoted H_ω to OPEN/UNPROVEN (local-only), you MUST write that. Forbidden after demotion: "
                "'candidate for closure', 'proceed with deriving H_ω'.\n"
                "3) CORRECTIONS HONORED must list real corrections from this chat. Never invent empty theater.\n"
                "4) If H_X / H_coup lack definitions, mark OPEN/UNDEFINED.\n"
                "5) Output headings: LOCKED / OPEN / IN PROGRESS / OWNERS / CORRECTIONS HONORED / NEXT — but each bullet "
                "must cite a concrete peer claim or equation, not process noise.\n"
                "6) No victory essays. No Clay claims."
            )
            assign_block=""
            end="Reply as Adam with an honest BOARD (cite real claims, no empty template):"
        canon=(
            "=== CANONICAL STATUS (use unless a newer message overrides) ===\n"
            f"- {board['algebra']}\n"
            f"- H_ω: {board['h_omega']}\n"
            f"- H_X^unif: {board['h_x']}\n"
            f"- H_coup: {board['h_coup']}\n"
            "=== DEMOTIONS ===\n"+("\n".join("- "+x for x in board["demotions"]) if board["demotions"] else "- (none parsed)")+"\n"
            "=== CORRECTIONS ===\n"+("\n".join("- "+x for x in board["corrections"][:10]) if board["corrections"] else "- (scan transcript)")+"\n"
            "=== ANTHONY ORDERS ===\n"+s._anthony_orders(max_msgs=3,max_chars=700)+"\n"
            "=== HANDOFF FILE ===\n"+summary
        )
        if assign_block:canon=assign_block+"\n\n"+canon
        if mem_block:canon=mem_block+"\n\n"+canon
        rej=s._rejections_for("Adam")
        if rej:canon=("=== REPEATED-ERROR GUARD — peers ALREADY rejected these ===\n"
         "These were addressed to you and settled. Rebuilding any hypothesis on them is a FAILED turn — do not "
         "restate, rename, or extend them. If one of these is the only thing you have, say so plainly and answer "
         "the open binary question instead.\n"+"\n".join("- "+x for x in rej)+"\n\n")+canon
        tail=("\n\n"+extra) if extra else ""
        body="\n".join(lines)
        live_task=""
        if (assign or "").strip():
            live_task=("\n\n=== LIVE TASK THIS TURN (overrides reject-ledger and compact residue) ===\n"
             +(assign[:3500].strip())+"\n"
             "Answer the LIVE TASK only. Do not complete or rewrite rejected items listed above.")
        elif (direct or "").strip():
            live_task=("\n\n=== LIVE TASK THIS TURN (overrides reject-ledger and compact residue) ===\n"
             +(direct[:3500].strip())+"\n"
             "Answer the LIVE TASK only. Do not complete or rewrite rejected items listed above.")
        c=s._apply_compact("Adam",body,0)
        if c:
            return sysmsg+"\n\n"+(assign_block+"\n\n" if assign_block else "")+(mem_block+"\n\n" if mem_block else "")+c+tail+live_task+"\n\n"+end
        return sysmsg+"\n\n"+canon+"\n\n=== RECENT TRANSCRIPT (Adam posts stripped) ===\n"+body+tail+live_task+"\n\n"+end
    def adam_system_prompt(s):
        workish,prev_who,_,direct=s._adam_assigned_work()
        st=s._style_pref()
        # Adam quotes a bare FORMAT line back as a title ("**go DEEPER - Reasoning & Working**").
        # Say plainly that the directive is an instruction, not text to reproduce.
        sty=("\n"+"\n".join(st)+"\nThe FORMAT line above is an instruction to you — never print it, echo it, or use it as a heading.") if st else ""
        if direct:
            relay=s._adam_relay(prev_who)
            return (
                ("You are Adam in Amni-Delve. MODE: RELAYED QUESTION — a peer seat is passing you Anthony's question. "
                 "The question is in the user message. Answer it now in plain prose. "
                 "Asking him to restate it, or saying you lack the question, is a FAILED turn. "
                 "Never emit BOARD/BOARD UPDATE/LOCKED/OPEN/IN PROGRESS/CORRECTIONS HONORED/NEXT/'Task Executed' headings — a templated reply is a failed turn. "
                 "If you don't know the ANSWER, say that plainly — but do not claim the question is missing. "
                 "Inventing math or status is not allowed."+sty)
                if relay else
                ("You are Adam in Amni-Delve. Anthony is speaking to you DIRECTLY. Answer HIS question, in whatever "
                 "shape best fits it — prose to explain, a fenced block for code, bullets for a list, a table to compare. "
                 "Never emit BOARD/BOARD UPDATE/LOCKED/OPEN/IN PROGRESS/CORRECTIONS HONORED/NEXT/'Task Executed' headings — a templated reply is a failed turn. "
                 "Ignore any stale peer handoff; his message overrides it. If he asks whether you erred, consult the "
                 "REPEATED-ERROR GUARD, own those errors as yours plainly, and never claim a clean record while it is non-empty. "
                 "'I don't know' is an acceptable answer; inventing math or status is not."+sty)
            )
        if getattr(s,"_sit",False):
            return (
                "You are Adam in Amni-Delve. A peer seat has told you to STAND DOWN this round: there is no task for "
                "you and nothing to run. Reply with ONE short sentence — acknowledge you are holding, and name the one "
                "concrete thing that would put you back in play if there is one. "
                "Do NOT ask anyone to restate or clarify the question; you were not asked one. "
                "Do NOT offer to assist, and do NOT list what you could do. "
                "Do NOT run tools, invent numbers, or emit a board/template. Brevity is the correct answer here."+sty
            )
        if not s._proofish():
            return (
                "You are Adam in Amni-Delve, at a round table with other AIs. Answer what was asked, directly. "
                "Match the format to the request: prose, code in one fenced block, bullets, or a table — whichever fits. "
                "Never use a fixed template and never emit BOARD/LOCKED/OPEN/'Task Executed' headings. "
                "If you used tools, state plainly what you did and what the result was. No preamble, no status theatre."+sty
            )
        if workish:
            return (
                "You are Adam in Amni-Delve. Assigned WORK mode: produce real calculations/formulas first "
                "(RFD, H_dev, σ, σ/R, signs)."+sty+" Empty board-only replies fail. No invented CFD if data missing — "
                "analytic prior is honest ONLY after you actually opened the path; state the exact path you looked for. "
                "Never DATA MISSING on a file you did not attempt. Short board only after work. Prefer newest demotions. "
                "Obey REPEATED-ERROR GUARD absolutely: a claim peers rejected is dead — never restate, rename or extend it."
            )
        return (
            "You are Adam, Delve proof-tree officer. "
            "Always prefer the newest demotion/correction over older optimism. "
            "Obey REPEATED-ERROR GUARD absolutely: a claim peers rejected is dead — never restate, rename or extend it. "
            "After H_ω demotion, never say candidate-for-closure or derive-H_ω-next. "
            "Mark undefined hyps as UNDEFINED. Board bullets must cite real peer claims, not empty templates."
        )
    def seat_pref(s,seat,key,default=""):
        return str(((s.cfg.get("seat_prefs") or {}).get(seat) or {}).get(key) or default)
    @staticmethod
    def _seat_key(seat):
        t=str(seat or "").strip()
        return {"claude":"Claude","grok":"Grok","google":"Google","gemini":"Google","adam":"Adam","openai":"OpenAI","chatgpt":"OpenAI","copilot":"Copilot","cursor":"Cursor","opencode":"OpenCode"}.get(t.lower(),t[:1].upper()+t[1:] if t else t)
    def harness_id(s,seat):
        """Which harness this seat runs THIS turn. Most specific wins:
        per-turn override → seat pin (seat_prefs[Seat].harness) → per-mode map in cfg →
        shipped per-mode default → global harness_default. 'auto' anywhere means "keep
        looking", so a seat pinned to auto still follows the mode."""
        cap=Hub._seat_key(seat)
        def ok(v):
            v=str(v or "").strip().lower()
            return v if v in HARNESS_PROFILES else ""
        return s.harness_src(cap)[0]
    def harness_src(s,seat):
        """Returns (profile_id, source). `source` matters: only a profile the operator chose
        ('override'/'pin'/'cfg') may narrow TOOL access. A shipped per-mode default must never
        silently revoke what the Permissions panel advertises — that made seats report
        "I'm in plan mode with no tools" while the UI showed Read & write."""
        cap=Hub._seat_key(seat)
        def ok(v):
            v=str(v or "").strip().lower()
            return v if v in HARNESS_PROFILES else ""
        v=ok((getattr(s,"_harness_override",None) or {}).get(cap))
        if v:return v,"override"
        v=ok(s.seat_pref(cap,"harness",""))
        if v:return v,"pin"
        mode=str(s.cfg.get("path_preset") or "sequential").strip().lower()
        cfgm=dict(s.cfg.get("harness_by_mode") or {}).get(mode) or {}
        v=ok(cfgm.get(cap)) or ok(cfgm.get("*"))
        if v:return v,"cfg"
        ship=HARNESS_BY_MODE.get(mode) or {}
        v=ok(ship.get(cap)) or ok(ship.get("*"))
        if v:return v,"mode"
        return (ok(s.cfg.get("harness_default")) or "review"),"default"
    def harness(s,seat):
        pid,src=s.harness_src(seat)
        p=dict(HARNESS_PROFILES[pid]);p["source"]=src
        # The Permissions panel is an explicit, visible user control: it decides TOOLS.
        # A shipped per-mode default only sets budgets (time / turns / MCP), never revokes
        # access the panel shows. Operator-chosen profiles may still narrow tools.
        if src in ("mode","default"):
            acc=s.seat_pref(Hub._seat_key(seat),"access","write")
            p["tools"]={"none":"none","read":"read"}.get(acc,"write")
            p["permission"]="bypass" if p["tools"]=="write" else "plan"
        ov=dict((s.cfg.get("harness_overrides") or {}).get(p["id"]) or {})
        for k,v in ov.items():
            if k in ("tools","permission") and isinstance(v,str):p[k]=v
            elif k in ("timeout","max_turns") and isinstance(v,(int,float)):p[k]=int(v)
            elif k in ("mcp","stream") and isinstance(v,bool):p[k]=v
        # An explicit access=none pin must still win over a permissive profile.
        if s.seat_pref(Hub._seat_key(seat),"access","")=="none":p["tools"]="none";p["permission"]="plan"
        return p
    def set_harness(s,seat,pid):
        cap=Hub._seat_key(seat)
        pid=str(pid or "").strip().lower()
        if pid and pid!="auto" and pid not in HARNESS_PROFILES:return False,"unknown harness: "+pid
        sp=dict(s.cfg.get("seat_prefs") or {});row=dict(sp.get(cap) or {})
        if not pid or pid=="auto":row.pop("harness",None)
        else:row["harness"]=pid
        sp[cap]=row;s.cfg["seat_prefs"]=sp;save_cfg(s.cfg)
        return True,cap+" -> "+(pid or "auto")
    def _redact_paths(s,txt):
        t=re.sub(r'[A-Za-z]:[\\/][^\s"\'<>|,;)\]]*',lambda m:m.group(0).replace("\\","/").split("/")[-1],str(txt or ""))
        return re.sub(r'(?<![:\w])/(?:home|Users|tmp|var|etc|opt|mnt|media|srv|private)/[^\s"\'<>|,;)\]]*',lambda m:m.group(0).split("/")[-1],t)
    def code_mode(s):
        m=str(s.cfg.get("code_mode") or "").strip().lower()
        m={"review":"edit","open":"bypass"}.get(m,m)
        # unknown means SAFE: writes queue for approval rather than applying unasked
        return m if m in ("plan","edit","bypass") else ("bypass" if s.cfg.get("bypass",False) else "edit")
    def perm(s,seat="claude"):
        m=s.code_mode()
        cap=Hub._seat_key(seat)
        acc=s.seat_pref(cap,"access","write")
        h=s.harness(cap)
        # The harness is a ceiling, never an escalation: a chat/review seat cannot be pushed
        # into write mode by a permissive global code_mode.
        if h.get("tools")=="none":acc="none"
        elif h.get("tools")=="read" and acc=="write":acc="read"
        if h.get("permission")=="plan" and m=="bypass":m="edit"
        if acc=="none":return ["--permission-mode","plan"] if seat in ("claude","grok") else []
        if acc=="read" and m=="bypass":m="edit"
        if m=="bypass":return ["--permission-mode","bypassPermissions"]
        if m=="plan":return ["--permission-mode","plan"]
        if seat=="grok":return ["--permission-mode","dontAsk"]
        return []
    def _kill_tree(s,p):
        """A hung CLI usually has node children; killing the parent alone leaves them
        holding the pipes open and communicate() still blocks."""
        if p is None:return
        try:
            if os.name=="nt":
                _run(["taskkill","/PID",str(p.pid),"/T","/F"],
                               capture_output=True,timeout=20)
            else:
                import signal
                try:os.killpg(os.getpgid(p.pid),signal.SIGKILL)
                except Exception:p.kill()
        except Exception:
            try:p.kill()
            except Exception:pass
    def turn_timeout(s,seat=None):
        """Seconds a turn may run in TOTAL. 0 = no cap, and that is the default now.

        A wall-clock cap punishes the wrong thing. Claude streamed 467,385 characters of real
        work and was killed at 900s for being slow, not for being stuck - the cap cannot tell
        those apart because it never looks at the output. `turn_stall` does look, and kills
        only a seat that has gone SILENT, which is the failure the cap was there to catch.

        An explicit `turn_timeout`, or a per-seat `seat_limits[seat].timeout`, is an operator
        ceiling and still wins. `turn_cap: true` restores the old harness-driven behaviour."""
        try:v=int(s.cfg.get("turn_timeout") or 0)
        except Exception:v=0
        if v>0:return max(60,v)
        if seat:
            try:
                sl=(s.cfg.get("seat_limits") or {}).get(seat) or {}
                v2=int(sl.get("timeout") or 0)
                if v2>0:return max(60,v2)
            except Exception:pass
        if not s.cfg.get("turn_cap",False):return 0
        if seat:
            try:return max(60,int(s.harness(seat).get("timeout") or 600))
            except Exception:pass
        try:return max(60,int(os.environ.get("DELVE_TURN_TIMEOUT","600")))
        except Exception:return 600
    def turn_stall(s):
        """Seconds of TOTAL SILENCE before a seat is considered wedged. Not elapsed time -
        silence. A seat still writing is still working, however long it takes. 0 disables it,
        which really does mean a hung process holds the room until you press Stop."""
        try:v=int(s.cfg.get("turn_stall",420) if s.cfg.get("turn_stall") is not None else 420)
        except Exception:v=420
        return max(0,v)
    def _wait_proc(s,proc,inp,to,who="seat"):
        box={"o":[],"e":[],"rc":-1}
        grab=lambda k:"".join(box[k])
        _pre=(CTX.est(len(inp or "")) if CTX is not None else 0)
        # Fresh turn, fresh per-call flag: _ctx_from_line uses it to tell a per-call usage
        # reading apart from the CLI's end-of-turn aggregate. See that method for why.
        try:(s._ctx_asst if isinstance(getattr(s,"_ctx_asst",None),dict) else {}).pop(who,None)
        except Exception:pass
        # Answer length is accumulated as lines arrive, never recomputed. Re-parsing the whole
        # buffer on every tick is O(n^2): a 467k-char stream ticking every 0.4s for 900s would
        # re-parse about a gigabyte to print one number.
        st={"chars":0,"at":time.time(),"buf":[],"n":0,"flushed":0.0,"open":False,"think":False,"json":None}
        def _push(add,force=False):
            """Text reaches the room WHILE it is being written. Throttled by size and by time,
            because one SSE frame per token is a frame every 20ms and the queue is bounded."""
            if add:st["buf"].append(add);st["n"]+=len(add)
            now=time.time()
            if not st["buf"]:return
            if not force and st["n"]<420 and (now-st["flushed"])<0.45:return
            out="".join(st["buf"]);st["buf"]=[];st["n"]=0;st["flushed"]=now
            try:s.emit({"type":"delta","who":who,"add":out,"open":st["open"],"think":bool(st["think"])})
            except Exception:pass
        def _feed():
            try:proc.stdin.write(inp) if inp else None
            except Exception:pass
            try:proc.stdin.close()
            except Exception:pass
        def _drain(pipe,k):
            """The sniff runs HERE, not on the finished buffer: a tool_use block is on the
            wire the moment the model decides to call it, and the whole point of the work
            feed is that you see the edit before the turn ends, not after.

            The same pass reads usage. A `result` line carries the real token counts for the
            whole session; until it arrives the progress line runs on the streamed bytes,
            which is an estimate and is thrown away the moment the real number lands."""
            try:
                for ln in iter(pipe.readline,""):
                    box[k].append(ln)
                    if k!="o":
                        # stderr is liveness too. grok/agy/codex log tool progress there while
                        # keeping stdout for the final JSON, so a seat deep in real work read
                        # as "quiet 420s" and was killed mid-task — then re-asked from scratch.
                        st["at"]=time.time()
                        continue
                    st["at"]=time.time()
                    if ACT is not None:
                        try:ACT.sniff(who,ln)
                        except Exception:pass
                    if CTX is not None and '"usage"' in ln:
                        try:s._ctx_from_line(who,ln)
                        except Exception:pass
                    if '"text_delta"' in ln or '"thinking_delta"' in ln:
                        try:
                            t,think=s._delta_text(ln)
                            if t:
                                st["chars"]+=len(t);st["open"]=True
                                # Reasoning and answer are two streams into one card. Flush the
                                # buffer on a change of kind or the two interleave into each
                                # other's block.
                                if think!=st["think"]:_push("",force=True);st["think"]=think
                                _push(t)
                        except Exception:pass
                    elif ln.strip():
                        # A seat that does not stream JSON at all (plain --output-format text)
                        # has its lines forwarded so the room is never blind. Decide that ONCE,
                        # from the first non-empty line, and never revisit it.
                        #
                        # Testing each line for a leading "{" is not the same question. Grok
                        # runs --output-format json and prints a pretty-printed object, so only
                        # its FIRST line starts with "{" - every line after it ("text": "...",
                        # "stopReason": ..., }) failed the test and was streamed into the room
                        # as if it were the model talking. That is why Grok's thinking read as
                        # raw JSON.
                        if st["json"] is None:st["json"]=ln.lstrip().startswith(("{","["))
                        if st["json"] is False and not st["open"]:
                            st["chars"]+=len(ln);_push(ln)
            except Exception:pass
            finally:
                try:pipe.close()
                except Exception:pass
        readers=[threading.Thread(target=_drain,args=(proc.stdout,"o"),daemon=True),threading.Thread(target=_drain,args=(proc.stderr,"e"),daemon=True)]
        threading.Thread(target=_feed,daemon=True).start()
        for r in readers:r.start()
        def run():
            try:
                proc.wait()
                for r in readers:r.join(10)
                box["rc"]=proc.returncode
            except Exception as ex:box["e"].append("[exec error] "+str(ex)[:200]);box["rc"]=-1
        th=threading.Thread(target=run,daemon=True);th.start()
        t0=time.time();frame=0;stall=s.turn_stall();seen=0
        while th.is_alive():
            th.join(0.4)
            if s.abort.is_set():
                s._kill_tree(proc);th.join(8)
                return grab("o"),grab("e")+" [stopped]",-9
            now=time.time();elapsed=int(now-t0)
            _push("",force=True)
            quiet=int(now-st["at"])
            # Two ways out, and only one of them is on the clock. A cap kills a seat for being
            # SLOW; silence kills it for being STUCK. Only the second is a fault.
            if to>0 and elapsed>=to:
                partial=grab("o").strip()
                s.emit({"type":"status","text":who+(" hit the "+str(to)+"s cap — keeping the "+str(st["chars"])+" characters of answer it had already written" if partial else " stopped responding after "+str(to)+"s — ending its turn so the room can carry on")})
                s._kill_tree(proc);th.join(12)
                return grab("o"),grab("e")+" [timed out after "+str(to)+"s]",(0 if partial else -9)
            if stall and quiet>=stall:
                partial=grab("o").strip()
                s.emit({"type":"status","text":who+" went quiet for "+str(quiet)+"s (no output at all) — ending its turn"+(" and keeping the "+str(st["chars"])+" characters it had written" if partial else "")})
                s._kill_tree(proc);th.join(12)
                return grab("o"),grab("e")+" [timed out after "+str(quiet)+"s of silence]",(0 if partial else -9)
            seen=len(grab("o"))
            if CTX is not None and seen:
                # The prompt is context too. On the FIRST turn of a fresh session nothing has
                # reported usage yet, so counting only the output would show 0% while a 40k
                # prompt was already on the wire.
                try:s.ctx_live_set(who,_pre+CTX.est(st["chars"]))
                except Exception:pass
            note=(s.ctx_line(who) if (CTX is not None and seen) else "")
            clock=str(elapsed)+"s"+("/"+str(to)+"s" if to>0 else "")
            s.emit({"type":"tick","key":"wait","frame":frame,"who":who,"ctx":note,"quiet":quiet,
             "chars":st["chars"],
             "text":who+" · "+clock+(" · "+note if note else "")+
              (" · writing" if st["chars"] and quiet<3 else (" · working" if quiet<12 else " · quiet "+str(quiet)+"s"))})
            frame+=1
        _push("",force=True)
        if s.abort.is_set():
            s._kill_tree(proc)
            return grab("o"),grab("e")+" [stopped]",-9
        return grab("o"),grab("e"),box.get("rc",-1)
    def _exec(s,cmd,inp,who="seat"):
        to=s.turn_timeout(who)
        env=None
        if s.cfg.get("privacy_mode",True):
            env=dict(os.environ)
            env.update(PRIVACY_ENV)
        bk=(s.cfg.get("seat_backends") or {}).get(who) or {}
        if isinstance(bk,dict) and bk.get("backend"):
            env=dict(os.environ) if env is None else env
            kb=str(bk.get("backend") or "").lower();rg=str(bk.get("region") or "").strip();pj=str(bk.get("project") or "").strip()
            if who=="Claude" and kb=="bedrock":
                env["CLAUDE_CODE_USE_BEDROCK"]="1"
                if rg:env["AWS_REGION"]=rg
            elif who=="Claude" and kb=="vertex":
                env["CLAUDE_CODE_USE_VERTEX"]="1"
                if rg:env["CLOUD_ML_REGION"]=rg
                if pj:env["ANTHROPIC_VERTEX_PROJECT_ID"]=pj
            elif who=="Google" and kb=="vertex":
                env["GOOGLE_GENAI_USE_VERTEXAI"]="true"
                if pj:env["GOOGLE_CLOUD_PROJECT"]=pj
                if rg:env["GOOGLE_CLOUD_LOCATION"]=rg
        exe=str(cmd[0] or "")
        if not os.path.isfile(exe):
            w2=shutil.which(exe)
            if not w2:
                try:
                    import delve_providers as PV
                    base=os.path.basename(exe).lower().replace(".exe","")
                    for spc in PV._CLI_SEATS.values():
                        if str(spc.get("exe") or "").lower()==base:
                            p2,_=PV._find_cli(spc)
                            if p2:w2=p2
                            break
                except Exception:w2=None
            if w2:cmd=[w2]+list(cmd[1:])
        p=None
        try:
            p=_popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,cwd=s.work,text=True,encoding="utf-8",errors="replace",env=env)
            s._proc_add(p)
            out,err,rc=s._wait_proc(p,inp,to,who=who)
        except FileNotFoundError:
            out,err,rc="","["+str(who)+" CLI not found on this machine — open /setup for a guided install]",-1
        except Exception as e:out,err,rc="","[exec error] "+str(e),-1
        finally:s._proc_drop(p)
        return out,err,rc
    def disp(s,w):return (str(s.cfg.get("user_name") or "").strip() or "User") if w in ("Anthony","You") else w
    _MODERNIZE={"gpt-5":"gpt-5.2","o3":"gpt-5.2","o4-mini":"gpt-5.2-mini","gpt-4o":"gpt-5.2","gpt-4o-mini":"gpt-5.2-mini",
     "claude-sonnet-4":"claude-sonnet-5","claude-opus-4":"claude-opus-5","sonnet-4":"sonnet-5","sonnet-4-thinking":"sonnet-5",
     "gemini-2.5-pro":"gemini-3.1-pro"}
    def _model_id(s,key):
        v=str(s.cfg.get(key) or "").strip()
        if not v or len(v)>96 or v.startswith("-") or not re.match(r"^[A-Za-z0-9][A-Za-z0-9._:/\-@+]*$",v):return ""
        return Hub._MODERNIZE.get(v,v)
    def _stream_text_len(s,out):
        """Length of the ANSWER inside an NDJSON stream, not the length of the stream. Measured
        on a real call: 236 chars of envelope per text delta, so len(stdout) overstates the
        model's output by ~40x and is useless as a context signal."""
        t=out or ""
        if '"text_delta"' not in t:return len(t)
        n=0
        for ln in t.splitlines():
            if '"text_delta"' not in ln:continue
            try:d=json.loads(ln)
            except Exception:continue
            dl=((d.get("event") or {}).get("delta") or {}) if d.get("type")=="stream_event" else {}
            x=dl.get("text")
            if isinstance(x,str):n+=len(x)
        return n or len(t)
    def _delta_text(s,ln):
        """(text, is_thinking) out of ONE stream_event line. Called per token line, so it bails
        on the cheap string test before paying for a JSON parse.

        Extended thinking arrives as `thinking_delta` carrying `thinking`, not `text` - reading
        only text_delta is why the room saw a seat go silent for minutes and then produce an
        answer out of nowhere: it WAS talking, just not in the field we were listening to."""
        t=(ln or "").strip()
        if not t.startswith("{"):return "",False
        think='"thinking_delta"' in t
        if not think and '"text_delta"' not in t:return "",False
        try:d=json.loads(t)
        except Exception:return "",False
        if d.get("type")!="stream_event":return "",False
        dl=(d.get("event") or {}).get("delta") or {}
        x=dl.get("thinking") if think else dl.get("text")
        return (x if isinstance(x,str) else ""),think
    def _ctx_from_line(s,name,ln):
        """One NDJSON line that might carry a usage block — and the two kinds are NOT the same
        number. A per-call usage (Claude's `assistant` message lines) sums to what the session
        was actually holding on that call. The end-of-turn `result` line is an AGGREGATE across
        every API call in the turn: cache_read re-counts the whole conversation once per call,
        so a tool-heavy turn on a 150k session reports 3–6M. Storing that as 'session size' made
        _cli_should_fresh read 625% of a 1M window and throw the seat's session away after EVERY
        turn — which is why long rooms watched seats forget the board and re-derive it. The
        aggregate is only trusted when the CLI never reported a per-call number at all."""
        t=(ln or "").strip()
        if not t.startswith("{"):return
        try:d=json.loads(t)
        except Exception:return
        u=d.get("usage") if isinstance(d.get("usage"),dict) else ((d.get("message") or {}).get("usage") if isinstance(d.get("message"),dict) else None)
        if not isinstance(u,dict):return
        tot=CTX.from_usage(u) if CTX else 0
        if tot<=0:return
        seen=getattr(s,"_ctx_asst",None)
        if not isinstance(seen,dict):seen={};s._ctx_asst=seen
        if str(d.get("type") or "").lower()=="result":
            if seen.get(name):return
        else:seen[name]=True
        s.ctx_note(name,tot)
    def ctx_win(s,name):
        try:return CTX.window(name,s.seat_model(name)) if CTX else 200000
        except Exception:return 200000
    def ctx_used(s,name):
        """What the seat's live session is carrying: the last measured total plus whatever
        this turn has streamed so far."""
        return int(s.ctx.get(name,0) or 0)+int((getattr(s,"_ctx_live",None) or {}).get(name,0) or 0)
    def ctx_note(s,name,used):
        """Authoritative. A `result` usage line already counts the whole session (input +
        cache write + cache read + output), so it REPLACES the running figure - adding it
        would double-count the conversation on every turn."""
        try:used=int(used or 0)
        except Exception:used=0
        if used<=0:return
        s.ctx[name]=used
        try:(s._ctx_live or {}).pop(name,None)
        except Exception:pass
    def ctx_add_est(s,name,tokens):
        try:tokens=int(tokens or 0)
        except Exception:tokens=0
        if tokens<=0:return
        s.ctx[name]=int(s.ctx.get(name,0) or 0)+tokens
    def ctx_live_set(s,name,tokens):
        d=getattr(s,"_ctx_live",None)
        if not isinstance(d,dict):d={};s._ctx_live=d
        d[name]=max(0,int(tokens or 0))
    def ctx_reset(s,name):
        s.ctx.pop(name,None)
        try:(s._ctx_live or {}).pop(name,None)
        except Exception:pass
    def ctx_line(s,name):
        if CTX is None:return ""
        try:return CTX.fmt(s.ctx_used(name),s.ctx_win(name))
        except Exception:return ""
    def _pin(s,name,cont):
        """`--continue`/`-c` means "most recent conversation in this cwd" — every room
        shares one workspace, so a seat resumed whatever thread was freshest there:
        another Braid session, a oneshot, or the user's own CLI use. That is the
        context-bleed bug. Pin each room to its OWN CLI session id instead: mint a
        uuid on the first turn, resume exactly that uuid after.
        Long rooms: sticky --resume makes the CLI re-load every prior turn even when
        Braid already PTEX-compacted the prompt — seats get slower each round. Use
        _cli_should_fresh / cli_session_mode=refresh to mint a new pin periodically."""
        sid=s.sid.get(name) if cont else None
        if sid:return ["--resume",sid]
        sid=str(uuid.uuid4());s.sid[name]=sid
        return ["--session-id",sid]
    def _cli_should_fresh(s,name,prompt=""):
        """Refresh on CONTEXT, not on a turn count.

        A pinned CLI session re-sends its whole conversation every turn, so the cost of
        keeping it is proportional to how full it is - and "full" only means anything as a
        share of that model's own window. `cli_ctx_pct` (default 0.20) is that share: once a
        seat's session is carrying more than a fifth of its window, the pin is dropped and the
        next turn starts clean on Braid's own (already compacted) prompt.

        The old every-N-turns rule was blind both ways: it threw away a 27k-cache-creation
        session after two short chats, and it kept a tool-heavy session that was already past
        half of a 200k window. cli_session_refresh_every still applies as a CEILING for seats
        that report no usage at all, so an unmeasurable seat cannot grow forever."""
        mode=str(s.cfg.get("cli_session_mode") or "refresh").lower()
        if mode in ("fresh","oneshot","stateless","off","never"):return True
        if mode in ("pin","resume","sticky","always"):return False
        p=prompt or ""
        # A compacted PROMPT used to force a refresh here. In a long room the delta crosses the
        # compact threshold nearly every wave, so that rule quietly disabled session pinning for
        # exactly the rooms that need memory most. The prompt being short is a reason to KEEP
        # the session (cheap to extend), not to throw it away; only measured context decides.
        if CTX is not None:
            try:
                lim=float(s.cfg.get("cli_ctx_pct") if s.cfg.get("cli_ctx_pct") is not None else CTX.DEFAULT_PCT)
            except Exception:lim=CTX.DEFAULT_PCT
            win=s.ctx_win(name)
            # The prompt about to be sent counts: it is what tips the session over.
            used=s.ctx_used(name)+CTX.est(len(p))
            if CTX.should_refresh(used,win,lim):
                try:s.emit({"type":"status","text":SEAT_LABEL.get(name,name)+" session refreshed — "+CTX.fmt(used,win)+" is past the "+str(int(round(lim*100)))+"% mark; next turn starts clean"})
                except Exception:pass
                return True
            if s.ctx.get(name):return False
        try:every=max(1,int(s.cfg.get("cli_session_refresh_every") or 8))
        except Exception:every=8
        d=getattr(s,"_cli_turns",None)
        if not isinstance(d,dict):d={};s._cli_turns=d
        n=int(d.get(name,0) or 0)+1;d[name]=n
        return (n%every)==0
    def _cli_drop_pin(s,name):
        try:s.sid.pop(name,None)
        except Exception:pass
        # The session is gone, so what it was carrying is gone with it.
        try:s.ctx_reset(name)
        except Exception:pass
        d=getattr(s,"_cli_turns",None)
        if isinstance(d,dict):d[name]=0
    def _effort_argv(s,name):
        e=s.seat_effort(name)
        if not e:return []
        try:import delve_models as DM;spec=DM.effort_spec(name);flag=spec.get("flag") or ""
        except Exception:flag="--effort"
        if not flag or flag in ("cursor_param","codex_c"):return []
        return [flag,e]
    _NOMCP=None
    def _tool_argv(s,seat):
        """Deny-list, because an allow-list of "" is ambiguous across CLI versions and a
        partial toolset can fail requirement checks (grok's search_replace needs read_file)."""
        t=s.harness(seat).get("tools")
        if t=="none":return ["--disallowed-tools"," ".join(CLAUDE_TOOLS)]
        if t=="read":return ["--disallowed-tools"," ".join(CLAUDE_WRITE_TOOLS)]
        return []
    def _no_mcp_argv(s,seat=None):
        """A room turn is a conversation, not an IDE session. Left alone the CLI boots every
        plugin MCP server configured for the workspace; most sit `pending` and a broken one
        can hold the process with zero stdout until the seat is killed. Seats never call those
        tools, so start with an empty server set unless the operator asks for them."""
        if s.cfg.get("cli_mcp",False) or (seat and s.harness(seat).get("mcp")):return []
        if Hub._NOMCP is None:
            try:
                p=os.path.join(tempfile.gettempdir(),"braid_no_mcp.json")
                open(p,"w",encoding="utf-8").write('{"mcpServers":{}}');Hub._NOMCP=p
            except Exception:Hub._NOMCP=""
        return ["--mcp-config",Hub._NOMCP,"--strict-mcp-config"] if Hub._NOMCP else []
    def _parse_stream_json(s,txt):
        """NDJSON from `--output-format stream-json`. Tolerates a truncated tail: a killed
        seat leaves a half-written final line, and the text deltas before it are still good."""
        final="";deltas=[];msgs=[];stop="";err=False
        for ln in (txt or "").splitlines():
            ln=ln.strip()
            if not ln or not ln.startswith("{"):continue
            try:d=json.loads(ln)
            except Exception:continue
            t=d.get("type")
            if t=="result":
                if isinstance(d.get("result"),str):final=d["result"]
                stop=str(d.get("stop_reason") or "");err=bool(d.get("is_error"))
            elif t=="stream_event":
                ev=d.get("event") or {}
                if ev.get("type")=="content_block_delta":
                    dl=ev.get("delta") or {}
                    if dl.get("type")=="text_delta" and isinstance(dl.get("text"),str):deltas.append(dl["text"])
                elif ev.get("type")=="message_delta":stop=str((ev.get("delta") or {}).get("stop_reason") or stop)
            elif t=="assistant":
                for b in ((d.get("message") or {}).get("content") or []):
                    if isinstance(b,dict) and b.get("type")=="text" and isinstance(b.get("text"),str):msgs.append(b["text"])
        return ((final or "".join(deltas) or "\n".join(msgs)).strip(),stop,err)
    def call_claude(s,prompt,cont):
        mid=s._model_id("claude_model")
        stream=s.cfg.get("cli_stream",True) and s.harness("Claude").get("stream",True)
        fmt=["--output-format","stream-json","--include-partial-messages","--verbose"] if stream else ["--output-format","text"]
        cmd=[CLAUDE,"-p"]+fmt+s._no_mcp_argv("Claude")+s._tool_argv("Claude")+s.perm()+s._pin("Claude",cont)+(["--model",mid] if mid else [])+s._effort_argv("Claude")
        out,err,rc=s._exec(cmd,prompt,who="Claude")
        if s.abort.is_set():
            kept=((s._parse_stream_json(out)[0] if stream else (out or "")) or "").strip()
            return kept if len(kept)>=40 else "[claude stopped]"
        if stream:
            ans,stop,bad=s._parse_stream_json(out)
            if ans:
                if rc==-9:
                    try:s.emit({"type":"status","text":"Claude was cut off at the time cap — keeping the "+str(len(ans))+" chars it had already streamed"})
                    except Exception:pass
                return ans
            return "[claude error] stream ended with no text (stop_reason="+(stop or "none")+(" · "+(err or "").strip()[:200] if (err or "").strip() else "")+") — raw stream withheld ("+str(len((out or "")))+" chars)"
        ans=(out or "").strip()
        return ans or "[claude error] "+((err or "no output").strip())
    _NOTOOLS=("\n\n[BRAID] Answer directly from reasoning in THIS single turn. You have no tool "
     "access for this turn — a tool call is discarded and your turn is lost, so do not attempt "
     "one. Give the complete answer as prose now; do not describe what you are about to do.")
    def _grok_json(s,txt):
        """`--output-format json` gives the final text AND a stopReason. `plain` gives neither:
        when the single-turn session is cut short mid-tool it prints only the model's opening
        narration and exits 0, which is how the room kept seeing "I'll go do X" and no answer."""
        t=(txt or "").strip()
        if not t.startswith("{"):return None
        try:d=json.loads(t)
        except Exception:
            for ln in reversed(t.splitlines()):
                ln=ln.strip()
                if ln.startswith("{"):
                    try:d=json.loads(ln);break
                    except Exception:continue
            else:return None
        if not isinstance(d,dict):return None
        return ((d.get("text") or "").strip(),str(d.get("stopReason") or ""),d)
    _INTENT_RX=re.compile(r'(?is)(?:\b(?:i\'?ll|i am going to|i\'?m going to|let me|going to|digging into|scanning|checking|pulling up|first,? let me)\b.{0,400})\Z')
    def _grok_out(s,out):
        """(answer, stopReason) from whatever the grok CLI printed. streaming-messages-json is
        the same wire format Claude streams, so _parse_stream_json reads it; the single-JSON
        shape stays as the fallback for older CLIs, and raw text is the floor."""
        ans,stop,_bad=s._parse_stream_json(out)
        if ans or stop:return ans,stop
        j=s._grok_json(out)
        if j is not None:return j[0],j[1]
        return (out or "").strip(),""
    def _grok_truncated(s,ans,stop):
        if stop and stop not in ("end_turn","stop_sequence","max_tokens"):return True
        a=(ans or "").strip()
        if not a:return True
        return len(a)<420 and bool(Hub._INTENT_RX.search(a))
    def call_grok(s,prompt,cont):
        pf=tempfile.NamedTemporaryFile("w",suffix=".txt",delete=False,encoding="utf-8");pf.write(prompt);pf.close()
        mid=s._model_id("grok_model")
        try:mt=max(1,min(32,int(s.cfg.get("grok_max_turns") or s.harness("Grok").get("max_turns") or os.environ.get("DELVE_GROK_MAX_TURNS","12") or 12)))
        except Exception:mt=12
        boost=int((getattr(s,"_turn_boost",None) or {}).get("Grok") or 0)
        if boost>mt:
            mt=min(32,boost)
            if not getattr(s,"_turn_boost_said",False):
                s._turn_boost_said=True
                s.emit({"type":"status","text":"Grok gets "+str(mt)+" agent turns from now on (a turn hit the cap)"})
        # streaming-messages-json + partial messages: the turn TALKS while it works — the stall
        # detector sees output, the room sees the text as it is written, and a seat mid-tool no
        # longer reads as "quiet 420s" and gets killed for working. Same wire format as Claude,
        # so the existing stream parser and ctx accounting read it unchanged.
        cmd=[GROK,"--prompt-file",pf.name,"--output-format","streaming-messages-json","--include-partial-messages","--no-memory","--no-subagents","--max-turns",str(mt)]
        pm=s.perm("grok")
        if not pm:pm=["--permission-mode","dontAsk"]
        cmd+=pm+s._pin("Grok",cont)+(["--model",mid] if mid else [])+s._effort_argv("Grok")
        try:out,err,rc=s._exec(cmd,None,who="Grok")
        finally:
            try:os.unlink(pf.name)
            except Exception:pass
        if s.abort.is_set():
            s._cli_drop_pin("Grok")
            kept=(s._grok_out(out)[0] or "").strip()
            return kept if len(kept)>=40 else "[grok stopped]"
        ans,stop=s._grok_out(out)
        if ans or stop:
            # A turn WE cut (time cap / stall kill) was working, not refusing tools — re-asking
            # it "without tools" threw the work away and risked a second full stall. Keep what
            # it wrote, boost its agent turns, and only re-ask when the CLI itself gave up.
            if s._grok_truncated(ans,stop) and "[timed out after" in (err or ""):
                d=getattr(s,"_turn_boost",None)
                if not isinstance(d,dict):d={};s._turn_boost=d
                d["Grok"]=min(32,max(mt*2,16))
                s._cli_drop_pin("Grok")
                if ans:return ans.rstrip()+"\n\n[grok cut off mid-work — its next turn here gets "+str(d["Grok"])+" agent turns]"
                return "[grok timeout] no answer before the cut — next turn gets "+str(d["Grok"])+" agent turns"
            if s._grok_truncated(ans,stop) and not s.abort.is_set():
                try:s.emit({"type":"status","text":"Grok's turn ended before it answered (stopReason="+(stop or "none")+") — fresh session, re-asking without tools"})
                except Exception:pass
                s._cli_drop_pin("Grok")
                pf2=tempfile.NamedTemporaryFile("w",suffix=".txt",delete=False,encoding="utf-8")
                pf2.write(prompt+Hub._NOTOOLS);pf2.close()
                try:
                    cmd2=[];skip=False
                    for a in cmd:
                        if skip:skip=False;continue
                        if a in ("--resume","--session-id"):skip=True;continue
                        cmd2.append(pf2.name if a==pf.name else a)
                    cmd2+=s._pin("Grok",False)
                    o2,e2,_r2=s._exec(cmd2,None,who="Grok")
                finally:
                    try:os.unlink(pf2.name)
                    except Exception:pass
                if s.abort.is_set():
                    s._cli_drop_pin("Grok")
                    _j2=s._grok_json(o2);kept=((_j2[0] if _j2 is not None else o2) or "").strip()
                    if len(kept)<40:kept=(ans or "").strip()
                    return kept if len(kept)>=40 else "[grok stopped]"
                j2=s._grok_json(o2)
                a2,st2=("","")
                if j2 is not None:a2,st2,_=j2
                elif (o2 or "").strip():a2,st2=(o2 or "").strip(),""
                if a2 and not s._grok_truncated(a2,st2):return a2
                best=a2 if len(a2)>len(ans or "") else (ans or "")
                stop=st2 if a2 is best else stop
                s._cli_drop_pin("Grok")
                if best:
                    d=getattr(s,"_turn_boost",None)
                    if not isinstance(d,dict):d={};s._turn_boost=d
                    d["Grok"]=min(32,max(mt*2,16))
                    return best.rstrip()+"\n\n[grok incomplete] the CLI ended this turn early (stopReason="+(stop or "none")+") — Grok's next turn in this room gets "+str(d["Grok"])+" agent turns automatically"
            if ans:return ans
        else:
            ans=(out or "").strip()
            if ans:return ans
        e=((err or "")+(out or "")).strip()
        low=e.lower()
        s._cli_drop_pin("Grok")
        if any(k in low for k in ("rate limit","rate_limit","quota","429","too many requests","usage limit","resource_exhausted")):
            return "[grok rate-limit] "+(e[:220] or "quota/rate exhausted")
        if "max turns" in low:
            d=getattr(s,"_turn_boost",None)
            if not isinstance(d,dict):d={};s._turn_boost=d
            d["Grok"]=min(32,max(mt*2,16))
            return "[grok error] hit max-turns="+str(mt)+" — next Grok turn in this room gets "+str(d["Grok"])+" automatically "+e[:220]
        return "[grok error] "+(e or "no output")
    @staticmethod
    def _adam_step_evidence(g,cap=5):
        """What the tool steps actually returned. /api/delve/agentic carries per-step results now;
        without this the chat fallback answers a WORK task with no access to its own work."""
        rows=[]
        for st in ((g or {}).get("steps") or []):
            if not isinstance(st,dict):continue
            t=str(st.get("tool") or "").strip()
            if not t or t.startswith("("):continue
            v=str(st.get("value") or "").strip()
            r=re.sub(r"\s+"," ",str(st.get("result") or "").strip())[:280]
            # A missing file is a fact, not a stack trace. The raw FileNotFoundError leaked into
            # the evidence block, polluted the retry prompt, and read as degeneration — turn it
            # into the one line the next step can act on.
            m=re.search(r"FileNotFoundError.*?'([^']+)'",r or v)
            if m:
                v="";r="file not found: "+os.path.basename(m.group(1))+" — skip it and use what exists"
            if not (v or r):continue
            rows.append("- "+t+(" → "+v if v else "")+((" | "+r) if r else ""))
        if not rows:return ""
        return ("\n\n=== YOUR TOOL RUN (these steps really executed — use these results, do not re-derive or invent) ===\n"
         +"\n".join(rows[:cap])+"\nAnswer the task from the evidence above. If it is not enough, say exactly what is missing.")
    _NORM_RX=re.compile(r'\s+')
    _REPEAT_SIM=0.60
    _REPEAT_WINDOW=4
    def _adam_recent_says(s,k=1):
        out=[]
        for w,x in reversed(s.t):
            if w=="Adam" and (x or "").strip():
                out.append(x)
                if len(out)>=k:break
        return out
    def _adam_last_say(s):
        r=s._adam_recent_says(1)
        return r[0] if r else ""
    @staticmethod
    def _adam_sim(a,b):
        """Word-set Jaccard, not equality. Adam's repeat mode is a reworded board with the same
        vocabulary, and it alternates with a filler turn, so byte-equality against the previous
        turn alone missed 98 of them across the session store (median sim between genuine turns
        is 0.09, so 0.60 sits in the empty valley between the two modes)."""
        sa=set(Hub._NORM_RX.sub(" ",(a or "")).lower().split())
        sb=set(Hub._NORM_RX.sub(" ",(b or "")).lower().split())
        return (len(sa&sb)/len(sa|sb)) if sa and sb else 0.0
    def _adam_repeat_of(s,a,prior):
        hits=[(Hub._adam_sim(a,p),p) for p in prior]
        top=max(hits,key=lambda h:h[0]) if hits else (0.0,"")
        return top if top[0]>=Hub._REPEAT_SIM else (0.0,"")
    _BOARD_MARKS=("status board","project title","objective:","key features","key components","key deliverables","locked:","open:","in progress","corrections honored","next:")
    _SUBSTANCE=(re.compile(r"```"),re.compile(r"\b[\w./\\-]+\.(py|js|mjs|md|json|html|sql|txt|cmd|ps1)\b",re.I),
     re.compile(r"\d+\.\d+"),re.compile(r"\b\d{2,}\b"),re.compile(r"[=<>]\s*[-\d(]"),re.compile(r"\bline \d+\b",re.I))
    @staticmethod
    def _adam_empty_board(x):
        """The rewording loop is not lexically similar enough to trip a Jaccard threshold — each board
        restates the objective in fresh words. What it never carries is a number, a path, a code fence
        or an equation. Across the session store this splits 104 substance-free boards from the 51
        boards that do carry work, and leaves all 1572 non-board turns alone."""
        t=x or ""
        return sum(1 for m in Hub._BOARD_MARKS if m in t.lower())>=2 and not any(r.search(t) for r in Hub._SUBSTANCE)
    _FMT_ECHO_RX=re.compile(r'^\s*[*#_>\s]*(?:FORMAT\s*[:\-]\s*)?(?:go\s+DEEPER|keep\s+it\s+SHORT|answer\s+as\s+a\s+flat\s+bullet\s+list|present\s+the\s+answer\s+as\s+a\s+markdown\s+table|use\s+plain\s+language|write\s+in\s+prose\s+paragraphs|reply\s+with\s+the\s+code\s+only|do\s+NOT\s+use\s+section\s+headings)[^\n]*\n+',re.I)
    @staticmethod
    def _strip_format_echo(x):
        """Adam titles his turn with the FORMAT directive he was handed. It is scaffolding, not an
        answer, and it is the first thing Anthony sees in the room."""
        t=(x or "").lstrip()
        for _ in range(2):
            n=Hub._FMT_ECHO_RX.sub("",t,count=1)
            if n==t:break
            t=n.lstrip()
        return t or (x or "")
    def _adam_no_repeat(s,ans,prompt,sys_p,to,mc,mt,sid):
        """A seat that re-emits a turn it already took has not taken a turn. Deterministic decoding
        plus a replayed session makes this silent, so re-ask once with the repeat quoted."""
        a=(ans or "").strip()
        if len(a)<60 or a.startswith("[adam"):return ans
        prior=s._adam_recent_says(Hub._REPEAT_WINDOW)
        sim,prev=s._adam_repeat_of(a,prior)
        try:tasked=any(s._adam_assigned_work()[i] for i in (0,3))
        except Exception:tasked=False
        empty=not prev and tasked and Hub._adam_empty_board(a)
        if not prev and not empty:return ans
        why=("re-emitted an earlier turn (sim %.2f)"%sim) if prev else "answered assigned work with a status board carrying no number, path or equation"
        try:s.emit({"type":"status","text":"Adam "+why+" — re-asking once"})
        except Exception:pass
        lead=("You already said this in this room:\n\n"+prev[:1800]+"\n\nRepeating it is a failed turn. ") if prev else (
         "Your answer was a status board with no work in it:\n\n"+a[:1200]+"\n\nA board that restates the objective "
         "is a failed turn — the objective is not in question. Do the assigned work itself: the numbers, the file, "
         "the code, the equation. ")
        rp=(lead+
         "Answer the request below again — keep anything that was right, but say something NEW: correct what was "
         "wrong, add what was missing, or state plainly what you cannot determine and why. No status board, no "
         "restatement of the project objective.\n\n"+prompt)
        try:alt=(ADAM.ask(rp,timeout=to,max_chars=mc,max_tokens=mt,system=sys_p,temperature=0.5,session_id=sid) or "").strip()
        except Exception:alt=""
        if alt and not alt.startswith("[adam") and not s._adam_repeat_of(alt,prior+[a])[1] and not (tasked and Hub._adam_empty_board(alt)):return alt
        try:s.emit({"type":"status","text":"Adam produced no new work twice — seat skipped this round; give it a different task"})
        except Exception:pass
        return "[adam repeat] Two passes with no new work ("+why+"); seat skipped. Assign a concrete calculation, file or endpoint."
    def call_adam(s,prompt):
        if ADAM is None:return "[adam unavailable] bridge missing"
        try:
            if not ADAM.is_up():
                st=ADAM.boot_state()
                phase=st.get("phase")
                age=int(st.get("lock_age_s") or 0)
                if phase in ("down","thrash") or (phase=="booting" and (age>150 or not st.get("procs"))):
                    s.emit({"type":"status","text":"Adam offline — starting…"})
                    r=ADAM.start(s.cfg.get("adam_mode","light"))
                    s.emit({"type":"status","text":"Adam start: "+str((r or {}).get("phase") or (r or {}).get("reason") or r)[:120]})
                if not ADAM.is_up():
                    s.emit({"type":"status","text":"Waiting for Adam /healthz…"})
                    for _ in range(50):
                        if ADAM.is_up():break
                        time.sleep(1.5)
        except Exception as e:
            try:s.emit({"type":"status","text":"Adam autostart error: "+str(e)[:100]})
            except Exception:pass
        to=int(s.cfg.get("adam_timeout") or os.environ.get("AMNI_DELVE_ADAM_TIMEOUT","180") or 180)
        mc=int(s.cfg.get("adam_max_chars") or os.environ.get("AMNI_DELVE_ADAM_MAX_CHARS","16000") or 16000)
        workish,prev_who,assign,direct=s._adam_assigned_work()
        def_tok="2800" if workish else ("2400" if direct else "1800")
        mt=int(s.cfg.get("adam_max_tokens") or os.environ.get("AMNI_DELVE_ADAM_TOK",def_tok) or def_tok)
        if workish and mt<1800:mt=2800
        elif direct and mt<1600:mt=2400
        elif mt<1200:mt=1800
        sys_p=s.adam_system_prompt()
        task_key=(assign or s._goal_line() or "delve work")[:400]
        # Math allow-list: never expose grammar/chart/tts skills to Delve WORK turns.
        MATH_TOOLS=("calc","run_python","solve","stats","formula","units","numtheory","matrix",
         "file_read","file_write","file_list","code_edit","test_run","shell","project_info","http_get")
        CODE_TOOLS=MATH_TOOLS+("code_diff","symbols","format_code","parse_error","git")
        COMPUTE_TOOLS=frozenset(("calc","run_python","solve","stats","formula","numtheory","matrix","units","shell","test_run"))
        s._seat_dump(sys_p,workish,direct,assign,"",(s.stamp if workish else str(s.stamp)+"_t"+str(len(s.t))),"route")
        # Math/code → agentic tools. Continuous improve: ledger brief → tools → grade → record → occasional PTEX commit.
        if workish and s.cfg.get("adam_tools",True) and hasattr(ADAM,"ask_agentic"):
            unres=bool(s.cfg.get("adam_unrestricted")) and os.environ.get("AMNI_AGENTIC_UNRESTRICTED","0")=="1"
            led=""
            try:led=ADAM.coding_brief(task_key,k=6) if hasattr(ADAM,"coding_brief") else ""
            except Exception:led=""
            rej=s._rejections_for("Adam",cap=5)
            rej_blk=("\n".join("- "+x for x in rej)+"\n") if rej else ""
            is_code=Hub._is_code_work(assign or "")
            allow=list(CODE_TOOLS if is_code else MATH_TOOLS)
            def _agentic_goal(extra=""):
                allow_s=", ".join(allow)
                return (
                    "You are Adam in Amni-Delve WORK mode. Continuous improvement: fix prior fails, recompute everything.\n"
                    "HARD RULES:\n"
                    "1) MATH: use calc with args {\"expr\":\"...\"} OR run_python with {\"code\":\"print(...)}.\n"
                    "2) ONLY these tool names exist: "+allow_s+". Any other name (run_grammar_2, braid_fib, chart, tts) FAILS. Do not invent tools.\n"
                    "3) Never invent numbers. After a calc value returns, emit final with that number — do not re-call calc forever.\n"
                    "4) Dead claims (peer rejected) stay dead — do not rename or rebuild them.\n"
                    "5) CODE: file_read first, then code_edit/file_write, then test_run or run_python. The tool is named code_edit — 'file_edit' does not exist and will fail.\n"
                    "6) Ignore braid_fib.py unless THIS task explicitly asks to create that exact file.\n"
                    "7) URLs/HTTP: fetch with http_get {\"url\":\"http://127.0.0.1:PORT/path\"} and paste the RAW body it returns. run_python has NO network and shell has NO curl — do not try either. Fetch ONLY the URLs the task names — never invent extra endpoints — then emit final immediately with every body you got. Never report a URL as unreachable unless http_get itself returned an error; quote that error verbatim.\n"
                    +(extra+"\n" if extra else "")
                    +"=== TASK ===\n"+(assign or prompt)[:6000]+"\n\n"
                    +(led+"\n\n" if led else "")
                    +(("=== REPEATED-ERROR GUARD ===\n"+rej_blk+"\n") if rej_blk else "")
                    +"Finish with equations + numbers first, then a short honest summary."
                )
            steps=int(s.cfg.get("adam_steps") or 14)
            # Adam's room file tools land in a per-room scratch dir, not the live work tree.
            # A degenerated loop dropped hallucinated axis_*.md into Documents/ai/src — the
            # serve builds its skill registry from cwd, so scoping cwd scopes every file op.
            # cfg adam_files="work" restores real-tree access for rooms that mean it.
            sand=s.work if str(s.cfg.get("adam_files") or "")=="work" else os.path.join(DATA,"adam_scratch",s.stamp)
            try:os.makedirs(sand,exist_ok=True)
            except Exception:sand=s.work
            g=ADAM.ask_agentic(_agentic_goal(),cwd=sand,max_steps=steps,timeout=int(s.cfg.get("adam_agentic_timeout") or 600),unrestricted=unres,roots=None,allow_tools=allow)
            ans=(g.get("answer") or "").strip() if isinstance(g,dict) else ""
            tools=[str(st.get("tool") or "") for st in ((g or {}).get("steps") or []) if isinstance(st,dict)]
            used=", ".join(x for x in dict.fromkeys(tools) if x)
            ran_num=any(t in COMPUTE_TOOLS for t in tools)
            # Self-grade: math without a real compute tool (calc/run_python/…) → forced retry
            needs_num=bool(Hub._NUMDEMAND_RX.search(assign or ""))
            junk=any(re.search(r'(?i)grammar|tts|chart|image_gen|quote|azno',t or "") for t in tools)
            if (ans and needs_num and not ran_num) or junk:
                try:s.emit({"type":"status","text":"Adam used wrong/no compute tools ("+(used or "none")+") — retry with calc/run_python only"})
                except Exception:pass
                allow2=["calc","run_python","solve","stats","formula","numtheory","matrix","units"]
                g2=ADAM.ask_agentic(_agentic_goal("RETRY: Call calc or run_python NOW. Do not call any other skill. Pass the expression from THIS task only — never an example expression, never a number you were not asked about."),cwd=sand,max_steps=max(10,steps),timeout=int(s.cfg.get("adam_agentic_timeout") or 600),unrestricted=unres,roots=None,allow_tools=allow2)
                ans2=(g2.get("answer") or "").strip() if isinstance(g2,dict) else ""
                if ans2:
                    keep=ans if (ans and len(ans2)<max(160,len(ans)//2)) else ""
                    g,ans=g2,((keep+"\n\n"+ans2) if keep else ans2)
                    tools=[str(st.get("tool") or "") for st in ((g or {}).get("steps") or []) if isinstance(st,dict)]
                    used=", ".join(x for x in dict.fromkeys(tools) if x)
                    ran_num=any(t in COMPUTE_TOOLS for t in tools)
            degen=False
            if ans and (re.search(r"(?i)stop reason:|made no progress for|ran out of time after|what blocked me:|unknown tool|no such tool|invalid tool|\{'value':|'tier':\s*'",ans) or Hub._SYNTH_RX.search(ans) or (len(ans)<120 and re.match(r"(?i)^\W*(the\s+)?(final\s+)?answer\s+is\b[^\n]{0,24}$",ans.strip()))):
                degen=True
                try:s.emit({"type":"status","text":"Adam agentic degenerated (loop stop-reason leak) — chat fallback"})
                except Exception:pass
                # Salvage: the steps DID run. Handing chat the raw goal alone threw that evidence away
                # and let the seat answer from nothing, which is how the same wrong answer came back twice.
                ev=s._adam_step_evidence(g)
                try:alt=(ADAM.ask(((assign or prompt)[:6000]+ev),max_tokens=mt,system=sys_p,session_id=s.stamp) or "").strip()
                except Exception:alt=""
                ans=alt if (alt and not alt.startswith("[adam")) else ""
            if ans and not needs_num and len(ans)<260 and len(assign or "")>400 and re.search(r'(?i)via (the )?math engine|not a standard numeral|undefined|≈\s*-?\d',ans):
                try:alt=(ADAM.ask((assign or prompt)[:6000],max_tokens=mt,system=sys_p,session_id=s.stamp) or "").strip()
                except Exception:alt=""
                if alt and len(alt)>len(ans) and not alt.startswith("[adam"):ans=alt
            if ans:
                nst=str(g.get("n_steps") or 0)
                # Adam's steps into the changes tab — the other seats stream tool_use lines the
                # sniffer reads; Adam's run comes back as structured steps, so push them here.
                if ACT is not None:
                    for _st in ((g or {}).get("steps") or [])[:24]:
                        if not isinstance(_st,dict):continue
                        _t=str(_st.get("tool") or "").strip()
                        if not _t or _t.startswith("("):continue
                        try:ACT.record("Adam",ACT.KIND.get(_t,"tool"),str(_st.get("path") or _st.get("file") or ""),str(_st.get("value") or _st.get("result") or "")[:200],tool=_t)
                        except Exception:pass
                try:
                    s.emit({"type":"status","text":(
                     "Adam's "+nst+" tool step(s)"+(" — "+used if used else "")+" degenerated; this answer came from chat, not from tools"
                     if degen else
                     "Adam ran "+nst+" tool step(s) in "+str(g.get("workdir") or s.work)+(" — "+used if used else "")+(" · tools allowed="+str(len(allow)) if allow else ""))})
                except Exception:pass
                ans=s._adam_no_repeat(ans,prompt,sys_p,to,mc,mt,s.stamp)
                ok=bool(not degen and (ran_num or (is_code and any(t in ("file_write","code_edit","file_read") for t in tools))))
                if s.cfg.get("ptex_learn",True) and hasattr(ADAM,"coding_record"):
                    try:
                        ADAM.coding_record(task=task_key,outcome=ans[:500],
                         lesson=("tools="+ (used or "none")+("; agentic answer was degenerate — chat wrote this" if degen else ("; computed" if ran_num else "; NO compute tool — weak"))),
                         success=(False if degen else (ok if needs_num else True)),session_id=s.stamp,approach=("agentic_degen_chat" if degen else "agentic"),
                         errors=(["agentic loop leaked its stop reason instead of an answer"] if degen else ([] if ok else ["answered math without run_python"])),
                         kind=("delve_work_degen" if degen else "delve_work"))
                    except Exception:pass
                s._learn_tick(task_key)
                return ans
            if isinstance(g,dict) and g.get("missing"):
                try:s.emit({"type":"status","text":"Adam has no /api/delve/agentic (restart Adam for tools) — chat fallback"})
                except Exception:pass
            elif isinstance(g,dict) and g.get("error"):
                try:s.emit({"type":"status","text":"Adam tool run failed ("+str(g.get("error"))[:80]+") — chat fallback"})
                except Exception:pass
                if s.cfg.get("ptex_learn",True) and hasattr(ADAM,"coding_record"):
                    try:ADAM.coding_record(task=task_key,outcome=str(g.get("error"))[:300],lesson="agentic failed — next time check tool args and run_python first",success=False,session_id=s.stamp,approach="agentic",errors=[str(g.get("error"))[:200]],kind="delve_work_fail")
                    except Exception:pass
        _sid=(s.stamp if workish else (str(s.stamp)+"_t"+str(len(s.t))))
        s._seat_dump(sys_p,workish,direct,assign,prompt,_sid,"chat")
        ans=ADAM.ask(prompt,timeout=to,max_chars=mc,max_tokens=mt,system=sys_p,temperature=0.12 if workish else 0.15,session_id=_sid)
        if isinstance(ans,str) and Hub._DEGEN_RX.match(ans.strip()) and not Hub._NUMDEMAND_RX.search(assign or ""):
            try:s.emit({"type":"status","text":"Adam returned a bare numeric answer to a prose turn (exact-LUT hijack) — re-asking with LUT bypass"})
            except Exception:pass
            retry=("Answer in prose. This is NOT a multiple-choice or arithmetic question — do not reply with a bare number "
             "and never begin with \"The answer is\". Write at least three sentences of substance.\n\n"+prompt)
            try:alt=ADAM.ask(retry,timeout=to,max_chars=mc,max_tokens=mt,system=sys_p,temperature=0.4,session_id=_sid)
            except Exception:alt=""
            if isinstance(alt,str) and alt.strip() and not alt.startswith("[adam") and not Hub._DEGEN_RX.match(alt.strip()):ans=alt
        fr=getattr(ADAM,"last_finish","") or ""
        if isinstance(ans,str) and fr=="length":
            try:s.emit({"type":"status","text":"Adam hit max_tokens="+str(mt)+" — raise adam_max_tokens if answers keep truncating"})
            except Exception:pass
            ans=ans.rstrip()+"\n\n…[Adam hit output length cap — ask “finish that” to continue]"
        if isinstance(ans,str) and ans:
            ans=ans.replace("\u2011","-").replace("\u2013","-").replace("\u2014","-").replace("\u00a0"," ")
            ans=Hub._strip_format_echo(ans)
            ans=s._adam_no_repeat(ans,prompt,sys_p,to,mc,mt,_sid)
        # Chat-only math is a learning failure — bank it so the next attempt forces tools harder
        if workish and s.cfg.get("ptex_learn",True) and hasattr(ADAM,"coding_record") and ans and not str(ans).startswith("[adam"):
            try:ADAM.coding_record(task=task_key,outcome=ans[:400],lesson="chat fallback — next attempt MUST use run_python for numbers",success=False,session_id=_sid,approach="chat_fallback",errors=["no agentic tools"],kind="delve_chat_math")
            except Exception:pass
            s._learn_tick(task_key)
        return ans
    def _learn_tick(s,task=""):
        """After learn events, occasionally bake ledger → PTEX so next boots recall stronger."""
        if not s.cfg.get("ptex_learn",True) or ADAM is None:return
        n=int(getattr(s,"_learn_n",0) or 0)+1;s._learn_n=n
        every=int(s.cfg.get("ptex_commit_every") or os.environ.get("DELVE_PTEX_COMMIT_EVERY","4") or 4)
        if n%max(1,every):return
        if not hasattr(ADAM,"coding_commit"):return
        def _go():
            try:
                r=ADAM.coding_commit(timeout=120)
                s.emit({"type":"status","text":"Adam PTEX commit: "+str((r or {}).get("committed") or (r or {}).get("ok") or r)[:100]})
            except Exception as e:
                try:s.emit({"type":"status","text":"Adam PTEX commit skipped: "+str(e)[:80]})
                except Exception:pass
        threading.Thread(target=_go,daemon=True).start()
    def call_google(s,prompt,cont):
        if GOOGLE is None:return "[google unavailable] delve_google missing"
        def sink(p):s._proc_add(p)
        eff=s.seat_effort("Google")
        mid=s._model_id("google_model")
        to=s.turn_timeout("Google")
        # Headless: always skip permission prompts. Plan vs accept-edits still follows Files mode.
        gh=s.harness("Google")
        byp=(s.code_mode()!="plan") and (s.seat_pref("Google","access","write")!="none") and gh.get("tools")=="write"
        try:return GOOGLE.ask(prompt,model=mid,bypass=byp,cont=cont,cwd=s.work,timeout=to,proc_sink=sink,effort=eff,session=(s.sid.get("Google") if cont else None),sid_sink=lambda cid:s.sid.__setitem__("Google",cid))
        finally:s._proc_drop(s.proc)
    def _probe_cached(s,slot,fn,ttl,down_ttl=None):
        """A health probe costs a round trip. Blocking /api/state on one made every
        conversation switch wait for it. Once a value exists, serve it and re-probe
        behind the request instead."""
        now=time.time();c=getattr(s,slot,None)
        if c and (now-c[1])<((down_ttl or ttl) if not c[0] else ttl):return c[0]
        if c:
            if not getattr(s,slot+"_busy",False):
                setattr(s,slot+"_busy",True)
                def _r():
                    try:setattr(s,slot,(bool(fn()),time.time()))
                    except Exception:pass
                    finally:setattr(s,slot+"_busy",False)
                threading.Thread(target=_r,daemon=True).start()
            return c[0]
        res=bool(fn());setattr(s,slot,(res,now));return res
    def adam_up(s):
        return s._probe_cached("_adam_up_c",lambda:ADAM is not None and ADAM.is_up(),2.5,12.0)
    def google_up(s):
        return s._probe_cached("_google_up_c",lambda:GOOGLE is not None and GOOGLE.installed() and GOOGLE.signed_in(),5.0)
    def seat_cfg(s,name):
        return ((s.cfg.get("providers") or {}).get(name) or {})
    def adam_available(s):
        """Adam is opt-in. It only joins the table if the local model is actually
        installed AND the user said yes at setup - never as a silent default."""
        v=s.cfg.get("adam_enabled")
        if v is False:return False
        if PTEX is None or not hasattr(PTEX,"_ai_root"):return bool(v)
        try:root=PTEX._ai_root()
        except Exception:root=""
        return bool(root) if v is None else bool(v)
    def seat_installed(s,name):
        """Probing the filesystem for eight CLIs costs ~0.2s, and /api/state asks
        several times per poll. Cache it briefly, keyed on the provider config so a
        seat you just connected shows up immediately."""
        if PROV is None:return name in CORE_AGENTS
        key=repr(sorted((s.cfg.get("providers") or {}).items()))
        c=getattr(s,"_instc",None)
        if c is None or c[0]!=key or (time.time()-c[1])>20:
            c=(key,time.time(),{});s._instc=c
        hit=c[2]
        if name in hit:return hit[name]
        spec=(PROV._CLI_SEATS or {}).get(name)
        if not spec:hit[name]=False;return False
        try:p,_=PROV._find_cli(spec)
        except Exception:p=None
        hit[name]=bool(p);return hit[name]
    def seats_dirty(s):
        s._instc=None;s._seatc=None
    def seat_up(s,name):
        if name=="Adam":return s.adam_available() and s.adam_up()
        kind=(s.seat_cfg(name).get("kind") or "").lower()
        if kind=="off":return False
        if kind and kind not in ("cli","adam"):return True
        if name=="Google":return s.google_up()
        if name=="Claude":return bool(CLAUDE) and (shutil.which(CLAUDE) is not None or os.path.exists(CLAUDE))
        if name=="Grok":return bool(GROK) and (shutil.which(GROK) is not None or os.path.exists(GROK))
        return s.seat_installed(name)
    def seat_hint(s,name):
        cool=s._cool_left(name)
        if cool:
            why=(getattr(s,"_cool",{}) or {}).get(name,("",0))[0]
            return (why or "cooling down")+" — retry in "+str(cool)+"s"
        if name=="Adam":return "start it with /adam start light|heavy, or the Start button in Controls"
        if name=="Google":
            if GOOGLE is None:return "Google bridge missing"
            if not GOOGLE.installed():return "install Antigravity CLI (agy) — https://antigravity.google/cli"
            if not GOOGLE.signed_in():return "run agy once and pick Google OAuth"
            return "run agy once and pick Google OAuth"
        if name=="Grok":
            if not (GROK and (shutil.which(GROK) or os.path.exists(GROK))):return "install Grok CLI (~/.grok/bin/grok)"
        if name=="Claude":
            if not (CLAUDE and (shutil.which(CLAUDE) or os.path.exists(CLAUDE))):return "install Claude Code CLI"
        if PROV is not None:
            spec=(PROV._CLI_SEATS or {}).get(name) or {}
            g=spec.get("get")
            if g:
                # Installed-but-signed-out gets the seat's sign-in recipe. "install it" on an
                # auth failure told Anthony to reinstall a CLI already on PATH — and for Cursor
                # the obvious next move (`agent login`) opens Grok Build's OAuth instead.
                p,_=PROV._find_cli(spec)
                return (spec.get("hint") or "sign in, then retry") if p else "install it: "+g
        return "connect it on the setup page"
    _RESET_AT_RX=re.compile(r'(?i)try again (?:at|after)\s+([A-Z][a-z]{2,8})\s+(\d{1,2})(?:st|nd|rd|th)?,?\s+(\d{4})(?:\s+at)?\s+(\d{1,2}):(\d{2})\s*(AM|PM)?')
    _MONTHS={m:i+1 for i,m in enumerate(("jan","feb","mar","apr","may","jun","jul","aug","sep","oct","nov","dec"))}
    @staticmethod
    def _parse_reset_ts(text):
        """Pull an explicit reset time out of a provider error ("try again at Aug 27th, 2026
        12:12 PM"). Returns epoch seconds or 0. Local time — providers phrase these in the
        user's clock, and being an hour off matters less than defaulting to 2 minutes."""
        m=Hub._RESET_AT_RX.search(str(text or ""))
        if not m:return 0
        try:
            mon=Hub._MONTHS.get(m.group(1)[:3].lower())
            if not mon:return 0
            hh=int(m.group(4))%12+(12 if (m.group(6) or "").upper()=="PM" else 0)
            ts=time.mktime((int(m.group(3)),mon,int(m.group(2)),hh,int(m.group(5)),0,0,0,-1))
            return ts if ts>time.time() else 0
        except Exception:return 0
    # Where a seat's capacity actually comes from, and where you top it up. Two different
    # products per provider: a flat subscription (what these CLIs sign into by default) and
    # metered prepay credits (needs an API key). Only the second is "buy tokens".
    SEAT_BILLING={
     "OpenAI":{"provider":"OpenAI","sub_url":"https://chatgpt.com/#pricing","sub_label":"Upgrade ChatGPT plan",
      "credit_url":"https://platform.openai.com/settings/organization/billing/overview","credit_label":"Add OpenAI API credits",
      "key_env":"OPENAI_API_KEY","auth_file":"~/.codex/auth.json"},
     "Claude":{"provider":"Anthropic","sub_url":"https://claude.ai/upgrade","sub_label":"Upgrade Claude plan",
      "credit_url":"https://console.anthropic.com/settings/billing","credit_label":"Add Anthropic API credits",
      "key_env":"ANTHROPIC_API_KEY","auth_file":"~/.claude/.credentials.json"},
     "Grok":{"provider":"xAI","sub_url":"https://grok.com","sub_label":"Manage xAI plan",
      "credit_url":"https://console.x.ai","credit_label":"Add xAI API credits",
      "key_env":"GROK_API_KEY","auth_file":"~/.grok/auth.json"},
     "Google":{"provider":"Google","sub_url":"https://one.google.com/about/google-ai-plans/","sub_label":"Manage Google AI plan",
      "credit_url":"https://aistudio.google.com/app/apikey","credit_label":"Add Google API key / billing",
      "key_env":"GOOGLE_API_KEY","auth_file":"~/.antigravity/auth.json"},
    }
    def seat_billing(s,name):
        """What buying more capacity means for THIS seat, given how it is actually signed in.
        A CLI on subscription auth cannot spend prepaid API credits — saying otherwise would
        send the user to buy tokens that the seat will never touch."""
        n=Hub._seat_key(name);b=Hub.SEAT_BILLING.get(n)
        if not b:return None
        env=b.get("key_env") or ""
        has_key=bool(os.environ.get(env)) if env else False
        mode="unknown";detail=""
        try:
            p=os.path.expanduser(b.get("auth_file") or "")
            if p and os.path.isfile(p):
                raw=open(p,encoding="utf-8",errors="replace").read()[:20000]
                low=raw.lower()
                if '"auth_mode"' in low and '"chatgpt"' in low:mode="subscription";detail="ChatGPT account auth"
                elif '"auth_mode": "api"' in low or '"api_key"' in low and env.lower() in low:mode="api_key"
                elif "oidc" in low or "refresh_token" in low or "oauth" in low:mode="subscription";detail="account (OAuth/OIDC) auth"
        except Exception:pass
        if mode=="unknown" and has_key:mode="api_key";detail="API key in "+env
        prepay=(mode=="api_key")
        return {"provider":b["provider"],"mode":mode,"detail":detail,"prepay_active":prepay,
         "has_api_key":has_key,"key_env":env,
         "sub_url":b["sub_url"],"sub_label":b["sub_label"],
         "credit_url":b["credit_url"],"credit_label":b["credit_label"],
         "note":("Metered API credits are in use — topping up restores this seat."
                 if prepay else
                 "This seat signs in with a "+b["provider"]+" subscription, not prepaid credits. "
                 "Buying API credits will NOT lift this limit unless you also set "+(env or "an API key")+
                 " so the CLI bills metered usage.")}
    def payg_status(s,name):
        b=s.seat_billing(name)
        if not b:return None
        n=Hub._seat_key(name)
        stored=bool((s.cfg.get("seat_api_keys") or {}).get(n))
        return {"seat":n,"on":bool(b.get("prepay_active")) or stored,"supported":n in Hub.SEAT_BILLING,
         "needs_key":not (stored or b.get("has_api_key")),"key_env":b.get("key_env") or "",
         "get_key_url":{"OpenAI":"https://platform.openai.com/api-keys","Claude":"https://console.anthropic.com/settings/keys",
                        "Grok":"https://console.x.ai","Google":"https://aistudio.google.com/app/apikey"}.get(n,""),
         "provider":b.get("provider") or n,"mode":b.get("mode")}
    def payg_enable(s,name,key=""):
        """Switch a seat from subscription auth to metered API billing, for real: store the key,
        put it in this process's env (children inherit it), and for Codex run the CLI's own
        `login --with-api-key` since a subscription auth.json otherwise wins over the env var.
        The previous auth file is backed up so the toggle is reversible."""
        n=Hub._seat_key(name);b=Hub.SEAT_BILLING.get(n)
        if not b:return {"ok":False,"error":"seat has no billing profile"}
        key=(key or "").strip() or os.environ.get(b.get("key_env") or "","")
        if not key:return {"ok":False,"need_key":True,"error":"no API key provided"}
        d=dict(s.cfg.get("seat_api_keys") or {});d[n]=key;s.cfg["seat_api_keys"]=d
        if b.get("key_env"):os.environ[b["key_env"]]=key
        note=""
        if n=="OpenAI":
            try:
                p=os.path.expanduser(b.get("auth_file") or "")
                if p and os.path.isfile(p) and not os.path.isfile(p+".braid-sub.bak"):
                    shutil.copyfile(p,p+".braid-sub.bak")
                exe=None
                try:
                    import delve_providers as PROV
                    exe,_=PROV._find_cli((PROV._CLI_SEATS or {}).get("OpenAI") or {})
                except Exception:pass
                if exe:
                    r=_run([exe,"login","--with-api-key"],input=key,capture_output=True,text=True,timeout=90)
                    note=("codex login --with-api-key ok" if r.returncode==0 else "codex login rc="+str(r.returncode)+" "+((r.stderr or r.stdout) or "")[:160])
                    if r.returncode!=0:
                        s.cfg["seat_api_keys"]=({k:v for k,v in d.items() if k!=n});save_cfg(s.cfg)
                        return {"ok":False,"error":note}
            except Exception as e:note="codex login failed: "+str(e)[:140]
        s.limit_clear(n);save_cfg(s.cfg)
        s.emit({"type":"status","text":SEAT_LABEL.get(n,n)+" → pay-as-you-go enabled ("+(b.get("provider") or n)+" metered billing)"})
        s.emit({"type":"limits","seats":s.limits_snapshot()})
        return {"ok":True,"seat":n,"note":note,"payg":s.payg_status(n)}
    def payg_disable(s,name):
        n=Hub._seat_key(name);b=Hub.SEAT_BILLING.get(n) or {}
        d=dict(s.cfg.get("seat_api_keys") or {});d.pop(n,None);s.cfg["seat_api_keys"]=d
        if b.get("key_env"):os.environ.pop(b["key_env"],None)
        note=""
        try:
            p=os.path.expanduser(b.get("auth_file") or "")
            if p and os.path.isfile(p+".braid-sub.bak"):
                shutil.copyfile(p+".braid-sub.bak",p);note="restored subscription auth"
        except Exception as e:note="restore failed: "+str(e)[:120]
        save_cfg(s.cfg)
        s.emit({"type":"status","text":SEAT_LABEL.get(n,n)+" → pay-as-you-go off"+(" ("+note+")" if note else "")})
        return {"ok":True,"seat":n,"note":note,"payg":s.payg_status(n)}
    def _limits(s):
        d=s.cfg.get("seat_limits")
        if not isinstance(d,dict):d={};s.cfg["seat_limits"]=d
        return d
    def limit_left(s,name):
        rec=s._limits().get(name)
        if not isinstance(rec,dict):return 0
        left=int((rec.get("until") or 0)-time.time())
        if left<=0:
            # Timer expired: drop the record so the next round probes the seat automatically.
            # If the provider is still dry the failure re-limits it (with escalation).
            s._limits().pop(name,None);save_cfg(s.cfg)
            s.emit({"type":"status","text":SEAT_LABEL.get(name,name)+" limit timer expired — seat re-enabled, will probe next turn"})
            return 0
        return left
    def limit_info(s,name):
        rec=s._limits().get(name)
        if not isinstance(rec,dict) or (rec.get("until") or 0)<=time.time():return None
        return {"why":rec.get("why") or "","kind":rec.get("kind") or "limit","until":int(rec.get("until") or 0),"left_s":max(0,int(rec.get("until",0)-time.time())),"strikes":int(rec.get("strikes") or 1),"billing":s.seat_billing(name),"payg":s.payg_status(name)}
    def limit_set(s,name,why,kind="rate",reply=""):
        """Automatic seat disable. Reset time comes from the provider error when it names one;
        otherwise escalates per consecutive strike (10m -> 30m -> 90m -> 4h30 cap) so a seat
        that recovers with fresh credits comes back on the first post-expiry probe."""
        d=s._limits();prev=d.get(name) if isinstance(d.get(name),dict) else {}
        strikes=int(prev.get("strikes") or 0)+1
        until=Hub._parse_reset_ts(reply)
        if not until:
            base=600*(3**min(strikes-1,3))
            until=time.time()+min(base,16200)
        d[name]={"why":str(why or kind)[:200],"kind":kind,"until":until,"strikes":strikes,"set_at":time.time()}
        save_cfg(s.cfg)
        import datetime as _dt
        s.emit({"type":"status","text":SEAT_LABEL.get(name,name)+" auto-disabled ("+kind+") until "+_dt.datetime.fromtimestamp(until).strftime("%b %d %H:%M")+" — override in the sidebar or it re-probes on expiry"})
        s.emit({"type":"limits","seats":s.limits_snapshot()})
    def limit_clear(s,name):
        had=s._limits().pop(name,None) is not None
        if had:
            save_cfg(s.cfg)
            s.emit({"type":"status","text":SEAT_LABEL.get(name,name)+" limit cleared by user — seat live again"})
            s.emit({"type":"limits","seats":s.limits_snapshot()})
        return had
    def limits_snapshot(s):
        out={}
        for n in list(s._limits().keys()):
            info=s.limit_info(n)
            if info:out[n]=info
        return out
    def _cool_left(s,name):
        d=getattr(s,"_cool",None) or {}
        rec=d.get(name)
        if not rec:return 0
        left=int(rec[1]-time.time())
        return left if left>0 else 0
    def _cool_set(s,name,sec,why):
        d=getattr(s,"_cool",None)
        if not isinstance(d,dict):d={};s._cool=d
        d[name]=(str(why or "cooling")[:160],time.time()+max(15,int(sec)))
    def _fail_kind(s,r):
        if not r:return "empty"
        low=str(r).lower()
        if "incomplete]" in low and ("ended this turn early" in low or "stopreason=" in low.replace(" ","")):return "error"
        if not str(r).startswith("["):return ""
        if any(k in low for k in ("rate-limit","rate limit","quota","429","resource_exhausted","too many requests","usage limit","limit exceeded")):return "rate"
        if any(k in low for k in ("not installed","not found","missing]","agy not found","produced nothing] get it")):return "missing"
        if any(k in low for k in ("not signed","auth]","oauth","unauthorized","401","login")):return "auth"
        if any(k in low for k in ("unavailable","overloaded","503","502","500 ","internal server error","service is currently","capacity")):return "unavailable"
        if any(k in low for k in ("timed out","timeout")):return "timeout"
        if any(k in low for k in ("error","stopped","unavailable","produced nothing")):return "error"
        return ""
    def live_roster(s):
        now=time.time()
        c=getattr(s,"_live_r_c",None)
        if c and (now-c[1])<5.0:return list(c[0])
        res=[n for n in s.roster_all() if s.seat_up(n)]
        s._live_r_c=(res,now);return list(res)
    def seats_available(s):
        """Cached: this walks every seat and touches the filesystem, and /api/state asks
        for it several times per poll. Any config write clears it via seats_dirty()."""
        key=(repr(sorted((s.cfg.get("providers") or {}).items())),s.cfg.get("adam_enabled"))
        c=getattr(s,"_seatc",None)
        if c and c[0]==key and (time.time()-c[1])<20:return list(c[2])
        out=[]
        for n in AGENTS:
            if n in out:continue
            if n=="Adam" and not s.adam_available():continue
            if s.seat_up(n) or (s.seat_cfg(n).get("kind") or "").lower() not in ("","off"):out.append(n)
        out=out or [n for n in CORE_AGENTS if n!="Adam" or s.adam_available()] or list(CORE_AGENTS)
        s._seatc=(key,time.time(),list(out))
        return list(out)
    def oneshot(s,name,prompt,system=""):
        """Ask ONE seat a single self-contained question. Never recorded, never continues a
        room session - and any CLI seat it touches is re-primed so the room's thread is intact."""
        pc=s.seat_cfg(name)
        kind=(pc.get("kind") or "").lower()
        if PROV is not None and kind and kind not in ("cli","adam"):
            return PROV.ask(name,pc,prompt,system)
        if name=="Adam":return s.call_adam((system+chr(10)+chr(10) if system else "")+prompt)
        if name in EXTRA_AGENTS:return s.call_cli_seat(name,(system+chr(10)+chr(10) if system else "")+prompt)
        keep=s.sid.get(name)
        try:
            s.sid.pop(name,None)
            return s._call(name,(system+chr(10)+chr(10) if system else "")+prompt,False)
        finally:
            s.started[name]=False
            if keep is not None:s.sid[name]=keep
            else:s.sid.pop(name,None)
    def _model_flags(s,name):
        mid=s.seat_model(name);eff=s.seat_effort(name)
        if name=="Cursor" and mid and eff and "effort=" not in mid:
            mid=(mid[:-1]+",effort="+eff+"]") if mid.endswith("]") else (mid+"[effort="+eff+"]")
        flags=[]
        if mid:
            if name=="OpenAI":flags+=["-m",mid]
            elif name in ("Copilot","Cursor","OpenCode"):flags+=["--model",mid]
        if name=="Copilot" and eff:flags+=["--effort",eff]
        if name=="OpenAI" and eff:flags+=["-c","model_reasoning_effort="+eff]
        return flags
    def _openai_argv(s,parts,tail):
        drop=set(("exec","--skip-git-repo-check","-m","--model"))
        base=[];i=0;parts=list(parts or [])
        while i<len(parts):
            a=parts[i]
            if a in drop or "{prompt}" in str(a) or str(a).startswith("model="):i+=1;continue
            if a=="-c" and i+1<len(parts) and (str(parts[i+1]).startswith("model=") or str(parts[i+1]).startswith("model_reasoning")):i+=2;continue
            base.append(a);i+=1
        mid=s.seat_model("OpenAI");eff=s.seat_effort("OpenAI")
        out=["exec","--skip-git-repo-check"]+(["-m",mid] if mid else [])+(["-c","model_reasoning_effort="+eff] if eff else [])+base
        return out if tail is None else out+[tail]
    def call_cli_seat(s,name,prompt):
        """Run a subscription CLI seat. NEVER put a room-sized prompt on argv.

        Windows CreateProcess hard-caps the command line at ~8191 characters. npm seats
        resolve to `.cmd` wrappers that re-enter via `cmd.exe /c …`, so most of that budget
        is already spent before our args. Expanding `{prompt}` into argv was why OpenAI /
        Copilot returned "The command line is too long." on every real turn. Short pings
        still go on argv; long prompts: Codex/OpenCode read stdin via `-`; Copilot/Cursor
        treat `-p -` as the literal string `-` (empty-seat bug) so they get a temp-file pointer.

        Codex: `codex exec [OPTIONS] [PROMPT]` — `--skip-git-repo-check` is an *exec*
        option (after `exec`), not a global option. Putting it before `exec` fails.
        Model pins: OpenAI `-m`, Copilot/Cursor/OpenCode `--model`."""
        if PROV is None:return "[unavailable] provider bridge missing"
        spec=(PROV._CLI_SEATS or {}).get(name) or {}
        path,_how=PROV._find_cli(spec)
        if not path:
            return "["+name+" not installed] open /setup for a guided install, or get it with: "+(spec.get("get") or "see the setup page")
        argv=list(spec.get("argv") or ["{prompt}"])
        uses=any("{prompt}" in a for a in argv)
        wrapper=os.name=="nt" and path.lower().endswith((".cmd",".bat",".ps1"))
        WIN_SOFT=(800 if wrapper else 3500) if os.name=="nt" else 100000
        mf=s._model_flags(name)
        tmp=None
        try:
            if not uses:
                out,err,rc=s._exec([path]+mf+list(argv),prompt,who=name)
            else:
                prompt=str(prompt or "")
                expanded=[(a.replace("{prompt}",prompt) if "{prompt}" in a else a) for a in argv]
                clen=len(path)+1+sum(len(a)+1 for a in expanded)+sum(len(a)+1 for a in mf)
                if wrapper:clen+=len(os.environ.get("ComSpec") or "cmd.exe")+16
                if clen<=WIN_SOFT and len(prompt)<=WIN_SOFT:
                    if name=="OpenAI":expanded=s._openai_argv(expanded,prompt)
                    elif mf:expanded=mf+[a for a in expanded if a not in mf and a not in ("-m","--model")]
                    out,err,rc=s._exec([path]+expanded,None,who=name)
                else:
                    rest=[a for a in argv if "{prompt}" not in a]
                    if name=="OpenAI":
                        out,err,rc=s._exec([path]+s._openai_argv(rest,"-"),prompt,who=name)
                    elif name=="OpenCode":
                        out,err,rc=s._exec([path]+(["run"] if not rest else rest[:1])+mf+(rest[1:] if rest else [])+["-"],prompt,who=name)
                    elif name in ("Copilot","Cursor"):
                        fd,tmp=tempfile.mkstemp(prefix="braid_"+name.lower()+"_",suffix=".txt");os.close(fd)
                        open(tmp,"w",encoding="utf-8").write(prompt)
                        ptr="Read the UTF-8 task file at this absolute path and complete it fully; reply with only your answer text (no meta about the file): "+tmp
                        flags=["--allow-all-tools"] if name=="Copilot" else []
                        out,err,rc=s._exec([path]+mf+["-p",ptr]+flags,None,who=name)
                    else:
                        out,err,rc=s._exec([path]+mf+rest+["-"],prompt,who=name)
        except Exception as e:
            return "["+name+" error] "+str(e)[:200]
        finally:
            if tmp:
                try:os.unlink(tmp)
                except Exception:pass
        r=s._strip_cli_noise(out,prompt)
        if r:return r
        # An ERROR/limit line is the truth; a prompt echo is noise. The echo used to fill the
        # 400-char budget so "usage limit" never reached _is_fail and the seat retried forever.
        raw_err=(err or "")+"\n"+(out or "")
        for ln in raw_err.splitlines():
            if re.search(r'(?i)^\s*(ERROR|FATAL)\b|usage limit|rate.?limit|quota|unauthorized|not logged in|login required|401|403|429',ln):
                return "["+name+" error] "+ln.strip()[:300]
        e=s._strip_cli_noise(err,prompt)[:400]
        if "command line is too long" in e.lower() or "WinError 206" in e:
            return "["+name+" produced nothing] prompt was too large for argv — Braid should have used stdin; update and retry"
        if "trusted directory" in e.lower() or "skip-git-repo-check" in e.lower():
            return "["+name+" produced nothing] "+e+" — hub should pass --skip-git-repo-check after exec; restart Delve if still failing"
        return "["+name+" produced nothing] "+(e or "check the command for this seat in setup — the flags may differ in your version")
    def _strip_cli_noise(s,txt,prompt=""):
        """Codex and friends print a startup banner plus a verbatim echo of the prompt on the
        same stream as the answer. Rendering that as the seat's reply is how the room ended up
        quoting its own system prompt back at itself."""
        t=(txt or "").replace("\r\n","\n")
        t=Hub._CLI_NOISE_RX.sub("",t)
        # Any line that appears verbatim in the prompt is an echo, wherever it sits — the old
        # head-anchored match missed mid-prompt chunks like "=== CONVERSATIONAL PATH PRESET".
        praw=str(prompt or "")
        if len(praw)>=40:
            t="\n".join(ln for ln in t.split("\n") if not (len(ln.strip())>=20 and ln.strip() in praw))
        p=re.sub(r'\s+',' ',praw).strip()
        if len(p)>=40:
            for n in (400,200,80):
                head=re.escape(p[:n]).replace(r"\ ",r"\s+")
                t=re.sub(r'(?is)'+head+r'.*?(?=\n\s*\n|\Z)',"",t,count=1)
                if not re.sub(r'\s+',' ',t).strip():break
        return t.strip()
    def _clip_prompt(s,name,prompt):
        try:cap=int(s.cfg.get("prompt_max_chars") or s.cfg.get("seat_max_prompt_chars") or os.environ.get("DELVE_PROMPT_MAX","48000") or 48000)
        except Exception:cap=48000
        if name=="Grok":
            try:cap=min(cap,int(s.cfg.get("grok_prompt_max") or os.environ.get("DELVE_GROK_PROMPT_MAX","40000") or 40000))
            except Exception:cap=min(cap,40000)
        if name in ("Claude","Google","ChatGPT","OpenAI","Copilot"):
            try:cap=min(cap,int(s.cfg.get("cli_prompt_max") or os.environ.get("DELVE_CLI_PROMPT_MAX","52000") or 52000))
            except Exception:cap=min(cap,52000)
        p=str(prompt or "")
        if len(p)<=cap:return p
        mid="\n\n…[delve hard-clip: middle omitted; PATH + latest handoff preserved at end]…\n\n"
        room=max(400,cap-len(mid));head=max(120,int(room*0.28));tail=max(200,room-head)
        try:s.emit({"type":"status","text":name+" prompt hard-clip "+str(len(p))+"→"+str(cap)+" chars (timeout guard)"})
        except Exception:pass
        return p[:head]+mid+p[-tail:]
    def _call(s,name,prompt,cont):
        prompt=s._clip_prompt(name,prompt)
        pc=s.seat_cfg(name)
        kind=(pc.get("kind") or "").lower()
        if PROV is not None and kind and kind not in ("cli","adam"):
            sysm=s.adam_system_prompt() if name=="Adam" else ""
            mid=s.seat_model(name)
            if mid and not pc.get("model"):pc=dict(pc);pc["model"]=mid
            return s._abortable(name,lambda:PROV.ask(name,pc,prompt,sysm))
        if name in EXTRA_AGENTS:return s.call_cli_seat(name,prompt)
        if name=="Claude":return s.call_claude(prompt,cont)
        if name=="Grok":return s.call_grok(prompt,cont)
        if name=="Google":return s._abortable("Google",lambda:s.call_google(prompt,cont))
        return s._abortable("Adam",lambda:s.call_adam(prompt))
    def _abortable(s,name,fn):
        if s.abort.is_set():return "["+str(name).lower()+" stopped]"
        box={};to=s.turn_timeout(name);t0=time.time();frame=0
        def w():
            try:box["v"]=fn()
            except Exception as e:box["v"]="["+str(name).lower()+" error] "+str(e)[:200]
        th=threading.Thread(target=w,daemon=True);th.start()
        while th.is_alive():
            th.join(0.25)
            if s.abort.is_set() and th.is_alive():return "["+str(name).lower()+" stopped]"
            elapsed=int(time.time()-t0)
            # `to` is 0 when the wall-clock cap is off (v3.7.24), and `elapsed>=0` is true on the
            # FIRST pass - so every seat that comes through here (Gemini, Adam: HTTP/tool turns,
            # not streamed subprocesses) was killed at zero seconds with "timed out after 0s".
            # No cap means no cap; these calls carry their own HTTP timeouts underneath and Stop
            # still works, so there is nothing to invent a ceiling for.
            if to>0 and elapsed>=to:
                s.emit({"type":"status","text":name+" HTTP/tool turn hit "+str(to)+"s — ending so the room can carry on"})
                return "["+str(name).lower()+" error] timed out after "+str(to)+"s"
            if frame%2==0:
                note=s.ctx_line(name) if CTX is not None else ""
                s.emit({"type":"tick","key":"wait","frame":frame//2,"who":name,"ctx":note,
                 "text":name+" · "+str(elapsed)+"s"+("/"+str(to)+"s" if to>0 else "")+(" · "+note if note else "")})
            frame+=1
        return box.get("v","")
    def _is_fail(s,r):
        return bool(s._fail_kind(r))
    def remote_turn(s,name,messages,extra="",record=False):
        """One seat turn against an external transcript (phone hub). Does not clobber the PC room.
        messages: list of {who|role, text|content}. who defaults Anthony for user/role user."""
        nm=s._canon(name) if name else ""
        if not nm or nm not in AGENTS:
            aliases={"gemini":"Google","chatgpt":"OpenAI","local":"Adam"}
            nm=aliases.get((name or "").strip().lower(),nm)
        if nm not in AGENTS:return {"ok":False,"error":"unknown seat","seat":name}
        rows=[]
        for m in (messages or []):
            if not isinstance(m,dict):continue
            who=(m.get("who") or "").strip()
            role=(m.get("role") or "").strip().lower()
            txt=(m.get("text") or m.get("content") or "").strip()
            if not txt:continue
            if not who:who="Anthony" if role in ("user","human","anthony","you","") else (m.get("speaker") or "Peer")
            rows.append((who,txt))
        if not rows:return {"ok":False,"error":"empty messages"}
        old_t=list(s.t);old_idx=dict(s.idx);old_started=dict(s.started)
        try:
            s.t=rows;s.idx={};s.started={}
            speaker,reply=s.turn(nm,start=0,extra=extra or "",record=bool(record))
            return {"ok":True,"who":speaker,"text":reply or "","model":s.seat_model(speaker),"model_short":s.seat_model_short(speaker),"seat":nm}
        except Exception as e:
            return {"ok":False,"error":str(e)[:240],"seat":nm}
        finally:
            s.t=old_t;s.idx=old_idx;s.started=old_started
    def remote_caps(s):
        out={}
        for n in s.roster_all():
            up=bool(s.seat_up(n)) if n!="Adam" else bool(s.adam_up())
            out[n]={"up":up,"label":SEAT_LABEL.get(n,n),"model":s.seat_model(n),"model_short":s.seat_model_short(n)}
        return {"ok":True,"seats":out,"version":VERSION,"adam_up":s.adam_up()}
    def turn(s,name,start=None,extra="",record=True):
        lab=SEAT_LABEL.get(name,name)
        lim=s.limit_left(name)
        if lim and name!="Adam":
            info=s.limit_info(name) or {}
            import datetime as _dt
            when=_dt.datetime.fromtimestamp(info.get("until",time.time())).strftime("%b %d %H:%M")
            reply="["+lab+" limited] "+(info.get("why") or info.get("kind") or "provider limit")+" — auto-retries "+when+" (override in sidebar)"
            s.emit({"type":"status","text":lab+" skipped — limited until "+when+" ("+(info.get("kind") or "limit")+")"})
            s.emit({"type":"msg","who":name,"text":reply,"model":s.seat_model(name),"model_short":s.seat_model_short(name)})
            if record:s.add(name,reply);s.idx[name]=len(s.t)
            return name,reply
        cool=s._cool_left(name)
        if cool and name!="Adam":
            why=(getattr(s,"_cool",{}) or {}).get(name,("",0))[0]
            reply="["+lab+" unavailable] "+(why or "cooling down")+" — retry in "+str(cool)+"s"
            s.emit({"type":"status","text":lab+" skipped ("+str(cool)+"s cool-down) — "+(why or "rate/error")})
            s.emit({"type":"msg","who":name,"text":reply,"model":s.seat_model(name),"model_short":s.seat_model_short(name)})
            if record:s.add(name,reply);s.idx[name]=len(s.t)
            return name,reply
        if not s.seat_up(name) and name!="Adam":
            hint=s.seat_hint(name)
            reply="["+lab+" unavailable] "+hint
            s.emit({"type":"status","text":lab+" is not available — "+hint})
            s.emit({"type":"msg","who":name,"text":reply,"model":s.seat_model(name),"model_short":s.seat_model_short(name)})
            if record:s.add(name,reply);s.idx[name]=len(s.t)
            return name,reply
        mach=""
        try:
            import delve_machine as _MC
            mach=_MC.note_for(name,int(os.environ.get("DELVE_PORT") or 8788))
        except Exception:mach=""
        fy="\n\n".join(x for x in (getattr(s,"files_note","") or "",s._fyi_block(),mach) if x)
        extra=((fy+"\n\n"+extra) if extra else fy) if fy else extra
        if name=="Adam":
            s._update_adam_handoff_summary()
            prompt=s.render_adam(extra);cont=False
        else:
            st=s.idx.get(name,0) if start is None else start
            prompt=s.render(st,name,extra);cont=s.started.get(name,False)
            if cont and s._cli_should_fresh(name,prompt):
                s._cli_drop_pin(name);cont=False
                # The dropped session WAS the seat's memory of everything before `st`. Sending a
                # fresh session the delta alone gave it amnesia plus a diff — seats re-derived
                # the whole board every refresh. A fresh session gets the story from the top,
                # which _apply_compact folds down to the recap + delta for long rooms.
                prompt=s.render(0,name,extra)
                try:s.emit({"type":"status","text":lab+" session refreshed — re-briefing from the top (compacted)"})
                except Exception:pass
        s.emit({"type":"thinking","who":name})
        if ACT is not None:
            try:ACT.turn_start(name,s.work,s.emit)
            except Exception:pass
        reply=run_spin(name,lambda:s._call(name,prompt,cont)) if s.spinner else s._call(name,prompt,cont)
        speaker=name
        kind=s._fail_kind(reply)
        if kind=="rate":
            s.limit_set(name,lab+" quota/rate limit: "+str(reply)[:140],"rate",reply=reply)
            s._cli_drop_pin(name)
        elif kind=="unavailable":
            s.limit_set(name,lab+" provider unavailable: "+str(reply)[:140],"unavailable",reply=reply)
            s._cli_drop_pin(name)
        elif kind=="auth":
            s.limit_set(name,lab+" needs sign-in — "+s.seat_hint(name),"auth",reply=reply)
            s.emit({"type":"status","text":lab+" auth failed — "+s.seat_hint(name)})
        elif kind=="missing":
            s._cool_set(name,180,lab+" not installed / not found")
            s.emit({"type":"status","text":lab+" missing — "+s.seat_hint(name)})
        elif kind=="timeout":
            s.emit({"type":"status","text":lab+" timed out — ending turn"})
            s._cli_drop_pin(name)
            try:s.emit({"type":"status","text":lab+" CLI pin cleared after timeout (next call starts fresh)"})
            except Exception:pass
        elif kind=="error":
            s._cli_drop_pin(name)
        if s.abort.is_set():
            s._cli_drop_pin(name)
        use_adam=bool(kind) and name in ("Claude","Grok","Google") and not s.abort.is_set() and s.cfg.get("adam_fallback",True) and s.adam_up()
        if use_adam and kind not in ("missing","auth"):
            s.emit({"type":"status","text":lab+" failed ("+kind+") — Adam ("+s.cfg.get("adam_mode","light")+") stepping in"})
            if ACT is not None:
                try:ACT.turn_start("Adam",s.work,s.emit)
                except Exception:pass
            a=run_spin("Adam",lambda:s.call_adam(s.render_adam())) if s.spinner else s._abortable("Adam",lambda:s.call_adam(s.render_adam()))
            if a and not str(a).startswith("[adam"):speaker="Adam";reply=a
        s.started[speaker]=True
        # A seat that reports no usage at all (grok/agy/codex return one final blob) still has
        # a session that grows. Estimate it from what we sent and what came back, so the same
        # 20%-of-window rule applies to every seat rather than only the one that streams.
        if CTX is not None and not s.ctx.get(name):
            try:s.ctx_add_est(name,CTX.est(len(prompt or "")+len(reply or "")))
            except Exception:pass
        if ACT is not None:
            try:ACT.turn_end(speaker)
            except Exception:pass
        if record:s.add(speaker,reply);s.idx[speaker]=len(s.t)
        # SHOW IT, THEN BANK IT. Banking is a side effect - it teaches PTEX - and it sat between
        # the answer being ready and the answer being emitted, making two HTTP calls to Adam on
        # the way. With Adam down each call blocks until it times out, so every seat's answer was
        # held back ~3.4s for a service the answer does not depend on. In a 6-seat concurrent
        # round that is 20s of the room looking dead, which is what "only one answered" was.
        s.emit({"type":"msg","who":speaker,"text":reply,"model":s.seat_model(speaker),"model_short":s.seat_model_short(speaker)})
        s._ptex_write_bg(speaker,reply)
        return speaker,reply
    def _ptex_is_junk(s,reply):
        r=(reply or "").strip()
        if not r:return True
        if r.startswith("["):return True
        low=r.lower()
        if re.match(r'(?is)^\s*(error|failed|unavailable|traceback|exception|timeout|rate.?limit)',r):return True
        if len(r)<700 and re.search(r'(?i)\b(not stored|connection refused|resource_exhausted|quota|rate.?limit|max turns|could not (start|connect|reach)|traceback \(most recent\))\b',r):return True
        if len(r)<500 and low.count("error")>=2:return True
        if re.search(r'(?i)^\[(claude|grok|google|adam)\s',r):return True
        return False
    def _ptex_write_bg(s,name,reply):
        """Bank off the turn's thread, and not at all when Adam is known to be down.

        atlas_record is two HTTP calls and there is no answer waiting on their result, so the
        only thing keeping them inline was habit. adam_up() is the cached probe, so a dead Adam
        costs one lookup here instead of two connection timeouts per seat."""
        try:
            if ADAM is None or not s.cfg.get("ptex_learn",True):return
            if not s.adam_up():
                if not getattr(s,"_ptex_said_down",False):
                    s._ptex_said_down=True
                    try:s.emit({"type":"status","text":"PTEX is not banking this room — Adam is not running"})
                    except Exception:pass
                return
            s._ptex_said_down=False
            threading.Thread(target=s._ptex_write,args=(name,reply),daemon=True).start()
        except Exception:pass
    def _ptex_write(s,name,reply):
        if ADAM is None or not hasattr(ADAM,"atlas_record") or not s.cfg.get("ptex_learn",True):return
        r=(reply or "").strip()
        if s._ptex_is_junk(r):return
        g=s._last_user_q(1) or s._goal_line()
        if not g:
            for w,x in reversed(s.t[-8:]):
                if w!=name and w!="System" and (x or "").strip():
                    g=re.sub(r'\s+',' ',x).strip()[:300];break
        if not g:return
        r2=re.sub(r'\s+',' ',r)[:1200]
        ok=False;err=""
        for sid in (s.seat_key(name),s._durable_slot(name)):
            try:
                res=ADAM.atlas_record(sid,g,r2) or {}
                if res.get("recorded"):ok=True
                elif res.get("error") and not err:err=str(res.get("error"))[:120]
            except Exception as e:
                if not err:err=str(e)[:120]
        if not ok:
            try:s.emit({"type":"status","text":"PTEX did not bank this reply"+((" — "+err) if err else " — is Adam up?")})
            except Exception:pass
    @property
    def _flow_brief(s):
        """Per-THREAD. Two seats running the same wave would otherwise overwrite each other's
        brief on the way in, and Adam decides work-vs-chat from this value."""
        return getattr(getattr(s,"_tls",None),"fb","") or ""
    @_flow_brief.setter
    def _flow_brief(s,v):
        if not hasattr(s,"_tls"):s._tls=threading.local()
        s._tls.fb=v or ""
    def _proc_add(s,p):
        """One slot could only ever hold the LAST child, so with two seats running at once an
        E-STOP left one of them alive and still writing into the room."""
        if p is None:return
        with s._proclk:s._procs.add(p);s.proc=p
    def _proc_drop(s,p):
        if p is None:return
        with s._proclk:
            s._procs.discard(p)
            if s.proc is p:s.proc=next(iter(s._procs),None)
    def _estop(s):
        s.abort.set()
        with s._proclk:live=list(s._procs)
        for p in live:
            try:s._kill_tree(p)
            except Exception:pass
        s._kill_tree(s.proc)
        for n in list((getattr(s,"sid",None) or {}).keys()):
            try:s._cli_drop_pin(n)
            except Exception:pass
        s.emit({"type":"estop"})
    def _watch_char(s,ch,buf):
        if ch in ("\x1b","\x03"):s._estop();return ""
        if ch in ("\r","\n"):
            line=buf.strip();sys.stdout.write("\n")
            if line.lower() in ("/stop","stop","/estop","estop","/halt"):s._estop()
            elif line:
                s.interjects.append(line);s._estop()
                sys.stdout.write(DIM+"↳ interject — stopping current turn, then your line goes next"+RST+"\n");sys.stdout.flush()
            return ""
        if ch in ("\b","\x7f"):return buf[:-1]
        sys.stdout.write(ch);sys.stdout.flush();return buf+ch
    def _watch_loop(s):
        buf=""
        while s._watch:
            if msvcrt.kbhit():buf=s._watch_char(msvcrt.getwch(),buf)
            else:time.sleep(0.03)
    def _watch_loop_posix(s):
        import select,termios,tty
        fd=sys.stdin.fileno()
        try:old=termios.tcgetattr(fd);tty.setcbreak(fd)
        except Exception:return
        buf=""
        try:
            while s._watch:
                r,_,_=select.select([sys.stdin],[],[],0.05)
                if r:buf=s._watch_char(sys.stdin.read(1),buf)
        finally:
            try:termios.tcsetattr(fd,termios.TCSADRAIN,old)
            except Exception:pass
    def _watch_start(s):
        s.abort.clear();s.interjects=[]
        if sys.stdin.isatty() and (msvcrt is not None or os.name!="nt"):
            s._watch=True;threading.Thread(target=(s._watch_loop if msvcrt is not None else s._watch_loop_posix),daemon=True).start()
    def _watch_stop(s):s._watch=False
    def _fyi_block(s):
        rows=[x for x in (getattr(s,"fyi",None) or []) if (x or "").strip()][-5:]
        if not rows:return ""
        return ("=== FYI FROM ANTHONY (context he wants every seat to hold — NOT a new request, do not answer it as a task) ===\n"
                +"\n".join("  - "+re.sub(r'\s+',' ',r).strip()[:600] for r in rows)
                +"\nUse it if it bears on your seat's job. Do not restate it back at him.")
    def fyi_add(s,text):
        t=(text or "").strip()
        if not t:return []
        s.fyi=[x for x in (getattr(s,"fyi",None) or []) if x!=t][-4:]+[t]
        s.emit({"type":"fyi","notes":list(s.fyi)});return list(s.fyi)
    def fyi_clear(s):
        s.fyi=[];s.emit({"type":"fyi","notes":[]});return []
    def _drain(s):
        msgs=s.interjects;s.interjects=[]
        for m in msgs:s.add("Anthony",m);s.emit({"type":"user","who":"Anthony","text":m})
        return bool(msgs)
    def maybe_learn(s,question,items,kind):
        # Banking is bookkeeping, never the room's critical path: one hung /memory POST per seat
        # used to stall the next turn by up to a minute. Fire and forget.
        if not s.cfg.get("ptex_learn",True) or PTEX is None:return
        threading.Thread(target=s._learn_now,args=(question,list(items),kind),daemon=True).start()
    def _learn_now(s,question,items,kind):
        if not s.cfg.get("ptex_learn",True) or PTEX is None:return
        good=[(w,t) for w,t in items if t and not s._ptex_is_junk(t) and not(t.startswith("[") and any(k in t.lower() for k in("stopped","error","skipped","unavailable")))]
        corr=s._corrections_by_agent(good) if hasattr(s,"_corrections_by_agent") else {}
        seats={w for w,_ in good}
        if not good:return
        if len(seats)<1 and not corr:return
        try:r=PTEX.feed(question,good,s.stamp,kind,corrections=corr)
        except TypeError:r=PTEX.feed(question,good,s.stamp,kind)
        except Exception as e:r={"ok":False,"error":str(e)}
        if not (r or {}).get("ok"):
            try:s.emit({"type":"status","text":"PTEX learn skipped — "+str((r or {}).get("error") or (r or {}).get("reason") or "no usable messages")[:120]})
            except Exception:pass
        elif (r or {}).get("ledger_stalled"):
            try:s.emit({"type":"status","text":"PTEX banked "+str(r.get("pairs"))+" pair(s) on disk; Adam ledger cut short — "+str(r["ledger_stalled"])[:80]})
            except Exception:pass
        if ADAM is not None and hasattr(ADAM,"coding_record"):
            for who,c in (corr or {}).items():
                if not c:continue
                try:
                    ADAM.coding_record(task=(question or "delve")[:400],
                     outcome=next((t for w,t in good if w==who),"")[:400],
                     lesson=("PEER CORRECTION on "+who+" — do not repeat: "+c)[:500],
                     success=False,session_id=s.stamp,approach="delve_"+kind,
                     errors=[c[:200]],kind="peer_corrected")
                except Exception:pass
                try:
                    if hasattr(ADAM,"atlas_record"):
                        ADAM.atlas_record(s.seat_key(who),(question or "correction")[:300],("AVOID — was wrong: "+c)[:800])
                        ADAM.atlas_record(s._durable_slot(who),(question or "correction")[:300],("AVOID — was wrong: "+c)[:800])
                except Exception:pass
        if ADAM is not None and hasattr(ADAM,"coding_record") and len(seats)>=2 and not corr.get("Adam"):
            best=next((t for w,t in reversed(good) if w!="Adam" and len(t or "")>80),None)
            if best:
                try:ADAM.coding_record(task=(question or "delve")[:400],outcome=best[:500],
                 lesson="peer consensus answer shape — prefer this method; recompute numbers yourself",
                 success=True,session_id=s.stamp,approach="peer_consensus",kind="delve_consensus")
                except Exception:pass
        s.emit({"type":"ptex","data":r})
        s._learn_tick(question or kind)
    def _canon(s,target):
        t=(target or "").strip();m={"claude":"Claude","grok":"Grok","google":"Google","gemini":"Google","adam":"Adam",
         "openai":"OpenAI","chatgpt":"OpenAI","codex":"OpenAI","copilot":"Copilot","cursor":"Cursor",
         "opencode":"OpenCode","all":"all","both":"both"}
        return m.get(t.lower(),t if t in AGENTS else t)
    def route(s,target,msg,only=None):
        target=s._canon(target);s.add("Anthony",msg);s.emit({"type":"user","who":"Anthony","text":msg});names=s.roster_all() if target=="all" else [target]
        pick=[s._canon(x) for x in (only or []) if s._canon(x) in AGENTS] if target=="all" else []
        if pick:
            names=[n for n in names if n in pick] or pick
            s.emit({"type":"status","text":"this turn: "+", ".join(SEAT_LABEL.get(n,n) for n in names)})
        s._watch_start();items=[]
        for n in names:
            if s.abort.is_set():break
            if not s.seat_up(n):
                lab=SEAT_LABEL.get(n,n);hint=s.seat_hint(n)
                s.emit({"type":"status","text":lab+" is not available — "+hint})
                s.emit({"type":"msg","who":n,"text":"["+lab+" unavailable] "+hint,"model":s.seat_model(n),"model_short":s.seat_model_short(n)});continue
            sp,rp=s.turn(n);items.append((sp,rp));s._drain()
        s._drain();s._watch_stop()
        if target=="all":s.maybe_learn(msg,items,"exchange")
    def pair(s):
        """The two seats that answer BLIND then peer-review. Whoever the user actually has,
        preferring paid seats over the local one - not a hardcoded Claude/Grok."""
        live=[n for n in s.live_roster() if n!="Adam"]
        if len(live)<2:live=(live+[n for n in s.live_roster() if n=="Adam"])[:2]
        if len(live)<2:live=[n for n in s.roster_all() if n not in live][:2-len(live)]+live
        return live[:2]
    def both(s,msg):
        s.add("Anthony",msg);s.emit({"type":"user","who":"Anthony","text":msg})
        duo=s.pair()
        if len(duo)<2:
            s.emit({"type":"status","text":"blind compare needs two seats — only "+(duo[0] if duo else "none")+" is available"})
            return s.route("all",msg) if duo else None
        a,b=duo[0],duo[1]
        la,lb=SEAT_LABEL.get(a,a),SEAT_LABEL.get(b,b)
        st={n:s.idx.get(n,0) for n in duo};s._watch_start();items=[]
        s.emit({"type":"status","text":"independent answers — "+la+" and "+lb+" cannot see each other yet"})
        wa,ra=s.turn(a,start=st[a],record=False);s.add(wa,ra);items.append((wa,ra))
        if not s.abort.is_set():
            wb,rb=s.turn(b,start=st[b],record=False);s.add(wb,rb);items.append((wb,rb))
        s._drain()
        if not s.abort.is_set():
            s.emit({"type":"status","text":"peer review"})
            def rv(other,olab):
                return (olab+" answered the SAME question independently (shown above as "+other+"). Compare "+
                 olab+"'s approach with yours - call out strengths, gaps, or mistakes on either side - "
                 "then refine or defend your own answer.")
            wa2,ra2=s.turn(a,start=st[a],extra=rv(b,lb),record=False);s.add(wa2,ra2);items.append((wa2,ra2))
            if not s.abort.is_set():
                wb2,rb2=s.turn(b,start=st[b],extra=rv(a,la),record=False);s.add(wb2,rb2);items.append((wb2,rb2))
        for n in duo:s.idx[n]=len(s.t)
        s._drain();s._watch_stop();s.maybe_learn(msg,items,"both")
    def _goal_verdict(s,goal,lap,judge):
        """The flow judge, reused for a plain looping room: one seat is asked to rule DONE or
        CONTINUE against the goal. Same prompt and same parser, so a verdict means the same
        thing whether it came from a flow or from the loop control."""
        if not judge or not goal:return {"done":False,"why":"","ok":False}
        try:
            import delve_graph as G
            return G._verdict(s,{"goal":goal,"end_prompt":""},{"j":{"agent":judge}},"j","",lap)
        except Exception:return {"done":False,"why":"","ok":False}
    def debate(s,rounds,topic,only=None,goal=""):
        if topic:s.add("Anthony",topic);s.emit({"type":"user","who":"Anthony","text":topic})
        q=topic or next((x for w,x in reversed(s.t) if w=="Anthony"),"[Amni-Delve debate]")
        s._watch_start();items=[];roster=list(s.roster_all())
        pick=[s._canon(x) for x in (only or []) if s._canon(x) in AGENTS]
        if pick:
            roster=[n for n in roster if n in pick] or pick
            s.emit({"type":"status","text":"debate seats: "+", ".join(SEAT_LABEL.get(n,n) for n in roster)})
        endless=int(rounds or 0)<=0
        goal=(goal or "").strip();blind=0
        i=0
        while endless or i<rounds:
            if s.abort.is_set():break
            i+=1;spoke=0;lastn=""
            s.emit({"type":"status","text":"round "+str(i)+("" if endless else "/"+str(rounds))})
            for n in roster:
                if s.abort.is_set():break
                if not s.seat_up(n):
                    lab=SEAT_LABEL.get(n,n)
                    s.emit({"type":"status","text":lab+" is not available — skipping seat"})
                    s.emit({"type":"msg","who":n,"text":"["+lab+" unavailable] "+s.seat_hint(n),"model":s.seat_model(n),"model_short":s.seat_model_short(n)});continue
                sp,rp=s.turn(n);items.append((sp,rp));s._drain();spoke+=1;lastn=n
                if len(items)>400:del items[:len(items)-400]
            if endless and not spoke and not s.abort.is_set():
                s.emit({"type":"status","text":"no seat is available — stopping the loop"});break
            if goal and spoke and not s.abort.is_set():
                v=s._goal_verdict(goal,i,lastn)
                if v.get("ok") and v.get("done"):
                    s.emit({"type":"status","text":"goal met — "+(v.get("why") or "")[:160]});break
                blind=0 if v.get("ok") else blind+1
                if blind>=3:
                    s.emit({"type":"status","text":"no seat could rule on the goal three times — stopping the loop"});break
        s._drain();s._watch_stop();s.maybe_learn(q,items,"debate")
HELP=("Amni-Delve commands:\n"
"  @<seat> <msg>              talk to one seat - @claude @grok @google/@gemini\n"
"                             @openai/@chatgpt @copilot @cursor @opencode @adam\n"
"  @all <msg>                 every connected seat, in order (sequential)\n"
"  @both <msg>                your two paid seats answer BLIND, then peer-review\n"
"  @adam <msg>                talk to Adam (Amni-Ai), if running\n"
"  <msg>                      send to current default target\n"
"  /debate N [topic]          agents respond to each other for N rounds (inf = until Stop)\n"
"  /adam                      show Adam status\n"
"  /adam start [light|heavy]  boot Adam (light=3B ATEX, heavy=8B ATEX packed)\n"
"  /adam mode light|heavy     set which Adam to boot next time\n"
"  /adam fallback on|off      let Adam cover when other agents fail\n"
"  /google                    show Google / agy status\n"
"  /default claude|grok|google|all   set default target\n"
"  /model claude|grok|google <name>  pin a model (omit name to reset)\n"
"  /bypass on|off             let agents touch the filesystem unprompted (default on)\n"
"  /ptex on|off               feed exchanges to Adam's PTEX learning (default on)\n"
"  /commit                    encode queued lessons into Adam's PTEX now (needs Adam)\n"
"  /who                       show status\n"
"  /save [name]               export the transcript\n"
"  /clear                     reset the conversation\n"
"  /help                      this help\n"
"  /quit                      exit\n"
"DURING an exchange (debate/both/all): type a line + Enter to INTERJECT (reaches them next turn);\n"
"  press Esc or type /stop then Enter for E-STOP (kills the in-flight agent immediately).")
def main():
    if os.name=="nt":os.system("")
    for st in (sys.stdout,sys.stderr,sys.stdin):
        try:st.reconfigure(encoding="utf-8",errors="replace")
        except Exception:pass
    h=Hub()
    print(BOLD+"Amni-Delve"+RST+" — You + Claude + Grok + Google + Adam. Type /help.")
    print(DIM+"claude: "+CLAUDE+"\ngrok:   "+GROK+"\ngoogle: "+(_google_exe() or "(agy missing)")+"\nworkspace: "+h.work+RST+"\n")
    while True:
        try:line=input(COL["Anthony"]+BOLD+"You> "+RST).lstrip("﻿ï»¿").strip()
        except (EOFError,KeyboardInterrupt):print();break
        if not line:continue
        if line in ("/quit","/exit","exit","quit"):break
        if line=="/help":print(HELP+"\n");continue
        if line=="/who":print(DIM+json.dumps({"default":h.cfg["default"],"claude_model":h.cfg.get("claude_model") or "(default)","grok_model":h.cfg.get("grok_model") or "(default)","google_model":h.cfg.get("google_model") or "(default)","google_up":h.google_up(),"google_cli":_google_exe(),"google_email":(GOOGLE.email() if GOOGLE else ""),"bypass":h.cfg.get("bypass",True),"ptex_learn":h.cfg.get("ptex_learn",True),"adam_repo":(PTEX is not None and bool(PTEX._ai_root())),"adam_up":h.adam_up(),"adam_mode":h.cfg.get("adam_mode","light"),"adam_fallback":h.cfg.get("adam_fallback",True),"messages":len(h.t),"workspace":h.work,"transcript":h.file},indent=2)+RST+"\n");continue
        if line.startswith("/google") or line=="/agy":
            print(DIM+json.dumps({"installed":(GOOGLE.installed() if GOOGLE else False),"signed_in":(GOOGLE.signed_in() if GOOGLE else False),"cli":_google_exe(),"email":(GOOGLE.email() if GOOGLE else ""),"model":h.cfg.get("google_model"),"hint":"First login: run `agy` in a terminal → Google OAuth"},indent=2)+RST+"\n");continue
        if line.startswith("/adam"):
            p=line.split();sub=p[1].lower() if len(p)>1 else "status"
            if sub=="status":print(DIM+"adam: "+("UP "+json.dumps(ADAM.health()) if h.adam_up() else "DOWN")+" | mode="+h.cfg.get("adam_mode","light")+" | fallback="+str(h.cfg.get("adam_fallback",True))+RST+"\n")
            elif sub=="start":
                mode=(p[2].lower() if len(p)>2 else h.cfg.get("adam_mode","light"));mode=mode if mode in ("light","heavy") else "light"
                print(DIM+"↳ "+json.dumps(ADAM.start(mode) if ADAM else {"ok":False,"reason":"bridge missing"})+RST+"\n")
            elif sub=="mode" and len(p)>2 and p[2].lower() in ("light","heavy"):h.cfg["adam_mode"]=p[2].lower();save_cfg(h.cfg);print(DIM+"adam_mode -> "+h.cfg["adam_mode"]+RST+"\n")
            elif sub=="fallback" and len(p)>2:h.cfg["adam_fallback"]=p[2].lower() in ("on","true","1","yes");save_cfg(h.cfg);print(DIM+"adam_fallback -> "+str(h.cfg["adam_fallback"])+RST+"\n")
            else:print(DIM+"usage: /adam [status|start light|heavy|mode light|heavy|fallback on|off]"+RST+"\n")
            continue
        if line=="/clear":h.t=[];h.idx={a:0 for a in AGENTS};h.reset_cli_pins();print(DIM+"(conversation cleared)"+RST+"\n");continue
        if line.startswith("/save"):
            p=line.split(maxsplit=1);name=p[1].strip() if len(p)>1 else h.stamp
            dst=os.path.join(SESS,"saved_"+name+".md");h.flush();shutil.copyfile(h.file,dst);print(DIM+"saved -> "+dst+RST+"\n");continue
        if line.startswith("/default"):
            p=line.split(maxsplit=1);val=p[1].strip().lower() if len(p)>1 else ""
            if val in ("gemini",):val="google"
            h.cfg["default"]=val if val in ("claude","grok","google","all") else h.cfg["default"];save_cfg(h.cfg);print(DIM+"default -> "+h.cfg["default"]+RST+"\n");continue
        if line.startswith("/harness"):
            p=line.split(maxsplit=2)
            if len(p)<2:
                mode=str(h.cfg.get("path_preset") or "sequential")
                print(DIM+"harness · mode "+mode+" · default "+str(h.cfg.get("harness_default") or "review")+RST)
                for n in ("Claude","Grok","Google","Adam","OpenAI"):
                    hp=h.harness(n)
                    print(DIM+"  %-7s %-6s %-5s tools=%-5s %ds%s"%(SEAT_LABEL.get(n,n),h.harness_id(n),
                     "(pin)" if h.seat_pref(n,"harness","") else "(auto)",hp.get("tools"),h.turn_timeout(n),
                     " mcp" if hp.get("mcp") else "")+RST)
                print(DIM+"  profiles: "+", ".join(HARNESS_ORDER)+"   usage: /harness <seat> chat|review|build|auto"+RST+"\n")
            else:
                ok,msg=h.set_harness(p[1],p[2] if len(p)>2 else "auto")
                print(DIM+("harness "+msg if ok else msg)+RST+"\n")
            continue
        if line.startswith("/model"):
            p=line.split(maxsplit=2);who=p[1].lower() if len(p)>=2 else ""
            if who=="gemini":who="google"
            ok=who in ("claude","grok","google")
            if ok:
                key=who+"_model";h.cfg[key]=p[2].strip() if len(p)>2 else "";save_cfg(h.cfg);print(DIM+key+" -> "+(h.cfg[key] or "(default)")+RST+"\n")
            else:print(DIM+"usage: /model claude|grok|google <name>"+RST+"\n")
            continue
        if line.startswith("/bypass"):
            p=line.split(maxsplit=1);v=p[1].strip().lower() if len(p)>1 else ""
            h.cfg["bypass"]=(v in ("on","true","1","yes")) if v else h.cfg.get("bypass",True);save_cfg(h.cfg);print(DIM+"bypass -> "+str(h.cfg["bypass"])+RST+"\n");continue
        if line.startswith("/ptex"):
            p=line.split(maxsplit=1);v=p[1].strip().lower() if len(p)>1 else ""
            h.cfg["ptex_learn"]=(v in ("on","true","1","yes")) if v else h.cfg.get("ptex_learn",True);save_cfg(h.cfg);print(DIM+"ptex_learn -> "+str(h.cfg["ptex_learn"])+RST+"\n");continue
        if line=="/commit":
            print(DIM+"↳ "+json.dumps(PTEX.commit() if PTEX else {"ok":False,"reason":"bridge unavailable"})+RST+"\n");continue
        if line.startswith("/debate"):
            p=line.split(maxsplit=2);a=p[1] if len(p)>1 else ""
            n=-1 if a.lower() in ("inf","infinite","∞","forever") else (int(a) if a.isdigit() else 3);topic=p[2] if len(p)>2 else ""
            h.debate(n,topic);continue
        if line.startswith("@claude "):h.route("Claude",line[8:].strip());continue
        if line.startswith("@grok "):h.route("Grok",line[6:].strip());continue
        if line.startswith("@google "):h.route("Google",line[8:].strip());continue
        if line.startswith("@gemini "):h.route("Google",line[8:].strip());continue
        if line.startswith("@all "):h.route("all",line[5:].strip());continue
        if line.startswith("@both "):h.both(line[6:].strip());continue
        if line.startswith("@adam "):h.route("Adam",line[6:].strip());continue
        if line.startswith("@"):print(DIM+"unknown target; use @claude, @grok, @google, @adam, @all or @both"+RST+"\n");continue
        h.route(h.cfg["default"],line)
    print(DIM+"transcript: "+h.file+RST)
if __name__=="__main__":main()
