import json,threading,queue,os,sys,time,re,atexit
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import delve,delve_usage,delve_graph
ROOT=os.path.dirname(os.path.abspath(__file__))
WEB=os.path.join(ROOT,"web")
MAX_BODY=16*1024*1024
SSE_BACKLOG=512
def under(root,p):
    root=os.path.realpath(root);p=os.path.realpath(p)
    return p==root or p.startswith(root+os.sep)
SUBS_LOCK=threading.Lock();PEND_LOCK=threading.Lock();AUTHOR_LOCK=threading.Lock();USAGE_CACHE={"t":0,"data":None,"refreshing":False}
ROOMS={};ROOMS_LOCK=threading.RLock();_CTX=threading.local()
MAX_ROOMS=max(1,int(os.environ.get("DELVE_MAX_ROOMS") or 8))
_MODEL_WARM=[]
_RET_DONE=[]
def _tail_args(q):
    """(tail, tailex, off) for /api/state. -1 means ABSENT, and absent is not 0. Clamping a missing
    tailex to 0 sent every ?tail= request - simple.html, the default UI - down the 'config only'
    branch: right transcript_total, empty transcript, so the room painted nothing but
    'Show earlier messages (N more)' and clicking it changed nothing."""
    tl=-1;tx=-1;of=0
    if q:
        from urllib.parse import parse_qs
        qs=parse_qs(q)
        if qs.get("tail"):
            try:tl=max(0,int(qs["tail"][0]))
            except Exception:tl=-1
        if qs.get("tailex"):
            try:tx=max(0,int(qs["tailex"][0]))
            except Exception:tx=-1
        if qs.get("off"):
            try:of=max(0,int(qs["off"][0]))
            except Exception:of=0
    return tl,tx,of
def _retention_sweep():
    if _RET_DONE:return
    _RET_DONE.append(1)
    try:
        days=int(HUB.cfg.get("session_retention_days") or 0)
        if days<=0:return
        sd=os.path.dirname(HUB.file);cut=time.time()-days*86400
        for fn in os.listdir(sd):
            p=os.path.join(sd,fn)
            if fn.startswith("session_") and fn.endswith(".md") and p!=HUB.file and os.path.getmtime(p)<cut:
                try:os.remove(p)
                except Exception:pass
    except Exception:pass
def _emit(rm,ev):
    """Seq is per ROOM now: two rooms answering at once each need their own monotonic
    counter or every event in one would read as a hole in the other and force endless
    resyncs. Ticks stay unnumbered - a dropped tick is harmless paint, and numbering it
    would make it look like a lost message and evict a real event from a full queue."""
    eph=ev.get("type")=="tick"
    with SUBS_LOCK:
        if not eph:rm.seq+=1;ev["seq"]=rm.seq
        data=json.dumps(ev)
        for q in list(rm.subs):
            try:q.put_nowait(data)
            except queue.Full:
                if eph:continue
                try:q.get_nowait();q.put_nowait(data)
                except Exception:pass
            except Exception:pass
def broadcast(ev):_emit(_room(),ev)
def broadcast_all(ev):
    with ROOMS_LOCK:rooms=list(ROOMS.values())
    for rm in rooms:_emit(rm,dict(ev))
class Room:
    """One conversation = one Hub + one busy lock + its own subscribers. Seats already mint
    a per-Hub --session-id uuid (Hub._pin), so two rooms driving the same CLI never share a
    conversation and can safely run at the same time."""
    def __init__(s,rid):
        s.id=rid;s.seq=0;s.subs=[];s.busy=threading.Lock();s.touched=time.time()
        s.hub=delve.Hub(sink=lambda ev:_emit(s,ev),spinner=False)
        _uniq_session(s.hub)
def _uniq_session(hub):
    """The session stamp is second-resolution, so two rooms opened in the same second get
    the same filename and then flush() over each other. Give the loser a suffix."""
    taken={os.path.basename(r.hub.file) for r in ROOMS.values()}
    if os.path.basename(hub.file) not in taken and not os.path.exists(hub.file):return
    n=2
    while n<1000:
        stamp="%s_%d"%(hub.stamp,n)
        p=os.path.join(delve.SESS,"session_"+stamp+".md")
        if os.path.basename(p) not in taken and not os.path.exists(p):
            hub.stamp=stamp;hub.file=p;return
        n+=1
def _mkmain():
    with ROOMS_LOCK:
        rm=ROOMS.get("main")
        if rm is None:rm=Room("main");ROOMS["main"]=rm
        return rm
def room(rid=None,create=True):
    rid=(str(rid or "main").strip() or "main")[:64]
    with ROOMS_LOCK:
        rm=ROOMS.get(rid)
        if rm is None and create and (len(ROOMS)<MAX_ROOMS or rid.startswith("_")):rm=Room(rid);ROOMS[rid]=rm
        if rm is None:return _mkmain()
        rm.touched=time.time();return rm
def _room():return getattr(_CTX,"room",None) or _mkmain()
class _HubProxy:
    """160 call sites say HUB. Rather than thread a room argument through every one, HUB
    resolves to the CURRENT request's hub via a thread-local - ThreadingHTTPServer gives
    each request its own thread, so the binding is exact."""
    def __getattr__(s,k):return getattr(_room().hub,k)
    def __setattr__(s,k,v):setattr(_room().hub,k,v)
class _BusyProxy:
    def locked(s):return _room().busy.locked()
    def acquire(s,*a,**k):return _room().busy.acquire(*a,**k)
    def release(s):return _room().busy.release()
    def __enter__(s):_room().busy.acquire();return s
    def __exit__(s,*a):_room().busy.release();return False
HUB=_HubProxy();BUSY=_BusyProxy()
_mkmain()
def spawn(fn,*a,**k):
    """A worker thread inherits nothing, so it must be pinned to the room that started it
    or its HUB/BUSY/broadcast would silently land in 'main'."""
    rm=_room()
    def go():
        _CTX.room=rm;fn(*a,**k)
    t=threading.Thread(target=go,daemon=True);t.start();return t
def push_cfg(cfg):
    me=_room()
    with ROOMS_LOCK:rooms=list(ROOMS.values())
    for r in rooms:
        if r is not me:
            try:r.hub.cfg.update(cfg)
            except Exception:pass
def rooms_state():
    with ROOMS_LOCK:rooms=list(ROOMS.values())
    return [{"room":r.id,"file":os.path.basename(r.hub.file),"busy":r.busy.locked(),
             "messages":len(r.hub.t),"clients":len(r.subs)} for r in rooms if not r.id.startswith("_")]
def room_of_file(name,skip=None):
    with ROOMS_LOCK:
        for r in ROOMS.values():
            if r.id!=skip and not r.id.startswith("_") and os.path.basename(r.hub.file)==name:return r.id
    return None
def reap_rooms():
    """A tab that closed leaves a Hub behind. Drop the empty, idle, unwatched ones so
    opening conversations all day does not pile up rooms - never 'main', never one with
    work in it."""
    with ROOMS_LOCK:
        for rid in [r.id for r in ROOMS.values() if r.id!="main" and not r.subs
                    and not r.busy.locked() and not r.hub.t and time.time()-r.touched>120]:
            ROOMS.pop(rid,None)
def _seed_text():
    """seed.md is OPT-IN and off by default.

    It used to be read at startup and again by every /api/sessions/new with no title, and
    `seed_add()` planted it as an "Anthony" turn - so a leftover file on disk became the
    first thing every seat in every new conversation was told, and it went out over the
    wire to every provider on the first message. That is a wrong answer twice: it is not
    something the user typed, and it is data leaving the machine that nobody asked to send.
    Turn it on deliberately with cfg.seed_on or DELVE_SEED=1 and it works exactly as before.

    Empty / whitespace-only seed.md is treated as absent — a leftover file with old
    topic text must never re-poison the room just because the file still exists."""
    if not (bool(HUB.cfg.get("seed_on")) or os.environ.get("DELVE_SEED")=="1"):return ""
    p=os.path.join(ROOT,"seed.md")
    if not os.path.exists(p):return ""
    try:return open(p,encoding="utf-8").read().strip()
    except Exception:return ""
def _looks_like_forced_seed(text):
    """Historical sessions all open with the same NVFP4 'Room context' blob that used to
    be forced from seed.md. When seed_on is off we must not re-surface that as if the
    user just typed it again."""
    t=(text or "").strip()
    if not t:return False
    return t.startswith("Room context") and "NVFP4" in t and "bitplanes" in t
def seed():
    if os.environ.get("DELVE_FRESH")=="1":
        txt=_seed_text()
        if txt and not HUB.t:HUB.seed_add("Anthony",txt)
        return
    want=str(HUB.cfg.get("last_session") or "").strip()
    last=None
    if want:
        p=os.path.join(delve.SESS,os.path.basename(want))
        if os.path.isfile(p):last={"path":p,"name":os.path.basename(p)}
    if last is None:
        last=delve.latest_session(min_bytes=1,prefer_rich=False)
    if last:
        r=HUB.load_session(last["path"],keep_file=True)
        if r.get("ok") and r.get("messages",0)>=1:
            # Forced seed.md text must not reappear as "Anthony orders" when seeding is off.
            # Lone seed session → start clean. Multi-message session that opens with the
            # historical blob → drop only that first Anthony turn so the real work stays.
            if (not bool(HUB.cfg.get("seed_on"))) and os.environ.get("DELVE_SEED")!="1" \
               and HUB.t and HUB.t[0][0]=="Anthony" and _looks_like_forced_seed(HUB.t[0][1]):
                if len(HUB.t)==1:
                    HUB.t=[];HUB.idx={a:0 for a in delve.AGENTS};HUB.reset_cli_pins()
                    HUB.stamp=delve.new_session_stamp()
                    HUB.file=os.path.join(delve.SESS,"session_"+HUB.stamp+".md");_uniq_session(_room().hub)
                    HUB._auto_seed=False
                    HUB.cfg.pop("last_session",None);delve.save_cfg(HUB.cfg)
                    print("[delve] skipped stale forced-seed session %s"%last["name"],flush=True)
                    return
                HUB.t=list(HUB.t[1:])
                HUB.reset_cli_pins()
                for a in delve.AGENTS:HUB.idx[a]=len(HUB.t);HUB.started[a]=False
                print("[delve] stripped forced-seed opener from %s (%s messages left)"%(last["name"],len(HUB.t)),flush=True)
            print("[delve] resumed session %s (%s messages)"%(last["name"],len(HUB.t)),flush=True);return
    txt=_seed_text()
    if txt and not HUB.t:HUB.seed_add("Anthony",txt)
def _cfg_ev():
    """Every config broadcast carries the resolved path+flow so the room cannot paint
    the seat roster while a flow is driving the backend (or drop FLOWNOW to null on a
    providers/adam write that only sent {config})."""
    p,fg=resolved_path()
    return {"type":"config","config":HUB.cfg,"path":p,"flow":flow_meta(fg),
            "queued":len(getattr(HUB,"pending",None) or [])+len(HUB.interjects)}
def _run(fn):
    with BUSY:
        try:fn()
        except Exception as e:broadcast({"type":"status","text":"error: "+str(e)})
        # attachments belong to the message they came with, never to the next one
        HUB.files_note=""
        broadcast({"type":"idle","pending":len(getattr(HUB,"pending",None) or [])})
    _drain_pending()
def _drain_pending():
    """A queued message is a message, not a footnote. When the room frees up, send the
    next one for real. Seat pick / target / debate / rounds are stored on the queue item
    so a skip or One-pass choice is not thrown away just because the room was busy.
    Only /api/estop may clear the queue."""
    with PEND_LOCK:
        if BUSY.locked() or not getattr(HUB,"pending",None):return
        nxt=HUB.pending.pop(0)
    broadcast({"type":"queued","text":"","queued":len(HUB.pending)})
    broadcast({"type":"status","text":"sending your queued message"})
    if isinstance(nxt,dict):
        txt,files=nxt.get("text",""),nxt.get("files")
        kw={"files":files,"target":nxt.get("target"),"seats":nxt.get("seats"),
            "rounds":nxt.get("rounds"),"debate":bool(nxt.get("debate")),"goal":nxt.get("goal") or ""}
    else:
        txt,kw=nxt,{"files":None}
    spawn(_dispatch,txt,**kw)
def _files_note(files):
    """Attachments ride into every seat's prompt as an addendum, not as transcript noise -
    the user sees the chips he attached, the seats get the paths and a readable excerpt."""
    rows=[f for f in (files or []) if isinstance(f,dict) and f.get("path")]
    if not rows:return "",""
    try:
        import delve_files as FS
        note=FS.brief(HUB,rows)
    except Exception:note=""
    tag="\n\nattached: "+", ".join(str(f.get("name") or f["path"]) for f in rows[:8])
    return note,(tag if note else "")
def _flow_loop_copy(fg,rounds=None,debate=False,goal=""):
    g=dict(fg)
    gl=(goal or "").strip()
    try:n=None if rounds in (None,"") else int(rounds)
    except Exception:n=None
    if not (debate or gl or n is not None):return g
    if gl and (n is None or n<=0 or debate):
        g["end_mode"]="goal";g["goal"]=gl[:2000]
        if n is not None and n>0:g["rounds"]=max(1,n)
    elif n is not None and n<=0:g["end_mode"]="infinite"
    elif n is not None and n>0:
        g["end_mode"]="rounds";g["rounds"]=max(1,min(50,n))
    return g
def _dispatch(text,target=None,seats=None,rounds=None,debate=False,files=None,goal=""):
    """One place that decides how a message is answered, so the queue and the composer
    can never disagree about which flow is active."""
    note,tag=_files_note(files)
    HUB.files_note=note
    if tag:text=(text or "")+tag
    target=(target or HUB.cfg.get("default") or "all").lower()
    if target in ("gemini","google"):target="google"
    fg=flow_of(HUB.cfg.get("path_preset"))
    only=[x for x in (seats or []) if isinstance(x,str)]
    if fg is not None and (target in ("all","debate") or debate):
        g=_flow_loop_copy(fg,rounds,debate,goal)
        _run(lambda:delve_graph.run(HUB,g,None,text,only=only));return {"flow":g.get("label")}
    if debate or target=="debate":
        try:n=3 if rounds in (None,"") else int(rounds)
        except Exception:n=3
        _run(lambda:HUB.debate(n,text,only,goal=goal));return {"debate":n}
    fn={"all":lambda:HUB.route("all",text,only),"both":lambda:HUB.both(text)}.get(
        target,lambda:HUB.route(target if target else "all",text,only))
    _run(fn);return {}
def _usage_refresh(force=False):
    try:
        data=delve_usage.snapshot(usage=bool(HUB.cfg.get("usage_poll")),fast=False)
    except Exception as e:
        data={"error":str(e)[:200],"claude":{"models":delve_usage.claude_models(),"usage":{"ok":False,"error":str(e)[:120]}},"grok":{"models":delve_usage.grok_models(fast=True),"usage":{"ok":False,"error":str(e)[:120]}},"google":{"models":delve_usage.google_models(fast=True),"usage":{"ok":False,"error":str(e)[:120]}}}
    USAGE_CACHE["t"]=time.time();USAGE_CACHE["data"]=data;USAGE_CACHE["refreshing"]=False;return data
def _usage_kick():
    if USAGE_CACHE.get("refreshing"):return
    USAGE_CACHE["refreshing"]=True
    threading.Thread(target=lambda:_usage_refresh(False),daemon=True).start()
def _usage(force=False):
    now=time.time();ttl=45
    hit=USAGE_CACHE["data"]
    if (not force) and hit is not None and (now-USAGE_CACHE["t"])<ttl:return hit
    if (not force) and hit is not None:
        _usage_kick();return hit
    if force:
        USAGE_CACHE["refreshing"]=False
        return _usage_refresh(True)
    try:data=delve_usage.snapshot(usage=False,fast=True)
    except Exception as e:
        data={"error":str(e)[:200],"claude":{"models":delve_usage.claude_models(),"usage":{"ok":False,"error":str(e)[:120]}},"grok":{"models":delve_usage.grok_models(fast=True),"usage":{"ok":False,"error":str(e)[:120]}},"google":{"models":delve_usage.google_models(fast=True),"usage":{"ok":False,"error":str(e)[:120]}}}
    USAGE_CACHE["t"]=now;USAGE_CACHE["data"]=data;_usage_kick();return data
def _braid_on(port):
    """Is the thing holding this port actually Braid, or someone else's server?"""
    try:
        import urllib.request
        with urllib.request.urlopen("http://127.0.0.1:%d/health"%port,timeout=2.5) as r:
            return json.loads(r.read().decode() or "{}").get("app")=="braid"
    except Exception:return False
class _Srv(ThreadingHTTPServer):
    """HTTPServer sets allow_reuse_address=1, and on Windows SO_REUSEADDR lets a second
    process bind a port that is ALREADY LISTENING. That is why starting Braid twice never
    raised: both copies bound 8788, both answered, each kept its own transcript. Off on
    Windows so a clash is a real error; kept on POSIX where it only skips TIME_WAIT."""
    allow_reuse_address=(os.name!="nt")
def _listen(port,tries=12,host="127.0.0.1"):
    """Bind the wanted port, and be honest about why we could not.

    Returns (server, port), or (None, port) when Braid already owns it - the caller
    raises that window rather than starting a second copy. Walking to the next port is
    only for a port somebody ELSE is using; drifting away from a running Braid is how
    you end up with several of them, each writing its own session file."""
    for i in range(max(1,tries)):
        p=port+i
        if _braid_on(p):return None,p          # ask before binding: see _Srv above
        try:return _Srv((host,p),H),p
        except OSError:
            if _braid_on(p):return None,p
            if i==0:print("[braid] port %d is taken by something else - trying %d"%(p,p+1),flush=True)
    raise SystemExit("could not bind any port between %d and %d"%(port,port+tries-1))
def flow_of(pid):
    pid=str(pid or "")
    return delve_graph.load(pid[5:],HUB.seats_available()) if pid.startswith("flow:") else None
def flow_meta(fg):
    """The one shape every endpoint hands the room for an active flow.

    `order` is the whole point: without it the front end fell back to the seat roster and
    painted a turn order the backend was not running. Every caller that used to build this
    dict inline now goes through here so /api/state, GET /api/config and POST /api/config
    cannot disagree about what the room is about to do."""
    if not fg:return None
    rows=delve_graph.visit_order(fg)
    return {"id":fg.get("id"),"label":fg.get("label"),"goal":fg.get("goal") or "",
            "nodes":len(fg.get("nodes") or []),
            "breaks":len([n for n in (fg.get("nodes") or []) if n.get("gather")]),
            "end_mode":fg.get("end_mode") or "rounds",
            # `order` is DEDUPED because the ribbon keys rows by seat name and a flow may seat
            # the same agent twice (Grok opens, Grok audits). `seats` keeps every visit, which
            # is what the turn-order panel lists.
            "order":list(dict.fromkeys(r["agent"] for r in rows if r.get("agent"))),
            "seats":rows}
def resolved_path():
    """ONE resolver. `Hub.active_path()` already turns `flow:<id>` into the flow's visit
    order AND applies cfg.seat_order to a plain preset; this used to re-derive the flow
    case here and call `delve.path_preset()` raw for the rest, which quietly dropped the
    user's ↑↓ ordering from /api/state while roster_all still honoured it. Two answers to
    one question is the bug class this whole pass exists to remove — don't fork it again."""
    return HUB.active_path(),flow_of(HUB.cfg.get("path_preset"))
PL_CACHE={"t":0,"data":None}
def path_list():
    """Path picker payload. Must NOT call seats_available()/live_roster() — those hit
    Adam /healthz and CLI probes and were ~200–400ms of every cold /api/state. Flow listing
    only needs schemas on disk; avail=None is fine (builtins bind later when run)."""
    now=time.time()
    if PL_CACHE["data"] is not None and (now-PL_CACHE["t"])<15.0:
        return PL_CACHE["data"]
    rows=list(delve.list_path_presets())
    for f in delve_graph.list_flows(None):
        rows.append({"id":"flow:"+f["id"],"label":f["label"],"flow":True,
                     "builtin":bool(f.get("builtin")),
                     "seats":f.get("seats") or [],"order":f.get("order") or [],
                     "breaks":f.get("breaks") or len([r for r in (f.get("order") or []) if r.get("gather")]),
                     "desc":(f.get("goal") or "").strip() or (str(f["nodes"])+" seats, "+str(f["edges"])+" handoffs · "+str(f.get("end_mode") or "rounds")),
                     "roles":{}})
    PL_CACHE["t"]=now;PL_CACHE["data"]=rows;return rows
def _prewarm():
    try:
        HUB.live_roster();path_list();_usage(False)
    except Exception:pass
class H(BaseHTTPRequestHandler):
    def log_message(s,*a):pass
    def _send(s,code,ctype,body):
        try:
            s.send_response(code);s.send_header("Content-Type",ctype);s.send_header("Content-Length",str(len(body)));s.send_header("Cache-Control","no-store")
            s.send_header("Referrer-Policy","no-referrer");s.send_header("X-Content-Type-Options","nosniff");s.send_header("X-Frame-Options","DENY")
            if getattr(s,"_setck",False):
                import delve_remote as RM
                s.send_header("Set-Cookie",RM.cookie_header());s._setck=False
            s.end_headers();s.wfile.write(body)
        except Exception:pass
    def _host_ok(s):
        """Blocks DNS rebinding. Host must be loopback, or in remote mode a bare IP
        literal (v4/v6). Hostnames — including .local mDNS — are rebindable and refused."""
        raw=(s.headers.get("Host") or "").strip().lower()
        if not raw:return True
        if raw.startswith("["):
            end=raw.find("]")
            if end<0:return False
            h=raw[1:end];rest=raw[end+1:]
            if rest and not re.match(r"^:\d{1,5}$",rest):return False
        elif raw.count(":")==1 and re.match(r"^[\w.-]+:\d{1,5}$",raw):
            h=raw.rsplit(":",1)[0]
        else:h=raw
        h=(h or "").strip().lower()
        if "%" in h:h=h.split("%",1)[0]
        if h in ("","127.0.0.1","localhost","::1","0.0.0.0"):return True
        if h.startswith("127."):return True
        if not getattr(s.server,"braid_remote",False):return False
        if re.match(r"^\d{1,3}(\.\d{1,3}){3}$",h):return True
        if ":" in h:
            try:
                import ipaddress;ipaddress.IPv6Address(h);return True
            except Exception:return False
        return False
    def _origin_ok(s):
        """A page you happen to be visiting must not be able to drive Braid.

        The interesting case is not fetch() - a cross-origin fetch with a JSON body is
        preflighted and dies there. It is the plain HTML form: enctype="text/plain" is a
        CORS *simple* request, so no preflight ever happens, and the body can still be
        valid JSON. That is a working CSRF against a desktop app that can write files and
        run tools, so it is checked here rather than left to the browser.

        Requests with no Origin and no Sec-Fetch-Site - curl, the app's own Python, the
        CLI - still pass. The attack needs a browser as the confused deputy; something
        already running as the user does not need to bother."""
        sfs=(s.headers.get("Sec-Fetch-Site") or "").strip().lower()
        if sfs and sfs not in ("same-origin","none"):return False
        org=(s.headers.get("Origin") or "").strip().lower()
        if not org or org=="null":return True
        host=(s.headers.get("Host") or "").strip().lower()
        if host and org in ("http://"+host,"https://"+host):return True
        port=0
        try:port=int(s.server.server_address[1])
        except Exception:pass
        return org in {"http://127.0.0.1:%d"%port,"http://localhost:%d"%port,"http://[::1]:%d"%port}
    def _is_loopback_client(s):
        ip=str(s.client_address[0] or "")
        if ip in ("127.0.0.1","::1","::ffff:127.0.0.1"):return True
        if ip.startswith("127."):return True
        return False
    def _pair_refuse(s,path):
        """JSON for APIs; a readable page for browser navigations (double-click / wrong port)."""
        msg="pairing key required — open Braid on your PC and scan the QR again"
        acc=(s.headers.get("Accept") or "").lower()
        wants_html=("text/html" in acc) or (s.command=="GET" and not path.startswith("/api/"))
        if wants_html and s.command=="GET":
            try:
                import delve_remote as RM
                local="http://127.0.0.1:%d/"%int(s.server.server_address[1] if not getattr(s.server,"braid_remote",False) else (os.environ.get("DELVE_PORT") or 8788))
                # Prefer the real local UI port when this is the phone listener
                if getattr(s.server,"braid_remote",False):
                    local="http://127.0.0.1:%d/"%int(os.environ.get("DELVE_PORT") or 8788)
                pair=RM.pair_url() if RM.running() else ""
                html=("<!doctype html><meta charset=utf-8><title>Braid — pair this device</title>"
                 "<body style=\"font-family:system-ui;max-width:36rem;margin:3rem auto;padding:0 1rem;line-height:1.5\">"
                 "<h1 style=\"font-size:1.2rem\">This is the phone link, not the desktop app</h1>"
                 "<p>You opened Braid's <b>remote</b> listener without a pairing key. "
                 "On this computer use the local app instead:</p>"
                 "<p><a href=\""+local+"\">Open Braid on this PC</a></p>"
                 +(("<p>Or pair this browser with the current key:<br><a href=\""+pair+"\">"+pair+"</a></p>") if pair else "")
                 +"<p style=\"color:#666;font-size:.9rem\">Turn off phone access in Controls → Remote if you do not need it.</p>"
                 "</body>")
                return s._send(401,"text/html; charset=utf-8",html.encode("utf-8"))
            except Exception:
                pass
        s._json({"ok":False,"error":msg},401)
    def _guard(s,path):
        if not s._host_ok():
            s._json({"ok":False,"error":"unexpected Host header — refusing this request"},403);return False
        if not s._origin_ok():
            s._json({"ok":False,"error":"cross-site request refused"},403);return False
        # Loopback is always free — even on the remote (0.0.0.0) listener. Pairing keys protect
        # phones on the LAN; the same PC already owns remote_secret.txt. Without this, double-
        # clicking while remote_on is true (or bookmarking :8789) shows raw JSON pairing errors.
        if s._is_loopback_client():return True
        if path=="/health":return True
        if not getattr(s.server,"braid_remote",False):return True
        import delve_remote as RM
        # Single port: the socket stays bound wide, so turning phone access off has to be
        # enforced here or the LAN would keep its access until a restart. Fail closed.
        if not RM.running():
            s._json({"ok":False,"error":"phone access is off — turn it on in Controls → Remote"},403);return False
        from urllib.parse import urlparse,parse_qs
        ip=s.client_address[0]
        if RM.rate_limited(ip):
            s._json({"ok":False,"error":"too many attempts — wait a few minutes"},429);return False
        key,how=RM.key_from(s.headers,parse_qs(urlparse(s.path).query))
        if RM.ok_key(key):
            if how=="query" and s.command=="GET" and not path.startswith("/api/"):
                try:
                    dest="/" if path in ("","/") else path
                    if dest=="/":dest="/?auto=1"
                    s.send_response(302);s.send_header("Location",dest);s.send_header("Set-Cookie",RM.cookie_header())
                    s.send_header("Referrer-Policy","no-referrer");s.send_header("Cache-Control","no-store");s.send_header("Content-Length","0");s.end_headers()
                except Exception:pass
                s._setck=False;return False
            s._setck=(how=="query");return True
        RM.fail(ip)
        s._pair_refuse(path)
        return False
    def _json(s,obj,code=200):
        s._send(code,"application/json; charset=utf-8",json.dumps(obj).encode("utf-8"))
    def _body_len(s,cap):
        try:n=int(s.headers.get("Content-Length") or 0)
        except Exception:return -1
        return -1 if n<0 or n>cap else n
    def _ctype(s,path):
        p=path.lower()
        for ext,ct in ((".css","text/css; charset=utf-8"),(".js","application/javascript; charset=utf-8"),
         (".png","image/png"),(".jpg","image/jpeg"),(".jpeg","image/jpeg"),(".svg","image/svg+xml"),
         (".webp","image/webp"),(".gif","image/gif"),(".ico","image/x-icon")):
            if p.endswith(ext):return ct
        return "text/plain; charset=utf-8"
    def _file(s,rel,ctype):
        # The separator matters: a bare prefix test also accepts a SIBLING whose name merely
        # starts with "web" (web2, webdata), because "...\web2\x".startswith("...\web") is true.
        # realpath rather than abspath so a symlinked directory cannot step outside either.
        root=os.path.realpath(WEB)
        p=os.path.realpath(os.path.join(WEB,rel))
        if (p!=root and not p.startswith(root+os.sep)) or not os.path.isfile(p):
            return s._send(404,"text/plain",b"not found")
        s._send(200,ctype,open(p,"rb").read())
    def _state(s,tail=-1,tailex=-1,off=0):
        ensure_adam_bg()
        u=_usage(False)
        _p,_fg=resolved_path()
        seats=HUB.resolved_seats()
        try:
            import delve_models as DM
            models=DM.catalog(fast=True)
            if not USAGE_CACHE.get("models_refreshing"):
                USAGE_CACHE["models_refreshing"]=True
                def _mr():
                    try:DM.catalog(fast=False)
                    except Exception:pass
                    finally:USAGE_CACHE["models_refreshing"]=False
                threading.Thread(target=_mr,daemon=True).start()
        except Exception:
            try:
                import threading,delve_models as DM
                if not _MODEL_WARM:
                    _MODEL_WARM.append(1);threading.Thread(target=DM.warm,daemon=True).start()
                _oai=DM.openai_models(fast=True);_cop=DM.copilot_models(fast=True);_cur=DM.cursor_models(fast=True);_ocd=DM.opencode_models(fast=True)
            except Exception:
                _oai=list(delve.SEAT_MODEL_DEFAULTS.get("OpenAI") or []);_cop=list(delve.SEAT_MODEL_DEFAULTS.get("Copilot") or []);_cur=list(delve.SEAT_MODEL_DEFAULTS.get("Cursor") or []);_ocd=list(delve.SEAT_MODEL_DEFAULTS.get("OpenCode") or [])
            models={"claude":(u.get("claude") or {}).get("models") or [],"grok":(u.get("grok") or {}).get("models") or [],"google":(u.get("google") or {}).get("models") or [],"Claude":(u.get("claude") or {}).get("models") or [],"Grok":(u.get("grok") or {}).get("models") or [],"Google":(u.get("google") or {}).get("models") or [],"Adam":list(delve.SEAT_MODEL_DEFAULTS.get("Adam") or []),"OpenAI":_oai,"Copilot":_cop,"Cursor":_cur,"OpenCode":_ocd}
        _tt=list(HUB.t)
        # Chunked cold paint. tailex=N ships only the last N exchanges (an exchange starts at a
        # user turn), so a thousand-turn room no longer serializes the whole chain on every
        # /api/state - the phone was spending seconds parsing history it would never paint.
        _uix=[i for i,(w,_x) in enumerate(_tt) if w in ("Anthony","You")]
        _exhid=0
        if off>0 and tail>0:
            # One PAGE, not a wider window. Without this the client had to re-fetch everything it
            # already had to see 50 more: an exchange here runs ~80 seat turns, so widening by 200
            # was a megabyte a click. off counts back from the newest message.
            _end=max(0,len(_tt)-off)
            _cut=_tt[max(0,_end-tail):_end]
        elif tailex is not None and tailex>=0 and len(_uix)>tailex:
            _exhid=len(_uix)-tailex
            # tailex=0 is "config only" - the same contract as tail=0 - and has no cut point.
            _cut=_tt[_uix[-tailex]:] if tailex else []
        else:
            _cut=_tt if tail<0 else (_tt[-tail:] if tail else [])
        return {"transcript":[{"who":w,"text":t} for w,t in _cut],"transcript_total":len(_tt),
         "exchanges_total":len(_uix),"exchanges_hidden":_exhid,"config":HUB.cfg,"path":_p,"paths":path_list(),"roster":HUB.roster_all(),"live":HUB.live_roster(),"seats":seats,"adam_available":HUB.adam_available(),"version":delve.VERSION,"share_improve":bool(HUB.cfg.get("share_improve")),"tutorial_done":bool(HUB.cfg.get("tutorial_done")),"seats_all":list(delve.AGENTS),"labels":dict(delve.SEAT_LABEL),"flow":flow_meta(_fg),"fyi":list(getattr(HUB,"fyi",None) or []),"queued":len(getattr(HUB,"pending",None) or [])+len(HUB.interjects),"session":{"file":os.path.basename(HUB.file),"path":HUB.file,"stamp":HUB.stamp,"messages":len(HUB.t)},"room":_room().id,"rooms":rooms_state(),"adam_repo":(delve.PTEX is not None and bool(delve.PTEX._ai_root())),"adam_up":HUB.adam_up(),"google_up":HUB.google_up(),"busy":BUSY.locked(),"claude":delve.CLAUDE,"grok":delve.GROK,"google":delve._google_exe(),"models":models,"effort":(models.get("effort") if isinstance(models,dict) else None),"usage":{"claude":(u.get("claude") or {}).get("usage"),"grok":(u.get("grok") or {}).get("usage"),"google":(u.get("google") or {}).get("usage")}}
    def _bind(s):
        """Which conversation is this request for? The tab says so with X-Braid-Room (or
        ?room= for EventSource, which cannot set headers). No header = 'main', so an old
        cached page keeps working exactly as before."""
        rid=s.headers.get("X-Braid-Room") or ""
        if not rid and "?" in s.path:
            from urllib.parse import parse_qs
            rid=(parse_qs(s.path.split("?",1)[1]).get("room") or [""])[0]
        _CTX.room=room(str(rid or "").lstrip("_"))
    def do_GET(s):
        s._bind()
        path=s.path.split("?",1)[0]
        if path=="/health":return s._json({"ok":True,"app":"braid","busy":BUSY.locked()})
        if path in ("/favicon.ico","/favicon.svg"):
            return s._file("favicon.svg","image/svg+xml")
        if path in ("/md.js","/room.js"):
            return s._file(path[1:],"application/javascript; charset=utf-8")
        if not s._guard(path):return
        if path in ("/config.json","/api/connect"):
            try:
                import delve_remote as RM
                st=RM.status(int(HUB.cfg.get("remote_port") or 8790),str(HUB.cfg.get("remote_host") or ""))
                loop=s._is_loopback_client()
                url=(st.get("url") or "") if loop else ""
                return s._json({"ok":True,"app":"braid","version":delve.VERSION,"busy":BUSY.locked(),
                 "remote_on":bool(st.get("on")),"url":url,"ip":st.get("ip") if loop else "","port":st.get("port"),
                 "local":"http://127.0.0.1:%d/"%int(os.environ.get("DELVE_PORT") or 8788) if loop else "",
                 "connect_file":(RM.connect_path() if (loop and st.get("on")) else "")})
            except Exception as e:
                return s._json({"ok":True,"app":"braid","version":delve.VERSION,"busy":BUSY.locked(),"error":str(e)[:120]})
        if path in ("/code","/code.html"):
            # Retired. The work dock inside the room does this job now - browsing, diffing,
            # editing and approvals - without dropping the SSE stream and the transcript on
            # the way there. Bookmarks and the old sidebar links land back in the room.
            s.send_response(302);s.send_header("Location","/?work=files");s.end_headers();return
        if path in ("/remote","/remote.html"):return s._file("remote.html","text/html; charset=utf-8")
        if path in ("/subscribe","/subscribe.html","/billing"):return s._file("subscribe.html","text/html; charset=utf-8")
        if path.startswith("/api/code/"):
            import delve_code as CO
            from urllib.parse import urlparse,parse_qs,unquote
            q=parse_qs(urlparse(s.path).query)
            g=lambda k:unquote((q.get(k) or [""])[0])
            op=path[len("/api/code/"):]
            r=(CO.ls(HUB,g("path")) if op=="ls" else CO.read(HUB,g("path")) if op=="read" else
               CO.tree(HUB) if op=="tree" else CO.search(HUB,g("q"),regex=g("regex")=="1",case=g("case")=="1",glob=g("glob"),files_only=g("files")=="1") if op=="search" else
               CO.git(HUB,g("op")) if op=="git" else CO.pending(HUB) if op=="pending" else None)
            return s._json(r,code=(r or {}).get("code",200) if isinstance(r,dict) else 200) if r is not None else s._send(404,"text/plain",b"not found")
        if path.startswith("/api/activity"):
            """Cold paint and resync for the work dock. Mounting the dock is also what ARMS
            the watcher: it has to be listening before a turn starts, or the first edits of
            that turn are already on disk by the time anything subscribes."""
            try:
                import delve_activity as ACT,delve_code as CO
                from urllib.parse import urlparse,parse_qs
                q=parse_qs(urlparse(s.path).query)
                try:n=int((q.get("since") or ["0"])[0] or 0)
                except Exception:n=0
                ACT.set_root(HUB.cfg.get("workspace") or HUB.work)
                return s._json({**ACT.since(n),"code_mode":CO.mode(HUB),"pending":len(CO.PENDING)})
            except Exception as e:
                return s._json({"ok":False,"error":str(e)[:200],"events":[],"seq":0},code=500)
        if path.startswith("/api/license"):
            import delve_license as LC
            from urllib.parse import urlparse,parse_qs
            force="refresh=1" in s.path
            return s._json({"ok":True,**LC.status(force),"buy_url":HUB.cfg.get("license_buy_url") or ""})
        if path.startswith("/api/privacy"):
            """Everything Braid does for seat privacy, stated checkably. The env block is the
            LITERAL dict injected at Hub._exec - not a paraphrase - and the verify prompt is a
            real end-to-end test: the seat's own shell runs inside the env Braid spawned, so
            asking it to print these variables proves what it actually received."""
            on=bool(HUB.cfg.get("privacy_mode",True))
            names=" ".join(sorted(delve.PRIVACY_ENV))
            verify_prompt=("Using your shell tool, print the current value of each of these "
             "environment variables and nothing else: "+names)
            seats=[]
            CONF={"Claude":["~/.claude/settings.json (env block wins over ours if set)"],
                  "Google":["~/.gemini/settings.json — usageStatisticsEnabled"],
                  "Grok":["~/.grok/ settings files"],
                  "OpenAI":["~/.codex/config.toml"]}
            for name in delve.AGENTS:
                seats.append({"seat":name,
                 "env":(delve.PRIVACY_ENV if on else {}),
                 "config_paths":CONF.get(name,[]),
                 "in_process":name=="Adam"})
            import delve_privacy as PRV
            return s._json({"ok":True,"privacy_mode":on,"cli_configs":PRV.report(),
             "env":delve.PRIVACY_ENV,"why":delve.PRIVACY_ENV_WHY,
             "verify_prompt":verify_prompt,"seats":seats,
             "adam_note":"Adam runs entirely on this machine — nothing to opt out of.",
             "scope_note":("These flags stop CLI telemetry, crash reporting and non-inference "
              "traffic. What a provider does with your PROMPTS (training/retention) is governed "
              "by your account's data controls on the provider side — Braid cannot flip those "
              "for you, so check them once per provider account."),
             "braid_note":("Braid itself sends nothing off this machine unless you use "
              "share/improve (opt-in, scrubbed) or updates/license checks.")})
        if path.startswith("/api/machine/state"):
            import delve_machine as MC
            return s._json({"ok":True,"machines":MC.state_all(),"chrome":bool(MC.chrome_path())})
        if path.startswith("/api/machine/shot"):
            import delve_machine as MC
            from urllib.parse import urlparse,parse_qs
            seat=(parse_qs(urlparse(s.path).query).get("seat") or [""])[0]
            mm=MC.get(seat)
            if not (mm and mm.frame):return s._json({"ok":False,"error":"no frame"},404)
            s.send_response(200);s.send_header("Content-Type","image/jpeg")
            s.send_header("Cache-Control","no-store");s.send_header("Content-Length",str(len(mm.frame)))
            s.end_headers();s.wfile.write(mm.frame);return
        if path.startswith("/api/machine/stream"):
            # MJPEG: one long multipart response a plain <img> renders live. Each client holds
            # a thread (ThreadingHTTPServer), writes stop the moment the tab closes.
            import delve_machine as MC,time as _t
            from urllib.parse import urlparse,parse_qs
            seat=(parse_qs(urlparse(s.path).query).get("seat") or [""])[0]
            mm=MC.get(seat)
            if not mm:return s._json({"ok":False,"error":"no machine"},404)
            s.send_response(200)
            s.send_header("Content-Type","multipart/x-mixed-replace; boundary=braidframe")
            s.send_header("Cache-Control","no-store");s.end_headers()
            last=0.0
            try:
                while mm.alive:
                    if mm.frame and mm.frame_at>last:
                        last=mm.frame_at
                        s.wfile.write(b"--braidframe\r\nContent-Type: image/jpeg\r\nContent-Length: "
                         +str(len(mm.frame)).encode()+b"\r\n\r\n"+mm.frame+b"\r\n")
                        s.wfile.flush()
                    _t.sleep(0.3)
            except Exception:pass
            return
        if path.startswith("/api/remote"):
            import delve_remote as RM
            return s._json({**RM.status(int(HUB.cfg.get("remote_port") or 8790),str(HUB.cfg.get("remote_host") or "")),"cfg_port":int(HUB.cfg.get("remote_port") or 8790),"persisted":bool(HUB.cfg.get("remote_on"))})
        if path in ("/","/index.html"):
            if not HUB.cfg.get("setup_done"):return s._file("setup.html","text/html; charset=utf-8")
            # Basic is the daily runner. Ultrasimple is still one click away at /simple, and
            # `ui_home` in the config flips the default back for anyone who prefers it.
            home=str(HUB.cfg.get("ui_home") or "basic").lower()
            return s._file("simple.html" if home=="simple" else "basic.html","text/html; charset=utf-8")
        if path in ("/simple","/simple.html"):return s._file("simple.html","text/html; charset=utf-8")
        if path in ("/setup","/setup.html"):return s._file("setup.html","text/html; charset=utf-8")
        if path in ("/basic","/basic.html"):return s._file("basic.html","text/html; charset=utf-8")
        if path in ("/advanced","/advanced.html"):
            s.send_response(302);s.send_header("Location","/basic");s.end_headers();return
        if path in ("/legacy","/index.html"):return s._file("index.html","text/html; charset=utf-8")
        if path in ("/flow","/flow.html"):return s._file("flow.html","text/html; charset=utf-8")
        if path in ("/ptex","/ptex.html"):return s._file("ptex.html","text/html; charset=utf-8")
        if path.startswith("/api/audit/export"):
            import io,zipfile
            sd=os.path.dirname(HUB.file)
            buf=io.BytesIO()
            with zipfile.ZipFile(buf,"w",zipfile.ZIP_DEFLATED) as z:
                for fn in sorted(os.listdir(sd)):
                    if fn.startswith("session_") and fn.endswith(".md"):
                        try:z.write(os.path.join(sd,fn),fn)
                        except Exception:pass
            data=buf.getvalue()
            s.send_response(200);s.send_header("Content-Type","application/zip")
            s.send_header("Content-Disposition","attachment; filename=braid_audit_sessions.zip")
            s.send_header("Content-Length",str(len(data)));s.end_headers();s.wfile.write(data);return
        if path.startswith("/api/state"):
            _retention_sweep()
            _tl,_tx,_of=_tail_args(s.path.split("?",1)[1] if "?" in s.path else "")
            return s._json({**s._state(_tl,_tx,_of),"seq":_room().seq})
        if path.startswith("/api/config"):
            p,fg=resolved_path()
            return s._json({"ok":True,"config":HUB.cfg,"busy":BUSY.locked(),"path":p,
             "queued":len(getattr(HUB,"pending",None) or [])+len(HUB.interjects),
             "flow":flow_meta(fg)})
        if path.startswith("/api/paths"):return s._json({"ok":True,"paths":path_list(),"current":HUB.cfg.get("path_preset") or "sequential"})
        if path.startswith("/api/harness"):
            seats=["Claude","Grok","Google","Adam","OpenAI"]
            return s._json({"ok":True,"profiles":delve.list_harness_profiles(),
                "default":HUB.cfg.get("harness_default") or "review",
                "by_mode":delve.HARNESS_BY_MODE,"by_mode_cfg":HUB.cfg.get("harness_by_mode") or {},
                "mode":HUB.cfg.get("path_preset") or "sequential",
                "seats":{n:{"harness":HUB.harness_id(n),"pinned":HUB.seat_pref(n,"harness","") or "auto",
                            "timeout":HUB.turn_timeout(n),"tools":HUB.harness(n).get("tools")} for n in seats}})
        if path.startswith("/api/system"):
            try:
                import delve_sysinfo as SI
                return s._json({"ok":True,**SI.advise()})
            except Exception as e:return s._json({"ok":False,"error":str(e)[:200]},code=500)
        if path.startswith("/api/providers"):
            try:
                import delve_providers as PV
                seats=delve.AGENTS
                cur=(HUB.cfg.get("providers") or {})
                dflt=lambda n:(cur.get(n) or ({"kind":"adam"} if n=="Adam" else
                 ({"kind":"cli"} if n in delve.CORE_AGENTS else {"kind":"off"})))
                return s._json({"ok":True,"detect":PV.detect(),"order":list(seats),
                 "hues":delve.SEAT_HUE,"labels":{n:delve.SEAT_LABEL.get(n,n) for n in seats},
                 "seats":{n:PV.public(n,dflt(n)) for n in seats},"kinds":list(PV.KINDS)})
            except Exception as e:return s._json({"ok":False,"error":str(e)[:200]},code=500)
        if path.startswith("/api/files/view"):
            """Inline twin of /download so an answer can SHOW a workspace image instead of
            offering a save dialog. Raster images only: html/svg stay unservable from this
            origin, and anything else keeps the attachment path."""
            import delve_files as FS
            from urllib.parse import urlparse,parse_qs,unquote
            q=parse_qs(urlparse(s.path).query)
            rel=unquote((q.get("path") or [""])[0])
            ext=os.path.splitext(rel)[1].lower()
            IMG={".png":"image/png",".jpg":"image/jpeg",".jpeg":"image/jpeg",".gif":"image/gif",
                 ".webp":"image/webp",".bmp":"image/bmp",".avif":"image/avif"}
            if ext not in IMG:return s._json({"ok":False,"error":"inline viewing is images only — use /api/files/download"},code=415)
            data,err=FS.read_bytes(HUB,rel)
            if data is None:return s._json({"ok":False,"error":err},code=404)
            s.send_response(200)
            s.send_header("Content-Type",IMG[ext])
            s.send_header("Content-Length",str(len(data)))
            s.send_header("Content-Disposition","inline")
            s.send_header("X-Content-Type-Options","nosniff")
            s.send_header("Referrer-Policy","no-referrer")
            s.send_header("Cache-Control","no-store")
            s.end_headers()
            try:s.wfile.write(data)
            except Exception:pass
            return
        if path.startswith("/api/files/download"):
            import delve_files as FS
            from urllib.parse import urlparse,parse_qs,unquote
            q=parse_qs(urlparse(s.path).query)
            rel=unquote((q.get("path") or [""])[0])
            data,err=FS.read_bytes(HUB,rel)
            if data is None:return s._json({"ok":False,"error":err},code=404)
            fn=FS.safe_name(os.path.basename(rel)) or "download"
            s.send_response(200)
            s.send_header("Content-Type",FS.ctype_for(rel))
            s.send_header("Content-Length",str(len(data)))
            s.send_header("Content-Disposition",'attachment; filename="%s"'%fn.replace('"',""))
            s.send_header("X-Content-Type-Options","nosniff")
            s.send_header("Referrer-Policy","no-referrer")
            s.send_header("Cache-Control","no-store")
            s.end_headers()
            try:s.wfile.write(data)
            except Exception:pass
            return
        if path.startswith("/api/files"):
            import delve_files as FS
            return s._json({"ok":True,"files":FS.listing(HUB),"max_bytes":FS.MAX_BYTES,
                            "blocked":sorted(FS.BLOCKED)})
        if path.startswith("/api/update/check"):
            import delve_update as UP
            r=UP.check(HUB.cfg)
            p=UP.pending()
            if p:
                # already downloaded and proved; it goes in when Braid closes
                r={**r,"ok":True,"update":True,"latest":p.get("version"),"staged_ready":True}
            return s._json(r)
        if path.startswith("/api/update"):
            import delve_update as UP
            return s._json(UP.status(HUB.cfg))
        if path.startswith("/api/share"):
            import delve_share as SH
            return s._json({"ok":True,**SH.preview(HUB.cfg),"history":SH.history(8),"to":SH.TO})
        if path.startswith("/api/memory/"):
            import delve_memory as MEM
            from urllib.parse import urlparse,parse_qs,unquote
            qs=parse_qs(urlparse(s.path).query)
            g=lambda k,d="":unquote((qs.get(k) or [d])[0])
            op=path[len("/api/memory/"):].strip("/")
            try:
                if op=="stats":r=MEM.stats()
                elif op=="cells":r=MEM.cells(g("slot","__global__"),int(g("limit","600") or 600),g("sort","recent"))
                elif op=="recent":r=MEM.recent(int(g("limit","120") or 120))
                elif op=="search":r=MEM.search(g("q"),int(g("limit","400") or 400),g("slot"),g("sort","recent"))
                elif op=="ledger":r=MEM.ledger(int(g("limit","40") or 40),g("task"))
                elif op=="rejections":r=MEM.rejections(g("q"),int(g("limit","300") or 300),g("sort","recent"))
                else:r=None
            except Exception as e:r={"ok":False,"error":str(e)[:200]}
            return s._json(r) if r is not None else s._send(404,"text/plain",b"not found")
        if path.startswith("/api/ptex/cells"):
            from urllib.parse import urlparse,parse_qs
            import delve_memory as MEM
            q=parse_qs(urlparse(s.path).query)
            slot=(q.get("slot") or ["__global__"])[0];lim=int((q.get("limit") or ["600"])[0] or 600)
            sort=(q.get("sort") or ["recent"])[0] or "recent"
            try:
                if slot in ("__recent__","__all__","recent","*"):
                    r=MEM.recent(min(lim,400));r["cells"]=r.get("hits") or r.get("cells") or []
                    return s._json(r)
                r=MEM.cells(slot,lim,sort)
                # Prefer useful slots first in the dropdown (not hex soup from May).
                slots=list(r.get("slots") or [])
                prefer=["__recent__","__global__","__local_user__","delve_Claude","delve_Grok","delve_Google","delve_Adam","delve_OpenAI","delve_Copilot"]
                rest=[x for x in slots if x not in prefer]
                rest_named=sorted([x for x in rest if str(x).startswith("delve_")],reverse=True)
                rest_other=sorted([x for x in rest if not str(x).startswith("delve_")])
                r["slots"]=[x for x in prefer if x in slots or x=="__recent__"]+rest_named+rest_other
                if "__recent__" not in r["slots"]:r["slots"]=["__recent__"]+r["slots"]
                r["ok"]=True
                return s._json(r)
            except Exception as e:
                return s._json({"ok":False,"error":str(e)[:180],"cells":[],"slots":["__recent__","__global__"],"hint":"Adam must be up for memory"},code=502)
        if path.startswith("/api/flows"):
            from urllib.parse import unquote
            rest=unquote(path[len("/api/flows"):].strip("/"))
            if not rest:return s._json({"ok":True,"flows":delve_graph.list_flows(HUB.seats_available()),"agents":HUB.seats_available(),"live":HUB.live_roster(),"all_agents":list(delve_graph.AGENTS),"end_modes":list(delve_graph.END_MODES)})
            g=delve_graph.load(rest,HUB.seats_available())
            if not g:return s._json({"ok":False,"error":"no such flow"},code=404)
            e,w=delve_graph.validate(g)
            return s._json({"ok":True,"flow":g,"errors":e,"warnings":w})
        if path.startswith("/api/dirs"):
            from urllib.parse import urlparse,parse_qs,unquote
            q=parse_qs(urlparse(s.path).query)
            g=lambda k,d="":(q.get(k) or [d])[0]
            # fs_scan=1: list every drive/folder including dot-dirs (picker only — agents stay jailed to workspace)
            fs_scan=str(g("fs_scan") or g("scan") or "").lower() in ("1","true","yes","on")
            want_roots=str(g("roots") or "").lower() in ("1","true","yes","on")
            cur_raw=unquote(g("path") or "").strip()
            def _drives():
                out=[]
                if os.name=="nt":
                    for letter in "CDEFGHIJKLMNOPQRSTUVWXYZ":
                        root=letter+":\\"
                        if os.path.isdir(root):out.append(root)
                else:
                    for p in ("/","/home","/Users","/mnt","/Volumes"):
                        if os.path.isdir(p):out.append(p)
                return out
            def _favs():
                home=os.path.expanduser("~")
                cand=[HUB.work,os.path.join(ROOT,"workspace"),home,
                      os.path.join(home,"Documents"),os.path.join(home,"Desktop"),
                      os.path.join(home,"Downloads"),os.path.abspath(os.path.join(ROOT,".."))]
                if os.name=="nt":
                    cand+=[os.path.expandvars(r"%USERPROFILE%"),os.path.expandvars(r"%PUBLIC%"),
                           os.path.expandvars(r"%SystemDrive%\\")]
                    cand+=_drives()
                else:cand+=_drives()
                ai=os.path.abspath(os.path.join(ROOT,".."))
                if os.path.isdir(ai):
                    try:cand+=[os.path.join(ai,d) for d in sorted(os.listdir(ai),key=str.lower)
                               if not d.startswith((".","_","-")) and os.path.isdir(os.path.join(ai,d))][:40]
                    except Exception:pass
                seen=set();out=[]
                for p in cand:
                    try:p=os.path.abspath(os.path.expandvars(os.path.expanduser(p or "")))
                    except Exception:continue
                    if not p or p in seen or not os.path.isdir(p):continue
                    seen.add(p);out.append(p)
                return out[:48]
            if want_roots and not cur_raw:
                roots=_drives() or [os.path.expanduser("~")]
                return s._json({"ok":True,"path":"","parent":"","sep":os.sep,"dirs":[],"roots":roots,
                 "favs":_favs(),"current":os.path.abspath(HUB.cfg.get("workspace") or HUB.work),"fs_scan":fs_scan})
            cur=cur_raw or (HUB.cfg.get("workspace") or HUB.work)
            cur=os.path.abspath(os.path.expandvars(os.path.expanduser(cur)))
            if not os.path.isdir(cur):
                # Typed path missing — fall back to home if scanning, else work
                cur=os.path.abspath(os.path.expanduser("~") if fs_scan else HUB.work)
                if not os.path.isdir(cur):cur=os.path.abspath(HUB.work)
            try:
                kids=[]
                for d in os.scandir(cur):
                    try:
                        if not d.is_dir(follow_symlinks=False):continue
                    except Exception:continue
                    n=d.name
                    if not fs_scan and (n.startswith(".") or n.startswith("__")):continue
                    kids.append(n)
                kids=sorted(kids,key=str.lower)
            except PermissionError as e:
                return s._json({"ok":False,"error":"permission denied: "+str(e)[:120],"path":cur,"dirs":[],"favs":_favs(),"fs_scan":fs_scan})
            except Exception as e:
                return s._json({"ok":False,"error":str(e)[:160],"path":cur,"dirs":[],"favs":_favs(),"fs_scan":fs_scan})
            par=os.path.dirname(cur.rstrip("\\/")) or cur
            # At drive root on Windows, parent == self; expose roots for "up"
            at_root=(par==cur) or (os.name=="nt" and len(cur.rstrip("\\/"))<=3 and cur[1:3] in (":\\",":/"))
            return s._json({"ok":True,"path":cur,"parent":("" if at_root else par),"sep":os.sep,
             "dirs":kids[:800],"favs":_favs(),"roots":(_drives() if at_root or fs_scan else []),
             "current":os.path.abspath(HUB.cfg.get("workspace") or HUB.work),"fs_scan":fs_scan,"at_root":at_root})
        if path.startswith("/api/sessions"):
            rows=[]
            for it in delve.list_sessions(60,rich=True):
                if it.get("archived") and "include_archived=1" not in s.path:continue
                row={k:it.get(k) for k in ("name","size","mtime","title","messages","speakers","preview","pinned","archived")}
                other=room_of_file(str(row.get("name") or ""),skip=_room().id)
                if other:row["open_in"]=other
                rows.append(row)
            return s._json({"ok":True,"sessions":rows,"current":os.path.basename(HUB.file),"count":len(rows),
             "busy":BUSY.locked(),"room":_room().id,"rooms":rooms_state()})
        if path.startswith("/api/billing/feedback"):
            import delve_billing as BB
            return s._json(BB.feedback_list(50))
        if path.startswith("/api/billing/price"):
            import delve_billing as BB
            from urllib.parse import urlparse,parse_qs
            q=parse_qs(urlparse(s.path).query);g=lambda k,d:(q.get(k) or [d])[0]
            return s._json({"ok":True,"price":BB.price(g("tier","beta"),g("period","month"),int(g("seats","1") or 1)),
             "team":BB.team_quote(int(g("seats","1") or 1)),"plans":BB.plans()})
        if path.startswith("/api/billing"):
            import delve_billing as BB
            return s._json({"ok":True,**BB.catalog(),"account":BB.account()})
        if path.startswith("/api/usage"):
            force=("refresh=1" in s.path) or ("force=1" in s.path);return s._json(_usage(force))
        if path.startswith("/api/models"):
            force=("refresh=1" in s.path) or ("force=1" in s.path)
            try:
                import delve_models as DM
                cat=DM.catalog(fast=not force)
                if not force:
                    threading.Thread(target=lambda:DM.catalog(fast=False),daemon=True).start()
                cat["seats"]=HUB.resolved_seats()
                return s._json(cat)
            except Exception:
                u=_usage(False)
                return s._json({"claude":(u.get("claude") or {}).get("models") or [],"grok":(u.get("grok") or {}).get("models") or [],"google":(u.get("google") or {}).get("models") or [],
                 "Claude":(u.get("claude") or {}).get("models") or [],"Grok":(u.get("grok") or {}).get("models") or [],"Google":(u.get("google") or {}).get("models") or [],
                 "Adam":list(delve.SEAT_MODEL_DEFAULTS.get("Adam") or []),"OpenAI":list(delve.SEAT_MODEL_DEFAULTS.get("OpenAI") or []),
                 "Copilot":list(delve.SEAT_MODEL_DEFAULTS.get("Copilot") or []),"Cursor":list(delve.SEAT_MODEL_DEFAULTS.get("Cursor") or []),
                 "OpenCode":list(delve.SEAT_MODEL_DEFAULTS.get("OpenCode") or []),"seats":HUB.resolved_seats()})
        if path.startswith("/api/remote/caps"):return s._json(HUB.remote_caps())
        if path.startswith("/api/stream"):return s._stream()
        if path.startswith("/logos/"):return s._file(path[1:],s._ctype(path))
        if path.startswith("/web/"):return s._file(path[5:],s._ctype(path))
        s._send(404,"text/plain",b"not found")
    def do_POST(s):
        s._bind()
        path=s.path.split("?",1)[0]
        # a binary upload must not be pushed through json.loads
        if path.startswith("/api/files/upload"):
            if not s._guard(path):return
            import delve_files as FS
            ln=s._body_len(FS.MAX_BYTES+1024)
            if ln<0:
                return s._json({"ok":False,"error":"that file is larger than %d MB"%(FS.MAX_BYTES//(1024*1024))},code=413)
            data=s.rfile.read(ln) if ln else b""
            from urllib.parse import unquote
            name=unquote(s.headers.get("X-Braid-Filename") or "file")
            r=FS.save(HUB,name,data)
            if r.get("ok"):broadcast({"type":"files","added":r})
            return s._json(r,code=200 if r.get("ok") else 400)
        ln=s._body_len(MAX_BODY)
        if ln<0:return s._json({"ok":False,"error":"request body is missing a usable length"},code=413)
        raw=s.rfile.read(ln) if ln else b"{}"
        # An HTML form can only ever send urlencoded / multipart / text-plain. Insisting on
        # a real JSON content type is what stops a form on someone else's page from posting
        # a JSON body here without tripping a CORS preflight.
        # An EMPTY Content-Type is not the same as "not a form". fetch() with a Blob body whose
        # type is "" sends no Content-Type at all and is still a CORS *simple* request, so
        # accepting "" handed that shape a free pass through the third layer. A body must say
        # what it is; a zero-length body still needs nothing.
        ct=(s.headers.get("Content-Type") or "").split(";",1)[0].strip().lower()
        if ln and ct not in ("application/json","text/json"):
            if not s._guard(path):return
            return s._json({"ok":False,"error":"this endpoint takes application/json"},code=415)
        try:body=json.loads(raw.decode("utf-8") or "{}")
        except Exception:body={}
        if not s._guard(path):return
        if path.startswith("/api/code/"):
            import delve_code as CO
            op=path[len("/api/code/"):]
            r=(CO.write(HUB,body.get("path"),body.get("content") or "",by=str(body.get("by") or "you"),emit=broadcast) if op=="write" else
               CO.approve(HUB,body.get("id") or 0,bool(body.get("allow")),emit=broadcast) if op=="approve" else
               CO.undo(HUB) if op=="undo" else CO.accept(HUB) if op=="accept" else None)
            return s._json(r,code=(r or {}).get("code",200) if isinstance(r,dict) else 200) if r is not None else s._send(404,"text/plain",b"not found")
        if path.startswith("/api/license"):
            import delve_license as LC
            act=str(body.get("action") or "activate").lower()
            if act=="deactivate":
                LC.deactivate();return s._json({"ok":True,**LC.status()})
            r=LC.activate(body.get("key"))
            return s._json({**r,**({"state":LC.status(True).get("state")} if r.get("ok") else {}),"status_full":LC.status()})
        if path.startswith("/api/machine/"):
            import delve_machine as MC
            seat=str(body.get("seat") or "").strip()
            if seat not in delve.AGENTS:return s._json({"ok":False,"error":"unknown seat"},400)
            op=path[len("/api/machine/"):].strip("/")
            if op=="start":
                r=MC.start(seat,HUB.work)
                if r.get("ok"):broadcast({"type":"status","text":seat+"'s machine is up — watch it in the Machines dock"})
                return s._json(r)
            if op=="stop":
                r=MC.stop(seat)
                broadcast({"type":"status","text":seat+"'s machine stopped"})
                return s._json(r)
            if op=="nav":
                mm=MC.get(seat)
                if not (mm and mm.alive):return s._json({"ok":False,"error":"machine not running"},409)
                return s._json(mm.navigate(body.get("url")))
            if op=="exec":
                mm=MC.get(seat)
                if not (mm and mm.alive):return s._json({"ok":False,"error":"machine not running"},409)
                return s._json(mm.exec(body.get("cmd")))
            return s._json({"ok":False,"error":"unknown machine op"},400)
        if path.startswith("/api/privacy/harden"):
            import delve_privacy as PRV
            r=PRV.harden()
            broadcast({"type":"status","text":"privacy: CLI configs hardened"})
            return s._json({"ok":True,"results":r})
        if path.startswith("/api/remote"):
            import delve_remote as RM
            if body.get("firewall"):
                r=RM.fw_open(int(HUB.cfg.get("remote_port") or 8790))
                return s._json({**RM.status(int(HUB.cfg.get("remote_port") or 8790)),"firewall_attempt":r})
            if body.get("host") is not None:
                HUB.cfg["remote_host"]=str(body.get("host") or "");delve.save_cfg(HUB.cfg)
            on=body.get("on");pref=str(HUB.cfg.get("remote_host") or "")
            if on is True:
                # One port: if this listener is already bound wide, adopt it. If Braid started
                # with phone access off it is on loopback only, and widening a live socket is
                # not worth the dropped SSE streams - persist the choice and say so plainly.
                if getattr(s.server,"braid_remote",False):
                    port_now=int(s.server.server_address[1])
                    RM.adopt(port_now);HUB.cfg["remote_port"]=port_now
                    HUB.cfg["remote_on"]=True;delve.save_cfg(HUB.cfg)
                    r=RM.status(host_pref=pref)
                else:
                    HUB.cfg["remote_on"]=True;delve.save_cfg(HUB.cfg)
                    return s._json({**RM.status(host_pref=pref),"persisted":True,"restart_required":True,
                     "error":"phone access is on for next launch — restart Braid to open it on this port"},code=409)
            elif on is False:
                RM.stop();HUB.cfg["remote_on"]=False;delve.save_cfg(HUB.cfg);r=RM.status(host_pref=pref)
            else:r=RM.status(host_pref=pref)
            return s._json({**r,"persisted":bool(HUB.cfg.get("remote_on"))})
        if path.startswith("/api/send"):return s._send_msg(body)
        if path.startswith("/api/remote/caps"):
            return s._json(HUB.remote_caps())
        if path.startswith("/api/remote/turn"):
            seat=str(body.get("seat") or body.get("who") or "").strip()
            msgs=body.get("messages") or body.get("transcript") or []
            if not isinstance(msgs,list):return s._json({"ok":False,"error":"messages must be a list"},code=400)
            if not seat:return s._json({"ok":False,"error":"need seat"},code=400)
            if BUSY.locked():return s._json({"ok":False,"error":"PC room is busy — try again in a moment","busy":True},code=409)
            if not BUSY.acquire(blocking=False):return s._json({"ok":False,"error":"PC room is busy","busy":True},code=409)
            try:
                r=HUB.remote_turn(seat,msgs,extra=str(body.get("extra") or ""),record=bool(body.get("record")))
                return s._json(r,code=200 if r.get("ok") else 400)
            finally:
                try:BUSY.release()
                except Exception:pass
        if path.startswith("/api/estop"):HUB._estop();HUB.pending=[];broadcast({"type":"queued","text":"","queued":0});return s._json({"ok":True})
        if path.startswith("/api/bugreport"):
            import delve_bugreport as BR
            r=BR.send(str(body.get("message") or ""),hub=HUB,
             include_diag=bool(body.get("include_diag",True)),contact=str(body.get("contact") or ""),
             webhook=HUB.cfg.get("bug_webhook"))
            return s._json({"ok":True,**r})
        if path.startswith("/api/billing/feedback"):
            import delve_billing as BB
            return s._json(BB.feedback_add(body.get("text"),body.get("kind") or "note",body.get("where") or ""))
        if path.startswith("/api/billing/quote"):
            import delve_billing as BB
            return s._json(BB.quote(body.get("budget"),body.get("providers"),
             str(body.get("tier") or "beta"),int(body.get("seats") or 1),str(body.get("period") or "month")))
        if path.startswith("/api/billing/signup"):
            import delve_billing as BB
            r=BB.signup(body.get("email"),body.get("budget"),body.get("providers"),
             str(body.get("tier") or "beta"),int(body.get("seats") or 1),str(body.get("period") or "month"))
            if r.get("ok"):
                provs=dict(HUB.cfg.get("providers") or {});provs.update(r.get("seats") or {})
                HUB.cfg["providers"]=provs;HUB.seats_dirty();delve.save_cfg(HUB.cfg);broadcast(_cfg_ev())
            return s._json(r)
        if path.startswith("/api/providers/secret"):
            import delve_providers as PV
            seat=str(body.get("seat") or "").strip()
            if seat not in delve.AGENTS:return s._json({"ok":False,"error":"unknown seat"},code=400)
            return s._json(PV.set_secret(seat,body.get("secret") or ""))
        if path.startswith("/api/providers/test"):
            import delve_providers as PV
            seat=str(body.get("seat") or "").strip()
            cfg=body.get("cfg") if isinstance(body.get("cfg"),dict) else None
            if not cfg:
                cfg=((HUB.cfg.get("providers") or {}).get(seat) or
                     ({"kind":"adam"} if seat=="Adam" else
                      ({"kind":"cli"} if seat in delve.CORE_AGENTS else {"kind":"off"})))
            return s._json(PV.test(seat,cfg))
        if path.startswith("/api/providers"):
            import delve_providers as PV
            seat=str(body.get("seat") or "").strip()
            if seat not in delve.AGENTS:return s._json({"ok":False,"error":"unknown seat"},code=400)
            cfg=body.get("cfg") if isinstance(body.get("cfg"),dict) else {}
            for k in ("secret","key","api_key"):cfg.pop(k,None)
            # `base` is where this seat's API key gets sent. Stored config is writable by a
            # paired remote device, so an unchecked base is a key-exfiltration channel, not a
            # preference. Same for key_env, which names an environment variable to ship.
            ok,why=PV.safe_base(cfg.get("base"))
            if not ok:return s._json({"ok":False,"error":why},code=400)
            ke=str(cfg.get("key_env") or "").strip()
            if ke and not re.match(r"^[A-Z][A-Z0-9_]{0,63}$",ke):
                return s._json({"ok":False,"error":"key_env must be a plain environment variable name"},code=400)
            provs=dict(HUB.cfg.get("providers") or {});provs[seat]=cfg
            HUB.cfg["providers"]=provs;HUB.seats_dirty();delve.save_cfg(HUB.cfg)
            return s._json({"ok":True,"seat":seat,"cfg":PV.public(seat,cfg)})
        if path.startswith("/api/files/delete"):
            import delve_files as FS
            r=FS.delete(HUB,body.get("path"))
            if r.get("ok"):broadcast({"type":"files","removed":body.get("path")})
            return s._json(r)
        if path.startswith("/api/update/install"):
            import delve_update as UP
            r=UP.update_now(HUB.cfg)
            if r.get("ok") and r.get("restarting"):
                # The swap script cannot replace a running image, so it sits waiting for
                # this process to go. Nothing used to make that happen and the update just
                # hung: spawn the exit ourselves, once the reply is on the wire.
                def _bow_out():
                    time.sleep(1.5)
                    os._exit(0)
                threading.Thread(target=_bow_out,daemon=True).start()
            return s._json(r)
        if path.startswith("/api/share/build"):
            import delve_share as SH
            return s._json(SH.build(HUB.cfg,body.get("parts"),body.get("note") or ""))
        if path.startswith("/api/memory/"):
            import delve_memory as MEM
            op=path[len("/api/memory/"):].strip("/")
            try:
                if op=="edit":r=MEM.edit(body.get("slot") or "__global__",body.get("q"),body.get("a"))
                elif op=="forget":r=MEM.forget(body.get("pattern"),str(body.get("atlas") or "personal"))
                elif op in ("rejections/drop","rejections"):
                    r=MEM.rejections_drop(body.get("idxs"),body.get("q") or "",bool(body.get("all")))
                elif op=="wipe":r=MEM.wipe(str(body.get("what") or "rejections"),body.get("pattern") or "")
                else:r=None
            except Exception as e:r={"ok":False,"error":str(e)[:200]}
            return s._json(r) if r is not None else s._send(404,"text/plain",b"not found")
        if path.startswith("/api/fyi/clear"):
            return s._json({"ok":True,"fyi":HUB.fyi_clear()})
        if path.startswith("/api/queue/clear"):
            HUB.interjects=[];HUB.pending=[];broadcast({"type":"queued","text":"","queued":0});return s._json({"ok":True,"count":0})
        if path.startswith("/api/flows/author"):
            import delve_flowgen as FGEN
            """Writing a flow is not a turn in this conversation, so it must not queue behind
            one. It used to take the room's own BUSY lock and call FGEN.author(HUB,...), which
            also meant hub.abort.clear() wiping an in-flight estop and oneshot() emitting into
            a room that was mid-answer. It now runs on a scratch room with its own hub, lock
            and abort flag - edit a flow while any chat is running, in use or not."""
            if not AUTHOR_LOCK.acquire(blocking=False):return s._json({"ok":False,"error":"already writing a flow — one at a time"},code=409)
            try:r=FGEN.author(room("_author").hub,str(body.get("prompt") or ""),str(body.get("seat") or ""))
            finally:
                try:AUTHOR_LOCK.release()
                except Exception:pass
            return s._json(r)
        if path.startswith("/api/flows/delete"):
            return s._json({"ok":delve_graph.delete(str(body.get("id") or ""))})
        if path.startswith("/api/flows/run"):
            g=delve_graph.load(str(body.get("id") or ""),HUB.seats_available()) or (body.get("flow") if isinstance(body.get("flow"),dict) else None)
            if not g:return s._json({"ok":False,"error":"no such flow"},code=404)
            if BUSY.locked():return s._json({"ok":False,"error":"this conversation is mid-answer — stop it, or start a new conversation to run this flow"},code=409)
            sp=body.get("start_prompt")
            um=(body.get("text") or body.get("user_msg") or "").strip()
            if body.get("adopt"):
                HUB.cfg["path_preset"]="flow:"+str(g.get("id") or "");delve.save_cfg(HUB.cfg)
                broadcast(_cfg_ev())
            if not um:return s._json({"ok":False,"error":"a flow runs on a message — type what you want the room to work on"},code=400)
            spawn(_run,lambda:delve_graph.run(HUB,g,sp,um))
            return s._json({"ok":True,"started":True,"label":g.get("label")})
        if path.startswith("/api/flows"):
            g=body.get("flow") if isinstance(body.get("flow"),dict) else body
            return s._json(delve_graph.save(g))
        if path.startswith("/api/sessions/new"):
            if BUSY.locked():return s._json({"ok":False,"error":"busy — stop current exchange first"},409)
            title=(body.get("title") or "").strip()
            HUB.t=[];HUB.idx={a:0 for a in delve.AGENTS};HUB.reset_cli_pins()
            HUB.stamp=delve.new_session_stamp()
            HUB.file=os.path.join(delve.SESS,"session_"+HUB.stamp+".md");_uniq_session(_room().hub)
            HUB._auto_seed=False
            HUB.cfg["last_session"]=os.path.basename(HUB.file);delve.save_cfg(HUB.cfg)
            # A new conversation is blank unless the user named it (title becomes the
            # first message) or deliberately opted into seed.md. Never plant leftover
            # disk text into a conversation the user just asked to start clean.
            if title:
                HUB.add("Anthony",title);meta=delve.load_sessions_meta();meta[os.path.basename(HUB.file)]={"title":title[:120]};delve.save_sessions_meta(meta)
            else:
                txt=_seed_text()
                if txt:HUB.seed_add("Anthony",txt)
            broadcast({"type":"reload","file":os.path.basename(HUB.file),"messages":len(HUB.t)})
            broadcast({"type":"status","text":"new conversation "+os.path.basename(HUB.file)})
            broadcast({"type":"idle"})
            return s._json({"ok":True,"file":os.path.basename(HUB.file),"messages":len(HUB.t),"stamp":HUB.stamp})
        if path.startswith("/api/sessions/delete"):
            """A transcript is work, not a temp file - delete RECYCLES into sessions/_deleted/
            so a misclick is recoverable from the folder rather than from a backup. Same
            `under()` jail as resume: the name is caller-supplied and this one unlinks."""
            name=os.path.basename((body.get("name") or body.get("file") or "").strip())
            if not (name.startswith("session_") and name.endswith(".md")):
                return s._json({"ok":False,"error":"that is not a conversation file"},400)
            src=os.path.join(delve.SESS,name)
            if not under(delve.SESS,src):return s._json({"ok":False,"error":"path outside sessions/"},400)
            if not os.path.isfile(src):return s._json({"ok":False,"error":"no such conversation"},404)
            if os.path.basename(HUB.file)==name and BUSY.locked():
                return s._json({"ok":False,"error":"that is the open conversation and the room is mid-answer — stop it first"},409)
            trash=os.path.join(delve.SESS,"_deleted")
            try:
                os.makedirs(trash,exist_ok=True)
                dst=os.path.join(trash,name)
                if os.path.exists(dst):dst=os.path.join(trash,os.path.splitext(name)[0]+"_"+str(int(time.time()))+".md")
                os.replace(src,dst)
            except Exception as e:return s._json({"ok":False,"error":str(e)[:160]},500)
            meta=delve.load_sessions_meta();meta.pop(name,None);delve.save_sessions_meta(meta)
            if HUB.cfg.get("last_session")==name:
                HUB.cfg.pop("last_session",None);delve.save_cfg(HUB.cfg)
            fresh=None
            if os.path.basename(HUB.file)==name:
                HUB.t=[];HUB.idx={a:0 for a in delve.AGENTS};HUB.reset_cli_pins()
                HUB.stamp=delve.new_session_stamp()
                HUB.file=os.path.join(delve.SESS,"session_"+HUB.stamp+".md");_uniq_session(_room().hub)
                HUB._auto_seed=False
                fresh=os.path.basename(HUB.file)
                broadcast({"type":"reload","file":fresh,"messages":0})
            broadcast({"type":"sessions"})
            return s._json({"ok":True,"deleted":name,"recycled_to":os.path.join("sessions","_deleted",name),"current":fresh or os.path.basename(HUB.file)})
        if path.startswith("/api/sessions/meta"):
            name=os.path.basename((body.get("name") or body.get("file") or "").strip())
            if not name:return s._json({"ok":False,"error":"missing name"},400)
            meta=delve.load_sessions_meta();row=dict(meta.get(name) or {})
            if "title" in body:row["title"]=str(body.get("title") or "")[:120]
            if "pinned" in body:row["pinned"]=bool(body.get("pinned"))
            if "archived" in body:row["archived"]=bool(body.get("archived"))
            meta[name]=row;delve.save_sessions_meta(meta)
            broadcast({"type":"sessions"})
            return s._json({"ok":True,"name":name,"meta":row})
        if path.startswith("/api/sessions/resume") or path.startswith("/api/sessions/load"):
            if BUSY.locked():return s._json({"ok":False,"error":"busy — stop current exchange first"},409)
            name=(body.get("name") or body.get("file") or "").strip()
            if not name or name in ("latest","last",""):
                last=delve.latest_session(min_bytes=int(body.get("min_bytes") or 400))
                if not last:return s._json({"ok":False,"error":"no session files found"})
                path_load=last["path"]
            else:
                base=os.path.basename(name)
                path_load=os.path.join(delve.SESS,base) if not os.path.isabs(name) else name
                if not under(delve.SESS,path_load):return s._json({"ok":False,"error":"path outside sessions/"},400)
            # Two hubs on one transcript would both flush() it and the loser's turns vanish.
            # The tab that asked simply adopts the room that already has it open.
            other=room_of_file(os.path.basename(path_load),skip=_room().id)
            if other:return s._json({"ok":True,"switch_room":other,"file":os.path.basename(path_load)})
            r=HUB.load_session(path_load,keep_file=True)
            if r.get("ok"):
                # Opening a conversation is what "where I left off" means. Only /sessions/new used
                # to record it, so a restart dropped you into the newest room, not the open one.
                try:HUB.cfg["last_session"]=os.path.basename(HUB.file);delve.save_cfg(HUB.cfg)
                except Exception:pass
                broadcast({"type":"reload","file":os.path.basename(path_load),"messages":r.get("messages")})
                broadcast({"type":"status","text":"resumed "+os.path.basename(path_load)+" ("+str(r.get("messages"))+" messages)"})
                broadcast({"type":"idle"})
            return s._json(r)
        if path.startswith("/api/export"):
            return s._json({"ok":True,"file":os.path.basename(HUB.file),"path":HUB.file,"markdown":open(HUB.file,encoding="utf-8",errors="replace").read() if os.path.exists(HUB.file) else "","messages":len(HUB.t)})
        if path.startswith("/api/google"):
            u=delve_usage.google_usage() if hasattr(delve_usage,"google_usage") else {};return s._json(u)
        if path.startswith("/api/setup/assist"):
            if s.client_address[0] not in ("127.0.0.1","::1"):
                return s._json({"ok":False,"error":"local only"},code=403)
            import delve_providers as PV
            return s._json(PV.setup_assist(str(body.get("seat") or ""),str(body.get("action") or "")))
        if path.startswith("/api/config"):
            if "seat_model" in body and isinstance(body.get("seat_model"),dict):
                sm=body["seat_model"];seat=str(sm.get("seat") or sm.get("name") or "").strip();mid=sm.get("model","")
                if seat not in delve.AGENTS:return s._json({"ok":False,"error":"unknown seat"},code=400)
                ok,err=HUB.set_seat_model(seat,mid)
                if not ok:return s._json({"ok":False,"error":err},code=400)
                # Adam loads its model at boot. Picking a bake in the sidebar therefore has to
                # cycle the serve, in the background so the UI stays responsive, and the result
                # is broadcast so a failed swap is visible instead of silently testing the old model.
                if seat=="Adam" and delve.ADAM is not None and str(mid).startswith("bakes/"):
                    def _swap(b=str(mid)):
                        broadcast({"type":"status","text":"Adam loading "+b+" — ~30s, the seat is offline until it answers /healthz"})
                        try:r=delve.ADAM.restart(HUB.cfg.get("adam_mode","light"),wait=True,budget=300,bake=b)
                        except Exception as e:r={"ok":False,"reason":str(e)[:160]}
                        broadcast({"type":"status","text":("Adam now running "+str(r.get("live_bake") or b)+" (up in "+str(r.get("wait_s"))+"s)") if r.get("phase")=="up" else ("Adam model swap failed — "+str(r.get("reason") or r.get("phase"))[:160])})
                        broadcast(_cfg_ev())
                    spawn(_swap)
                if "effort" in sm:
                    ok,err=HUB.set_seat_effort(seat,sm.get("effort") or "")
                    if not ok:return s._json({"ok":False,"error":err},code=400)
            if "seat_effort" in body and isinstance(body.get("seat_effort"),dict):
                se=body["seat_effort"];seat=str(se.get("seat") or se.get("name") or "").strip()
                if seat not in delve.AGENTS:return s._json({"ok":False,"error":"unknown seat"},code=400)
                ok,err=HUB.set_seat_effort(seat,se.get("effort") or se.get("level") or "")
                if not ok:return s._json({"ok":False,"error":err},code=400)
            if "seat_models" in body and isinstance(body.get("seat_models"),dict):
                for sn,mv in body["seat_models"].items():
                    if sn not in delve.AGENTS:continue
                    ok,err=HUB.set_seat_model(sn,mv)
                    if not ok:return s._json({"ok":False,"error":err},code=400)
            _locked=set(HUB.cfg.get("_managed_keys") or []);_mskip=[]
            for k in ("bypass","ptex_learn","privacy_mode","user_name","board_style","seat_backends","update_channel","session_retention_days","default","path_preset","claude_model","grok_model","google_model","adam_fallback","adam_mode","workspace","adam_tools","adam_steps","adam_intent","ui_mode","basic_layout","setup_done","code_mode","remote_port","seat_order","last_session","license_buy_url","seat_prefs","remote_host","compact_ctx","compact_k","compact_recap_chars","compact_min_chars","compact_every","adam_ctx_turns","adam_msg_chars","adam_enabled","share_improve","share_consent_ts","usage_poll","privacy_asked","tutorial_done","license_url","license_pubkey","turn_timeout","auto_update","update_url","release_pubkey","adam_unrestricted","seed_on","harness_default","harness_by_mode","harness_overrides","cli_mcp","cli_stream","grok_max_turns","answer_style",
             # v3.7.24/25 turn policy. Without these on the list the knobs exist in the code and
             # are unreachable from anything but a hand-edit of the file while Braid is stopped -
             # and the running app rewrites that file from memory, so the edit is lost anyway.
             "turn_cap","turn_stall","cli_ctx_pct","cli_session_mode","cli_session_refresh_every"):
                if k in body:
                    if k in _locked:
                        _mskip.append(k);continue
                    v=body[k]
                    if k=="seed_on":v=bool(v)
                    if k in ("claude_model","grok_model","google_model"):
                        v=str(v or "").strip()
                        if v and (len(v)>96 or v.startswith("-") or not re.match(r"^[A-Za-z0-9][A-Za-z0-9._:/\-@+]*$",v)):
                            return s._json({"ok":False,"error":k+" must be a plain model id (no leading dashes, no shell metacharacters)"},code=400)
                    if k=="adam_unrestricted":v=bool(v)
                    if k=="turn_cap":v=bool(v)
                    if k=="turn_stall":
                        try:v=max(0,int(v))
                        except Exception:return s._json({"ok":False,"error":"turn_stall must be seconds (0 disables it)"},code=400)
                    if k=="cli_ctx_pct":
                        try:v=float(v)
                        except Exception:return s._json({"ok":False,"error":"cli_ctx_pct must be a fraction, e.g. 0.2"},code=400)
                        if not (0<=v<1):return s._json({"ok":False,"error":"cli_ctx_pct must be between 0 and 1 (0.2 = refresh at a fifth of the window)"},code=400)
                    if k=="cli_session_refresh_every":
                        try:v=max(1,int(v))
                        except Exception:return s._json({"ok":False,"error":"cli_session_refresh_every must be a whole number of turns"},code=400)
                    if k=="cli_session_mode":
                        v=str(v or "").strip().lower()
                        if v not in ("refresh","pin","resume","sticky","always","fresh","oneshot","stateless","off","never"):
                            return s._json({"ok":False,"error":"cli_session_mode must be refresh, pin or fresh"},code=400)
                    if k=="workspace":
                        v=os.path.abspath(os.path.expandvars(os.path.expanduser(str(v or "").strip())))
                        if not os.path.isdir(v):return s._json({"ok":False,"error":"not a directory: "+v},code=400)
                        HUB.work=v
                        try:os.makedirs(v,exist_ok=True)
                        except Exception:pass
                    if k in ("compact_k","adam_ctx_turns"):
                        try:v=max(1,min(60,int(v)))
                        except Exception:v=5
                    if k in ("compact_recap_chars","adam_msg_chars"):
                        try:v=max(120,min(8000,int(v)))
                        except Exception:v=600
                    if k=="compact_min_chars":
                        try:v=max(1500,min(200000,int(v)))
                        except Exception:v=8000
                    if k=="compact_every":
                        try:v=max(1,min(40,int(v)))
                        except Exception:v=4
                    if k=="compact_ctx":v=bool(v)
                    if k in ("adam_enabled","tutorial_done"):v=bool(v)
                    if k in ("license_url","update_url"):
                        v=str(v or "").strip().rstrip("/")
                        if v and not (v.lower().startswith("https://") or v.lower().startswith("http://127.0.0.1") or v.lower().startswith("http://localhost")):
                            return s._json({"ok":False,"error":"that endpoint must be https:// — a plaintext licence or update server can be rewritten in transit"},code=400)
                    if k=="auto_update":
                        v=str(v or "notify").strip().lower()
                        if v not in ("off","notify","auto"):v="notify"
                    if k in ("license_pubkey","release_pubkey"):
                        v="".join(str(v or "").split()).lower()
                        if v and (len(v)!=64 or any(c not in "0123456789abcdef" for c in v)):
                            return s._json({"ok":False,"error":"that is not a 32-byte hex Ed25519 public key"},code=400)
                    if k=="turn_timeout":
                        try:v=max(60,min(7200,int(v)))
                        except Exception:v=900
                    if k=="share_improve":
                        v=bool(v)
                        HUB.cfg["share_consent_ts"]=__import__("time").time() if v else 0
                    if k=="adam_steps":
                        try:v=max(1,min(24,int(v)))
                        except Exception:v=8
                    if k in ("adam_tools","adam_intent","adam_fallback","ptex_learn","privacy_asked","privacy_mode","compact_ctx"):v=bool(v)
                    if k=="answer_style":v="full" if str(v).lower() in ("full","long","0","false") else "concise"
                    if k=="usage_poll":
                        v=bool(v);USAGE_CACHE["t"]=0;USAGE_CACHE["data"]=None
                    if k=="default" and str(v).lower()=="gemini":v="google"
                    if k=="path_preset":
                        v=str(v or "sequential").strip()
                        if v.startswith("flow:"):
                            if not delve_graph.load(v[5:],HUB.seats_available()):v="sequential"
                        else:
                            v=v.lower()
                            if v not in delve.PATH_PRESETS:v="sequential"
                    if k=="code_mode":
                        v={"review":"edit","open":"bypass"}.get(str(v or "").strip().lower(),str(v or "").strip().lower())
                        if v not in ("plan","edit","bypass"):v="edit"
                    if k=="remote_port":
                        try:v=max(1024,min(65535,int(v)))
                        except Exception:v=8790
                    HUB.cfg[k]=v
            HUB.seats_dirty();delve.save_cfg(HUB.cfg)
            # One settings file, many rooms: a room that missed the write would keep answering
            # on the old model / permission mode until it was restarted.
            push_cfg(HUB.cfg)
            ev=_cfg_ev();broadcast_all(ev)
            return s._json({"ok":True,"config":HUB.cfg,"path":ev["path"],
             "queued":ev["queued"],"flow":ev["flow"],"seats":HUB.resolved_seats(),
             **({"managed_locked":_mskip,"managed_note":"locked by your IT policy"} if _mskip else {})})
        if path.startswith("/api/clear"):
            HUB.t=[];HUB.idx={a:0 for a in delve.AGENTS};HUB.started={a:False for a in delve.AGENTS}
            HUB.stamp=delve.new_session_stamp();HUB.file=os.path.join(delve.SESS,"session_"+HUB.stamp+".md");_uniq_session(_room().hub)
            HUB._auto_seed=False
            broadcast({"type":"cleared"});return s._json({"ok":True})
        if path.startswith("/api/commit"):
            _rm=_room()
            def _bg_commit(rm=_rm):
                r=delve.PTEX.commit() if delve.PTEX else {"ok":False,"reason":"bridge unavailable"}
                _emit(rm,{"type":"status","kind":"commit","ok":bool(r.get("ok")),
                 "text":("Committed "+str(r.get("committed") or 0)+" lesson(s)") if r.get("ok") else ("Commit failed - "+str(r.get("error") or r.get("reason") or "unknown"))})
            threading.Thread(target=_bg_commit,daemon=True).start()
            return s._json({"ok":True,"queued":True})
        if path.startswith("/api/limits"):
            act=(body.get("action") or "list").lower()
            if act=="payg":
                seat=delve.Hub._seat_key(body.get("seat") or "")
                r=(HUB.payg_enable(seat,body.get("key") or "") if body.get("enable",True) else HUB.payg_disable(seat))
                HUB.seats_dirty();broadcast(_cfg_ev());return s._json(r)
            if act=="clear":
                seat=delve.Hub._seat_key(body.get("seat") or "")
                ok=HUB.limit_clear(seat)
                broadcast(_cfg_ev());return s._json({"ok":ok,"seat":seat,"limits":HUB.limits_snapshot()})
            return s._json({"ok":True,"limits":HUB.limits_snapshot()})
        if path.startswith("/api/adam"):
            act=(body.get("action") or "status").lower()
            mode=(body.get("mode") or HUB.cfg.get("adam_mode","light"))
            if not delve.ADAM:r={"ok":False,"reason":"bridge missing","up":False,"phase":"down"}
            elif act=="start":r=delve.ADAM.start(mode,bake=(body.get("bake") or HUB.cfg.get("adam_bake") or None))
            elif act=="bakes":
                r={"ok":True,"bakes":delve.ADAM.list_bakes(),"live":delve.ADAM.live_bake(),"hot_swappable":False,
                   "note":"the serve loads one bake at boot; switching models restarts Adam (~30s) and Braid verifies the live bake afterwards"}
            elif act=="restart":
                bk=(body.get("bake") or "").strip()
                broadcast({"type":"status","text":"Adam "+("switching model → "+bk if bk else "hot-restart")+" — cycling serve…"})
                r=delve.ADAM.restart(mode,wait=bool(body.get("wait",True)),budget=int(body.get("budget") or 300),bake=bk or None)
                if r.get("phase")=="wrong_bake":
                    broadcast({"type":"status","text":"Adam model swap FAILED — "+str(r.get("reason"))[:160]})
                else:
                    broadcast({"type":"status","text":"Adam restart: "+("up in "+str(r.get("wait_s"))+"s on "+str(r.get("live_bake") or r.get("bake") or "?") if r.get("phase")=="up" else str(r.get("reason") or r.get("phase"))[:120])})
            elif act=="stop_strays":
                killed=delve.ADAM.stop_strays(keep_venv=False);r={"ok":True,"killed":killed,"status":delve.ADAM.status(mode)}
            else:
                r=delve.ADAM.status(mode);r["fallback"]=HUB.cfg.get("adam_fallback",True);r["mode"]=mode
            broadcast(_cfg_ev());return s._json(r)
        s._send(404,"text/plain",b"not found")
    def _send_msg(s,body):
        target=(body.get("target") or HUB.cfg.get("default") or "all").lower();text=(body.get("text") or "").strip()
        if not text:return s._send(400,"application/json",b'{"ok":false,"error":"empty"}')
        try:
            import delve_license as LC
            ok,st=LC.allowed()
            if not ok:return s._json({"ok":False,"error":"Your Braid trial has ended — subscribe or add your licence key to keep asking the room.","license":st},code=402)
        except Exception:pass
        mode=str(body.get("mode") or "send").lower()
        if mode=="fyi":
            notes=HUB.fyi_add(text);return s._json({"ok":True,"fyi":notes})
        files=[f for f in (body.get("files") or []) if isinstance(f,dict) and f.get("path")]
        seats=body.get("seats");rounds=body.get("rounds");goal=str(body.get("goal") or "")[:2000]
        deb=(target=="debate") or bool(body.get("debate"))
        item={"text":text,"files":files,"target":target,"seats":seats,"rounds":rounds,"debate":deb,"goal":goal}
        busy_now=BUSY.locked()
        if mode=="queue" or (busy_now and mode in ("send","interject","")):
            if busy_now and mode!="queue":
                HUB._estop()
                broadcast({"type":"status","text":"interject — stopping the room to send your message now"})
                with PEND_LOCK:HUB.pending.insert(0,item)
                broadcast({"type":"queued","text":text,"queued":len(HUB.pending)})
                return s._json({"ok":True,"queued":True,"interject":True,"count":len(HUB.pending)})
            with PEND_LOCK:HUB.pending.append(item)
            broadcast({"type":"queued","text":text,"queued":len(HUB.pending)})
            if not BUSY.locked():spawn(_drain_pending)
            return s._json({"ok":True,"queued":True,"count":len(HUB.pending)})
        spawn(_dispatch,text,target,seats,rounds,deb,files=files,goal=goal)
        fg=flow_of(HUB.cfg.get("path_preset"))
        return s._json({"ok":True,**({"flow":fg.get("label")} if (fg is not None and (target in ("all","debate") or deb)) else {})})
    def _stream(s):
        q=queue.Queue(maxsize=SSE_BACKLOG)
        rm=_room()
        with SUBS_LOCK:rm.subs.append(q)
        try:
            s.send_response(200);s.send_header("Content-Type","text/event-stream");s.send_header("Cache-Control","no-cache");s.send_header("Connection","keep-alive")
            s.send_header("Referrer-Policy","no-referrer");s.send_header("X-Content-Type-Options","nosniff");s.end_headers()
            s.wfile.write(b": connected\n\n");s.wfile.flush()
            while True:
                try:data=q.get(timeout=15)
                except queue.Empty:
                    hb=json.dumps({"type":"hb","busy":rm.busy.locked(),"queued":len(getattr(rm.hub,"pending",None) or [])+len(getattr(rm.hub,"interjects",None) or [])})
                    s.wfile.write(("data: "+hb+"\n\n").encode("utf-8"));s.wfile.flush();continue
                s.wfile.write(("data: "+data+"\n\n").encode("utf-8"));s.wfile.flush()
        except Exception:pass
        finally:
            with SUBS_LOCK:
                if q in rm.subs:rm.subs.remove(q)
            reap_rooms()
def autostart_adam():
    if delve.ADAM is None or os.environ.get("DELVE_NO_ADAM_AUTOSTART")=="1":
        print("[delve] adam autostart skipped (bridge missing or DELVE_NO_ADAM_AUTOSTART)",flush=True);return
    if HUB.cfg.get("adam_enabled") is False:
        print("[delve] adam autostart skipped (adam_enabled=false)",flush=True);return
    if not HUB.adam_available():
        print("[delve] adam autostart skipped (Amni-Ai not available)",flush=True);return
    try:
        # Always go through start(): it kills thrash/dupes and clears stale .launching locks.
        r=delve.ADAM.start(HUB.cfg.get("adam_mode","light"),bake=(HUB.cfg.get("adam_bake") or None))
        print("[delve] adam autostart -> %s"%r,flush=True)
    except Exception as e:print("[delve] adam autostart failed: %s"%e,flush=True)
_ADAM_KICK_AT=0.0
_ADAM_CHECK_AT=0.0
def ensure_adam_bg():
    """boot_state() probes locks and processes for ~0.6s. It used to run inline, so every
    /api/state - every conversation switch - waited on a watchdog that only ever spawns a
    background thread anyway. Off the request path, throttled."""
    global _ADAM_CHECK_AT
    if delve.ADAM is None or os.environ.get("DELVE_NO_ADAM_AUTOSTART")=="1":return
    if time.time()-_ADAM_CHECK_AT<5.0:return
    _ADAM_CHECK_AT=time.time()
    threading.Thread(target=_adam_bg_check,daemon=True).start()
def _adam_bg_check():
    global _ADAM_KICK_AT
    if HUB.cfg.get("adam_enabled") is False or not HUB.adam_available():return
    try:
        st=delve.ADAM.boot_state()
        if st.get("phase")=="up":
            tops=st.get("tops") or []
            if len(tops)<=1 and not st.get("bad"):return
        elif st.get("phase")=="booting":
            age=st.get("lock_age_s")
            if age is not None and age<150:return
            if age is None and (st.get("procs") or []) and (time.time()-_ADAM_KICK_AT)<90:return
        elif st.get("phase")=="down" and (time.time()-_ADAM_KICK_AT)<8:return
        _ADAM_KICK_AT=time.time()
        threading.Thread(target=lambda:delve.ADAM.start(HUB.cfg.get("adam_mode","light"),bake=(HUB.cfg.get("adam_bake") or None)),daemon=True).start()
    except Exception:pass
_UPDATE_DONE=False
def _update_watch():
    """In auto mode, fetch and verify the next build quietly in the background. Nothing is
    swapped here - the binary is only replaced once Braid is on its way out, so a session is
    never interrupted and the next launch is simply the newer build."""
    import delve_update as UP
    time.sleep(90)
    while True:
        try:
            if str(HUB.cfg.get("auto_update",UP.DEFAULT_MODE)).lower()=="auto":
                r=UP.auto_tick(HUB.cfg)
                if r.get("ok") and r.get("staged"):
                    print("[braid] %s downloaded - it installs when you close Braid"%r.get("version"),flush=True)
        except Exception:pass
        time.sleep(3*3600)
def _finish_update_on_exit():
    """Hand a staged build to the swap script as the process winds down. Guarded so the two
    exit paths (serve_forever returning, and atexit) cannot both fire it."""
    global _UPDATE_DONE
    if _UPDATE_DONE:return
    _UPDATE_DONE=True
    try:
        import delve_update as UP
        r=UP.apply_pending_on_exit()
        if r and r.get("ok"):
            print("[braid] installing %s on the way out - next launch is the new build"%r.get("version"),flush=True)
        elif r and r.get("error"):
            print("[braid] staged update not applied: %s"%r.get("error"),flush=True)
    except Exception:pass
atexit.register(_finish_update_on_exit)
def _ask_running_remote_on(port):
    """Second copy must never bind its OWN empty Hub to the phone port. Ask the live hub."""
    try:
        import urllib.request
        body=json.dumps({"on":True}).encode("utf-8")
        req=urllib.request.Request("http://127.0.0.1:%d/api/remote"%int(port),data=body,method="POST",
         headers={"Content-Type":"application/json","Content-Length":str(len(body))})
        with urllib.request.urlopen(req,timeout=6) as r:
            return json.loads(r.read().decode() or "{}")
    except Exception as e:
        return {"ok":False,"error":str(e)[:160]}
def main():
    seed()
    try:
        import delve_activity as ACT
        ACT.attach(broadcast)
    except Exception:pass
    threading.Thread(target=_prewarm,daemon=True).start()
    port=int(os.environ.get("DELVE_PORT","8788"))
    # ONE PORT. The phone used to get a second listener on its own port; the guard already
    # treats loopback as keyless and everything else as needing a pairing key, so the same
    # socket serves both. Bind wide only when phone access is actually on.
    want_remote=bool(HUB.cfg.get("remote_on")) or os.environ.get("DELVE_REMOTE_ON")=="1"
    srv,port=_listen(port,host=("0.0.0.0" if want_remote else "127.0.0.1"))
    if srv is not None:srv.braid_remote=want_remote
    url="http://127.0.0.1:"+str(port)
    if srv is None:
        print("Braid is already running  ->  "+url)
        print("[braid] not starting a second phone listener (that used to show a empty/demo room on the phone)")
        if os.environ.get("DELVE_REMOTE_ON")=="1" or HUB.cfg.get("remote_on"):
            r=_ask_running_remote_on(port)
            if r.get("url"):print("[braid] phone URL (live hub) ->  "+r.get("url"),flush=True)
            elif r.get("error"):print("[braid] could not enable remote on live hub: "+str(r.get("error")),flush=True)
        if not os.environ.get("DELVE_NO_OPEN"):
            try:
                import webbrowser;webbrowser.open(url)
            except Exception:pass
        return
    threading.Thread(target=autostart_adam,daemon=True).start()
    threading.Thread(target=_update_watch,daemon=True).start()
    print("Amni-Delve UI  ->  "+url+"   (Ctrl-C to stop)")
    if want_remote:
        try:
            import delve_remote as RM
            r=RM.adopt(port)
            HUB.cfg["remote_port"]=int(port);HUB.cfg["remote_on"]=True;delve.save_cfg(HUB.cfg)
            print("[braid] phone access on the same port %s"%port,flush=True)
            if r.get("url"):print("[braid] phone URL       ->  "+r.get("url"),flush=True)
        except Exception as e:print("[braid] remote adopt failed: %s"%e,flush=True)
    if not os.environ.get("DELVE_NO_OPEN"):
        try:
            import webbrowser;webbrowser.open(url)
        except Exception:pass
    try:srv.serve_forever()
    except KeyboardInterrupt:print("\nbye")
    finally:_finish_update_on_exit()
if __name__=="__main__":main()
