import os,time,difflib,subprocess,fnmatch,re
try:
    from delve_proc import run as _run,popen as _popen,check_output as _co
except Exception:
    from subprocess import run as _run,Popen as _popen,check_output as _co
try:import delve_activity as ACT
except Exception:ACT=None
def _act(by,kind,rel,note=""):
    """Braid's own write tool is the one source that knows both the seat AND the exact bytes,
    so it reports itself rather than waiting for the watcher to notice the mtime."""
    if ACT is None:return
    try:ACT.record(by,kind,rel,note,tool="braid")
    except Exception:pass
MAX_READ=2_000_000
SKIP=(".","__pycache__","node_modules","target",".git","venv")
MODES=("plan","edit","bypass")
LEGACY={"review":"edit","open":"bypass","plan":"plan"}
def canon_mode(m):
    m=str(m or "").strip().lower()
    return m if m in MODES else LEGACY.get(m,"")
CHANGES=[];PENDING=[];_SEQ=[0]
def _root(hub):return os.path.realpath(hub.cfg.get("workspace") or hub.work)
def _jail(hub,rel):
    root=_root(hub)
    p=os.path.realpath(os.path.join(root,str(rel or "").replace("\\","/").lstrip("/")))
    if p!=root and not p.startswith(root+os.sep):raise PermissionError("outside workspace")
    return p
def _rel(hub,p):
    r=os.path.relpath(p,_root(hub)).replace("\\","/")
    return "" if r=="." else r
def mode(hub):
    m=canon_mode(hub.cfg.get("code_mode"))
    return m or ("bypass" if hub.cfg.get("bypass",False) else "edit")
def ls(hub,rel=""):
    try:p=_jail(hub,rel)
    except PermissionError:return {"ok":False,"error":"outside workspace","code":403}
    if not os.path.isdir(p):return {"ok":False,"error":"not a directory"}
    dirs=[];files=[]
    try:
        for e in sorted(os.scandir(p),key=lambda x:x.name.lower()):
            if e.name.startswith(SKIP[0]) or e.name in SKIP:continue
            if e.is_dir():dirs.append(e.name)
            else:files.append({"name":e.name,"size":e.stat().st_size})
    except Exception as e:return {"ok":False,"error":str(e)[:160]}
    return {"ok":True,"path":_rel(hub,p),"dirs":dirs,"files":files,"root":_root(hub)}
def tree(hub,cap=3000):
    root=_root(hub);out=[]
    for base,ds,fs in os.walk(root):
        ds[:]=[d for d in ds if not (d.startswith(".") or d in SKIP)]
        for f in fs:
            if f.startswith("."):continue
            out.append(os.path.relpath(os.path.join(base,f),root).replace("\\","/"))
            if len(out)>=cap:return {"ok":True,"files":out,"truncated":True}
    return {"ok":True,"files":out,"truncated":False}
def read(hub,rel):
    try:p=_jail(hub,rel)
    except PermissionError:return {"ok":False,"error":"outside workspace","code":403}
    if not os.path.isfile(p):return {"ok":False,"error":"no such file"}
    raw=open(p,"rb").read(MAX_READ+1)
    if b"\x00" in raw[:8000]:return {"ok":False,"error":"binary file"}
    return {"ok":True,"path":str(rel).replace("\\","/"),"content":raw[:MAX_READ].decode("utf-8","replace"),"truncated":len(raw)>MAX_READ}
def _apply(hub,rel,content,by):
    p=_jail(hub,rel)
    before=open(p,encoding="utf-8",errors="replace").read() if os.path.isfile(p) else None
    d=os.path.dirname(p)
    if d:os.makedirs(d,exist_ok=True)
    with open(p,"w",encoding="utf-8",newline="") as f:f.write(content)
    CHANGES.append({"path":str(rel).replace("\\","/"),"before":before,"ts":time.time(),"by":by})
    _act(by,"write" if before is None else "edit",str(rel).replace("\\","/"),
     ("new file · " if before is None else "")+str(len(content))+" chars")
    return {"ok":True,"path":str(rel).replace("\\","/"),"applied":True,"changes":len(CHANGES)}
def write(hub,rel,content,by="you",emit=None):
    try:_jail(hub,rel)
    except PermissionError:return {"ok":False,"error":"outside workspace","code":403}
    m=mode(hub)
    if m=="plan":return {"ok":False,"error":"plan mode — nothing gets written; switch to Review or Open","mode":m}
    if m=="edit":
        _SEQ[0]+=1
        try:before=read(hub,rel).get("content")
        except Exception:before=None
        item={"id":_SEQ[0],"path":str(rel).replace("\\","/"),"before":before,"after":str(content),"by":by,"ts":time.time()}
        PENDING.append(item)
        _act(by,"queued",item["path"],"waiting for your approval")
        if emit:emit({"type":"approval","id":item["id"],"path":item["path"],"by":by,"pending":len(PENDING)})
        return {"ok":True,"queued":True,"id":item["id"],"pending":len(PENDING),"mode":m}
    return _apply(hub,rel,str(content),by)
def pending(hub):
    rows=[]
    for it in PENDING:
        d="\n".join(difflib.unified_diff((it["before"] or "").splitlines(),it["after"].splitlines(),"current","proposed",lineterm=""))
        rows.append({"id":it["id"],"path":it["path"],"by":it["by"],"ts":it["ts"],"diff":d[:20000]})
    return {"ok":True,"pending":rows,"mode":mode(hub),"changes":len(CHANGES)}
def approve(hub,pid,allow,emit=None):
    it=next((x for x in PENDING if x["id"]==int(pid)),None)
    if not it:return {"ok":False,"error":"no such pending change"}
    PENDING.remove(it)
    if not allow:_act(it["by"],"discarded",it["path"],"you turned this change down")
    r=_apply(hub,it["path"],it["after"],it["by"]) if allow else {"ok":True,"discarded":True,"path":it["path"]}
    if emit:emit({"type":"approval","resolved":it["id"],"allowed":bool(allow),"pending":len(PENDING)})
    r["pending"]=len(PENDING)
    return r
def undo(hub):
    n=0
    while CHANGES:
        ch=CHANGES.pop()
        try:p=_jail(hub,ch["path"])
        except PermissionError:continue
        if ch["before"] is None:
            if os.path.isfile(p):os.remove(p)
        else:
            with open(p,"w",encoding="utf-8",newline="") as f:f.write(ch["before"])
        n+=1
    return {"ok":True,"reverted":n}
def accept(hub):
    n=len(CHANGES);CHANGES.clear()
    return {"ok":True,"accepted":n}
def _matcher(q,regex,case):
    if regex:
        try:return re.compile(q,0 if case else re.I).search
        except re.error as e:raise ValueError("bad pattern: "+str(e)[:80])
    if case:
        return lambda s:q in s
    ql=q.lower()
    return lambda s:ql in s.lower()
def search(hub,q,cap=400,regex=False,case=False,glob="",files_only=False):
    """Every occurrence of anything: matches file NAMES and file CONTENTS, grouped by file.
    'get_' finds every file whose path contains get_ AND every line containing get_."""
    q=str(q or "").strip()
    if not q:return {"ok":False,"error":"empty query"}
    try:hit=_matcher(q,regex,case)
    except ValueError as e:return {"ok":False,"error":str(e)}
    root=_root(hub)
    gl=[x.strip() for x in str(glob or "").split(",") if x.strip()]
    files={};nameHits=[];scanned=0;lines=0;trunc=False
    for base,ds,fs in os.walk(root):
        ds[:]=[d for d in ds if not (d.startswith(".") or d in SKIP)]
        for f in sorted(fs):
            if f.startswith("."):continue
            fp=os.path.join(base,f)
            rel=os.path.relpath(fp,root).replace("\\","/")
            if gl and not any(fnmatch.fnmatch(rel,g) or fnmatch.fnmatch(f,g) for g in gl):continue
            inName=bool(hit(rel))
            if inName:nameHits.append(rel)
            if files_only:
                if inName:files.setdefault(rel,{"path":rel,"name":True,"hits":[],"n":0})
                continue
            rows=[]
            try:
                if os.path.getsize(fp)>1048576:
                    if inName:files.setdefault(rel,{"path":rel,"name":True,"hits":[],"n":0,"skipped":"too big to scan"})
                    continue
                raw=open(fp,"rb").read()
                if b"\x00" in raw[:8000]:
                    if inName:files.setdefault(rel,{"path":rel,"name":True,"hits":[],"n":0,"skipped":"binary"})
                    continue
                scanned+=1
                for i,line in enumerate(raw.decode("utf-8","replace").splitlines(),1):
                    if hit(line):
                        lines+=1
                        if len(rows)<40:rows.append({"line":i,"text":line.strip()[:220]})
                        else:trunc=True
            except Exception:continue
            if rows or inName:
                files.setdefault(rel,{"path":rel,"name":inName,"hits":[],"n":0})
                files[rel]["hits"]=rows;files[rel]["n"]=len(rows)+(1 if trunc and len(rows)>=40 else 0)
                files[rel]["name"]=inName
    out=sorted(files.values(),key=lambda x:(not x.get("name"),-x.get("n",0),x["path"]))
    flat=[]
    for fr in out:
        if fr.get("name") and not fr["hits"]:flat.append({"path":fr["path"],"line":0,"text":"(filename match)"})
        for hrow in fr["hits"]:
            flat.append({"path":fr["path"],"line":hrow["line"],"text":hrow["text"]})
            if len(flat)>=cap:
                return {"ok":True,"hits":flat,"files":out,"truncated":True,"scanned":scanned,
                        "matches":lines,"name_matches":len(nameHits),"query":q}
    return {"ok":True,"hits":flat,"files":out,"truncated":trunc,"scanned":scanned,
            "matches":lines,"name_matches":len(nameHits),"query":q}
GIT={"status":["status","--short","-b"],"log":["log","--oneline","-15"],"diff":["diff","--stat"],"diff_full":["diff"]}
# The workspace is user-chosen and agent-writable, and a repo's own .git/config can make git
# EXECUTE things: core.fsmonitor and core.pager are commands, and so is any alias. Running a
# read-only status inside a repo you did not write is therefore not read-only. These -c
# overrides come before the subcommand so nothing in the repo can win, and the environment
# drops system/global config and any credential prompt.
GIT_SAFE=["git","--no-pager","-c","core.fsmonitor=false","-c","core.pager=cat","-c","core.hooksPath=",
          "-c","core.sshCommand=","-c","protocol.ext.allow=never","-c","alias.=","--no-optional-locks"]
GIT_ENV={"GIT_CONFIG_NOSYSTEM":"1","GIT_CONFIG_GLOBAL":os.devnull,"GIT_TERMINAL_PROMPT":"0",
         "GIT_ASKPASS":"","GIT_OPTIONAL_LOCKS":"0"}
def git(hub,op):
    args=GIT.get(str(op or "").lower())
    if not args:return {"ok":False,"error":"unknown op (status|log|diff|diff_full)"}
    try:
        r=_run(GIT_SAFE+args,cwd=_root(hub),capture_output=True,text=True,encoding="utf-8",
         errors="replace",timeout=20,env={**os.environ,**GIT_ENV})
        return {"ok":r.returncode==0,"out":(r.stdout or r.stderr or "").strip()[:40000]}
    except Exception as e:return {"ok":False,"error":str(e)[:160]}
