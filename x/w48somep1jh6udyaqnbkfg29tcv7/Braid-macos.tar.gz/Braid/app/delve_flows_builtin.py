"""Flows that ship with Braid. Read-only; editing one saves your own copy.
Seats are declared by ROLE, not by vendor - `bind()` maps them onto whatever the
user actually has connected, so a built-in flow works for someone running Codex
and Copilot exactly as well as for someone running Claude and Gemini."""
PREFIX="builtin:"
BUILTIN=[
{"id":PREFIX+"roundtable","label":"Parallel roundtable (all at once)","kind":"graph","v":1,
 "goal":"Every seat answers the same question independently and in parallel, then the round starts again.",
 "start_prompt":("Every seat at this table answers the user DIRECTLY and INDEPENDENTLY. You are not reviewing "
  "anyone and you are not handing off - the others are answering the same question at the same moment and you "
  "cannot see their work this round. Give your own best answer in full: your reasoning, your numbers, your "
  "recommendation. Do not wait for anyone, do not defer to anyone, and do not describe what you are about to do "
  "- do it. If a later round shows you what the others said, use it to make your next answer stronger."),
 "end_prompt":"","end_mode":"infinite","rounds":3,"judge":"","max_visits":80,"memory":True,"memory_k":3,
 "async":True,"start_node":"n1","start_nodes":["n1"],
 "nodes":[
  {"id":"n1","slot":"*","role":"Independent answer","x":120,"y":90,
   "brief":"Answer the user's question yourself, completely, as if you were the only seat here. State your reasoning and commit to a position. You cannot see the other seats this round - that is deliberate, so give your own best shot rather than a reaction to anyone."}],
 "edges":[]},
{"id":PREFIX+"analytic","label":"Braid Analytic Round","kind":"graph","v":1,
 "goal":"Derive and stress-test a closed-form mathematical framework for the problem at hand, using classical algebraic manipulation first and numerics only where symbolic treatment genuinely fails.",
 "start_prompt":("This table is doing engineering and mathematical/scientific analysis. Work in classical notation first: "
  "define symbols, state assumptions and domains, derive by algebraic and analytic manipulation, carry units and "
  "limiting cases. Reach for code-based numerics ONLY when a closed form is unavailable or must be checked, and say "
  "plainly which it is. Every seat here is a peer — no seat reports to another, no seat defers to another. Be "
  "adversarial about the mathematics and cooperative about the goal: attack derivations, not people, and hand back a "
  "repair with every objection. When another seat exposes a flaw in your work, absorb it and make your next pass "
  "stronger. Teach as you go — show the step, not just the result."),
 "end_prompt":"","end_mode":"goal","rounds":3,"judge":"n4","max_visits":60,"memory":True,"memory_k":3,
 "start_node":"n1",
 "nodes":[
  {"id":"n1","slot":"lead","role":"Lead framework architect","x":330,"y":60,
   "brief":"Open by stating the problem in formal terms: variables, governing relations, assumptions, boundary and limiting conditions. Derive the candidate framework symbolically and hand over the full derivation chain with every step exposed so the others can attack it line by line."},
  {"id":"n2","slot":"critic","role":"Adversarial derivation auditor","x":330,"y":195,
   "brief":"Attack the derivation where it is weakest: hidden assumptions, illegal manipulations, dimensional inconsistency, degenerate or singular cases, and regimes where the result breaks. For every objection you raise, supply a corrected line or an alternative route rather than only a verdict."},
  {"id":"n3","slot":"second","role":"Independent formalism and validation","x":330,"y":330,
   "brief":"Re-derive the result by a genuinely different route and say where the two agree and where they diverge. Check limiting cases and units independently. Where a closed form is impossible, run the numerics and state the error bound."},
  {"id":"n4","slot":"director","role":"Gathered director and scorer","gather":True,"x":330,"y":465,
   "brief":"Read the whole cycle as one piece of work. Reconcile the routes, rule on what is settled and what is still open, name the ONE thing the next lap must fix, and direct the seats by name."}],
 "edges":[
  {"id":"e1","from":"n1","to":"n2","label":"the symbolic derivation, its assumptions, and the exact steps you least trust","cond":""},
  {"id":"e2","from":"n2","to":"n3","label":"the surviving derivation plus every objection and your proposed repair","cond":""},
  {"id":"e3","from":"n3","to":"n4","label":"your independent re-derivation, where the two routes agree or diverge, and the numbers","cond":""},
  {"id":"e4","from":"n4","to":"n1","label":"the reconciled ruling and the open question to attack next","cond":""},
  {"id":"e5","from":"n2","to":"n1","label":"a fatal flaw that invalidates the framework before further work is worth doing","cond":"FATAL"}]},

{"id":PREFIX+"draft","label":"Draft & Edit","kind":"graph","v":1,
 "goal":"Turn a rough idea into a finished piece the writer would actually put their name on.",
 "start_prompt":("This table is writing, not analysing. Keep the writer's voice - you are sharpening their piece, not "
  "replacing it with yours. Prefer the concrete noun over the abstract one, cut what does not earn its place, and "
  "never pad to look thorough. Quote the line you are changing and say why. If the piece has a reader in mind, keep "
  "them in mind."),
 "end_prompt":"","end_mode":"goal","rounds":3,"judge":"n3","max_visits":40,"memory":True,"memory_k":3,
 "start_node":"n1",
 "nodes":[
  {"id":"n1","slot":"lead","role":"Drafter","x":250,"y":70,
   "brief":"Write the piece. Commit to a shape and a voice rather than hedging across three options. Mark anywhere you were guessing at facts the writer has not given you."},
  {"id":"n2","slot":"critic","role":"Line editor","x":460,"y":70,
   "brief":"Edit line by line. Cut flab, fix rhythm, kill cliche and repetition, and flag any claim that needs a source. Quote the original line beside your change so the writer can refuse it."},
  {"id":"n3","slot":"director","role":"Reader's advocate","gather":True,"x":355,"y":215,
   "brief":"Read the whole thing cold, as the intended reader. Say what landed, what confused you, and the ONE change that would most improve it. Do not rewrite - direct."}],
 "edges":[
  {"id":"e1","from":"n1","to":"n2","label":"the draft, and the parts you are least sure of","cond":""},
  {"id":"e2","from":"n2","to":"n3","label":"the edited draft and what you changed","cond":""},
  {"id":"e3","from":"n3","to":"n1","label":"what to fix on the next pass","cond":""}]},

{"id":PREFIX+"build","label":"Build & Review","kind":"graph","v":1,
 "goal":"Ship a working change: written, reviewed, and actually run before anyone calls it done.",
 "start_prompt":("This table is writing code that has to run. Read the surrounding code before you add to it and match "
  "its conventions. Small, reviewable changes beat sweeping rewrites. NOTHING is 'done' on the strength of an "
  "assertion - say exactly what you ran and paste what it printed. If you could not run it, say so plainly rather "
  "than implying success."),
 "end_prompt":"","end_mode":"goal","rounds":4,"judge":"n3","max_visits":60,"memory":True,"memory_k":3,
 "start_node":"n1",
 "nodes":[
  {"id":"n1","slot":"lead","role":"Implementer","x":250,"y":70,
   "brief":"Make the change. Read the existing code first and follow its idiom. Keep the diff small and say what you actually ran to check it."},
  {"id":"n2","slot":"critic","role":"Reviewer","x":460,"y":70,
   "brief":"Review the change as if it were about to ship. Hunt for the failure the author did not consider: edge cases, error paths, concurrency, and anything that silently does nothing. Give the repro, not just the worry."},
  {"id":"n3","slot":"director","role":"Verifier","gather":True,"x":355,"y":215,
   "brief":"Read the change and the review together. Decide whether this is genuinely verified or merely asserted, and if it is only asserted, say what has to be run before it ships."}],
 "edges":[
  {"id":"e1","from":"n1","to":"n2","label":"the change, what you ran, and what it printed","cond":""},
  {"id":"e2","from":"n2","to":"n3","label":"the findings, each with a repro","cond":""},
  {"id":"e3","from":"n3","to":"n1","label":"what still has to be fixed or proven","cond":""}]},

{"id":PREFIX+"ideas","label":"Ideas & Options","kind":"graph","v":1,
 "goal":"Put real options on the table, weigh them honestly, and come back with a recommendation you can act on.",
 "start_prompt":("This table is helping someone decide something. Generate options that are genuinely different from "
  "each other, not three shades of the same one. Say what each would cost - money, time, effort, risk - and be "
  "honest about the one you like least. End with a recommendation, not a menu. Plain language: no strategy-deck "
  "vocabulary."),
 "end_prompt":"","end_mode":"rounds","rounds":2,"judge":"n3","max_visits":30,"memory":True,"memory_k":3,
 "start_node":"n1",
 "nodes":[
  {"id":"n1","slot":"lead","role":"Options","x":250,"y":70,
   "brief":"Put three genuinely different options on the table, each with what it would actually take and who it suits. No filler option that exists only to make another look good."},
  {"id":"n2","slot":"critic","role":"Devil's advocate","x":460,"y":70,
   "brief":"Take each option apart: what goes wrong, what it costs that nobody mentioned, and who would regret it. Then say which one survives best."},
  {"id":"n3","slot":"director","role":"Recommendation","gather":True,"x":355,"y":215,
   "brief":"Read both and give a straight recommendation with the reason in one sentence, plus the first thing to do about it. Say what would change your mind."}],
 "edges":[
  {"id":"e1","from":"n1","to":"n2","label":"the options and what each really costs","cond":""},
  {"id":"e2","from":"n2","to":"n3","label":"what survives and what does not","cond":""},
  {"id":"e3","from":"n3","to":"n1","label":"the angle still missing","cond":""}]},
]
SLOT_ORDER=("lead","critic","second","director")
def _pick(slot,avail,used):
    """Give each declared slot a real seat. Slots keep their declared order so the
    same flow reads the same way every time, and the local seat takes the director
    chair when it exists - it is free, and the director reads rather than derives."""
    if not avail:return ""
    if slot=="director" and "Adam" in avail and len(avail)>1:return "Adam"
    paid=[a for a in avail if a!="Adam"] or list(avail)
    i=SLOT_ORDER.index(slot) if slot in SLOT_ORDER else len(used)
    return paid[i%len(paid)]
def bind(g,avail):
    """Map a built-in's role slots onto the seats this user actually has.

    A node with slot "*" is a TEMPLATE, not a seat: it expands to one node per connected seat.
    A parallel roundtable is "every seat you have, at once" - it cannot be written as a fixed
    number of nodes without either leaving seats out or inventing ones that are not there."""
    g=dict(g);avail=[a for a in (avail or []) if a] or ["Claude"]
    nodes=[];used=[];expand={}
    for n in g.get("nodes") or []:
        n=dict(n)
        if n.get("slot")=="*":
            made=[]
            for i,seat in enumerate(avail):
                m=dict(n);m["id"]=n["id"]+("" if i==0 else "_"+str(i+1))
                m["agent"]=seat;m["slot"]="rival";m["y"]=int(n.get("y") or 60)
                m["x"]=int(n.get("x") or 120)+i*210
                nodes.append(m);used.append(seat);made.append(m["id"])
            expand[n["id"]]=made
            continue
        a=n.get("agent")
        if a not in avail:a=_pick(n.get("slot"),avail,used)
        n["agent"]=a;used.append(a)
        nodes.append(n)
    g["nodes"]=nodes
    edges=[]
    for e in (g.get("edges") or []):
        for f in expand.get(e.get("from"),[e.get("from")]):
            for t in expand.get(e.get("to"),[e.get("to")]):
                if f==t and e.get("from")!=e.get("to"):continue
                d=dict(e);d["from"]=f;d["to"]=t;d["id"]="e"+str(len(edges)+1);edges.append(d)
    g["edges"]=edges
    if expand:
        sn=[]
        for x in (g.get("start_nodes") or []):sn.extend(expand.get(x,[x]))
        if sn:g["start_nodes"]=list(dict.fromkeys(sn))
        if g.get("start_node") in expand:g["start_node"]=expand[g["start_node"]][0]
    return g
def is_builtin(fid):return str(fid or "").startswith(PREFIX)
def get(fid,avail=None):
    for g in BUILTIN:
        if g["id"]==fid:return bind(g,avail) if avail else dict(g)
    return None
def listing(avail=None):
    """`seats` is the order the flow actually SPEAKS in, not the order the nodes happen to be
    stored in - the room paints this, so it has to be the executed order or the ribbon lies."""
    import delve_graph as GR
    out=[]
    for g in BUILTIN:
        b=bind(g,avail) if avail else g
        # Count the BOUND graph. A "*" template is one stored node and N real seats, so the
        # unbound count told the flow list a seven-seat roundtable had one node in it.
        out.append({"id":g["id"],"label":g["label"],"nodes":len(b["nodes"]),"edges":len(b["edges"]),
         "end_mode":g["end_mode"],"goal":(g.get("goal") or "")[:160],"saved":0,"builtin":True,
         "seats":GR.seat_order(b),"order":GR.visit_order(b),
         "breaks":len([n for n in b["nodes"] if n.get("gather")])})
    return out
