import json,re
import delve_graph as GR
ALIAS={"gemini":"Google","google":"Google","bard":"Google","antigravity":"Google","agy":"Google",
 "claude":"Claude","anthropic":"Claude","sonnet":"Claude","opus":"Claude","haiku":"Claude",
 "grok":"Grok","xai":"Grok","x.ai":"Grok",
 "adam":"Adam","local":"Adam","amni":"Adam","ptex":"Adam",
 "openai":"OpenAI","gpt":"OpenAI","chatgpt":"OpenAI","codex":"OpenAI","o3":"OpenAI",
 "copilot":"Copilot","github":"Copilot",
 "cursor":"Cursor","cursor-agent":"Cursor",
 "opencode":"OpenCode","open code":"OpenCode"}
def _seat(name,avail):
    t=re.sub(r'[^a-z0-9. ]','',str(name or "").strip().lower())
    if not t:return ""
    for k in (t,t.split()[0] if t.split() else ""):
        if k in ALIAS and ALIAS[k] in avail:return ALIAS[k]
    for a in avail:
        if a.lower() in t or t in a.lower():return a
    for k,v in ALIAS.items():
        if k in t and v in avail:return v
    return ""
def brief_for(avail,seat_notes=None):
    notes=seat_notes or {}
    rows="\n".join("  - "+a+(" — "+notes[a] if notes.get(a) else "") for a in avail)
    return ("You are laying out a MULTI-AGENT WORK FLOW for Braid, a round table where several AI seats hand work "
     "to each other. Return ONE JSON object and NOTHING else — no prose, no markdown fence, no commentary.\n\n"
     "SEATS YOU MAY USE (these are the only ones this user actually has connected — do not invent others):\n"+rows+"\n\n"
     "SHAPE:\n"
     "{\n"
     '  "label": short name for the flow,\n'
     '  "goal": one sentence — what the whole graph is working toward,\n'
     '  "start_prompt": standing background every seat should hold (NOT a question),\n'
     '  "end_mode": "rounds" | "goal" | "success" | "infinite",\n'
     '  "rounds": integer laps when end_mode is "rounds" (2-5 is usual),\n'
     '  "nodes": [ {"id":"n1","agent":"<one of the seats above>","role":"3-5 words",\n'
     '              "brief":"one or two sentences telling THIS seat what its job is",\n'
     '              "gather": true only for a review seat that must act alone} ],\n'
     '  "edges": [ {"from":"n1","to":"n2","label":"what n1 hands n2","cond":""} ],\n'
     '  "start_node": id of the single seat that opens a RELAY flow,\n'
     '  "start_nodes": [ids] - the seats that open TOGETHER, for a concurrent flow,\n'
     '  "async": true - every seat in a wave answers at the same time, blind to the others,\n'
     '  "judge": id of the seat that rules on whether the goal is met (optional)\n'
     "}\n\n"
     "RULES THAT MATTER:\n"
     "- 2 to 6 nodes. Every node needs a real role and a real brief — no filler seats.\n"
     "- Edges are HANDOFFS. The label says what is passed, e.g. \"the failing test and your diagnosis\".\n"
     "- Give the graph a cycle so work can iterate: something should lead back toward the start.\n"
     "\n"
     "SEQUENTIAL OR CONCURRENT - READ THE REQUEST AND PICK ONE:\n"
     "- The DEFAULT is a relay: one start_node, and each seat reads what the seat before it said.\n"
     "- If the user asks for the seats to work AT THE SAME TIME, INDEPENDENTLY, IN PARALLEL, "
     "CONCURRENTLY, BLIND TO EACH OTHER, as RIVALS, as a RACE, each giving their OWN or BEST "
     "SHOT, or 'all at once', then it is NOT a relay and a chain is the WRONG answer. Set "
     '"async": true AND list every one of those seats in "start_nodes". A chain like '
     "n1->n2->n3->n1 makes each seat read the one before it, which is the exact opposite of "
     "working independently.\n"
     '- Under "async" the seats in a wave are rendered from the SAME point in the transcript, so '
     "they genuinely cannot see each other's answer that wave. That is what makes it independent.\n"
     "- For 'every seat answers at once, then the round restarts when they are all done': put "
     'EVERY seat in "start_nodes", set "async": true, give each seat one edge back to the '
     'opening so the next lap begins when the wave ends, and use end_mode "infinite" (or '
     '"rounds" with a number if they asked for a set number of laps).\n'
     "- A concurrent wave needs NO edges between the seats inside it. An edge between two rivals "
     "is a handoff, and a handoff makes the second one read the first.\n"
     '- A node with "gather": true is a REVIEW BREAK. Everyone else stops, every reply from that cycle is '
     "collected into ONE report, and this seat reads it alone and rules. Use one for a director, judge, "
     "editor or QA seat — it is what makes review independent instead of a reaction to whoever spoke last.\n"
     '- "cond" is optional; when set, that edge is only followed if the reply contains that text.\n'
     "- Play to each seat's strengths, but never assign a seat that is not in the list above.\n"
     "- If end_mode is \"goal\" or \"success\", set a judge.\n")
def _rows(v):
    return v if isinstance(v,list) else []
def _json_from(text):
    t=(text or "").strip()
    m=re.search(r'```(?:json)?\s*(.+?)```',t,re.S)
    if m:t=m.group(1).strip()
    i=t.find("{");j=t.rfind("}")
    if i<0 or j<i:return None
    frag=t[i:j+1]
    for cand in (frag,re.sub(r',\s*([}\]])',r'\1',frag)):
        try:return json.loads(cand)
        except Exception:pass
    return None
def layout(nodes,edges,start):
    idx={n["id"]:n for n in nodes}
    out={}
    for e in edges:out.setdefault(e.get("from"),[]).append(e.get("to"))
    depth={};seen=set();level=[start] if start in idx else ([nodes[0]["id"]] if nodes else [])
    d=0
    while level and d<12:
        nxt=[]
        for nid in level:
            if nid in seen or nid not in idx:continue
            seen.add(nid);depth[nid]=d
            for t in out.get(nid,[]):
                if t not in seen:nxt.append(t)
        level=list(dict.fromkeys(nxt));d+=1
    for n in nodes:
        if n["id"] not in depth:depth[n["id"]]=d;d+=0
    rows={}
    for n in nodes:rows.setdefault(depth[n["id"]],[]).append(n)
    for lvl,group in rows.items():
        span=(len(group)-1)*210
        for i,n in enumerate(group):
            n["x"]=int(330-span/2+i*210);n["y"]=int(60+lvl*135)
    return nodes
def normalize(raw,avail):
    warn=[]
    if not isinstance(raw,dict):return None,["the model did not return a flow object"]
    g=GR.blank()
    g["label"]=str(raw.get("label") or "Generated flow")[:120]
    g["goal"]=str(raw.get("goal") or "")[:1200]
    g["start_prompt"]=str(raw.get("start_prompt") or "")[:2000]
    g["end_prompt"]=str(raw.get("end_prompt") or "")[:2000]
    mode=str(raw.get("end_mode") or "rounds").strip().lower()
    g["end_mode"]=mode if mode in GR.END_MODES else "rounds"
    try:g["rounds"]=max(1,min(50,int(raw.get("rounds") or 3)))
    except Exception:g["rounds"]=3
    src=_rows(raw.get("nodes"))
    if not src:return None,["the model returned no seats"]
    nodes=[];remap={};used=set()
    for i,n in enumerate(src[:8]):
        if not isinstance(n,dict):continue
        nid="n"+str(len(nodes)+1)
        old=str(n.get("id") or n.get("name") or ("#"+str(i)))
        remap[old]=nid;remap[str(i)]=nid;remap[str(i+1)]=nid
        want=n.get("agent") or n.get("seat") or n.get("model") or ""
        a=_seat(want,avail)
        if not a:
            a=avail[len(nodes)%len(avail)]
            if want:warn.append('"'+str(want)[:24]+'" is not connected here — that seat is '+a+" instead")
        nodes.append({"id":nid,"agent":a,"role":str(n.get("role") or "")[:60],
         "brief":str(n.get("brief") or n.get("task") or "")[:600],
         "gather":bool(n.get("gather") or n.get("review_break") or n.get("review")),
         "x":0,"y":0})
        used.add(a)
        if n.get("review_after"):
            try:nodes[-1]["review_after"]=max(0,min(12,int(n["review_after"])))
            except Exception:pass
    if not nodes:return None,["the model returned no usable seats"]
    ids={n["id"] for n in nodes}
    def ref(v):
        k=str(v if v is not None else "")
        return remap.get(k) or (k if k in ids else "")
    edges=[];seen=set()
    for e in _rows(raw.get("edges")):
        if not isinstance(e,dict):continue
        f=ref(e.get("from") or e.get("source"));t=ref(e.get("to") or e.get("target"))
        if not f or not t:continue
        key=(f,t,str(e.get("label") or "")[:40])
        if key in seen:continue
        seen.add(key)
        edges.append({"id":"e"+str(len(edges)+1),"from":f,"to":t,
         "label":str(e.get("label") or "")[:160],"cond":str(e.get("cond") or "")[:80]})
    if not edges and len(nodes)>1:
        warn.append("the model gave no handoffs — chained the seats in order so the flow still runs")
        for i in range(len(nodes)-1):
            edges.append({"id":"e"+str(i+1),"from":nodes[i]["id"],"to":nodes[i+1]["id"],"label":"","cond":""})
        edges.append({"id":"e"+str(len(edges)+1),"from":nodes[-1]["id"],"to":nodes[0]["id"],"label":"another pass","cond":""})
    g["start_node"]=ref(raw.get("start_node")) or nodes[0]["id"]
    """Concurrency survives the normaliser.

    This function used to build the graph key by key and simply never copy `async` or
    `start_nodes`, so a model that correctly answered "these five work at once" had its answer
    thrown away here and the user got a relay. Teaching the prompt about concurrency without
    this is a no-op."""
    g["async"]=bool(raw.get("async") or raw.get("concurrent") or raw.get("parallel") or raw.get("independent"))
    sn=[x for x in (ref(v) for v in _rows(raw.get("start_nodes") or raw.get("start"))) if x]
    g["start_nodes"]=list(dict.fromkeys(sn))
    if g["async"] and len(g["start_nodes"])<2:
        # Asked for independence but named one opener (or none): the seats that nothing hands
        # to are the ones that can honestly start together.
        tgt={e["to"] for e in edges}
        roots=[n["id"] for n in nodes if n["id"] not in tgt] or [n["id"] for n in nodes]
        g["start_nodes"]=roots
        warn.append("made "+str(len(roots))+" seats open together — concurrent was asked for but only one opener was named")
    if g["async"] and len(g["start_nodes"])>1:
        # An edge BETWEEN two seats of the opening wave is a handoff, and a handoff is exactly
        # what independence is not. Drop those; keep the ones that carry the lap forward.
        opens=set(g["start_nodes"])
        keep=[e for e in edges if not (e["from"] in opens and e["to"] in opens)]
        if len(keep)!=len(edges):
            warn.append("dropped "+str(len(edges)-len(keep))+" handoff(s) between seats that are supposed to answer independently")
            edges=keep
            for i,e in enumerate(edges):e["id"]="e"+str(i+1)
        if g["start_nodes"]:g["start_node"]=g["start_nodes"][0]
    j=ref(raw.get("judge"))
    g["judge"]=j if j else ""
    if g["end_mode"] in ("goal","success") and not g["judge"]:
        gath=[n["id"] for n in nodes if n.get("gather")]
        g["judge"]=gath[0] if gath else nodes[-1]["id"]
        warn.append("no judge was named — "+(GR._who({n["id"]:n for n in nodes},g["judge"]))+" rules")
    g["nodes"]=layout(nodes,edges,g["start_node"]);g["edges"]=edges
    if len(used)<2 and len(avail)>1:
        warn.append("every seat in this flow is "+list(used)[0]+" — you may want to spread the work")
    return g,warn
def author(hub,description,seat="",notes=None):
    desc=(description or "").strip()
    if not desc:return {"ok":False,"error":"describe the flow you want first"}
    avail=hub.seats_available()
    live=[a for a in hub.live_roster()] or avail
    pick=seat if seat in avail else ""
    if not pick:
        pick=next((a for a in live if a!="Adam"),live[0] if live else "")
    if not pick:return {"ok":False,"error":"no seat is connected to build the flow with"}
    prompt=brief_for(avail,notes)+"\nWHAT THE USER WANTS:\n"+desc[:4000]+"\n\nReturn the JSON object now."
    order=[pick]+[a for a in live if a!=pick and a!="Adam"]+[a for a in live if a!=pick and a=="Adam"]
    r="";tried=[]
    for who in order[:3]:
        hub.abort.clear()
        try:reply=hub.oneshot(who,prompt)
        except Exception as e:reply="["+who.lower()+" error] "+str(e)[:200]
        r=(reply or "").strip();pick=who;tried.append(who)
        if r and not r.startswith("["):break
    if not r or r.startswith("["):
        return {"ok":False,"error":(r[:200] or (pick+" returned nothing"))+
         (" — tried "+", ".join(tried) if len(tried)>1 else ""),"by":pick}
    raw=_json_from(r)
    if raw is None:
        return {"ok":False,"error":pick+" did not return usable JSON — try again, or describe it more concretely","by":pick,"raw":r[:1500]}
    g,warn=normalize(raw,avail)
    if g is None:
        return {"ok":False,"error":"; ".join(warn) or "the flow came back empty","by":pick,"raw":r[:1500]}
    errs,gwarn=GR.validate(g)
    return {"ok":not errs,"flow":g,"errors":errs,"warnings":warn+gwarn,"by":pick,
     "error":("; ".join(errs) if errs else "")}
