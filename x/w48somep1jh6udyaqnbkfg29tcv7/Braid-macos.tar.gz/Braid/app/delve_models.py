import json,os,re,subprocess,time,shutil
try:
 from delve_proc import run as _run,popen as _popen,check_output as _co
except Exception:
 from subprocess import run as _run,Popen as _popen,check_output as _co
ROOT=os.path.dirname(os.path.abspath(__file__))
CACHE=os.path.join(ROOT,"models_live_cache.json")
TTL=3600
EFFORT={
 "Claude":{"flag":"--effort","levels":["","low","medium","high","xhigh","max"],"default":"medium","hint":"claude --effort"},
 "Grok":{"flag":"--effort","levels":["","low","medium","high"],"default":"medium","hint":"grok --effort / --reasoning-effort"},
 "Google":{"flag":"--effort","levels":["","low","medium","high"],"default":"medium","hint":"agy --effort"},
 "OpenAI":{"flag":"codex_c","levels":["","low","medium","high","xhigh"],"default":"medium","hint":"codex -c model_reasoning_effort=…"},
 "Copilot":{"flag":"--effort","levels":["","none","minimal","low","medium","high","xhigh","max"],"default":"medium","hint":"copilot --effort"},
 "Cursor":{"flag":"cursor_param","levels":["","low","medium","high"],"default":"medium","hint":"model[effort=…]"},
 "OpenCode":{"flag":"","levels":[""],"default":"","hint":"no effort flag"},
 "Adam":{"flag":"","levels":[""],"default":"","hint":"use model light/heavy"}}
OPENAI_FALLBACK=[
 {"id":"gpt-5.6-terra","label":"GPT-5.6 terra"},{"id":"gpt-5.4","label":"GPT-5.4"},
 {"id":"gpt-5.2","label":"GPT-5.2"},{"id":"gpt-5.2-mini","label":"GPT-5.2 mini"}]
COPILOT_FALLBACK=[
 {"id":"auto","label":"auto"},{"id":"gpt-5.4","label":"GPT-5.4"},{"id":"gpt-5.2","label":"GPT-5.2"},
 {"id":"claude-sonnet-5","label":"Claude Sonnet 5"},{"id":"claude-opus-5","label":"Claude Opus 5"},
 {"id":"gemini-3.1-pro","label":"Gemini 3.1 Pro"}]
CURSOR_FALLBACK=[
 {"id":"gpt-5.2","label":"gpt-5.2"},{"id":"sonnet-5","label":"sonnet-5"},
 {"id":"gemini-3.1-pro","label":"gemini-3.1-pro"},{"id":"claude-opus-5","label":"claude-opus-5"}]
def _read(p,d=None):
 try:return json.load(open(p,encoding="utf-8"))
 except Exception:return d if d is not None else {}
def _write(p,obj):
 try:
  with open(p,"w",encoding="utf-8") as f:json.dump(obj,f)
 except Exception:pass
def _cache_get(key,ttl=TTL):
 c=_read(CACHE,{})
 row=c.get(key) or {}
 if row.get("models") and (time.time()-float(row.get("t") or 0))<ttl:return _prune(list(row["models"]))
 return None
def _cache_set(key,models):
 c=_read(CACHE,{})
 c[key]={"t":time.time(),"models":list(models)};_write(CACHE,c)
def _prune(models):
 import delve_usage as _U
 return _U.prune(models)
def _merge(primary,fallback):
 out=[];seen=set()
 for m in (primary or [])+(fallback or []):
  mid=(m.get("id") if isinstance(m,dict) else str(m) or "").strip()
  if not mid or mid in seen:continue
  seen.add(mid)
  out.append(m if isinstance(m,dict) else {"id":mid,"label":mid})
 return out
def _run_lines(cmd,timeout=8):
 try:
  r=_run(cmd,capture_output=True,text=True,timeout=timeout,encoding="utf-8",errors="replace")
  return (r.stdout or "")+(r.stderr or "")
 except Exception:return ""
def _parse_star_models(text):
 out=[];seen=set()
 for line in (text or "").splitlines():
  s=line.strip()
  if not s:continue
  if s.startswith("*") or s.startswith("-") or s.startswith("•"):
   mid=s.lstrip("*-• ").split()[0].strip("(),")
  elif re.match(r"^[A-Za-z0-9][A-Za-z0-9._:/\-\[\]=,+]*$",s.split()[0] if s.split() else ""):
   mid=s.split()[0]
  else:continue
  if mid.lower() in ("available","models:","model","default","id","name"):continue
  if mid and mid not in seen:out.append({"id":mid,"label":mid,"hint":"live"});seen.add(mid)
 return out
MD_URL="https://models.dev/api.json"
MD_TTL=86400
# Bumped when the KEPT SHAPE changes. v1 dropped limit.context, so a cache written by it has
# no window to read and every seat would fall back to the default forever - the TTL alone does
# not express "this row is the wrong shape".
MD_KEY="_modelsdev2"
_MD_SKIP=("image","video","audio","tts","whisper","embed","moderation","realtime","transcribe","imagine","search","robotic","live","native")
def _modelsdev(fast=False):
 """models.dev - public cross-provider registry, the same feed opencode uses. One fetch a
 day; every seat list gets provider-current ids instead of a hand-kept snapshot."""
 c=_read(CACHE,{});row=c.get(MD_KEY) or {}
 if row.get("data") and (time.time()-float(row.get("t") or 0))<MD_TTL:return row["data"]
 if fast:return row.get("data") or {}
 try:
  import urllib.request
  raw=json.loads(urllib.request.urlopen(urllib.request.Request(MD_URL,headers={"User-Agent":"Braid/3.7"}),timeout=12).read().decode("utf-8"))
 except Exception:
  return row.get("data") or {}
 keep={}
 for prov in ("openai","google","anthropic","xai","github-copilot"):
  ms=(raw.get(prov) or {}).get("models") or {}
  rows=[]
  for mid,meta in ms.items():
   lid=str(mid).lower()
   if any(t in lid for t in _MD_SKIP):continue
   lim=(meta or {}).get("limit") or {}
   try:ctx=int(lim.get("context") or 0)
   except Exception:ctx=0
   rows.append({"id":mid,"label":(meta or {}).get("name") or mid,"ctx":ctx,
    "hint":"provider · "+str((meta or {}).get("release_date") or ""),"rd":str((meta or {}).get("release_date") or "")})
  rows.sort(key=lambda m:m.get("rd") or "",reverse=True)
  keep[prov]=[{k:v for k,v in m.items() if k!="rd"} for m in rows[:14]]
 c[MD_KEY]={"t":time.time(),"data":keep};_write(CACHE,c)
 return keep
def modelsdev_list(provider,fast=False):
 return _prune(list((_modelsdev(fast=fast) or {}).get(provider) or []))
def openai_models(fast=False):
 hit=_cache_get("OpenAI")
 if hit is not None:return hit
 out=[]
 cfg=os.path.expanduser("~/.codex/config.toml")
 if os.path.isfile(cfg):
  try:
   raw=open(cfg,encoding="utf-8").read()
   m=re.search(r'^\s*model\s*=\s*["\']([^"\']+)["\']',raw,re.M)
   if m:out.append({"id":m.group(1),"label":m.group(1)+" · config","hint":"~/.codex/config.toml"})
  except Exception:pass
 if not fast:
  for cmd in (["codex","models"],["codex","--help"]):
   t=_run_lines(cmd,6)
   if "Available" in t or "*" in t:out.extend(_parse_star_models(t));break
 sess=os.path.expanduser("~/.codex/sessions")
 if os.path.isdir(sess):
  try:
   files=sorted([os.path.join(sess,f) for f in os.listdir(sess) if f.endswith((".json",".jsonl"))],key=os.path.getmtime,reverse=True)[:8]
   seen={m["id"] for m in out}
   for p in files:
    try:
     raw=open(p,encoding="utf-8",errors="replace").read(8000)
     for mid in re.findall(r'"model"\s*:\s*"([^"]+)"',raw):
      if mid and mid not in seen:out.append({"id":mid,"label":mid,"hint":"recent session"});seen.add(mid)
    except Exception:pass
  except Exception:pass
 md=modelsdev_list("openai",fast=fast)
 out=_merge(md,out) if md else (out if len(out)>=2 else _merge(out,[dict(m,hint="offline list") for m in OPENAI_FALLBACK]))
 out=_prune(out);_cache_set("OpenAI",out);return out
def copilot_models(fast=False):
 hit=_cache_get("Copilot")
 if hit is not None:return hit
 out=[]
 if not fast:
  which=shutil.which("copilot")
  if which:
   t=_run_lines([which,"--help"],5)
   for m in re.findall(r'copilot --model ([A-Za-z0-9._:\-]+)',t):
    out.append({"id":m,"label":m,"hint":"help example"})
 md=modelsdev_list("github-copilot",fast=fast)
 out=_merge(out,md) if md else (out if len(out)>=2 else _merge(out,[dict(m,hint="offline list") for m in COPILOT_FALLBACK]))
 out=_prune(out);_cache_set("Copilot",out);return out
def cursor_models(fast=False):
 hit=_cache_get("Cursor")
 if hit is not None:return hit
 out=[]
 if not fast:
  which=shutil.which("cursor-agent") or shutil.which("agent")
  if which:
   t=_run_lines([which,"--list-models"],10)
   if t and "Authentication" not in t and "Error" not in t[:80]:
    out=_parse_star_models(t)
    if not out:
     for line in t.splitlines():
      mid=line.strip().split()[0] if line.strip() else ""
      if mid and re.match(r"^[A-Za-z0-9]",mid) and "login" not in mid.lower():
       out.append({"id":mid,"label":mid,"hint":"list-models"})
 if len(out)<2:
  md=_merge(modelsdev_list("anthropic",fast=fast)[:4],modelsdev_list("openai",fast=fast)[:4])
  out=_merge(out,md) if md else _merge(out,[dict(m,hint="offline list") for m in CURSOR_FALLBACK])
 out=_prune(out);_cache_set("Cursor",out);return out
def opencode_models(fast=False):
 hit=_cache_get("OpenCode")
 if hit is not None:return hit
 out=[{"id":"","label":"(CLI default)"}]
 which=shutil.which("opencode")
 if which and not fast:
  t=_run_lines([which,"models"],8)
  out=_merge(_parse_star_models(t),out)
 out=_prune(out)
 _cache_set("OpenCode",out);return out
def warm():
 for fn in (openai_models,copilot_models,cursor_models,opencode_models):
  try:fn(fast=False)
  except Exception:pass
_DEF_CACHE={}
def default_model(seat):
 """What "default" actually resolves to, read from the same places the CLI itself reads.
 The UI used to print the word "default", which tells the user nothing."""
 now=time.time();hit=_DEF_CACHE.get(seat)
 if hit and now-hit[0]<60:return hit[1]
 out=""
 try:
  if seat=="Grok":
   mc=_read(os.path.expanduser(os.path.join("~",".grok","models_cache.json")),{})
   for mid,meta in (mc.get("models") or {}).items():
    info=(meta.get("info") if isinstance(meta,dict) else None) or {}
    if (isinstance(meta,dict) and meta.get("default")) or info.get("default"):out=mid;break
   out=out or "grok-4.6"
  elif seat=="OpenAI":
   raw=open(os.path.expanduser(os.path.join("~",".codex","config.toml")),encoding="utf-8").read()
   m=re.search(r'^\s*model\s*=\s*["\']([^"\']+)["\']',raw,re.M)
   out=m.group(1) if m else ""
  elif seat=="Claude":
   st=_read(os.path.expanduser(os.path.join("~",".claude","settings.json")),{})
   out=str(st.get("model") or "")
  elif seat=="Copilot":out="auto"
 except Exception:out=""
 _DEF_CACHE[seat]=(now,out)
 return out
def effort_spec(seat):
 return dict(EFFORT.get(seat) or {"flag":"","levels":[""],"default":"","hint":""})
def all_effort():
 return {k:effort_spec(k) for k in EFFORT}
def adam_models():
 """light/heavy stay as convenience aliases; every loadable bake on disk is also offered so a
 model can be selected — and therefore A/B tested — from the room. The serve loads one bake at
 boot, so picking one restarts Adam; Braid verifies the live bake afterwards."""
 out=[{"id":"light","label":"light · 3B"},{"id":"heavy","label":"heavy · 8B"}]
 try:
  import delve_adam as A
  live=(A.live_bake() or "").lower()
  for b in A.list_bakes():
   lbl=b["name"]+(" · %.1f GB"%(b["size_mb"]/1024) if b["size_mb"]>50 else " · tiny")
   if live and b["id"].lower()==live:lbl+=" (loaded)"
   out.append({"id":b["id"],"label":lbl})
 except Exception:pass
 return out
_CAT={}
CAT_TTL=120
def catalog(fast=True):
 import delve_usage as U
 now=time.time();hit=_CAT.get("v")
 if fast and hit:
  if now-hit[0]>=CAT_TTL and not _CAT.get("busy"):
   import threading
   _CAT["busy"]=True
   threading.Thread(target=refresh_bg,daemon=True).start()
  return hit[1]
 cl=U.claude_models();gr=U.grok_models(fast=fast);go=U.google_models(fast=fast)
 out={
  "claude":cl,"Claude":cl,"grok":gr,"Grok":gr,"google":go,"Google":go,
  "OpenAI":openai_models(fast=fast),"Copilot":copilot_models(fast=fast),
  "Cursor":cursor_models(fast=fast),"OpenCode":opencode_models(fast=fast),
  "Adam":adam_models(),
  "effort":all_effort(),"fast":bool(fast)}
 _CAT["v"]=(now,out)
 return out
def refresh_bg():
 try:catalog(fast=False)
 except Exception:pass
 finally:_CAT.pop("busy",None)
