import json,os,re,subprocess,time,shutil
try:
 from delve_proc import run as _run,popen as _popen,check_output as _co
except Exception:
 from subprocess import run as _run,Popen as _popen,check_output as _co
ROOT=os.path.dirname(os.path.abspath(__file__))
CACHE=os.path.join(ROOT,"models_live_cache.json")
TTL=3600
EFFORT={
 "Claude":{"flag":"--effort","levels":["","low","medium","high","xhigh","max"],"default":"medium","hint":"claude --effort"},
 "Grok":{"flag":"--effort","levels":["","low","medium","high"],"default":"medium","hint":"grok --effort / --reasoning-effort"},
 "Google":{"flag":"--effort","levels":["","low","medium","high"],"default":"medium","hint":"agy --effort"},
 "OpenAI":{"flag":"codex_c","levels":["","low","medium","high","xhigh"],"default":"medium","hint":"codex -c model_reasoning_effort=…"},
 "Copilot":{"flag":"--effort","levels":["","none","minimal","low","medium","high","xhigh","max"],"default":"medium","hint":"copilot --effort"},
 "Cursor":{"flag":"","levels":["","low","medium","high"],"default":"","hint":"effort is in the model id (cursor-grok-4.6-high-fast), not [effort=]"},
 "OpenCode":{"flag":"--variant","levels":["","low","medium","high","max","minimal"],"default":"","hint":"opencode run --variant"},
 "Adam":{"flag":"","levels":[""],"default":"","hint":"use model light/heavy"}}
OPENAI_FALLBACK=[
 {"id":"gpt-5.6-terra","label":"GPT-5.6 terra"},{"id":"gpt-5.4","label":"GPT-5.4"},
 {"id":"gpt-5.2","label":"GPT-5.2"},{"id":"gpt-5.2-mini","label":"GPT-5.2 mini"}]
COPILOT_FALLBACK=[
 {"id":"auto","label":"auto"},{"id":"gpt-5.4","label":"GPT-5.4"},{"id":"gpt-5.2","label":"GPT-5.2"},
 {"id":"claude-sonnet-5","label":"Claude Sonnet 5"},{"id":"claude-opus-5","label":"Claude Opus 5"},
 {"id":"gemini-3.1-pro","label":"Gemini 3.1 Pro"}]
# Real cursor-agent --model ids (2026-08-30 --list-models). models.dev anthropic/openai
# slugs are NOT valid here — they poisoned the Cursor dropdown after a fast catalog miss.
CURSOR_FALLBACK=[
 {"id":"auto","label":"Auto (default)"},
 {"id":"cursor-grok-4.6-high","label":"Cursor Grok 4.6"},
 {"id":"cursor-grok-4.6-high-fast","label":"Cursor Grok 4.6 Fast"},
 {"id":"composer-2.5","label":"Composer 2.5"},
 {"id":"gpt-5.2","label":"GPT-5.2"},
 {"id":"claude-opus-5-high","label":"Claude Opus 5"}]
def _read(p,d=None):
 try:return json.load(open(p,encoding="utf-8"))
 except Exception:return d if d is not None else {}
def _write(p,obj):
 try:
  with open(p,"w",encoding="utf-8") as f:json.dump(obj,f)
 except Exception:pass
def _cache_get(key,ttl=TTL):
 c=_read(CACHE,{})
 row=c.get(key) or {}
 if row.get("models") and (time.time()-float(row.get("t") or 0))<ttl:return _prune(list(row["models"]))
 return None
def _cache_set(key,models):
 c=_read(CACHE,{})
 c[key]={"t":time.time(),"models":list(models)};_write(CACHE,c)
def _prune(models):
 import delve_usage as _U
 return _U.prune(models)
def cost_tier(cin,cout,mid=""):
 """Spend band. Missing prices are unknown, not free — a subscription CLI with no
 $/M is not a $0 API. Only an id that says free, or a vendor row that published $0
 (see _cost_of), is free."""
 lid=str(mid or "").lower()
 try:cin=float(cin or 0);cout=float(cout or 0)
 except Exception:cin=cout=0.0
 if "free" in lid:return "free"
 if cin<=0 and cout<=0:return ""
 return "low" if cout<2 else ("mid" if cout<15 else "high")
def cost_mark(m):
 t=(m or {}).get("tier") or ""
 return {"cursor":"","free":"free","low":"$","mid":"$$","high":"$$$"}.get(t,"")
def _cost_of(meta,mid=""):
 c=(meta or {}).get("cost") if isinstance(meta,dict) else None
 if not isinstance(c,dict):c={}
 try:cin=float(c.get("input") or 0);cout=float(c.get("output") or 0)
 except Exception:cin=cout=0.0
 if cin<=0 and cout<=0:return cin,cout,"free"
 return cin,cout,cost_tier(cin,cout,mid)
def merge_opencode(md,cli):
 out=[];seen=set()
 def add(mid,label,hint,cin,cout,tier):
  mid=str(mid or "").strip()
  if not mid or mid in seen:return
  if "/" not in mid:mid="opencode/"+mid
  if mid in seen:return
  seen.add(mid);seen.add(mid.split("/",1)[-1])
  out.append({"id":mid,"label":label or mid.split("/",1)[-1],"hint":hint or "","cost_in":cin,"cost_out":cout,"tier":tier or cost_tier(cin,cout,mid)})
 idx={}
 for m in md or []:
  if not isinstance(m,dict):continue
  i=str(m.get("id") or "")
  idx[i]=m;idx[i.split("/")[-1]]=m
  add(i,m.get("label") or i,m.get("hint") or "vendor",m.get("cost_in") or 0,m.get("cost_out") or 0,m.get("tier") or "")
 for c in cli or []:
  if not isinstance(c,dict):continue
  i=str(c.get("id") or "").strip()
  if not i:continue
  meta=idx.get(i) or idx.get(i.split("/")[-1]) or {}
  add(i,meta.get("label") or c.get("label") or i,c.get("hint") or "live",meta.get("cost_in") or 0,meta.get("cost_out") or 0,meta.get("tier") or cost_tier(0,0,i))
 rank={"free":0,"low":1,"mid":2,"high":3}
 out.sort(key=lambda m:(rank.get(m.get("tier") or "",9),str(m.get("label") or m.get("id") or "").lower()))
 return out
def _merge(primary,fallback):
 out=[];seen=set()
 for m in (primary or [])+(fallback or []):
  mid=(m.get("id") if isinstance(m,dict) else str(m) or "").strip()
  if not mid or mid in seen:continue
  seen.add(mid)
  out.append(m if isinstance(m,dict) else {"id":mid,"label":mid})
 return out
def _run_lines(cmd,timeout=8):
 try:
  r=_run(cmd,capture_output=True,text=True,timeout=timeout,encoding="utf-8",errors="replace")
  return (r.stdout or "")+(r.stderr or "")
 except Exception:return ""
def _parse_star_models(text):
 out=[];seen=set()
 for line in (text or "").splitlines():
  s=line.strip()
  if not s:continue
  if s.startswith("*") or s.startswith("-") or s.startswith("•"):
   mid=s.lstrip("*-• ").split()[0].strip("(),")
  elif re.match(r"^[A-Za-z0-9][A-Za-z0-9._:/\-\[\]=,+]*$",s.split()[0] if s.split() else ""):
   mid=s.split()[0]
  else:continue
  if mid.lower() in ("available","models:","model","default","id","name"):continue
  if mid and mid not in seen:out.append({"id":mid,"label":mid,"hint":"live"});seen.add(mid)
 return out
MD_URL="https://models.dev/api.json"
MD_TTL=86400
# Bumped when the KEPT SHAPE changes. v1 dropped limit.context, so a cache written by it has
# no window to read and every seat would fall back to the default forever - the TTL alone does
# not express "this row is the wrong shape".
MD_KEY="_modelsdev4"
_MD_SKIP=("image","video","audio","tts","whisper","embed","moderation","realtime","transcribe","imagine","search","robotic","live","native","veo","lyria")
def _modelsdev(fast=False):
 """models.dev - public cross-provider registry, the same feed opencode uses. One fetch a
 day; every seat list gets provider-current ids instead of a hand-kept snapshot."""
 c=_read(CACHE,{});row=c.get(MD_KEY) or {}
 if row.get("data") and (time.time()-float(row.get("t") or 0))<MD_TTL:return row["data"]
 if fast:return row.get("data") or {}
 try:
  import urllib.request
  raw=json.loads(urllib.request.urlopen(urllib.request.Request(MD_URL,headers={"User-Agent":"Braid/3.7"}),timeout=12).read().decode("utf-8"))
 except Exception:
  return row.get("data") or {}
 keep={}
 for prov in ("openai","google","anthropic","xai","github-copilot","opencode"):
  ms=(raw.get(prov) or {}).get("models") or {}
  rows=[]
  for mid,meta in ms.items():
   lid=str(mid).lower()
   if any(t in lid for t in _MD_SKIP):continue
   st=str((meta or {}).get("status") or "").lower()
   if st in ("deprecated","retired"):continue
   lim=(meta or {}).get("limit") or {}
   try:ctx=int(lim.get("context") or 0)
   except Exception:ctx=0
   cin,cout,tier=_cost_of(meta,mid)
   rows.append({"id":mid,"label":(meta or {}).get("name") or mid,"ctx":ctx,"cost_in":cin,"cost_out":cout,"tier":tier,
    "hint":("free" if tier=="free" else "$%.2g/$%.2g"%(cin,cout))+" · "+str((meta or {}).get("release_date") or ""),"rd":str((meta or {}).get("release_date") or "")})
  rows.sort(key=lambda m:m.get("rd") or "",reverse=True)
  rank={"free":0,"low":1,"mid":2,"high":3}
  rows.sort(key=lambda m:rank.get(m.get("tier") or "",9))
  cap=80 if prov in ("opencode","github-copilot") else 16
  keep[prov]=[{k:v for k,v in m.items() if k!="rd"} for m in rows[:cap]]
 c[MD_KEY]={"t":time.time(),"data":keep};_write(CACHE,c)
 return keep
def modelsdev_list(provider,fast=False):
 return _prune(list((_modelsdev(fast=fast) or {}).get(provider) or []))
def _stamp_tier(out,provider,fast=False):
 idx={}
 for m in modelsdev_list(provider,fast=fast) or []:
  if not isinstance(m,dict):continue
  i=str(m.get("id") or "")
  idx[i]=m;idx[i.split("/")[-1]]=m
 for m in out or []:
  if not isinstance(m,dict) or m.get("tier"):continue
  src=idx.get(str(m.get("id") or "")) or idx.get(str(m.get("id") or "").split("/")[-1]) or {}
  if src.get("tier"):
   m["tier"]=src.get("tier");m["cost_in"]=src.get("cost_in") or 0;m["cost_out"]=src.get("cost_out") or 0
  else:
   t=cost_tier(m.get("cost_in") or 0,m.get("cost_out") or 0,m.get("id"))
   if t:m["tier"]=t
 return out
def openai_models(fast=False):
 hit=_cache_get("OpenAI")
 if hit is not None and any(isinstance(m,dict) and m.get("tier") for m in hit):return hit
 out=[]
 cfg=os.path.expanduser("~/.codex/config.toml")
 if os.path.isfile(cfg):
  try:
   raw=open(cfg,encoding="utf-8").read()
   m=re.search(r'^\s*model\s*=\s*["\']([^"\']+)["\']',raw,re.M)
   if m:out.append({"id":m.group(1),"label":m.group(1)+" · config","hint":"~/.codex/config.toml"})
  except Exception:pass
 if not fast:
  for cmd in (["codex","models"],["codex","--help"]):
   t=_run_lines(cmd,6)
   if "Available" in t or "*" in t:out.extend(_parse_star_models(t));break
 sess=os.path.expanduser("~/.codex/sessions")
 if os.path.isdir(sess):
  try:
   files=sorted([os.path.join(sess,f) for f in os.listdir(sess) if f.endswith((".json",".jsonl"))],key=os.path.getmtime,reverse=True)[:8]
   seen={m["id"] for m in out}
   for p in files:
    try:
     raw=open(p,encoding="utf-8",errors="replace").read(8000)
     for mid in re.findall(r'"model"\s*:\s*"([^"]+)"',raw):
      if mid and mid not in seen:out.append({"id":mid,"label":mid,"hint":"recent session"});seen.add(mid)
    except Exception:pass
  except Exception:pass
 md=modelsdev_list("openai",fast=fast)
 out=_merge(md,out) if md else (out if len(out)>=2 else _merge(out,[dict(m,hint="offline list") for m in OPENAI_FALLBACK]))
 out=_stamp_tier(_prune(out),"openai",fast=fast);_cache_set("OpenAI",out);return out
def copilot_models(fast=False):
 hit=_cache_get("Copilot")
 if hit is not None and any(isinstance(m,dict) and m.get("tier") for m in hit):return hit
 out=[]
 if not fast:
  which=shutil.which("copilot")
  if which:
   t=_run_lines([which,"--help"],5)
   for m in re.findall(r'copilot --model ([A-Za-z0-9._:\-]+)',t):
    out.append({"id":m,"label":m,"hint":"help example"})
 md=modelsdev_list("github-copilot",fast=fast)
 out=_merge(out,md) if md else (out if len(out)>=2 else _merge(out,[dict(m,hint="offline list") for m in COPILOT_FALLBACK]))
 out=_stamp_tier(_prune(out),"github-copilot",fast=fast);_cache_set("Copilot",out);return out
def _cursor_ids_live(models):
 """True if this looks like cursor-agent's own catalog, not a models.dev anthropic/openai dump."""
 for m in models or []:
  i=str((m.get("id") if isinstance(m,dict) else m) or "").lower()
  if i=="auto" or i.startswith("composer") or i.startswith("cursor-") or "grok" in i:
   return True
 return False
def _cursor_from_cli(models):
 """Disk cache of CURSOR_FALLBACK must not block --list-models. Fast catalog writes that list
 with hint 'offline list'; only rows from cursor-agent itself count as a live hit."""
 return any(isinstance(m,dict) and "list-models" in str(m.get("hint") or "") for m in models or [])
def _cursor_is_own(mid):
 """Cursor Models pool: Grok 4.6/4.5 and Composer 2.5. Auto is the router (can spill).
 Other models (Claude/GPT/Gemini/…) are a separate included allowance, then API price.
 https://cursor.com/docs/models-and-pricing"""
 lid=str(mid or "").lower()
 return lid=="auto" or "composer" in lid or "grok" in lid
def _cursor_priced(models):
 """Cache is usable only when Grok/Composer are tagged as the Cursor pool, not API $."""
 own=False;other=False
 for m in models or []:
  if not isinstance(m,dict):continue
  if _cursor_is_own(m.get("id")):
   if m.get("tier")!="cursor":return False
   own=True
  elif m.get("tier") in ("low","mid","high"):other=True
 return own and other
_CURSOR_EFFORT=re.compile(r"(?:-(?:fast|thinking|none|low|medium|high|xhigh|max|extra-high|minimal))+$",re.I)
def _cursor_family_id(mid):
 """cursor-grok-4.6-high-fast → grok-4.6; claude-opus-5-thinking-high → claude-opus-5."""
 i=str(mid or "").strip()
 if i.lower().startswith("cursor-"):i=i[7:]
 prev=""
 while i and i!=prev:
  prev=i;i=_CURSOR_EFFORT.sub("",i)
 return i
def _claude_flip(mid):
 """claude-4.6-sonnet → claude-sonnet-4-6 (models.dev / Anthropic slug)."""
 m=re.match(r"^claude-(\d+(?:\.\d+)?)[-_](sonnet|opus|haiku|fable)$",str(mid or ""),re.I)
 if not m:return str(mid or "")
 return "claude-%s-%s"%(m.group(2).lower(),m.group(1).replace(".","-"))
def _md_cost_index(fast=False):
 idx={}
 for rows in (_modelsdev(fast=fast) or {}).values():
  for m in rows or []:
   if not isinstance(m,dict):continue
   i=str(m.get("id") or "")
   if not i:continue
   row={"tier":m.get("tier"),"cost_in":m.get("cost_in") or 0,"cost_out":m.get("cost_out") or 0}
   if not row.get("tier") or row.get("tier")=="free":continue
   idx[i]=row;idx[i.split("/")[-1]]=row
 return idx
def _cursor_stamp(out,fast=False,idx=None):
 """Two Cursor pools (docs 2026): Grok/Composer = Cursor Models; everyone else = Other
 Models (included to a plan limit, then API price). Auto sits with Cursor Models as the
 router. Never stamp 'free' — included-until-limit is not a $0 API."""
 if idx is None:idx=_md_cost_index(fast=fast)
 for m in out or []:
  if not isinstance(m,dict):continue
  mid=str(m.get("id") or "")
  if _cursor_is_own(mid):
   m["tier"]="cursor";m["pool"]="cursor";continue
  m["pool"]="other"
  fam=_cursor_family_id(mid)
  src=idx.get(fam) or idx.get(_claude_flip(fam)) or {}
  if not src:
   best=""
   for k in idx:
    if k and (fam==k or fam.startswith(k+"-") or k.startswith(fam+"-")) and len(k)>len(best):best=k
   if best:src=idx[best]
  if src.get("tier") in ("low","mid","high"):
   m["tier"]=src["tier"];m["cost_in"]=src.get("cost_in") or 0;m["cost_out"]=src.get("cost_out") or 0
   continue
  lid=(mid+" "+fam).lower()
  if any(x in lid for x in ("nano","mini","haiku","flash-lite")):m["tier"]="low"
  elif any(x in lid for x in ("opus","fable")):m["tier"]="high"
  elif any(x in lid for x in ("sonnet","gpt","gemini","kimi","glm")):m["tier"]="mid"
  else:m.pop("tier",None)
 return out
def _parse_cursor_models(text):
 """cursor-agent --list-models prints `id - Label (default)` lines, not a star list."""
 out=[];seen=set();default=""
 for line in (text or "").splitlines():
  s=line.strip()
  if not s or s.lower().startswith("available") or s.lower().startswith("tip:"):continue
  if " - " not in s:continue
  mid,lab=s.split(" - ",1);mid=mid.strip();lab=lab.strip()
  if not mid or mid.lower() in ("available","models:","model","default","id","name"):continue
  if "login" in mid.lower() or mid in seen:continue
  if not re.match(r"^[A-Za-z0-9][A-Za-z0-9._:\-]*$",mid):continue
  seen.add(mid)
  row={"id":mid,"label":lab or mid,"hint":"list-models"}
  if "(default)" in (lab or "").lower():
   default=mid;row["default"]=True
  out.append(row)
 return out,default
def _cursor_bin():
 """cursor-agent.cmd/.exe only. Never Grok Build's `agent` (PATH collision since the acquisition)."""
 cands=[]
 try:
  import delve_providers as P
  spec=(P._CLI_SEATS or {}).get("Cursor") or {}
  p,_=P._find_cli(spec)
  if p:cands.append(p)
  for cand in spec.get("paths") or []:
   cands.append(os.path.expandvars(os.path.expanduser(cand)))
 except Exception:pass
 for extra in (shutil.which("cursor-agent"),shutil.which("cursor-agent.cmd"),shutil.which("cursor-agent.exe")):
  if extra:cands.append(extra)
 for p in cands:
  if not p or not os.path.isfile(p):continue
  low=p.replace("\\","/").lower();base=os.path.basename(p).lower()
  if "/.grok/" in low or base in ("agent","agent.exe"):continue
  if base.endswith(".ps1"):
   cmd=os.path.splitext(p)[0]+".cmd"
   if os.path.isfile(cmd):return cmd
   continue
  return p
 return ""
def cursor_models(fast=False):
 hit=_cache_get("Cursor")
 if hit is not None and _cursor_ids_live(hit) and _cursor_from_cli(hit) and _cursor_priced(hit):return hit
 out=[];default=""
 if hit is not None and _cursor_ids_live(hit) and _cursor_from_cli(hit):
  out=list(hit)
 elif not fast:
  which=_cursor_bin()
  if which:
   t=_run_lines([which,"--list-models"],10)
   if t and "Authentication" not in t and "Error" not in t[:80]:
    out,default=_parse_cursor_models(t)
 if not _cursor_ids_live(out):
  out=_merge(out,[dict(m,hint="offline list") for m in CURSOR_FALLBACK])
 if default:
  out=sorted(out,key=lambda m:(0 if (isinstance(m,dict) and m.get("id")==default) else 1))
 out=_cursor_stamp(_prune(out),fast=fast)
 if _cursor_from_cli(out) and _cursor_ids_live(out):_cache_set("Cursor",out)
 return out
def opencode_models(fast=False):
 hit=_cache_get("OpenCode")
 which=shutil.which("opencode")
 if hit is not None and any(isinstance(m,dict) and m.get("tier") for m in hit) and not (which and len(hit)<=1):
  return hit
 cli=[]
 if which and not fast:
  cli=_parse_star_models(_run_lines([which,"models"],10))
 md=modelsdev_list("opencode",fast=fast)
 out=[{"id":"","label":"(CLI default)"}]+_prune(merge_opencode(md,cli))
 if not which or len(out)>1:_cache_set("OpenCode",out)
 return out
def warm():
 for fn in (openai_models,copilot_models,cursor_models,opencode_models):
  try:fn(fast=False)
  except Exception:pass
_DEF_CACHE={}
def default_model(seat):
 """What "default" actually resolves to, read from the same places the CLI itself reads.
 The UI used to print the word "default", which tells the user nothing."""
 now=time.time();hit=_DEF_CACHE.get(seat)
 if hit and now-hit[0]<60:return hit[1]
 out=""
 try:
  if seat=="Grok":
   mc=_read(os.path.expanduser(os.path.join("~",".grok","models_cache.json")),{})
   for mid,meta in (mc.get("models") or {}).items():
    info=(meta.get("info") if isinstance(meta,dict) else None) or {}
    if (isinstance(meta,dict) and meta.get("default")) or info.get("default"):out=mid;break
   out=out or "grok-4.6"
  elif seat=="OpenAI":
   raw=open(os.path.expanduser(os.path.join("~",".codex","config.toml")),encoding="utf-8").read()
   m=re.search(r'^\s*model\s*=\s*["\']([^"\']+)["\']',raw,re.M)
   out=m.group(1) if m else ""
  elif seat=="Claude":
   st=_read(os.path.expanduser(os.path.join("~",".claude","settings.json")),{})
   out=str(st.get("model") or "")
  elif seat=="Copilot":out="auto"
  elif seat=="Cursor":out="auto"
 except Exception:out=""
 _DEF_CACHE[seat]=(now,out)
 return out
def effort_spec(seat):
 return dict(EFFORT.get(seat) or {"flag":"","levels":[""],"default":"","hint":""})
def all_effort():
 return {k:effort_spec(k) for k in EFFORT}
def adam_models():
 """light/heavy stay as convenience aliases; every loadable bake on disk is also offered so a
 model can be selected — and therefore A/B tested — from the room. The serve loads one bake at
 boot, so picking one restarts Adam; Braid verifies the live bake afterwards."""
 out=[{"id":"light","label":"light · 3B"},{"id":"heavy","label":"heavy · 8B"}]
 try:
  import delve_adam as A
  live=(A.live_bake() or "").lower()
  for b in A.list_bakes():
   lbl=b["name"]+(" · %.1f GB"%(b["size_mb"]/1024) if b["size_mb"]>50 else " · tiny")
   if live and b["id"].lower()==live:lbl+=" (loaded)"
   out.append({"id":b["id"],"label":lbl})
 except Exception:pass
 return out
_CAT={}
CAT_TTL=120
def catalog(fast=True):
 import delve_usage as U
 now=time.time();hit=_CAT.get("v")
 if fast and hit:
  if now-hit[0]>=CAT_TTL and not _CAT.get("busy"):
   import threading
   _CAT["busy"]=True
   threading.Thread(target=refresh_bg,daemon=True).start()
  return hit[1]
 cl=U.claude_models();gr=U.grok_models(fast=fast);go=U.google_models(fast=fast)
 cl=_stamp_tier(cl,"anthropic",fast=fast)
 gr=_stamp_tier(gr,"xai",fast=fast)
 out={
  "claude":cl,"Claude":cl,"grok":gr,"Grok":gr,"google":go,"Google":go,
  "OpenAI":openai_models(fast=fast),"Copilot":copilot_models(fast=fast),
  "Cursor":cursor_models(fast=fast),"OpenCode":opencode_models(fast=fast),
  "Adam":adam_models(),
  "effort":all_effort(),"fast":bool(fast)}
 _CAT["v"]=(now,out)
 return out
def refresh_bg():
 try:catalog(fast=False)
 except Exception:pass
 finally:_CAT.pop("busy",None)
