#!/bin/sh
cd "$(dirname "$0")/app" || exit 1
DELVE_DATA_DIR="${DELVE_DATA_DIR:-$HOME/Library/Application Support/Braid}"
export DELVE_DATA_DIR
if ! python3 -c "import sys; raise SystemExit(0 if sys.version_info>=(3,9) else 1)" 2>/dev/null; then
  echo "Braid needs Python 3.9 or newer."
  echo "If macOS just offered to install the command line developer tools, accept."
  echo "When the install completes, open Braid.command again."
  xcode-select --install 2>/dev/null
  echo "Press Return to close this window."
  read -r _
  exit 1
fi
exec python3 launch.py
