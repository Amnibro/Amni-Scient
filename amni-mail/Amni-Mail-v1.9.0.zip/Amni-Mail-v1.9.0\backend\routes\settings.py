from fastapi import APIRouter
from pydantic import BaseModel, ConfigDict
from typing import Optional
from config import cfg
import sync_engine, db
router = APIRouter(prefix="/api/settings", tags=["settings"])
class SettingsUpdate(BaseModel):
    model_config = ConfigDict(extra='allow')
    theme: Optional[str] = None
    density: Optional[str] = None
    pane_sizes: Optional[list] = None
    sync_interval: Optional[int] = None
    auto_sync_enabled: Optional[bool] = None
    auto_sync_only_inbox: Optional[bool] = None
    ai_url: Optional[str] = None
    ai_model: Optional[str] = None
    onboarding_done: Optional[bool] = None
    shortcuts: Optional[dict] = None
    font_size: Optional[int] = None
    row_height: Optional[int] = None
    reading_pane_position: Optional[str] = None
    visited_tabs: Optional[list] = None
    undo_send_seconds: Optional[int] = None
    scheduling_link: Optional[str] = None
    scheduling_link_label: Optional[str] = None
_SECRET_KEYS = ("google_client_secret", "microsoft_client_secret", "xai_api_key")
_READONLY = {"oauth_gmail", "oauth_outlook", "google_client_secret_set", "microsoft_client_secret_set", "xai_api_key_set"}
def public_settings():
    d = dict(cfg.__dict__)
    from routes.oauth import _get_creds
    gid, gsec = _get_creds("gmail")
    mid, msec = _get_creds("outlook")
    d["oauth_gmail"] = bool((gid or "").strip())
    d["oauth_outlook"] = bool((mid or "").strip())
    d["google_client_secret_set"] = bool((gsec or "").strip())
    d["microsoft_client_secret_set"] = bool((msec or "").strip())
    import os
    d["xai_api_key_set"] = bool((os.environ.get("XAI_API_KEY") or d.get("xai_api_key") or "").strip())
    for k in _SECRET_KEYS:
        d.pop(k, None)
    return d
@router.get("/")
async def get_settings():
    return public_settings()
@router.patch("/")
async def update_settings(data: SettingsUpdate):
    payload = data.model_dump(exclude_none=True)
    for k, v in payload.items():
        if k in _READONLY:
            continue
        if k in _SECRET_KEYS and (not v or not str(v).strip()):
            continue
        if not hasattr(cfg, k):
            continue
        setattr(cfg, k, v)
    if getattr(cfg, "xai_api_key", "").strip() or __import__("os").environ.get("XAI_API_KEY"):
        if getattr(cfg, "ai_provider", "auto") in ("auto", "xai"):
            cfg.ai_compose = True
    cfg.save()
    return public_settings()
@router.get("/shortcuts")
async def get_shortcuts():
    return cfg.shortcuts
@router.patch("/shortcuts")
async def update_shortcuts(shortcuts: dict):
    cfg.shortcuts.update(shortcuts)
    cfg.save()
    return cfg.shortcuts
@router.get("/sync/status")
async def sync_status():
    return sync_engine.get_sync_status()
@router.post("/sync/now")
async def sync_now():
    return await sync_engine.trigger_sync_now(sync_engine._ws_broadcast_ref)
def normalize_from_addr(raw: str) -> str:
    s = (raw or "").strip().lower()
    if "<" in s and ">" in s:
        inner = s[s.rfind("<")+1:s.rfind(">")].strip()
        if "@" in inner:
            return inner
    return s
class TrustImageReq(BaseModel):
    account_id: int
    from_addr: str
@router.get("/trusted-image-senders")
async def list_trusted_image_senders(account_id: Optional[int] = None):
    sql = "SELECT account_id, from_addr, created_at FROM trusted_image_senders"
    params: list = []
    if account_id is not None:
        sql += " WHERE account_id=?"
        params.append(account_id)
    sql += " ORDER BY created_at DESC LIMIT 2000"
    return await db.fetch_all(sql, params)
@router.post("/trusted-image-senders/add")
async def add_trusted_image_sender(req: TrustImageReq):
    addr = normalize_from_addr(req.from_addr)
    if not addr:
        return {"ok": False, "error": "empty address"}
    await db.exec_q("INSERT OR IGNORE INTO trusted_image_senders (account_id, from_addr) VALUES (?,?)", [req.account_id, addr])
    return {"ok": True, "account_id": req.account_id, "from_addr": addr}
@router.post("/trusted-image-senders/remove")
async def remove_trusted_image_sender(req: TrustImageReq):
    addr = normalize_from_addr(req.from_addr)
    await db.exec_q("DELETE FROM trusted_image_senders WHERE account_id=? AND from_addr=?", [req.account_id, addr])
    return {"ok": True}
