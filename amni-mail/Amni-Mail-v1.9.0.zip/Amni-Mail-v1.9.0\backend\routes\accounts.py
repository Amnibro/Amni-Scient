import re
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, field_validator
import db, auth, imap_client
router = APIRouter(prefix="/api/accounts", tags=["accounts"])
_EMAIL_RE = re.compile(r'^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$')
class AccountCreate(BaseModel):
    name: str
    email: str
    imap_host: str = ""
    imap_port: int = 993
    smtp_host: str = ""
    smtp_port: int = 587
    auth_type: str = "password"
    username: str = ""
    password: str = ""
    color: str = "#4A90D9"
    @field_validator('email')
    @classmethod
    def validate_email(cls, v):
        if not _EMAIL_RE.match(v):
            raise ValueError('Invalid email address format')
        return v.strip().lower()
    @field_validator('name')
    @classmethod
    def validate_name(cls, v):
        return v.strip()[:128] if v else v
class AccountUpdate(BaseModel):
    name: str = None
    color: str = None
    enabled: bool = None
    password: str = None
@router.get("/")
async def list_accounts():
    rows = await db.fetch_all("SELECT id,name,email,imap_host,smtp_host,auth_type,color,enabled,created_at FROM accounts")
    return [{**dict(r), "creds_present": auth.has_account_creds(r["id"])} for r in rows]
@router.post("/")
async def create_account(data: AccountCreate):
    provider = auth.detect_provider(data.email)
    imap_host = data.imap_host or provider.get("imap_host", "")
    imap_port = data.imap_port or provider.get("imap_port", 993)
    smtp_host = data.smtp_host or provider.get("smtp_host", "")
    smtp_port = data.smtp_port or provider.get("smtp_port", 587)
    if not imap_host or not smtp_host:
        raise HTTPException(400, "Could not auto-detect provider. Please provide IMAP/SMTP hosts.")
    import sqlite3
    try:
        cursor = await db.exec_q(
            "INSERT INTO accounts (name,email,imap_host,imap_port,smtp_host,smtp_port,auth_type,color) VALUES (?,?,?,?,?,?,?,?)",
            [data.name, data.email, imap_host, imap_port, smtp_host, smtp_port, data.auth_type, data.color]
        )
    except sqlite3.IntegrityError:
        raise HTTPException(400, "Account already exists")
    account_id = cursor.lastrowid
    auth.save_account_creds(account_id, data.username or data.email, data.password)
    account = await db.fetch_one("SELECT * FROM accounts WHERE id=?", [account_id])
    try:
        client = await imap_client.get_imap(account)
        await imap_client.disconnect(account_id)
    except Exception as e:
        await db.exec_q("DELETE FROM accounts WHERE id=?", [account_id])
        auth.delete_account_creds(account_id)
        raise HTTPException(400, f"Connection failed: {e}")
    import asyncio, sync_engine
    asyncio.create_task(sync_engine.sync_account(dict(account)))
    return {"id": account_id, "status": "connected"}
@router.get("/{account_id}")
async def get_account(account_id: int):
    acc = await db.fetch_one("SELECT id,name,email,imap_host,smtp_host,auth_type,color,enabled,created_at FROM accounts WHERE id=?", [account_id])
    if not acc:
        raise HTTPException(404, "Account not found")
    return acc
@router.patch("/{account_id}")
async def update_account(account_id: int, data: AccountUpdate):
    updates, params = [], []
    if data.name is not None:
        updates.append("name=?")
        params.append(data.name)
    if data.color is not None:
        updates.append("color=?")
        params.append(data.color)
    if data.enabled is not None:
        updates.append("enabled=?")
        params.append(1 if data.enabled else 0)
    acc = await db.fetch_one("SELECT * FROM accounts WHERE id=?", [account_id])
    if not acc:
        raise HTTPException(404, "Account not found")
    if data.password:
        old = auth.load_account_creds(account_id)
        auth.save_account_creds(account_id, old.get("username") or acc["email"], data.password, oauth_token=old.get("oauth_token"), refresh_token=old.get("refresh_token"))
        await db.exec_q("UPDATE accounts SET auth_type='password' WHERE id=?", [account_id])
        import imap_client
        await imap_client.disconnect(account_id)
    if updates:
        params.append(account_id)
        await db.exec_q(f"UPDATE accounts SET {','.join(updates)} WHERE id=?", params)
    elif not data.password:
        raise HTTPException(400, "No fields to update")
    return {"status": "updated"}
async def _rebuild_fts_tables():
    _db = await db.get_db()
    for fts, content, cols in [("emails_fts", "emails", "subject, from_addr, from_name, body_text, preview"), ("attachments_fts", "attachments", "filename, extracted_text")]:
        await _db.execute(f"DROP TABLE IF EXISTS {fts}")
        await _db.execute(f"CREATE VIRTUAL TABLE {fts} USING fts5({cols}, content='{content}', content_rowid='id')")
        await _db.execute(f"INSERT INTO {fts}({fts}) VALUES('rebuild')")
    await _db.commit()
@router.delete("/{account_id}")
async def delete_account(account_id: int):
    await imap_client.disconnect(account_id)
    auth.delete_account_creds(account_id)
    import sqlite3
    try:
        await db.exec_q("DELETE FROM accounts WHERE id=?", [account_id])
    except sqlite3.DatabaseError as e:
        if "malformed" in str(e).lower():
            await _rebuild_fts_tables()
            await db.exec_q("DELETE FROM accounts WHERE id=?", [account_id])
            return {"status": "deleted", "note": "search index was rebuilt to complete this delete"}
        raise
    return {"status": "deleted"}
@router.post("/{account_id}/test")
async def test_connection(account_id: int):
    acc = await db.fetch_one("SELECT * FROM accounts WHERE id=?", [account_id])
    if not acc:
        raise HTTPException(404, "Account not found")
    try:
        client = await imap_client.get_imap(acc)
        folders = await imap_client.list_folders(acc)
        return {"status": "ok", "folders": len(folders)}
    except Exception as e:
        raise HTTPException(400, f"Connection failed: {e}")
@router.get("/providers/detect")
async def detect_provider(email: str):
    return auth.detect_provider(email)
class AliasCreate(BaseModel):
    email: str
    display_name: str = ""
    is_default: bool = False
    @field_validator('email')
    @classmethod
    def _v_email(cls, v):
        if not _EMAIL_RE.match(v): raise ValueError('Invalid email address format')
        return v.strip().lower()
@router.get("/{account_id}/aliases")
async def list_aliases(account_id: int):
    return await db.fetch_all("SELECT id,account_id,email,display_name,is_default,created_at FROM account_aliases WHERE account_id=? ORDER BY is_default DESC, email ASC", [account_id])
@router.post("/{account_id}/aliases")
async def create_alias(account_id: int, data: AliasCreate):
    acc = await db.fetch_one("SELECT id FROM accounts WHERE id=?", [account_id])
    if not acc: raise HTTPException(404, "Account not found")
    if data.is_default:
        await db.exec_q("UPDATE account_aliases SET is_default=0 WHERE account_id=?", [account_id])
    try:
        cur = await db.exec_q("INSERT INTO account_aliases (account_id,email,display_name,is_default) VALUES (?,?,?,?)", [account_id, data.email, data.display_name, 1 if data.is_default else 0])
    except Exception as e:
        raise HTTPException(409, f"Alias exists or invalid: {e}")
    return {"id": cur.lastrowid, "account_id": account_id, "email": data.email, "display_name": data.display_name, "is_default": bool(data.is_default)}
@router.patch("/{account_id}/aliases/{alias_id}")
async def update_alias(account_id: int, alias_id: int, data: AliasCreate):
    if data.is_default:
        await db.exec_q("UPDATE account_aliases SET is_default=0 WHERE account_id=?", [account_id])
    await db.exec_q("UPDATE account_aliases SET email=?, display_name=?, is_default=? WHERE id=? AND account_id=?", [data.email, data.display_name, 1 if data.is_default else 0, alias_id, account_id])
    return {"updated": True}
@router.delete("/{account_id}/aliases/{alias_id}")
async def delete_alias(account_id: int, alias_id: int):
    await db.exec_q("DELETE FROM account_aliases WHERE id=? AND account_id=?", [alias_id, account_id])
    return {"deleted": True}
