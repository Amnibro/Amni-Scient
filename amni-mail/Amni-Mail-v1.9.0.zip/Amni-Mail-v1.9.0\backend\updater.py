import hashlib, json, zipfile
from pathlib import Path
from urllib.request import urlopen, Request
from version import APP_VERSION, UPDATE_FEED
def _parts(v: str):
    out = []
    for p in (v or "0").strip().lstrip("v").split("."):
        try: out.append(int(p))
        except ValueError: out.append(0)
    return tuple(out + [0, 0, 0])[:3]
def is_newer(remote: str, local: str) -> bool:
    return _parts(remote) > _parts(local)
def fetch_feed(url: str = UPDATE_FEED) -> dict:
    req = Request(url, headers={"User-Agent": f"Amni-Mail/{APP_VERSION}"})
    with urlopen(req, timeout=12) as r:
        return json.loads(r.read().decode("utf-8"))
def check_update(url: str = UPDATE_FEED) -> dict:
    try:
        feed = fetch_feed(url)
    except Exception as e:
        return {"ok": False, "current": APP_VERSION, "error": str(e), "available": False}
    remote = str(feed.get("version") or "")
    return {
        "ok": True,
        "current": APP_VERSION,
        "latest": remote,
        "available": is_newer(remote, APP_VERSION),
        "url": feed.get("url") or "",
        "sha256": feed.get("sha256") or "",
        "notes": feed.get("notes") or "",
    }
def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()
def apply_update(dest: Path, feed: dict) -> dict:
    url = feed.get("url") or ""
    if not url:
        return {"ok": False, "error": "no download url"}
    dest = Path(dest)
    dest.mkdir(parents=True, exist_ok=True)
    tmp = dest / "_update.zip"
    req = Request(url, headers={"User-Agent": f"Amni-Mail/{APP_VERSION}"})
    with urlopen(req, timeout=120) as r, open(tmp, "wb") as f:
        while True:
            b = r.read(1 << 16)
            if not b: break
            f.write(b)
    expect = (feed.get("sha256") or "").lower()
    if expect:
        got = _sha256(tmp)
        if got != expect:
            tmp.unlink(missing_ok=True)
            return {"ok": False, "error": f"sha256 mismatch {got} != {expect}"}
    stage = dest / "_staging"
    if stage.exists():
        import shutil
        shutil.rmtree(stage, ignore_errors=True)
    stage.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(tmp, "r") as z:
        z.extractall(stage)
    tmp.unlink(missing_ok=True)
    inner = _flatten_stage(stage)
    (dest / "_pending_update").write_text("1", encoding="utf-8")
    return {"ok": True, "staged": str(inner)}
_SKIP = {"data", "_staging", "_update.zip", "_pending_update", "venv", "__pycache__"}
def _flatten_stage(stage: Path) -> Path:
    kids = [p for p in stage.iterdir() if p.name not in {".", ".."}]
    if len(kids) == 1 and kids[0].is_dir():
        return kids[0]
    return stage
def install_root() -> Path:
    if getattr(__import__("sys"), "frozen", False):
        return Path(__import__("sys").executable).resolve().parent
    return Path(__file__).resolve().parents[1]
def promote_staging(dest: Path | None = None) -> dict:
    dest = Path(dest) if dest else install_root()
    flag = dest / "_pending_update"
    stage = dest / "_staging"
    if not stage.is_dir():
        flag.unlink(missing_ok=True)
        return {"ok": False, "error": "no staging"}
    src = _flatten_stage(stage)
    import shutil
    def _merge(s: Path, d: Path):
        d.mkdir(parents=True, exist_ok=True)
        for item in s.iterdir():
            if item.name in _SKIP:
                continue
            t = d / item.name
            if item.is_dir():
                _merge(item, t)
            else:
                shutil.copy2(item, t)
    _merge(src, dest)
    shutil.rmtree(stage, ignore_errors=True)
    flag.unlink(missing_ok=True)
    return {"ok": True, "dest": str(dest)}
def apply_pending_on_boot() -> dict | None:
    dest = install_root()
    if (dest / "_pending_update").exists() and (dest / "_staging").is_dir():
        return promote_staging(dest)
    return None
