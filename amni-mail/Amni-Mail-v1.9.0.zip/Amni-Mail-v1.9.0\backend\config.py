from pathlib import Path
from dataclasses import dataclass, field, fields
import os, json, sys
def _data_dir() -> Path:
    env = os.environ.get("AMNI_MAIL_DATA")
    if env:
        return Path(env)
    if getattr(sys, "frozen", False):
        return Path(os.environ.get("LOCALAPPDATA") or Path.home()) / "Amni-Mail" / "data"
    return Path(__file__).parent / "data"
DATA_DIR = _data_dir()
DB_PATH = DATA_DIR / "amni_mail2.db"
CRED_PATH = DATA_DIR / "credentials.enc"
SETTINGS_PATH = DATA_DIR / "settings.json"
DATA_DIR.mkdir(parents=True, exist_ok=True)
@dataclass
class Config:
    host: str = "0.0.0.0"
    port: int = 8026
    ai_url: str = "http://localhost:7700"
    ai_scout_url: str = "http://localhost:7700"
    ai_model: str = "qwen3.5-122b"
    ai_scout_model: str = "qwen3.5-122b"
    ai_provider: str = "auto"
    xai_api_key: str = ""
    xai_model: str = "grok-4.5"
    update_feed: str = "https://amni-scient.com/amni-mail/version.json"
    sync_interval: int = 60
    auto_sync_enabled: bool = True
    auto_sync_only_inbox: bool = False
    last_sync_at: str = ""
    last_sync_error: str = ""
    max_fetch: int = 50000
    theme: str = "dark"
    density: str = "comfortable"
    pane_sizes: list = field(default_factory=lambda: [20, 35, 45])
    font_size: int = 13
    row_height: int = 0
    reading_pane_position: str = "right"
    visited_tabs: list = field(default_factory=list)
    onboarding_done: bool = False
    signature: str = ""
    preview_pane: bool = True
    mark_read_on_open: bool = True
    load_images: bool = True
    ai_categorize: bool = True
    ai_summarize: bool = True
    ai_compose: bool = False
    notif_desktop: bool = True
    notif_sound: bool = True
    notif_badge: bool = True
    block_trackers: bool = True
    confirm_external: bool = True
    undo_send_seconds: int = 10
    google_client_id: str = ""
    google_client_secret: str = ""
    microsoft_client_id: str = ""
    microsoft_client_secret: str = ""
    shortcuts: dict = field(default_factory=lambda: {
        "delete": "Delete", "archive": "e", "reply": "r",
        "reply_all": "Shift+r", "forward": "f", "compose": "c",
        "search": "/", "next": "j", "prev": "k",
        "select_all": "Ctrl+a", "mark_read": "Shift+i",
        "mark_unread": "Shift+u", "refresh": "F5",
        "palette": "Ctrl+k", "help": "?"
    })
    def save(self):
        with open(SETTINGS_PATH, "w") as f:
            json.dump(self.__dict__, f, indent=2)
    @classmethod
    def load(cls):
        if SETTINGS_PATH.exists():
            with open(SETTINGS_PATH, "r") as f:
                raw = json.load(f)
            known = {f.name for f in fields(cls)}
            c = cls(**{k: v for k, v in raw.items() if k in known})
            obsolete = {"local", "scout-2b", ""}
            changed = False
            if (c.ai_model or "").strip() in obsolete:
                c.ai_model = cls.__dataclass_fields__["ai_model"].default; changed = True
            if (c.ai_scout_model or "").strip() in obsolete:
                c.ai_scout_model = cls.__dataclass_fields__["ai_scout_model"].default; changed = True
            if (c.theme or "") == "haven":
                c.theme = "dark"; changed = True
            if (c.xai_model or "").strip() in {"", "grok-4-1-fast", "grok-4-fast"}:
                c.xai_model = "grok-4.5"; changed = True
            if changed: c.save()
            return c
        c = cls()
        c.save()
        return c
cfg = Config.load()
