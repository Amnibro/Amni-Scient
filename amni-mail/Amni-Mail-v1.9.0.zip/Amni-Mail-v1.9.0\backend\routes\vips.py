from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional
import db
router = APIRouter(prefix="/api/vips", tags=["vips"])
class VipCreate(BaseModel):
    account_id: int
    from_addr: str
    label: str = ""
@router.get("")
async def list_vips(account_id: Optional[int] = None):
    sql = "SELECT v.id,v.account_id,v.from_addr,v.label,v.created_at,a.name AS account_name,a.color AS account_color FROM vip_senders v LEFT JOIN accounts a ON a.id=v.account_id"
    params = []
    if account_id:
        sql += " WHERE v.account_id=?"
        params.append(account_id)
    sql += " ORDER BY v.created_at DESC"
    return await db.fetch_all(sql, params)
@router.post("")
async def add_vip(data: VipCreate):
    addr = (data.from_addr or "").strip().lower()
    if not addr or "@" not in addr:
        raise HTTPException(400, "Invalid from_addr")
    try:
        cur = await db.exec_q("INSERT INTO vip_senders (account_id, from_addr, label) VALUES (?,?,?)", [data.account_id, addr, data.label or ""])
        return {"id": cur.lastrowid, "account_id": data.account_id, "from_addr": addr, "label": data.label or ""}
    except Exception:
        row = await db.fetch_one("SELECT id FROM vip_senders WHERE account_id=? AND from_addr=?", [data.account_id, addr])
        return {"id": (row or {}).get("id"), "account_id": data.account_id, "from_addr": addr, "label": data.label or "", "existed": True}
@router.delete("/{vip_id}")
async def remove_vip(vip_id: int):
    await db.exec_q("DELETE FROM vip_senders WHERE id=?", [vip_id])
    return {"deleted": True}
@router.delete("")
async def remove_by_addr(account_id: int, from_addr: str):
    addr = (from_addr or "").strip().lower()
    await db.exec_q("DELETE FROM vip_senders WHERE account_id=? AND from_addr=?", [account_id, addr])
    return {"deleted": True}
@router.get("/check")
async def is_vip(account_id: Optional[int] = None, from_addr: str = ""):
    if not account_id:
        return {"is_vip": False, "id": None, "label": None}
    addr = (from_addr or "").strip().lower()
    row = await db.fetch_one("SELECT id, label FROM vip_senders WHERE account_id=? AND LOWER(from_addr)=?", [account_id, addr])
    return {"is_vip": row is not None, "id": (row or {}).get("id"), "label": (row or {}).get("label")}
@router.get("/emails")
async def vip_emails(account_id: Optional[int] = None, limit: int = 200):
    sql = """SELECT e.* FROM emails e
             INNER JOIN vip_senders v ON v.account_id=e.account_id AND LOWER(v.from_addr)=LOWER(e.from_addr)"""
    params = []
    if account_id:
        sql += " WHERE e.account_id=?"
        params.append(account_id)
    sql += " ORDER BY e.date DESC LIMIT ?"
    params.append(limit)
    return await db.fetch_all(sql, params)
