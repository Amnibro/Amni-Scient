import asyncio, json, time, os
from pathlib import Path
from collections import defaultdict
try:
    from dotenv import load_dotenv
    load_dotenv(Path(__file__).parent / ".env")
except ImportError:
    pass
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from starlette.middleware.base import BaseHTTPMiddleware
from contextlib import asynccontextmanager
import db, sync_engine
from config import cfg, CRED_PATH
from routes import accounts, folders, emails, compose, ai, settings, oauth, rules, calendar, ooo, contacts, attachments, imports, searches, chat, followups, muted, feed, previews, pgp, outbox, vips, admin, update
from version import APP_VERSION
from fastapi.responses import JSONResponse, FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
import traceback, sys
_ws_clients: set[WebSocket] = set()
_ALLOWED_ORIGINS = {"http://localhost:5173", "http://localhost:8025", "http://localhost:8026", "http://127.0.0.1:5173", "http://127.0.0.1:8025", "http://127.0.0.1:8026"}
_VERSION = APP_VERSION
def _frontend_dist() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent / "frontend" / "dist"
    return Path(__file__).resolve().parent.parent / "frontend" / "dist"
_FRONTEND_DIST = _frontend_dist()
def origin_allowed(origin: str) -> bool:
    if not origin:
        return True
    o = origin.rstrip("/")
    if o in _ALLOWED_ORIGINS:
        return True
    from urllib.parse import urlparse
    p = urlparse(o)
    return (p.hostname or "") in {"localhost", "127.0.0.1", "::1"}
_rate_buckets: dict[str, list[float]] = defaultdict(list)
_RATE_LIMIT = 600
_RATE_WINDOW = 10
_RATE_LOCAL_HOSTS = {"127.0.0.1", "::1", "localhost"}

def _check_cred_perms():
    if not CRED_PATH.exists():
        return
    try:
        import stat
        mode = os.stat(CRED_PATH).st_mode
        if mode & (stat.S_IROTH | stat.S_IWOTH):
            print(f"[WARN] {CRED_PATH} is world-readable — tightening")
            os.chmod(CRED_PATH, 0o600)
            print(f"Fixed: {CRED_PATH} permissions set to 600")
    except Exception:
        pass

class RateLimitMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        ip = request.client.host if request.client else "unknown"
        if ip in _RATE_LOCAL_HOSTS:
            return await call_next(request)
        now = time.monotonic()
        bucket = _rate_buckets[ip]
        _rate_buckets[ip] = [t for t in bucket if now - t < _RATE_WINDOW]
        if len(_rate_buckets[ip]) >= _RATE_LIMIT:
            return Response(json.dumps({"detail": "Rate limit exceeded"}), status_code=429, media_type="application/json")
        _rate_buckets[ip].append(now)
        return await call_next(request)

def mail_csp(host: str, port: int) -> str:
    return f"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob: https: http:; font-src 'self'; connect-src 'self' ws://{host}:{port} wss://{host}:{port} ws://127.0.0.1:{cfg.port} ws://localhost:{cfg.port}"
class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        response = await call_next(request)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["X-XSS-Protection"] = "1; mode=block"
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        host = request.url.hostname or "localhost"
        port = request.url.port or cfg.port
        response.headers["Content-Security-Policy"] = mail_csp(host, port)
        response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
        return response

async def ws_broadcast(data: dict):
    msg = json.dumps(data)
    dead = set()
    for ws in _ws_clients:
        try:
            await ws.send_text(msg)
        except Exception:
            dead.add(ws)
    _ws_clients.difference_update(dead)

@asynccontextmanager
async def lifespan(app: FastAPI):
    try:
        import updater as _upd
        _upd.apply_pending_on_boot()
    except Exception:
        pass
    _check_cred_perms()
    await db.get_db()
    await db.init_builtin_templates()
    import asyncio
    asyncio.create_task(sync_engine.start_sync_loop(cfg.sync_interval, ws_broadcast))
    asyncio.create_task(sync_engine.start_idle_listeners(ws_broadcast))
    asyncio.create_task(sync_engine.start_scheduler_loop(ws_broadcast))
    asyncio.create_task(sync_engine.start_snooze_loop(ws_broadcast))
    asyncio.create_task(sync_engine.start_thread_backfill())
    yield
    await sync_engine.stop_sync()
    await db.close_db()

app = FastAPI(title="Amni-Mail", version=_VERSION, lifespan=lifespan)

@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    return JSONResponse(
        status_code=500,
        content={"detail": "Internal Server Error", "traceback": traceback.format_exc()}
    )

app.add_middleware(SecurityHeadersMiddleware)
app.add_middleware(RateLimitMiddleware)
app.add_middleware(CORSMiddleware, allow_origins=list(_ALLOWED_ORIGINS),
                   allow_credentials=True, allow_methods=["GET","POST","PATCH","DELETE","OPTIONS"], allow_headers=["Content-Type","Authorization"])
app.include_router(accounts.router)
app.include_router(folders.router)
app.include_router(emails.router)
app.include_router(compose.router)
app.include_router(ai.router)
app.include_router(settings.router)
app.include_router(oauth.router)
app.include_router(rules.router)
app.include_router(calendar.router)
app.include_router(ooo.router)
app.include_router(contacts.router)
app.include_router(attachments.router)
app.include_router(imports.router)
app.include_router(searches.router)
app.include_router(chat.router)
app.include_router(followups.router)
app.include_router(muted.router)
app.include_router(feed.router)
app.include_router(previews.router)
app.include_router(pgp.router)
app.include_router(outbox.router)
app.include_router(vips.router)
app.include_router(admin.router)
app.include_router(update.router)
@app.websocket("/ws")
async def websocket_endpoint(ws: WebSocket):
    origin = (ws.headers.get("origin") or "").rstrip("/")
    if origin and not origin_allowed(origin):
        await ws.close(code=1008)
        return
    await ws.accept()
    _ws_clients.add(ws)
    try:
        while True:
            data = await ws.receive_text()
            msg = json.loads(data)
            if msg.get("type") == "ping":
                await ws.send_text(json.dumps({"type": "pong"}))
    except WebSocketDisconnect:
        _ws_clients.discard(ws)
@app.get("/api/health")
async def health():
    return {"status": "ok", "version": _VERSION}
@app.get("/")
async def spa_root():
    index = _FRONTEND_DIST / "index.html"
    if index.exists():
        return FileResponse(index)
    return HTMLResponse("<!doctype html><meta charset=utf-8><title>Amni-Mail</title><body style='background:#08090B;color:#EDEFF2;font-family:Archivo,Segoe UI,sans-serif;padding:48px'><h1 style='letter-spacing:.16em;text-transform:uppercase;font-size:14px'>Amni-Mail</h1><p>Frontend is not built. Run <code>scripts/package.ps1</code> or <code>npm run build</code> in frontend, then restart.</p></body>")
if _FRONTEND_DIST.exists():
    app.mount("/assets", StaticFiles(directory=str(_FRONTEND_DIST / "assets")), name="assets")
    @app.get("/{path:path}")
    async def spa_fallback(path: str):
        if path.startswith("api/") or path == "ws":
            return JSONResponse({"detail": "Not found"}, 404)
        direct = _FRONTEND_DIST / path
        if direct.is_file():
            return FileResponse(direct)
        index = _FRONTEND_DIST / "index.html"
        if index.exists():
            return FileResponse(index)
        return JSONResponse({"detail": "Not found"}, 404)
if __name__ == "__main__":
    import uvicorn, webbrowser, threading
    def _open():
        import time
        time.sleep(0.9)
        webbrowser.open(f"http://127.0.0.1:{cfg.port}")
    if os.environ.get("AMNI_MAIL_NO_BROWSER") != "1":
        threading.Thread(target=_open, daemon=True).start()
    uvicorn.run("main:app", host=cfg.host, port=cfg.port, log_level="info")
