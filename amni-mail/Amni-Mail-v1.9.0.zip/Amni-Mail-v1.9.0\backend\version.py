APP_VERSION = "1.9.0"
UPDATE_FEED = "https://amni-scient.com/amni-mail/version.json"
