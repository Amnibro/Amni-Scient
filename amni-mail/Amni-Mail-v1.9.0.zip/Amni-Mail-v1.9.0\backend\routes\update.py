from fastapi import APIRouter
import updater
from config import cfg
router = APIRouter(prefix="/api/update", tags=["update"])
@router.get("/status")
async def update_status():
    feed = getattr(cfg, "update_feed", "") or None
    return updater.check_update(feed) if feed else updater.check_update()
@router.post("/check")
async def update_check():
    return await update_status()
@router.post("/apply")
async def update_apply():
    feed_url = getattr(cfg, "update_feed", "") or None
    st = updater.check_update(feed_url) if feed_url else updater.check_update()
    if not st.get("ok"):
        return {**st, "applied": False}
    if not st.get("available"):
        return {**st, "applied": False, "error": "already current"}
    dest = updater.install_root()
    try:
        feed = updater.fetch_feed(feed_url) if feed_url else updater.fetch_feed()
    except Exception as e:
        return {"ok": False, "applied": False, "error": str(e)}
    out = updater.apply_update(dest, feed)
    return {**st, **out, "restart": bool(out.get("ok"))}
