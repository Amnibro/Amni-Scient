@echo off
setlocal
cd /d "%~dp0"
if exist "_pending_update" if exist "backend\venv\Scripts\python.exe" (
  backend\venv\Scripts\python.exe -c "import sys;sys.path.insert(0,'backend');import updater;print(updater.promote_staging())"
)
if exist "AmniMail.exe" if exist "_pending_update" (
  if exist "_staging" (
    robocopy "_staging" "." /E /XD data _staging /NFL /NDL /NJH /NJS /nc /ns /np
    for /d %%D in ("_staging\*") do robocopy "%%D" "." /E /XD data _staging /NFL /NDL /NJH /NJS /nc /ns /np
    rmdir /s /q "_staging"
  )
  del /f /q "_pending_update"
)
echo === Amni-Mail ===
if not exist "backend\venv\Scripts\python.exe" (
    echo Creating Python venv...
    python -m venv backend\venv
    if errorlevel 1 (
        echo Python 3.11+ is required. https://www.python.org/downloads/
        pause
        exit /b 1
    )
    backend\venv\Scripts\python.exe -m pip install -r backend\requirements.txt
)
if not exist "frontend\dist\index.html" (
    where npm >nul 2>nul
    if errorlevel 1 (
        echo frontend\dist is missing and npm is not on PATH.
        echo Run scripts\package.ps1 on a machine with Node, then copy the folder here.
        pause
        exit /b 1
    )
    echo Building frontend...
    pushd frontend
    if not exist node_modules npm install
    call npm run build
    popd
)
echo Starting Amni-Mail on http://127.0.0.1:8026
set AMNI_MAIL_NO_BROWSER=
backend\venv\Scripts\python.exe backend\main.py
endlocal
