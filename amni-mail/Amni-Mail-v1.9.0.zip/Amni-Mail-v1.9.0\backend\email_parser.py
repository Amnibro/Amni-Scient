import email, re
from email import policy
from email.utils import parseaddr, parsedate_to_datetime
from datetime import datetime
import bleach
from bleach.css_sanitizer import CSSSanitizer
from db import derive_thread_id
from ics_parser import parse_ics, get_method
ALLOWED_TAGS = [
    "a", "abbr", "article", "b", "blockquote", "br", "caption", "center", "code",
    "col", "colgroup", "div", "em", "figcaption", "figure", "font", "h1", "h2",
    "h3", "h4", "h5", "h6", "header", "hr", "i", "img", "li", "ol", "p", "pre",
    "section", "small", "span", "strong", "sub", "sup", "table", "tbody", "td",
    "tfoot", "th", "thead", "tr", "u", "ul"
]
ALLOWED_ATTRS = {
    "*": ["style", "align", "valign", "width", "height", "bgcolor", "color", "background", "class"],
    "a": ["href", "title", "target", "rel"],
    "img": ["src", "alt", "width", "height", "border"],
    "td": ["colspan", "rowspan", "width", "height", "bgcolor", "align", "valign"],
    "th": ["colspan", "rowspan", "width", "height", "bgcolor", "align", "valign"],
    "table": ["width", "border", "cellpadding", "cellspacing", "bgcolor", "align", "role"],
    "font": ["color", "size", "face"],
    "col": ["span", "width"],
}
_CSS = CSSSanitizer(allowed_css_properties=[
    "color", "background", "background-color", "background-image", "background-repeat",
    "font", "font-size", "font-weight", "font-family", "font-style", "font-variant",
    "text-align", "text-decoration", "text-transform", "letter-spacing", "line-height",
    "padding", "padding-top", "padding-right", "padding-bottom", "padding-left",
    "margin", "margin-top", "margin-right", "margin-bottom", "margin-left",
    "width", "max-width", "min-width", "height", "max-height", "min-height",
    "border", "border-top", "border-right", "border-bottom", "border-left",
    "border-color", "border-width", "border-style", "border-collapse", "border-radius",
    "display", "vertical-align", "white-space", "list-style", "list-style-type",
    "opacity", "box-sizing",
])
_UNSUB_URI = re.compile(r"<([^>]+)>")
_UNSUB_LINK_TEXT = re.compile(r'<a[^>]+href=["\']([^"\']+)["\'][^>]*>(?:(?!</a>).){0,200}?(?:unsubscribe|opt[-\s]?out|manage\s+(?:your\s+)?(?:subscription|preferences)|email\s+preferences)(?:(?!</a>).){0,80}?</a>', re.IGNORECASE | re.DOTALL)
_UNSUB_LINK_URL = re.compile(r'<a[^>]+href=["\']([^"\']*(?:unsubscribe|opt[-_]?out|email[-_]?preferences|list-manage)[^"\']*)["\']', re.IGNORECASE)
_UNSUB_TEXT_URL = re.compile(r'(https?://[^\s<>"]{6,400}?(?:unsubscribe|opt[-_]?out|email[-_]?preferences)[^\s<>"]{0,200})', re.IGNORECASE)
def _scan_body_unsub(body_html: str, body_text: str) -> str:
    if body_html:
        m = _UNSUB_LINK_TEXT.search(body_html)
        if m and m.group(1).lower().startswith(("http://", "https://")):
            return m.group(1).strip()
        m = _UNSUB_LINK_URL.search(body_html)
        if m and m.group(1).lower().startswith(("http://", "https://")):
            return m.group(1).strip()
    if body_text:
        m = _UNSUB_TEXT_URL.search(body_text)
        if m:
            return m.group(1).strip()
    return ""
def sanitize_html(html_str: str) -> str:
    if not html_str:
        return ""
    html_str = re.sub(r'<script[^>]*>.*?</script>', '', html_str, flags=re.DOTALL | re.IGNORECASE)
    html_str = re.sub(r'<style[^>]*>.*?</style>', '', html_str, flags=re.DOTALL | re.IGNORECASE)
    html_str = re.sub(r'on\w+="[^"]*"', '', html_str, flags=re.IGNORECASE)
    html_str = re.sub(r"on\w+='[^']*'", '', html_str, flags=re.IGNORECASE)
    return bleach.clean(html_str, tags=ALLOWED_TAGS, attributes=ALLOWED_ATTRS, strip=True, css_sanitizer=_CSS, protocols=["http", "https", "mailto", "cid", "data"])
def _pick_unsub(header_val: str) -> tuple[str, str]:
    if not header_val:
        return "", ""
    uris = _UNSUB_URI.findall(header_val)
    http = next((u for u in uris if u.lower().startswith(("http://", "https://"))), "")
    mailto = next((u for u in uris if u.lower().startswith("mailto:")), "")
    return http or mailto, "http" if http else ("mailto" if mailto else "")
def parse_email(raw: bytes) -> dict:
    try:
        msg = email.message_from_bytes(raw, policy=policy.default)
    except Exception:
        return None
    from_name, from_addr = parseaddr(msg.get("From", ""))
    to_addrs = msg.get("To", "")
    cc_addrs = msg.get("Cc", "")
    subject = msg.get("Subject", "(no subject)")
    message_id = msg.get("Message-ID", "") or ""
    in_reply_to = msg.get("In-Reply-To", "") or ""
    references = msg.get("References", "") or ""
    thread_id = derive_thread_id(references, in_reply_to, message_id, subject, from_addr)
    unsub_hdr = msg.get("List-Unsubscribe", "")
    unsub_uri, unsub_kind = _pick_unsub(unsub_hdr)
    unsub_post = msg.get("List-Unsubscribe-Post", "")
    auth_results = " | ".join(v for v in msg.get_all("Authentication-Results") or [] if v)
    reply_to_hdr = msg.get("Reply-To", "") or ""
    _, reply_to_addr = parseaddr(reply_to_hdr)
    try:
        date = parsedate_to_datetime(msg.get("Date", ""))
    except Exception:
        date = datetime.now()
    body_text, body_html = "", ""
    attachments = []
    ics_events = []
    ics_method = ""
    if msg.is_multipart():
        for part in msg.walk():
            ct = part.get_content_type()
            disp = str(part.get("Content-Disposition", ""))
            if ct == "text/calendar":
                try:
                    ics_text = part.get_payload(decode=True).decode("utf-8", errors="replace")
                    ics_events = parse_ics(ics_text)
                    ics_method = get_method(ics_text) or part.get_param("method", "") or ""
                except Exception:
                    pass
                continue
            if "attachment" in disp:
                attachments.append({
                    "filename": part.get_filename() or "unnamed",
                    "content_type": ct,
                    "size": len(part.get_payload(decode=True) or b""),
                    "content_id": part.get("Content-ID", ""),
                    "data": part.get_payload(decode=True)
                })
            elif ct == "text/plain" and not body_text:
                body_text = part.get_payload(decode=True).decode("utf-8", errors="replace")
            elif ct == "text/html" and not body_html:
                body_html = part.get_payload(decode=True).decode("utf-8", errors="replace")
    else:
        ct = msg.get_content_type()
        payload = msg.get_payload(decode=True)
        if payload:
            text = payload.decode("utf-8", errors="replace")
            body_text = text if ct == "text/plain" else body_text
            body_html = text if ct == "text/html" else body_html
    preview = (body_text or re.sub(r'<[^>]+>', '', body_html))[:200].strip()
    ics_uid = (ics_events[0]["uid"] if ics_events else "") or ""
    if not unsub_uri:
        body_unsub = _scan_body_unsub(body_html, body_text)
        if body_unsub:
            unsub_uri = body_unsub
            unsub_kind = "http"
    mdn_orig = ""; mdn_disp = ""; mdn_recip = ""
    try:
        if msg.is_multipart() and msg.get_content_type() == "multipart/report":
            if (msg.get_param("report-type", "") or "").lower() == "disposition-notification":
                for p in msg.walk():
                    if p.get_content_type() == "message/disposition-notification":
                        try:
                            sub = email.message_from_bytes(p.get_payload(decode=True) or b"", policy=policy.default)
                            mdn_orig = (sub.get("Original-Message-ID", "") or "").strip()
                            mdn_disp = (sub.get("Disposition", "") or "").strip()
                            mdn_recip = (sub.get("Original-Recipient", "") or sub.get("Final-Recipient", "") or "").strip()
                        except Exception:
                            pass
                        break
    except Exception:
        pass
    return {
        "message_id": message_id, "thread_id": thread_id,
        "in_reply_to": in_reply_to, "references_hdr": references,
        "from_addr": from_addr, "from_name": from_name,
        "to_addrs": to_addrs, "cc_addrs": cc_addrs,
        "subject": subject, "date": str(date),
        "body_text": body_text, "body_html": sanitize_html(body_html),
        "preview": preview, "attachments": attachments,
        "unsubscribe_uri": unsub_uri, "unsubscribe_post": unsub_post,
        "ics_uid": ics_uid, "ics_events": ics_events, "ics_method": ics_method,
        "is_list": bool(msg.get("List-Id") or msg.get("Precedence", "").lower() in ("list", "bulk", "auto_reply")),
        "is_auto": bool(msg.get("Auto-Submitted") and msg.get("Auto-Submitted", "").lower() != "no"),
        "auth_results": auth_results, "reply_to": reply_to_addr,
        "mdn_original_message_id": mdn_orig, "mdn_disposition": mdn_disp, "mdn_recipient": mdn_recip
    }
