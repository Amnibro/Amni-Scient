from fastapi import APIRouter, HTTPException, Query
BODY_FETCH_TIMEOUT = 60
from pydantic import BaseModel
from typing import Optional
from datetime import datetime, timezone, timedelta
import asyncio, urllib.parse, httpx, json
import db, imap_client, smtp_client, auth
from email_parser import parse_email, _scan_body_unsub
from trust import compute_trust
router = APIRouter(prefix="/api/emails", tags=["emails"])
@router.get("/{email_id}/receipts")
async def get_receipts(email_id: int):
    rows = await db.fetch_all("SELECT id, recipient, disposition, reported_at FROM read_receipts WHERE sent_email_id=? ORDER BY reported_at DESC", [email_id])
    return {"receipts": [dict(r) for r in rows]}
@router.get("/stats/today")
async def stats_today(account_id: Optional[int] = None):
    params: list = []
    acct_clause = ""
    if account_id:
        acct_clause = " AND e.account_id=?"
        params.append(account_id)
    recv = await db.fetch_one(f"SELECT COUNT(*) as cnt FROM emails e JOIN folders f ON f.id = e.folder_id WHERE e.is_deleted=0 AND f.folder_type='inbox' AND e.date >= datetime('now','start of day','localtime'){acct_clause}", params)
    sent = await db.fetch_one(f"SELECT COUNT(*) as cnt FROM emails e JOIN folders f ON f.id = e.folder_id WHERE e.is_deleted=0 AND f.folder_type='sent' AND e.date >= datetime('now','start of day','localtime'){acct_clause}", params)
    arch = await db.fetch_one(f"SELECT COUNT(*) as cnt FROM emails e JOIN folders f ON f.id = e.folder_id WHERE e.is_deleted=0 AND f.folder_type='archive' AND e.date >= datetime('now','start of day','localtime'){acct_clause}", params)
    unread_now = await db.fetch_one(f"SELECT COUNT(*) as cnt FROM emails e JOIN folders f ON f.id = e.folder_id WHERE e.is_deleted=0 AND f.folder_type='inbox' AND e.is_read=0 AND (e.snoozed_until IS NULL OR e.snoozed_until <= datetime('now')){acct_clause}", params)
    return {"received": recv["cnt"], "sent": sent["cnt"], "archived": arch["cnt"], "unread": unread_now["cnt"]}
@router.get("/draft-for-thread")
async def draft_for_thread(account_id: int, thread_id: str = "", message_id: str = ""):
    if not thread_id and not message_id:
        return {"draft": None}
    where = ["e.account_id=?", "e.is_deleted=0", "f.folder_type='drafts'"]
    params: list = [account_id]
    cond = []
    if thread_id:
        cond.append("e.thread_id=?"); params.append(thread_id)
    if message_id:
        cond.append("e.in_reply_to=?"); params.append(message_id)
    where.append("(" + " OR ".join(cond) + ")")
    row = await db.fetch_one(f"SELECT e.id, e.subject, e.to_addrs, e.date, e.body_text FROM emails e JOIN folders f ON f.id=e.folder_id WHERE {' AND '.join(where)} ORDER BY e.date DESC LIMIT 1", params)
    if not row: return {"draft": None}
    bt = (row.get("body_text") or "")[:140]
    return {"draft": {"id": row["id"], "subject": row.get("subject") or "", "to": row.get("to_addrs") or "", "date": row.get("date"), "preview": bt}}
class BulkAction(BaseModel):
    email_ids: list[int]
class MoveAction(BaseModel):
    email_ids: list[int]
    dest_folder_id: int
class FlagAction(BaseModel):
    email_ids: list[int]
    flag: str
    add: bool = True
class SnoozeAction(BaseModel):
    email_ids: list[int]
    until: str
@router.get("/")
async def list_emails(folder_id: int, sort_by: str = "date", sort_dir: str = "DESC",
    offset: int = 0, limit: int = 200, category: Optional[str] = None,
    is_read: Optional[bool] = None, is_starred: Optional[bool] = None,
    account_id: Optional[int] = None, show_snoozed: bool = False):
    allowed_sorts = {"date", "from_addr", "subject", "size", "ai_priority", "ai_category"}
    sort_by = sort_by if sort_by in allowed_sorts else "date"
    sort_dir = "ASC" if sort_dir.upper() == "ASC" else "DESC"
    cols = "id,uid,account_id,folder_id,from_addr,from_name,to_addrs,subject,date,size,is_read,is_starred,is_pinned,has_attachments,preview,ai_category,ai_priority,thread_id,snoozed_until,ics_uid,unsubscribe_uri"
    if folder_id == 0:
        sql = f"SELECT {cols} FROM emails e WHERE is_deleted=0 AND folder_id IN (SELECT id FROM folders WHERE folder_type='inbox'"
        params = []
        if account_id:
            sql += " AND account_id=?"
            params.append(account_id)
        sql += ")"
    else:
        sql = f"SELECT {cols} FROM emails e WHERE folder_id=? AND is_deleted=0"
        params = [folder_id]
    if not show_snoozed:
        sql += " AND (snoozed_until IS NULL OR snoozed_until <= datetime('now'))"
    if category:
        cats = [c.strip() for c in category.split(",") if c.strip()]
        if len(cats) == 1:
            sql += " AND ai_category=?"
            params.append(cats[0])
        elif cats:
            sql += " AND ai_category IN (" + ",".join(["?"] * len(cats)) + ")"
            params.extend(cats)
    if is_read is not None:
        sql += " AND is_read=?"
        params.append(1 if is_read else 0)
    if is_starred is not None:
        sql += " AND is_starred=?"
        params.append(1 if is_starred else 0)
    sql += f" ORDER BY {sort_by} {sort_dir} LIMIT ? OFFSET ?"
    params.extend([limit, offset])
    emails = await db.fetch_all(sql, params)
    ids_with_att = [e["id"] for e in emails if e.get("has_attachments")]
    if ids_with_att:
        ph = ",".join("?" * len(ids_with_att))
        atts = await db.fetch_all(f"SELECT id, email_id, filename, content_type, size FROM attachments WHERE email_id IN ({ph}) AND filename IS NOT NULL AND filename != '' AND (content_id IS NULL OR content_id = '') ORDER BY email_id, id", ids_with_att)
        by_eid: dict[int, list] = {}
        for a in atts:
            by_eid.setdefault(a["email_id"], []).append({"id": a["id"], "filename": a["filename"], "content_type": a["content_type"], "size": a["size"]})
        for e in emails:
            if e.get("has_attachments"):
                e["attachments"] = by_eid.get(e["id"], [])[:3]
    if emails:
        try:
            _ids = [e["id"] for e in emails if e.get("from_addr")]
            if _ids:
                _ph = ",".join(["?"] * len(_ids))
                _first = await db.fetch_all(f"SELECT e.id FROM emails e WHERE e.id IN ({_ph}) AND e.from_addr != '' AND NOT EXISTS (SELECT 1 FROM emails e2 WHERE e2.account_id = e.account_id AND LOWER(e2.from_addr) = LOWER(e.from_addr) AND e2.is_deleted = 0 AND (e2.date < e.date OR (e2.date = e.date AND e2.id < e.id)))", _ids)
                _fset = {r["id"] for r in _first}
                for e in emails:
                    e["is_first_contact"] = e["id"] in _fset
                _addrs = list({(e.get("from_addr") or "").lower() for e in emails if e.get("from_addr")})
                if _addrs:
                    _aph = ",".join(["?"] * len(_addrs))
                    _acct_clause = ""
                    _cparams = list(_addrs)
                    if account_id:
                        _acct_clause = " AND account_id=?"
                        _cparams.append(account_id)
                    _rows = await db.fetch_all(f"SELECT LOWER(from_addr) as a, COUNT(*) as c FROM emails WHERE is_deleted=0 AND LOWER(from_addr) IN ({_aph}) AND date >= datetime('now','-7 days'){_acct_clause} GROUP BY LOWER(from_addr)", _cparams)
                    _cmap = {r["a"]: r["c"] for r in _rows}
                    for e in emails:
                        e["sender_7d_count"] = _cmap.get((e.get("from_addr") or "").lower(), 0)
                _tids = [(e.get("thread_id") or "") for e in emails if (e.get("thread_id") or "")]
                if _tids:
                    _tph = ",".join(["?"] * len(_tids))
                    _nr = await db.fetch_all(f"SELECT e.id, e.thread_id, e.date FROM emails e JOIN folders f ON f.id=e.folder_id WHERE e.id IN ({_ph}) AND e.thread_id IN ({_tph}) AND f.folder_type='inbox' AND e.date < datetime('now','-3 days') AND e.is_deleted=0 AND NOT EXISTS (SELECT 1 FROM emails e2 JOIN folders f2 ON f2.id=e2.folder_id WHERE e2.account_id=e.account_id AND e2.thread_id=e.thread_id AND f2.folder_type='sent' AND e2.date > e.date AND e2.is_deleted=0)", _ids + _tids)
                    _nrset = {r["id"] for r in _nr}
                    for e in emails:
                        e["needs_reply"] = e["id"] in _nrset
        except Exception:
            pass
    if folder_id == 0:
        cnt_sql = "SELECT COUNT(*) as cnt FROM emails WHERE is_deleted=0 AND folder_id IN (SELECT id FROM folders WHERE folder_type='inbox'"
        cnt_params = []
        if account_id:
            cnt_sql += " AND account_id=?"
            cnt_params.append(account_id)
        cnt_sql += ")"
        total = await db.fetch_one(cnt_sql, cnt_params)
    else:
        total = await db.fetch_one("SELECT COUNT(*) as cnt FROM emails WHERE folder_id=? AND is_deleted=0", [folder_id])
    return {"emails": emails, "total": total["cnt"], "offset": offset, "limit": limit}
@router.get("/search")
async def search(q: str, account_id: Optional[int] = None, folder_id: Optional[int] = None, limit: int = 200):
    return await db.search_emails(q, account_id, folder_id, limit)
class SetCategoryRequest(BaseModel):
    email_ids: list[int]
    category: str
    learn: bool = True
@router.post("/set-category")
async def set_category(data: SetCategoryRequest):
    cat = (data.category or "").strip().lower()
    if not cat:
        raise HTTPException(400, "category required")
    if not data.email_ids:
        return {"updated": 0, "learned": 0}
    placeholders = ",".join("?" * len(data.email_ids))
    rows = await db.fetch_all(f"SELECT id, account_id, from_addr FROM emails WHERE id IN ({placeholders})", data.email_ids)
    learned = 0
    for r in rows:
        await db.exec_q("UPDATE emails SET ai_category=? WHERE id=?", [cat, r["id"]])
        await db.exec_q("INSERT OR REPLACE INTO ai_cache (email_id, category, priority) VALUES (?, ?, COALESCE((SELECT priority FROM ai_cache WHERE email_id=?), 3))", [r["id"], cat, r["id"]])
        if data.learn and r.get("from_addr"):
            try:
                await db.exec_q("INSERT INTO category_overrides (account_id, from_addr, category) VALUES (?,?,?) ON CONFLICT(account_id, from_addr) DO UPDATE SET category=excluded.category", [r["account_id"], r["from_addr"], cat])
                learned += 1
            except Exception:
                pass
    return {"updated": len(rows), "learned": learned, "category": cat}
class MarkCategoryReadRequest(BaseModel):
    category: str
    account_id: Optional[int] = None
    folder_id: Optional[int] = None
class MarkFolderReadRequest(BaseModel):
    folder_id: int
    account_id: Optional[int] = None
@router.post("/mark-folder-read")
async def mark_folder_read(data: MarkFolderReadRequest):
    if data.folder_id == 0:
        sql = "UPDATE emails SET is_read=1 WHERE is_read=0 AND is_deleted=0 AND folder_id IN (SELECT id FROM folders WHERE folder_type='inbox'"
        params: list = []
        if data.account_id:
            sql += " AND account_id=?"
            params.append(data.account_id)
        sql += ")"
    else:
        sql = "UPDATE emails SET is_read=1 WHERE is_read=0 AND is_deleted=0 AND folder_id=?"
        params = [data.folder_id]
    cur = await db.exec_q(sql, params)
    return {"marked": cur.rowcount if hasattr(cur, "rowcount") else 0}
@router.post("/mark-category-read")
async def mark_category_read(data: MarkCategoryReadRequest):
    cats = [c.strip() for c in (data.category or "").split(",") if c.strip()]
    if not cats:
        raise HTTPException(400, "category required")
    sql = "UPDATE emails SET is_read=1 WHERE is_read=0 AND is_deleted=0 AND ai_category IN (" + ",".join("?" * len(cats)) + ")"
    params = list(cats)
    if data.folder_id and data.folder_id > 0:
        sql += " AND folder_id=?"
        params.append(data.folder_id)
    elif data.account_id:
        sql += " AND folder_id IN (SELECT id FROM folders WHERE folder_type='inbox' AND account_id=?)"
        params.append(data.account_id)
    cur = await db.exec_q(sql, params)
    return {"marked": cur.rowcount if hasattr(cur, "rowcount") else 0}
@router.get("/category-overrides")
async def list_category_overrides(account_id: Optional[int] = None):
    sql = "SELECT id, account_id, from_addr, category, created_at FROM category_overrides"
    params = []
    if account_id:
        sql += " WHERE account_id=?"
        params.append(account_id)
    sql += " ORDER BY created_at DESC LIMIT 500"
    return await db.fetch_all(sql, params)
@router.delete("/category-overrides/{ovr_id}")
async def delete_category_override(ovr_id: int):
    await db.exec_q("DELETE FROM category_overrides WHERE id=?", [ovr_id])
    return {"deleted": True}
async def _sync_imap_read(account_id: int, folder_id: int, uid: int):
    try:
        acc = await db.fetch_one("SELECT * FROM accounts WHERE id=?", [account_id])
        fld = await db.fetch_one("SELECT path FROM folders WHERE id=?", [folder_id])
        if acc and fld:
            await imap_client.batch_flag(acc, fld["path"], [uid], "\\Seen", True)
    except Exception:
        pass
@router.get("/{email_id}")
async def get_email(email_id: int, force: int = 0):
    em = await db.fetch_one("SELECT * FROM emails WHERE id=?", [email_id])
    if not em:
        raise HTTPException(404, "Email not found")
    em = dict(em)
    need_fetch = force or not em.get("body_fetched") or not (em.get("body_text") or em.get("body_html"))
    if need_fetch:
        acc = await db.fetch_one("SELECT * FROM accounts WHERE id=?", [em["account_id"]])
        fld = await db.fetch_one("SELECT path FROM folders WHERE id=?", [em["folder_id"]])
        if not acc:
            em["body_fetch_error"] = f"account {em['account_id']} not found in DB"
        elif not fld:
            em["body_fetch_error"] = f"folder {em['folder_id']} not found in DB"
        elif not auth.has_account_creds(em["account_id"]):
            em["body_fetch_error"] = f"Account {acc.get('email','?')} needs to be reconnected — credentials missing. Open Settings → Accounts to re-authenticate."
            em["needs_reauth"] = True
            em["reauth_account_id"] = em["account_id"]
        else:
            try:
                raw = await asyncio.wait_for(imap_client.fetch_email_body(acc, fld["path"], em["uid"]), timeout=BODY_FETCH_TIMEOUT)
                if raw is None:
                    em["body_fetch_error"] = f"IMAP returned no body (uid={em['uid']}, folder={fld['path']}) — check backend log for [BODY]"
                elif not raw:
                    em["body_fetch_error"] = f"IMAP returned empty bytes (uid={em['uid']})"
                else:
                    parsed = parse_email(raw)
                    if not parsed:
                        em["body_fetch_error"] = f"parser returned None for {len(raw)}-byte body"
                    elif not (parsed.get("body_text") or parsed.get("body_html")):
                        em["body_fetch_error"] = f"parsed OK but body_text and body_html both empty ({len(raw)}B raw) — not persisting so retry can try again"
                    else:
                        await db.exec_q(
                            "UPDATE emails SET body_text=?, body_html=?, preview=?, size=?, has_attachments=?, body_fetched=1 WHERE id=?",
                            [parsed["body_text"], parsed["body_html"], parsed["preview"], len(raw), 1 if parsed["attachments"] else 0, email_id])
                        for k in ("body_text", "body_html", "preview"):
                            em[k] = parsed[k]
                        em["has_attachments"] = 1 if parsed["attachments"] else 0
                        em["body_fetched"] = 1
            except asyncio.TimeoutError:
                em["body_fetch_error"] = f"IMAP fetch timed out after {BODY_FETCH_TIMEOUT}s (uid={em['uid']}, folder={fld['path']})"
            except Exception as e:
                em["body_fetch_error"] = f"{type(e).__name__}: {e}"
    if not em["is_read"]:
        await db.exec_q("UPDATE emails SET is_read=1 WHERE id=?", [email_id])
        await db.exec_q("UPDATE folders SET unread_count=MAX(0,unread_count-1) WHERE id=?", [em["folder_id"]])
        asyncio.create_task(_sync_imap_read(em["account_id"], em["folder_id"], em["uid"]))
    atts = await db.fetch_all("SELECT id,filename,content_type,size FROM attachments WHERE email_id=?", [email_id])
    em["attachments"] = [dict(a) for a in atts]
    if em.get("ics_uid"):
        ev = await db.fetch_one("SELECT * FROM calendar_events WHERE uid=? AND (email_id=? OR account_id=?)", [em["ics_uid"], email_id, em["account_id"]])
        em["calendar_event"] = ev
    return em
@router.get("/{email_id}/trust")
async def get_trust(email_id: int):
    row = await db.fetch_one("SELECT id, account_id, from_addr, from_name, reply_to, body_html, auth_results, thread_id FROM emails WHERE id=?", [email_id])
    if not row:
        raise HTTPException(404, "Email not found")
    is_list = bool(await db.fetch_one("SELECT 1 FROM emails WHERE id=? AND (unsubscribe_uri IS NOT NULL AND unsubscribe_uri != '')", [email_id]))
    row['is_list'] = is_list
    hist = await db.fetch_one("SELECT COUNT(*) AS count, MIN(date) AS first_seen FROM emails WHERE from_addr=? AND account_id=?", [row['from_addr'], row['account_id']])
    own = await db.fetch_one("SELECT email FROM accounts WHERE id=?", [row['account_id']])
    own_addr = (own or {}).get('email', '') or ''
    replied = 0
    if row.get('thread_id') and own_addr:
        rep = await db.fetch_one("SELECT COUNT(*) AS n FROM emails WHERE thread_id=? AND from_addr=?", [row['thread_id'], own_addr])
        replied = int((rep or {}).get('n') or 0)
    history = {'count': int((hist or {}).get('count') or 0) - 1, 'first_seen': (hist or {}).get('first_seen') or '', 'replied': replied}
    if history['count'] < 0: history['count'] = 0
    return compute_trust(row, history)
@router.get("/{email_id}/thread")
async def get_thread(email_id: int):
    em = await db.fetch_one("SELECT thread_id, account_id FROM emails WHERE id=?", [email_id])
    if not em or not em["thread_id"]:
        raise HTTPException(404, "No thread found")
    return await db.fetch_all(
        "SELECT id,from_addr,from_name,to_addrs,subject,date,preview,is_read,is_starred,has_attachments,ai_category,folder_id FROM emails WHERE thread_id=? AND account_id=? AND is_deleted=0 ORDER BY date ASC",
        [em["thread_id"], em["account_id"]])
@router.post("/snooze")
async def snooze_emails(data: SnoozeAction):
    if not data.email_ids:
        return {"snoozed": 0}
    try:
        until_dt = datetime.fromisoformat(data.until.replace("Z", "+00:00"))
    except Exception:
        raise HTTPException(400, "Invalid until (ISO 8601 required)")
    ph = ",".join("?" for _ in data.email_ids)
    await db.exec_q(f"UPDATE emails SET snoozed_until=? WHERE id IN ({ph})", [until_dt.isoformat()] + data.email_ids)
    return {"snoozed": len(data.email_ids), "until": until_dt.isoformat()}
@router.post("/unsnooze")
async def unsnooze_emails(data: BulkAction):
    if not data.email_ids:
        return {"unsnoozed": 0}
    ph = ",".join("?" for _ in data.email_ids)
    await db.exec_q(f"UPDATE emails SET snoozed_until=NULL WHERE id IN ({ph})", data.email_ids)
    return {"unsnoozed": len(data.email_ids)}
async def _perform_unsubscribe(em: dict) -> dict:
    uri = (em.get("unsubscribe_uri") or "").strip()
    if not uri:
        return {"ok": False, "error": "No unsubscribe link found", "uri": ""}
    post_hdr = (em.get("unsubscribe_post") or "")
    try:
        if uri.lower().startswith(("http://", "https://")):
            async with httpx.AsyncClient(timeout=10.0, follow_redirects=True) as client:
                r = await client.post(uri, data={"List-Unsubscribe": "One-Click"}) if "one-click" in post_hdr.lower() else await client.get(uri)
                return {"method": "http", "status_code": r.status_code, "ok": 200 <= r.status_code < 400, "uri": uri}
        if uri.lower().startswith("mailto:"):
            parsed = urllib.parse.urlparse(uri)
            qs = urllib.parse.parse_qs(parsed.query)
            subject = qs.get("subject", ["unsubscribe"])[0]
            body = qs.get("body", [""])[0]
            acc = await db.fetch_one("SELECT * FROM accounts WHERE id=?", [em["account_id"]])
            if not acc:
                return {"ok": False, "error": "Account not found", "uri": uri}
            await smtp_client.send_email(acc, parsed.path, subject, f"<p>{body}</p>", body)
            return {"method": "mailto", "ok": True, "to": parsed.path, "uri": uri}
        return {"ok": False, "error": f"Unsupported scheme: {uri}", "uri": uri}
    except Exception as e:
        return {"ok": False, "error": str(e), "uri": uri}
@router.post("/{email_id}/unsubscribe")
async def unsubscribe(email_id: int):
    em = await db.fetch_one("SELECT id, account_id, from_addr, unsubscribe_uri, unsubscribe_post FROM emails WHERE id=?", [email_id])
    if not em:
        raise HTTPException(404, "Email not found")
    em = dict(em)
    if not (em.get("unsubscribe_uri") or "").strip():
        raise HTTPException(400, "No unsubscribe link found (header or body)")
    return await _perform_unsubscribe(em)
@router.get("/subscriptions/list")
async def list_subscriptions(account_id: Optional[int] = None, limit: int = 500):
    sql = ("SELECT from_addr, MAX(from_name) AS from_name, COUNT(*) AS count, "
           "SUM(CASE WHEN is_read=0 THEN 1 ELSE 0 END) AS unread, "
           "MAX(date) AS last_seen, MIN(date) AS first_seen, "
           "MAX(id) AS sample_id, MAX(account_id) AS account_id "
           "FROM emails WHERE is_deleted=0 AND unsubscribe_uri IS NOT NULL AND unsubscribe_uri != ''")
    params: list = []
    if account_id:
        sql += " AND account_id=?"
        params.append(account_id)
    sql += " GROUP BY from_addr ORDER BY count DESC LIMIT ?"
    params.append(limit)
    return await db.fetch_all(sql, params)
@router.post("/subscriptions/backfill")
async def backfill_unsubscribe(account_id: Optional[int] = None, limit: int = 5000):
    sql = ("SELECT id, body_html, body_text FROM emails WHERE is_deleted=0 "
           "AND (unsubscribe_uri IS NULL OR unsubscribe_uri='') "
           "AND (is_list=1 OR LOWER(COALESCE(body_text,'')||COALESCE(body_html,'')) LIKE '%unsubscribe%')")
    params: list = []
    if account_id:
        sql += " AND account_id=?"
        params.append(account_id)
    sql += " ORDER BY id DESC LIMIT ?"
    params.append(max(1, min(20000, int(limit))))
    rows = await db.fetch_all(sql, params)
    found = 0
    sem = asyncio.Semaphore(16)
    async def scan_one(r):
        nonlocal found
        async with sem:
            uri = _scan_body_unsub(r.get("body_html") or "", r.get("body_text") or "")
            if uri:
                await db.exec_q("UPDATE emails SET unsubscribe_uri=? WHERE id=? AND (unsubscribe_uri IS NULL OR unsubscribe_uri='')", [uri, r["id"]])
                found += 1
    await asyncio.gather(*(scan_one(r) for r in rows), return_exceptions=True)
    return {"scanned": len(rows), "found": found}
class BulkUnsub(BaseModel):
    senders: list[str]
    archive_past: bool = False
    delete_past: bool = False
    account_id: Optional[int] = None
@router.post("/subscriptions/bulk-unsub")
async def bulk_unsubscribe(data: BulkUnsub):
    senders = [s for s in (data.senders or []) if s][:500]
    if not senders:
        return {"results": [], "archived": 0, "deleted": 0}
    sem = asyncio.Semaphore(8)
    results: list[dict] = []
    async def run_one(sender: str):
        async with sem:
            sql = ("SELECT id, account_id, from_addr, unsubscribe_uri, unsubscribe_post FROM emails "
                   "WHERE from_addr=? AND unsubscribe_uri IS NOT NULL AND unsubscribe_uri != '' AND is_deleted=0")
            params = [sender]
            if data.account_id:
                sql += " AND account_id=?"
                params.append(data.account_id)
            sql += " ORDER BY date DESC LIMIT 1"
            em = await db.fetch_one(sql, params)
            if not em:
                results.append({"sender": sender, "ok": False, "error": "no email with unsubscribe URI"})
                return
            res = await _perform_unsubscribe(dict(em))
            res["sender"] = sender
            results.append(res)
    await asyncio.gather(*(run_one(s) for s in senders), return_exceptions=True)
    archived = deleted = 0
    if data.archive_past or data.delete_past:
        ph = ",".join("?" for _ in senders)
        scope_sql = f"FROM emails e JOIN folders f ON e.folder_id=f.id WHERE e.from_addr IN ({ph}) AND e.is_deleted=0"
        scope_params = list(senders)
        if data.account_id:
            scope_sql += " AND e.account_id=?"
            scope_params.append(data.account_id)
        rows = await db.fetch_all(f"SELECT e.id AS eid, e.uid AS euid, e.account_id AS eaid, f.path AS folder_path {scope_sql}", scope_params)
        ids = [r["eid"] for r in rows]
        if ids:
            id_ph = ",".join("?" for _ in ids)
            if data.delete_past:
                await db.exec_q(f"DELETE FROM emails WHERE id IN ({id_ph})", ids)
                deleted = len(ids)
                by_folder: dict = {}
                for r in rows:
                    by_folder.setdefault((r["eaid"], r["folder_path"]), []).append(r["euid"])
                for (aid, fpath), uids in by_folder.items():
                    asyncio.create_task(_imap_delete_bg(aid, fpath, uids))
            elif data.archive_past:
                arch_map: dict = {}
                for r in rows:
                    arch = await db.fetch_one("SELECT id, path FROM folders WHERE account_id=? AND folder_type='archive' LIMIT 1", [r["eaid"]])
                    if arch:
                        arch_map.setdefault((r["eaid"], r["folder_path"], arch["id"], arch["path"]), []).append((r["eid"], r["euid"]))
                for (aid, fpath, dest_id, dest_path), pairs in arch_map.items():
                    eids = [p[0] for p in pairs]
                    uids = [p[1] for p in pairs]
                    eid_ph = ",".join("?" for _ in eids)
                    await db.exec_q(f"UPDATE emails SET folder_id=? WHERE id IN ({eid_ph})", [dest_id] + eids)
                    archived += len(eids)
                    async def _bg(aid, fpath, uids, dpath):
                        try:
                            acc = await db.fetch_one("SELECT * FROM accounts WHERE id=?", [aid])
                            if acc:
                                await asyncio.wait_for(imap_client.batch_move(acc, fpath, uids, dpath), timeout=30)
                        except Exception:
                            pass
                    asyncio.create_task(_bg(aid, fpath, uids, dest_path))
    return {"results": results, "archived": archived, "deleted": deleted, "ok_count": sum(1 for r in results if r.get("ok"))}
async def _imap_delete_bg(aid: int, fpath: str, uids: list):
    try:
        acc = await db.fetch_one("SELECT * FROM accounts WHERE id=?", [aid])
        if acc:
            await asyncio.wait_for(imap_client.batch_delete(acc, fpath, uids), timeout=30)
    except Exception:
        pass
async def _execute_deferred() -> int:
    rows = await db.fetch_all("SELECT * FROM deferred_actions WHERE status='pending' AND expires_at <= ?",
        [datetime.now(timezone.utc).isoformat()])
    committed = 0
    for r in rows:
        try:
            payload = json.loads(r["payload"] or "{}")
            ids = payload.get("email_ids", []) or []
            if r["kind"] == "delete" and ids:
                emails = await db.fetch_all(
                    f"SELECT e.id as eid, e.uid as euid, e.account_id as eaid, f.path as folder_path FROM emails e JOIN folders f ON e.folder_id=f.id WHERE e.id IN ({','.join('?' for _ in ids)})",
                    ids)
                by_folder = {}
                for em in emails:
                    by_folder.setdefault((em["eaid"], em["folder_path"]), []).append(em["euid"])
                await db.exec_q(f"DELETE FROM emails WHERE id IN ({','.join('?' for _ in ids)})", ids)
                for (aid, fpath), uids in by_folder.items():
                    asyncio.create_task(_imap_delete_bg(aid, fpath, uids))
            elif r["kind"] == "move" and ids:
                dest = payload.get("dest_folder_id")
                if dest is not None:
                    dest_row = await db.fetch_one("SELECT path FROM folders WHERE id=?", [dest])
                    emails = await db.fetch_all(
                        f"SELECT e.uid, e.account_id, f.path as folder_path FROM emails e JOIN folders f ON e.folder_id=f.id WHERE e.id IN ({','.join('?' for _ in ids)})",
                        ids)
                    by_folder = {}
                    for em in emails:
                        by_folder.setdefault((em["account_id"], em["folder_path"]), []).append(em["uid"])
                    await db.exec_q(f"UPDATE emails SET folder_id=? WHERE id IN ({','.join('?' for _ in ids)})", [dest] + ids)
                    if dest_row:
                        for (aid, fpath), uids in by_folder.items():
                            async def _bg_move(aid, fpath, uids, dpath):
                                try:
                                    acc = await db.fetch_one("SELECT * FROM accounts WHERE id=?", [aid])
                                    if acc: await asyncio.wait_for(imap_client.batch_move(acc, fpath, uids, dpath), timeout=30)
                                except Exception: pass
                            asyncio.create_task(_bg_move(aid, fpath, uids, dest_row["path"]))
            await db.exec_q("UPDATE deferred_actions SET status='committed', executed_at=CURRENT_TIMESTAMP WHERE id=?", [r["id"]])
            committed += 1
        except Exception as _e:
            await db.exec_q("UPDATE deferred_actions SET status='failed', executed_at=CURRENT_TIMESTAMP WHERE id=?", [r["id"]])
    return committed
@router.post("/defer/delete")
async def defer_delete(data: BulkAction, seconds: int = 10):
    if not data.email_ids: return {"deferred": 0}
    seconds = max(2, min(seconds, 60))
    expires = (datetime.now(timezone.utc) + timedelta(seconds=seconds)).isoformat()
    cur = await db.exec_q("INSERT INTO deferred_actions (kind, payload, expires_at) VALUES (?,?,?)",
        ["delete", json.dumps({"email_ids": data.email_ids}), expires])
    return {"undo_token": cur.lastrowid, "kind": "delete", "expires_at": expires, "expires_in": seconds, "count": len(data.email_ids)}
@router.post("/defer/move")
async def defer_move(data: MoveAction, seconds: int = 10):
    if not data.email_ids: return {"deferred": 0}
    seconds = max(2, min(seconds, 60))
    prev = await db.fetch_all(
        f"SELECT id, folder_id FROM emails WHERE id IN ({','.join('?' for _ in data.email_ids)})",
        data.email_ids)
    prev_map = {r["id"]: r["folder_id"] for r in prev}
    expires = (datetime.now(timezone.utc) + timedelta(seconds=seconds)).isoformat()
    cur = await db.exec_q("INSERT INTO deferred_actions (kind, payload, expires_at) VALUES (?,?,?)",
        ["move", json.dumps({"email_ids": data.email_ids, "dest_folder_id": data.dest_folder_id, "prev_folders": prev_map}), expires])
    return {"undo_token": cur.lastrowid, "kind": "move", "expires_at": expires, "expires_in": seconds, "count": len(data.email_ids), "dest_folder_id": data.dest_folder_id}
@router.post("/undo/{token}")
async def undo_action(token: int):
    row = await db.fetch_one("SELECT * FROM deferred_actions WHERE id=?", [token])
    if not row: raise HTTPException(404, "Unknown undo token")
    if row["status"] != "pending": raise HTTPException(409, f"Cannot undo (status={row['status']})")
    await db.exec_q("UPDATE deferred_actions SET status='canceled', executed_at=CURRENT_TIMESTAMP WHERE id=?", [token])
    payload = json.loads(row["payload"] or "{}")
    return {"ok": True, "kind": row["kind"], "email_ids": payload.get("email_ids", [])}
@router.post("/delete")
async def bulk_delete(data: BulkAction):
    if not data.email_ids:
        return {"deleted": 0}
    emails = await db.fetch_all(
        f"SELECT e.id as eid, e.uid as euid, e.account_id as eaid, f.path as folder_path FROM emails e JOIN folders f ON e.folder_id=f.id WHERE e.id IN ({','.join('?' for _ in data.email_ids)})",
        data.email_ids)
    by_folder = {}
    for em in emails:
        key = (em["eaid"], em["folder_path"])
        by_folder.setdefault(key, []).append(em["euid"])
    placeholders = ",".join("?" for _ in data.email_ids)
    await db.exec_q(f"DELETE FROM emails WHERE id IN ({placeholders})", data.email_ids)
    for (aid, fpath), uids in by_folder.items():
        asyncio.create_task(_imap_delete_bg(aid, fpath, uids))
    return {"deleted": len(data.email_ids)}
@router.post("/move")
async def bulk_move(data: MoveAction):
    dest = await db.fetch_one("SELECT * FROM folders WHERE id=?", [data.dest_folder_id])
    if not dest:
        raise HTTPException(404, "Destination folder not found")
    emails = await db.fetch_all(
        f"SELECT e.uid, e.account_id, f.path as folder_path FROM emails e JOIN folders f ON e.folder_id=f.id WHERE e.id IN ({','.join('?' for _ in data.email_ids)})",
        data.email_ids)
    by_folder = {}
    for em in emails:
        key = (em["account_id"], em["folder_path"])
        by_folder.setdefault(key, []).append(em["uid"])
    placeholders = ",".join("?" for _ in data.email_ids)
    await db.exec_q(f"UPDATE emails SET folder_id=? WHERE id IN ({placeholders})", [data.dest_folder_id] + data.email_ids)
    async def _bg_move(aid, fpath, uids, dpath):
        try:
            acc = await db.fetch_one("SELECT * FROM accounts WHERE id=?", [aid])
            if acc:
                await asyncio.wait_for(imap_client.batch_move(acc, fpath, uids, dpath), timeout=30)
        except Exception:
            pass
    for (aid, fpath), uids in by_folder.items():
        asyncio.create_task(_bg_move(aid, fpath, uids, dest["path"]))
    return {"moved": len(data.email_ids)}
@router.post("/flag")
async def bulk_flag(data: FlagAction):
    flag_map = {"read": ("is_read", "\\Seen"), "starred": ("is_starred", "\\Flagged"), "pinned": ("is_pinned", None)}
    if data.flag not in flag_map:
        raise HTTPException(400, f"Invalid flag. Use: {list(flag_map.keys())}")
    col, imap_flag = flag_map[data.flag]
    val = 1 if data.add else 0
    emails = await db.fetch_all(
        f"SELECT e.uid, e.account_id, f.path as folder_path FROM emails e JOIN folders f ON e.folder_id=f.id WHERE e.id IN ({','.join('?' for _ in data.email_ids)})",
        data.email_ids)
    by_folder = {}
    for em in emails:
        key = (em["account_id"], em["folder_path"])
        by_folder.setdefault(key, []).append(em["uid"])
    placeholders = ",".join("?" for _ in data.email_ids)
    await db.exec_q(f"UPDATE emails SET {col}=? WHERE id IN ({placeholders})", [val] + data.email_ids)
    async def _bg_flag(aid, fpath, uids, flag, add):
        try:
            acc = await db.fetch_one("SELECT * FROM accounts WHERE id=?", [aid])
            if acc:
                await asyncio.wait_for(imap_client.batch_flag(acc, fpath, uids, flag, add), timeout=30)
        except Exception:
            pass
    if imap_flag:
        for (aid, fpath), uids in by_folder.items():
            asyncio.create_task(_bg_flag(aid, fpath, uids, imap_flag, data.add))
    return {"flagged": len(data.email_ids)}
@router.get("/stats/categories")
async def category_stats(account_id: Optional[int] = None):
    sql = "SELECT ai_category, COUNT(*) as count FROM emails WHERE is_deleted=0"
    params = []
    if account_id:
        sql += " AND account_id=?"
        params.append(account_id)
    sql += " GROUP BY ai_category ORDER BY count DESC"
    return await db.fetch_all(sql, params)
