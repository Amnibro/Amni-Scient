from fastapi import APIRouter, HTTPException
import db, imap_client
router = APIRouter(prefix="/api/folders", tags=["folders"])
@router.get("/{account_id}")
async def list_folders(account_id: int):
    return await db.fetch_all(
        "SELECT * FROM folders WHERE account_id=? ORDER BY folder_type, name",
        [account_id]
    )
@router.post("/{account_id}/sync")
async def sync_all_folders(account_id: int):
    acc = await db.fetch_one("SELECT * FROM accounts WHERE id=?", [account_id])
    if not acc:
        raise HTTPException(404, "Account not found")
    folders = await imap_client.list_folders(acc)
    synced = 0
    for f in folders:
        existing = await db.fetch_one("SELECT id FROM folders WHERE account_id=? AND path=?", [account_id, f["path"]])
        if not existing:
            cursor = await db.exec_q(
                "INSERT INTO folders (account_id, name, path, folder_type) VALUES (?,?,?,?)",
                [account_id, f["name"], f["path"], f["folder_type"]]
            )
            fid = cursor.lastrowid
        else:
            fid = existing["id"]
        count = await imap_client.sync_folder(acc, f["path"], fid)
        synced += count
    return {"synced": synced, "folders": len(folders)}
@router.post("/{account_id}/create")
async def create_folder(account_id: int, name: str):
    acc = await db.fetch_one("SELECT * FROM accounts WHERE id=?", [account_id])
    if not acc:
        raise HTTPException(404, "Account not found")
    client = await imap_client.get_imap(acc)
    await client.create(name)
    cursor = await db.exec_q(
        "INSERT INTO folders (account_id, name, path, folder_type) VALUES (?,?,?,?)",
        [account_id, name, name, "custom"]
    )
    return {"id": cursor.lastrowid, "name": name}
