from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional
from datetime import datetime
import json
import db, smtp_client
from ics_parser import build_reply
router = APIRouter(prefix="/api/calendar", tags=["calendar"])
class RSVPData(BaseModel):
    email_id: int
    partstat: str
    comment: str = ""
class FromDetectedData(BaseModel):
    email_id: int
    summary: str
    dtstart: str
    dtend: Optional[str] = None
    location: str = ""
    description: str = ""
class EventCreate(BaseModel):
    account_id: Optional[int] = None
    summary: str
    dtstart: str
    dtend: Optional[str] = None
    location: str = ""
    description: str = ""
@router.get("/events")
async def list_events(account_id: Optional[int] = None, start: Optional[str] = None, end: Optional[str] = None, limit: int = 500):
    sql = "SELECT * FROM calendar_events WHERE 1=1"
    params = []
    if account_id:
        sql += " AND account_id=?"
        params.append(account_id)
    if start:
        sql += " AND (dtstart >= ? OR dtend >= ?)"
        params.extend([start, start])
    if end:
        sql += " AND dtstart <= ?"
        params.append(end)
    sql += " ORDER BY dtstart ASC LIMIT ?"
    params.append(limit)
    rows = await db.fetch_all(sql, params)
    for r in rows:
        try:
            r["attendees"] = json.loads(r.get("attendees") or "[]")
        except Exception:
            r["attendees"] = []
    return rows
@router.get("/events/{event_id}")
async def get_event(event_id: int):
    ev = await db.fetch_one("SELECT * FROM calendar_events WHERE id=?", [event_id])
    if not ev:
        raise HTTPException(404, "Event not found")
    try:
        ev["attendees"] = json.loads(ev.get("attendees") or "[]")
    except Exception:
        ev["attendees"] = []
    return ev
@router.post("/events/from-detected")
async def create_from_detected(data: FromDetectedData):
    em = await db.fetch_one("SELECT id, account_id, from_addr FROM emails WHERE id=?", [data.email_id])
    if not em:
        raise HTTPException(404, "Email not found")
    try:
        datetime.fromisoformat(data.dtstart.replace("Z", "+00:00"))
        if data.dtend:
            datetime.fromisoformat(data.dtend.replace("Z", "+00:00"))
    except ValueError:
        raise HTTPException(400, "dtstart/dtend must be ISO 8601")
    uid = f"detected:{data.email_id}"
    existing = await db.fetch_one("SELECT id FROM calendar_events WHERE uid=? AND account_id=?", [uid, em["account_id"]])
    if existing:
        await db.exec_q(
            "UPDATE calendar_events SET summary=?, dtstart=?, dtend=?, location=?, description=?, email_id=?, organizer=?, method='DETECTED' WHERE id=?",
            [data.summary, data.dtstart, data.dtend, data.location, data.description, data.email_id, em.get("from_addr") or "", existing["id"]])
        eid = existing["id"]
    else:
        cur = await db.exec_q(
            "INSERT INTO calendar_events (account_id, email_id, uid, summary, dtstart, dtend, location, description, organizer, method, partstat, sequence) "
            "VALUES (?,?,?,?,?,?,?,?,?, 'DETECTED', 'ACCEPTED', 0)",
            [em["account_id"], data.email_id, uid, data.summary, data.dtstart, data.dtend, data.location, data.description, em.get("from_addr") or ""])
        eid = cur.lastrowid
    row = await db.fetch_one("SELECT * FROM calendar_events WHERE id=?", [eid])
    if row:
        try:
            row["attendees"] = json.loads(row.get("attendees") or "[]")
        except Exception:
            row["attendees"] = []
    return row
def _parse_iso(s: str):
    try:
        datetime.fromisoformat(s.replace("Z", "+00:00"))
    except ValueError:
        raise HTTPException(400, "dtstart/dtend must be ISO 8601")
def _attendees(row):
    if not row:
        return row
    try:
        row["attendees"] = json.loads(row.get("attendees") or "[]")
    except Exception:
        row["attendees"] = []
    return row
@router.post("/events")
async def create_event(data: EventCreate):
    if not (data.summary or "").strip():
        raise HTTPException(400, "summary required")
    _parse_iso(data.dtstart)
    if data.dtend:
        _parse_iso(data.dtend)
    aid = data.account_id
    if not aid:
        acc = await db.fetch_one("SELECT id FROM accounts ORDER BY id LIMIT 1")
        aid = acc["id"] if acc else None
    uid = f"local:{int(datetime.utcnow().timestamp()*1000)}"
    cur = await db.exec_q(
        "INSERT INTO calendar_events (account_id, email_id, uid, summary, dtstart, dtend, location, description, organizer, method, partstat, sequence) VALUES (?,?,?,?,?,?,?,?,?,?,?,0)",
        [aid, None, uid, data.summary.strip(), data.dtstart, data.dtend, data.location or "", data.description or "", "", "PUBLISH", "ACCEPTED"])
    row = await db.fetch_one("SELECT * FROM calendar_events WHERE id=?", [cur.lastrowid])
    return _attendees(row)
@router.delete("/events/{event_id}")
async def delete_event(event_id: int):
    ev = await db.fetch_one("SELECT id FROM calendar_events WHERE id=?", [event_id])
    if not ev:
        raise HTTPException(404, "Event not found")
    await db.exec_q("DELETE FROM calendar_events WHERE id=?", [event_id])
    return {"deleted": True}
@router.post("/rsvp")
async def rsvp(data: RSVPData):
    valid = {"ACCEPTED", "DECLINED", "TENTATIVE"}
    partstat = data.partstat.upper()
    if partstat not in valid:
        raise HTTPException(400, f"partstat must be one of {valid}")
    em = await db.fetch_one("SELECT id, account_id, ics_uid FROM emails WHERE id=?", [data.email_id])
    if not em or not em.get("ics_uid"):
        raise HTTPException(404, "Email has no ICS invite")
    ev = await db.fetch_one("SELECT * FROM calendar_events WHERE uid=? AND account_id=?", [em["ics_uid"], em["account_id"]])
    if not ev:
        raise HTTPException(404, "Calendar event not found")
    acc = await db.fetch_one("SELECT * FROM accounts WHERE id=?", [em["account_id"]])
    if not acc:
        raise HTTPException(404, "Account not found")
    event = {"uid": ev["uid"], "summary": ev.get("summary") or "", "organizer": ev.get("organizer") or "",
             "dtstart": ev.get("dtstart"), "sequence": ev.get("sequence") or 0}
    ics_body = build_reply(event, acc["email"], acc.get("name") or acc["email"], partstat, data.comment)
    organizer = ev.get("organizer") or ""
    if not organizer:
        raise HTTPException(400, "Event has no organizer")
    subject = f"{partstat.title()}: {event['summary']}"
    try:
        await smtp_client.send_rsvp(acc, organizer, subject, ics_body, data.comment)
        await db.exec_q("UPDATE calendar_events SET partstat=? WHERE id=?", [partstat, ev["id"]])
        return {"status": "sent", "partstat": partstat, "to": organizer}
    except Exception as e:
        raise HTTPException(500, f"RSVP send failed: {e}")
