from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional
from datetime import datetime, timedelta, timezone
import db
router = APIRouter(prefix="/api/followups", tags=["followups"])
class CreateRequest(BaseModel):
    email_id: int
    remind_in_hours: Optional[int] = None
    remind_at: Optional[str] = None
    note: Optional[str] = None
class SnoozeRequest(BaseModel):
    remind_in_hours: int = 24
def _now() -> datetime:
    return datetime.now(timezone.utc)
def _parse_iso(s: str) -> datetime:
    s = s.replace("Z", "+00:00")
    return datetime.fromisoformat(s)
@router.post("/create")
async def create_followup(req: CreateRequest):
    em_rows = await db.fetch_all("SELECT id, account_id, thread_id, message_id, subject, from_addr, sent_at FROM emails WHERE id=?", [req.email_id])
    if not em_rows: raise HTTPException(404, "Email not found")
    em = em_rows[0]
    if req.remind_at:
        try: ra = _parse_iso(req.remind_at)
        except Exception: raise HTTPException(400, "Invalid remind_at ISO 8601")
    elif req.remind_in_hours is not None:
        if req.remind_in_hours < 1 or req.remind_in_hours > 24*90: raise HTTPException(400, "remind_in_hours out of range (1..2160)")
        ra = _now() + timedelta(hours=req.remind_in_hours)
    else:
        ra = _now() + timedelta(days=3)
    await db.exec_q("INSERT INTO follow_ups (email_id, account_id, thread_id, message_id, remind_at, status, note) VALUES (?,?,?,?,?,?,?)",
        [em["id"], em.get("account_id"), em.get("thread_id"), em.get("message_id"), ra.isoformat(), "pending", req.note])
    return {"ok": True, "remind_at": ra.isoformat()}
@router.get("/list")
async def list_followups(status: str = "pending", account_id: Optional[int] = None, due_only: bool = False, limit: int = 200):
    if status not in {"pending", "resolved", "dismissed", "all"}: raise HTTPException(400, "bad status")
    q = "SELECT f.*, e.subject as email_subject, e.from_addr as email_from, e.preview as email_preview, e.account_id as email_account FROM follow_ups f LEFT JOIN emails e ON e.id=f.email_id WHERE 1=1"
    params: list = []
    if status != "all":
        q += " AND f.status=?"; params.append(status)
    if account_id is not None:
        q += " AND f.account_id=?"; params.append(account_id)
    if due_only:
        q += " AND f.remind_at<=?"; params.append(_now().isoformat())
    q += " ORDER BY f.remind_at ASC LIMIT ?"; params.append(min(max(limit, 1), 500))
    rows = await db.fetch_all(q, params)
    return {"items": rows, "now": _now().isoformat()}
@router.get("/due-count")
async def due_count(account_id: Optional[int] = None):
    q = "SELECT COUNT(*) as n FROM follow_ups WHERE status='pending' AND remind_at<=?"
    params: list = [_now().isoformat()]
    if account_id is not None:
        q += " AND account_id=?"; params.append(account_id)
    rows = await db.fetch_all(q, params)
    return {"due": (rows[0]["n"] if rows else 0)}
@router.post("/{fid}/dismiss")
async def dismiss(fid: int):
    await db.exec_q("UPDATE follow_ups SET status='dismissed', resolved_at=? WHERE id=?", [_now().isoformat(), fid])
    return {"ok": True}
@router.post("/{fid}/snooze")
async def snooze(fid: int, req: SnoozeRequest):
    if req.remind_in_hours < 1 or req.remind_in_hours > 24*90: raise HTTPException(400, "remind_in_hours out of range")
    new_at = (_now() + timedelta(hours=req.remind_in_hours)).isoformat()
    await db.exec_q("UPDATE follow_ups SET remind_at=?, status='pending' WHERE id=?", [new_at, fid])
    return {"ok": True, "remind_at": new_at}
@router.delete("/{fid}")
async def delete_followup(fid: int):
    await db.exec_q("DELETE FROM follow_ups WHERE id=?", [fid])
    return {"ok": True}
@router.post("/auto-resolve")
async def auto_resolve():
    pending = await db.fetch_all("SELECT id, email_id, thread_id, message_id, account_id FROM follow_ups WHERE status='pending'")
    resolved = 0
    for f in pending:
        if not f.get("thread_id") and not f.get("message_id"): continue
        sent_row = await db.fetch_all("SELECT sent_at FROM emails WHERE id=?", [f["email_id"]])
        if not sent_row: continue
        sent_at = sent_row[0]["sent_at"]
        q = "SELECT id FROM emails WHERE folder_type!='sent' AND folder_type!='drafts' AND sent_at>? AND ("
        params: list = [sent_at]
        clauses = []
        if f.get("thread_id"):
            clauses.append("thread_id=?"); params.append(f["thread_id"])
        if f.get("message_id"):
            clauses.append("in_reply_to=?"); params.append(f["message_id"])
            clauses.append("references_hdr LIKE ?"); params.append(f"%{f['message_id']}%")
        q += " OR ".join(clauses) + ") LIMIT 1"
        replies = await db.fetch_all(q, params)
        if replies:
            await db.exec_q("UPDATE follow_ups SET status='resolved', resolved_at=? WHERE id=?", [_now().isoformat(), f["id"]])
            resolved += 1
    return {"resolved": resolved, "checked": len(pending)}
