from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional, List
import json
import db
router = APIRouter(prefix="/api/ooo", tags=["ooo"])
class OOOUpdate(BaseModel):
    enabled: Optional[bool] = None
    subject: Optional[str] = None
    body: Optional[str] = None
    start_at: Optional[str] = None
    end_at: Optional[str] = None
    exclude_domains: Optional[List[str]] = None
@router.get("/{account_id}")
async def get_ooo(account_id: int):
    row = await db.fetch_one("SELECT * FROM ooo_settings WHERE account_id=?", [account_id])
    if not row:
        return {"account_id": account_id, "enabled": 0, "subject": "Out of office", "body": "",
                "start_at": None, "end_at": None, "exclude_domains": []}
    try:
        row["exclude_domains"] = json.loads(row.get("exclude_domains") or "[]")
    except Exception:
        row["exclude_domains"] = []
    return row
@router.patch("/{account_id}")
async def update_ooo(account_id: int, data: OOOUpdate):
    acc = await db.fetch_one("SELECT id FROM accounts WHERE id=?", [account_id])
    if not acc:
        raise HTTPException(404, "Account not found")
    existing = await db.fetch_one("SELECT account_id FROM ooo_settings WHERE account_id=?", [account_id])
    if not existing:
        await db.exec_q("INSERT INTO ooo_settings (account_id) VALUES (?)", [account_id])
    payload = data.model_dump(exclude_none=True)
    if "enabled" in payload:
        payload["enabled"] = 1 if payload["enabled"] else 0
    if "exclude_domains" in payload:
        payload["exclude_domains"] = json.dumps(payload["exclude_domains"])
    if payload:
        cols = ",".join(f"{k}=?" for k in payload)
        await db.exec_q(f"UPDATE ooo_settings SET {cols} WHERE account_id=?", list(payload.values()) + [account_id])
    return await get_ooo(account_id)
@router.get("/{account_id}/log")
async def get_log(account_id: int, limit: int = 100):
    return await db.fetch_all("SELECT sender, sent_at FROM ooo_sent_log WHERE account_id=? ORDER BY sent_at DESC LIMIT ?", [account_id, limit])
