import asyncio
import sys
sys.path.insert(0, '.')
from routes.accounts import create_account, AccountCreate
import db
import auth

async def test():
    await db.get_db()
    data = AccountCreate(
        name="test",
        email="test2@gmail.com",
        password="test",
        auth_type="password",
        color="#ffffff"
    )
    try:
        res = await create_account(data)
        print("Success:", res)
    except Exception as e:
        import traceback
        traceback.print_exc()
    await db.close_db()

asyncio.run(test())
