import sqlite3, sys, time
from pathlib import Path
DB = Path(__file__).parent.parent / "data" / "amni_mail2.db"
print(f"Opening {DB} ({DB.stat().st_size / 1e6:.1f} MB)")
conn = sqlite3.connect(str(DB))
conn.execute("PRAGMA journal_mode=WAL")
print("Checkpointing WAL...")
r = conn.execute("PRAGMA wal_checkpoint(TRUNCATE)").fetchone()
print(f"  checkpoint result: {r}")
for fts, content, cols in [
    ("emails_fts",      "emails",      "subject, from_addr, from_name, body_text, preview"),
    ("attachments_fts", "attachments", "filename, extracted_text"),
]:
    print(f"\n[{fts}] dropping and recreating from {content}...")
    t0 = time.time()
    conn.execute(f"DROP TABLE IF EXISTS {fts}")
    conn.execute(f"CREATE VIRTUAL TABLE {fts} USING fts5({cols}, content='{content}', content_rowid='id')")
    print(f"  rebuilding index ({cols})...")
    conn.execute(f"INSERT INTO {fts}({fts}) VALUES('rebuild')")
    conn.commit()
    print(f"  done in {time.time() - t0:.1f}s")
print("\nFinal integrity_check:")
for row in conn.execute("PRAGMA integrity_check(5)").fetchall(): print(" ", row[0])
print("\nVacuuming...")
conn.execute("VACUUM")
conn.close()
print(f"Done. DB size now {DB.stat().st_size / 1e6:.1f} MB")
