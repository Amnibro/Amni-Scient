from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional
from pathlib import Path
from urllib.parse import urlparse
import httpx, os, sys, subprocess, json
import db, ai_engine
from config import cfg
router = APIRouter(prefix="/api/ai", tags=["ai"])
_AMNI_AI_PROC = None
def _find_amni_ai():
    env = os.environ.get("AMNI_AI_HOME")
    cands = [Path(env)] if env else []
    home = Path.home()
    cands += [home/"Documents"/"ai"/"Amni-Ai", home/"Amni-Ai", Path(__file__).resolve().parents[3]/"Amni-Ai"]
    return next((p for p in cands if p.is_dir() and ((p/"run.bat").exists() or (p/"amni").is_dir())), None)
def _list_models(root):
    md = root/"models"
    if not md.is_dir(): return []
    out = []
    for p in sorted(md.iterdir()):
        if p.is_dir() and (p/"config.json").exists():
            out.append({"name": p.name, "kind": "hf"})
        elif p.is_file() and p.suffix.lower() == ".gguf":
            out.append({"name": p.name, "kind": "gguf", "size_mb": round(p.stat().st_size/1048576, 1)})
    return out
def _port_from_url(url: str, default: int = 7700) -> int:
    try:
        p = urlparse(url).port
        return p if p else default
    except Exception:
        return default
def _host_from_url(url: str, default: str = "localhost") -> str:
    try:
        return urlparse(url).hostname or default
    except Exception:
        return default
async def _probe_running(url: str = None):
    target = url or cfg.ai_url
    try:
        async with httpx.AsyncClient(timeout=2.0) as c:
            r = await c.get(f"{target.rstrip('/')}/health")
            return r.status_code == 200
    except Exception:
        return False
class CategorizeRequest(BaseModel):
    email_ids: list[int]
class DraftRequest(BaseModel):
    email_id: int
    instructions: str = ""
class StartRequest(BaseModel):
    port: Optional[int] = None
    host: Optional[str] = None
    extra_args: list[str] = []
class TransformRequest(BaseModel):
    op: str
    text: str
    params: dict = {}
class CompleteRequest(BaseModel):
    prefix: str
    context: str = ""
class TemplateCreate(BaseModel):
    name: str
    category: str = "general"
    body: str
    trigger: Optional[str] = None
class TemplateUpdate(BaseModel):
    name: Optional[str] = None
    category: Optional[str] = None
    body: Optional[str] = None
    trigger: Optional[str] = None
class ApplyTemplateRequest(BaseModel):
    context: str = ""
@router.post("/categorize")
async def categorize_emails(data: CategorizeRequest):
    results = []
    for eid in data.email_ids:
        em = await db.fetch_one("SELECT id,subject,from_addr,preview FROM emails WHERE id=?", [eid])
        if not em:
            continue
        cat = await ai_engine.categorize_email(em["subject"], em["from_addr"], em["preview"])
        await db.exec_q("UPDATE emails SET ai_category=?, ai_priority=? WHERE id=?",
                       [cat.get("category", "unknown"), cat.get("priority", 3), eid])
        await db.exec_q("INSERT OR REPLACE INTO ai_cache (email_id,category,priority) VALUES (?,?,?)",
                       [eid, cat.get("category", "unknown"), cat.get("priority", 3)])
        results.append({"id": eid, **cat})
    return results
@router.post("/summarize-thread/{email_id}")
async def summarize_thread_endpoint(email_id: int, force: bool = False):
    em = await db.fetch_one("SELECT thread_id, account_id FROM emails WHERE id=?", [email_id])
    if not em or not em["thread_id"]:
        raise HTTPException(404, "No thread")
    msgs = await db.fetch_all(
        "SELECT id, from_addr, from_name, to_addrs, subject, date, body_text, preview FROM emails WHERE thread_id=? AND account_id=? AND is_deleted=0 ORDER BY date ASC",
        [em["thread_id"], em["account_id"]]
    )
    if len(msgs) < 2:
        raise HTTPException(400, "Thread has too few messages to summarize")
    last_date = msgs[-1]["date"] or ""
    if not force:
        cached = await db.fetch_one(
            "SELECT summary_json, last_message_date, message_count FROM thread_summaries WHERE account_id=? AND thread_id=?",
            [em["account_id"], em["thread_id"]]
        )
        if cached and cached["last_message_date"] == last_date and cached["message_count"] == len(msgs):
            try:
                return {"summary": json.loads(cached["summary_json"]), "cached": True, "message_count": len(msgs)}
            except Exception:
                pass
    summary = await ai_engine.summarize_thread_structured([dict(m) for m in msgs])
    try:
        await db.exec_q(
            "INSERT INTO thread_summaries (account_id, thread_id, last_message_date, message_count, summary_json) VALUES (?,?,?,?,?) ON CONFLICT(account_id, thread_id) DO UPDATE SET last_message_date=excluded.last_message_date, message_count=excluded.message_count, summary_json=excluded.summary_json, created_at=CURRENT_TIMESTAMP",
            [em["account_id"], em["thread_id"], last_date, len(msgs), json.dumps(summary)]
        )
    except Exception:
        pass
    return {"summary": summary, "cached": False, "message_count": len(msgs)}
@router.get("/summarize/{email_id}")
async def summarize(email_id: int):
    em = await db.fetch_one("SELECT * FROM emails WHERE id=?", [email_id])
    if not em:
        raise HTTPException(404, "Email not found")
    cached = await db.fetch_one("SELECT summary FROM ai_cache WHERE email_id=? AND summary IS NOT NULL", [email_id])
    if cached and cached["summary"]:
        return {"summary": cached["summary"]}
    thread = await db.fetch_all(
        "SELECT from_addr,date,subject,body_text,preview FROM emails WHERE thread_id=? ORDER BY date",
        [em["thread_id"] or em["message_id"]]
    )
    if len(thread) <= 1:
        thread = [em]
    summary = await ai_engine.summarize_thread(thread)
    await db.exec_q("UPDATE ai_cache SET summary=? WHERE email_id=?", [summary, email_id])
    await db.exec_q("UPDATE emails SET ai_summary=? WHERE id=?", [summary, email_id])
    return {"summary": summary}
@router.post("/draft-reply")
async def draft_reply(data: DraftRequest):
    em = await db.fetch_one("SELECT * FROM emails WHERE id=?", [data.email_id])
    if not em:
        raise HTTPException(404, "Email not found")
    profile = None
    acc = await db.fetch_one("SELECT voice_profile FROM accounts WHERE id=?", [em["account_id"]])
    if acc and acc.get("voice_profile"):
        import json as _j
        try:
            profile = _j.loads(acc["voice_profile"])
        except (ValueError, TypeError):
            profile = None
    return {"draft": await ai_engine.draft_reply(em, data.instructions, profile)}
@router.get("/voice-profile/{account_id}")
async def get_voice_profile(account_id: int):
    acc = await db.fetch_one("SELECT voice_profile, voice_updated_at FROM accounts WHERE id=?", [account_id])
    if not acc:
        raise HTTPException(404, "Account not found")
    profile = None
    if acc.get("voice_profile"):
        import json as _j
        try:
            profile = _j.loads(acc["voice_profile"])
        except (ValueError, TypeError):
            profile = None
    return {"profile": profile, "updated_at": acc.get("voice_updated_at")}
@router.post("/voice-profile/{account_id}/refresh")
async def refresh_voice_profile(account_id: int, sample_size: int = 40):
    acc = await db.fetch_one("SELECT id FROM accounts WHERE id=?", [account_id])
    if not acc:
        raise HTTPException(404, "Account not found")
    sample_size = max(5, min(80, sample_size))
    rows = await db.fetch_all(
        "SELECT body_text FROM emails e JOIN folders f ON e.folder_id=f.id "
        "WHERE e.account_id=? AND f.folder_type='sent' AND e.body_fetched=1 "
        "AND e.body_text IS NOT NULL AND LENGTH(e.body_text) > 30 "
        "ORDER BY e.date DESC LIMIT ?", [account_id, sample_size])
    bodies = [r.get("body_text") or "" for r in rows]
    if not bodies:
        return {"profile": None, "sampled": 0, "note": "No sent emails available — sync first."}
    profile = await ai_engine.derive_voice_profile(bodies)
    if not profile:
        return {"profile": None, "sampled": len(bodies), "note": "LLM did not return a usable profile."}
    import json as _j
    payload = _j.dumps(profile)
    await db.exec_q("UPDATE accounts SET voice_profile=?, voice_updated_at=CURRENT_TIMESTAMP WHERE id=?", [payload, account_id])
    row = await db.fetch_one("SELECT voice_updated_at FROM accounts WHERE id=?", [account_id])
    return {"profile": profile, "sampled": len(bodies), "updated_at": (row or {}).get("voice_updated_at")}
@router.get("/detect-event/{email_id}")
async def detect_event(email_id: int):
    em = await db.fetch_one("SELECT id,subject,from_addr,body_text,preview,ics_uid FROM emails WHERE id=?", [email_id])
    if not em:
        raise HTTPException(404, "Email not found")
    if em.get("ics_uid"):
        return {"has_event": False, "skipped": "real_ics"}
    cached = await db.fetch_one("SELECT detected_event FROM ai_cache WHERE email_id=?", [email_id])
    if cached and cached.get("detected_event"):
        import json as _j
        try:
            return _j.loads(cached["detected_event"])
        except (ValueError, TypeError):
            pass
    result = await ai_engine.detect_event(dict(em))
    import json as _j
    payload = _j.dumps(result)
    await db.exec_q(
        "INSERT INTO ai_cache (email_id, detected_event) VALUES (?, ?) "
        "ON CONFLICT(email_id) DO UPDATE SET detected_event=excluded.detected_event",
        [email_id, payload])
    return result
@router.get("/actions/{email_id}")
async def extract_actions(email_id: int):
    em = await db.fetch_one("SELECT * FROM emails WHERE id=?", [email_id])
    if not em:
        raise HTTPException(404, "Email not found")
    cached = await db.fetch_one("SELECT action_items FROM ai_cache WHERE email_id=? AND action_items IS NOT NULL", [email_id])
    if cached and cached["action_items"]:
        return {"actions": cached["action_items"]}
    actions = await ai_engine.extract_actions(em)
    await db.exec_q("INSERT OR REPLACE INTO ai_cache (email_id,action_items) VALUES (?,?)", [email_id, actions])
    return {"actions": actions}
@router.post("/complete")
async def complete(data: CompleteRequest):
    if not data.prefix.strip() or len(data.prefix) < 4:
        return {"suggestion": ""}
    return {"suggestion": await ai_engine.complete(data.prefix, data.context)}
@router.get("/quick-replies/{email_id}")
async def quick_replies(email_id: int):
    em = await db.fetch_one("SELECT * FROM emails WHERE id=?", [email_id])
    if not em:
        raise HTTPException(404, "Email not found")
    return {"replies": await ai_engine.quick_replies(em)}
@router.post("/smart-cleanup")
async def smart_cleanup(folder_id: int, limit: int = 50):
    emails = await db.fetch_all(
        "SELECT id,from_addr,subject,date,ai_category,ai_priority FROM emails WHERE folder_id=? AND is_deleted=0 ORDER BY date DESC LIMIT ?",
        [folder_id, limit]
    )
    return await ai_engine.smart_filter_suggest(emails)
@router.post("/transform")
async def transform(data: TransformRequest):
    if not data.text.strip() and data.op != "compose":
        raise HTTPException(400, "text is required")
    result = await ai_engine.transform(data.op, data.text, data.params)
    return {"result": result, "original": data.text, "op": data.op}
@router.get("/templates")
async def list_templates(category: Optional[str] = None):
    sql = "SELECT id, name, category, body, is_builtin, trigger, created_at FROM templates"
    params: list = []
    if category:
        sql += " WHERE category=?"
        params.append(category)
    sql += " ORDER BY is_builtin DESC, name"
    return await db.fetch_all(sql, params)
@router.post("/templates")
async def create_template(data: TemplateCreate):
    trig = (data.trigger or "").strip().lower().lstrip(";") or None
    cur = await db.exec_q("INSERT INTO templates (name, category, body, is_builtin, trigger) VALUES (?,?,?,0,?)",
                          [data.name.strip(), data.category.strip() or "general", data.body, trig])
    row = await db.fetch_one("SELECT id, name, category, body, is_builtin, trigger, created_at FROM templates WHERE id=?", [cur.lastrowid])
    return row
@router.patch("/templates/{tid}")
async def update_template(tid: int, data: TemplateUpdate):
    row = await db.fetch_one("SELECT * FROM templates WHERE id=?", [tid])
    if not row:
        raise HTTPException(404, "Template not found")
    if row.get("is_builtin"):
        raise HTTPException(400, "Built-in templates cannot be edited; clone instead")
    fields, params = [], []
    for k in ("name", "category", "body", "trigger"):
        v = getattr(data, k)
        if v is not None:
            if k == "trigger":
                v = (v or "").strip().lower().lstrip(";") or None
            fields.append(f"{k}=?")
            params.append(v)
    if fields:
        params.append(tid)
        await db.exec_q(f"UPDATE templates SET {','.join(fields)} WHERE id=?", params)
    return await db.fetch_one("SELECT id, name, category, body, is_builtin, trigger, created_at FROM templates WHERE id=?", [tid])
@router.delete("/templates/{tid}")
async def delete_template(tid: int):
    row = await db.fetch_one("SELECT is_builtin FROM templates WHERE id=?", [tid])
    if not row:
        raise HTTPException(404, "Template not found")
    if row.get("is_builtin"):
        raise HTTPException(400, "Built-in templates cannot be deleted")
    await db.exec_q("DELETE FROM templates WHERE id=?", [tid])
    return {"deleted": tid}
@router.post("/apply-template/{tid}")
async def apply_template(tid: int, data: ApplyTemplateRequest):
    row = await db.fetch_one("SELECT body FROM templates WHERE id=?", [tid])
    if not row:
        raise HTTPException(404, "Template not found")
    return {"result": await ai_engine.apply_template(row["body"], data.context), "template_id": tid}
@router.get("/health")
async def ai_health():
    try:
        async with httpx.AsyncClient(timeout=3.0) as client:
            r = await client.get(f"{cfg.ai_url}/health")
            return {"status": "online" if r.status_code == 200 else "error", "code": r.status_code}
    except Exception:
        return {"status": "offline"}
@router.get("/setup/status")
async def setup_status():
    global _AMNI_AI_PROC
    root = _find_amni_ai()
    running = await _probe_running()
    managed = _AMNI_AI_PROC.pid if _AMNI_AI_PROC and _AMNI_AI_PROC.poll() is None else None
    return {"running": running, "installed": root is not None, "install_path": str(root) if root else None,
            "models": _list_models(root) if root else [], "ai_url": cfg.ai_url,
            "port": _port_from_url(cfg.ai_url), "host": _host_from_url(cfg.ai_url),
            "managed_pid": managed,
            "install_hint": None if root else "Install Amni-Ai to ~/Documents/ai/Amni-Ai or set AMNI_AI_HOME env var"}
@router.post("/setup/start")
async def setup_start(data: StartRequest = None):
    global _AMNI_AI_PROC
    data = data or StartRequest()
    port = data.port or _port_from_url(cfg.ai_url)
    if not (1 <= port <= 65535):
        raise HTTPException(400, f"Invalid port: {port}")
    host = data.host or _host_from_url(cfg.ai_url)
    probe_url = f"http://{host}:{port}"
    if _AMNI_AI_PROC and _AMNI_AI_PROC.poll() is None:
        return {"status": "already_running", "pid": _AMNI_AI_PROC.pid, "port": port}
    if await _probe_running(probe_url):
        return {"status": "already_running", "pid": None, "port": port}
    root = _find_amni_ai()
    if not root:
        raise HTTPException(404, "Amni-Ai not installed. Expected at ~/Documents/ai/Amni-Ai or set AMNI_AI_HOME.")
    py = root/".venv"/"Scripts"/"python.exe"
    if not py.exists(): py = root/".venv"/"bin"/"python"
    if not py.exists(): py = Path(sys.executable)
    atlas = root/"full_lexicon_atlas"
    args = [str(py), "-B", "-m", "amni.model.panel_engine", "--atlas", str(atlas), "--web", "--port", str(port)]
    if data.host: args += ["--host", data.host]
    args += list(data.extra_args or [])
    env = os.environ.copy()
    env.setdefault("HIP_VISIBLE_DEVICES", "0")
    env.setdefault("HSA_OVERRIDE_GFX_VERSION", "11.0.0")
    flags = (subprocess.CREATE_NEW_PROCESS_GROUP | 0x00000008) if os.name == "nt" else 0
    try:
        _AMNI_AI_PROC = subprocess.Popen(args, cwd=str(root), env=env,
                                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                         stdin=subprocess.DEVNULL, creationflags=flags) if os.name == "nt" else \
                        subprocess.Popen(args, cwd=str(root), env=env,
                                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                         stdin=subprocess.DEVNULL, start_new_session=True)
    except Exception as e:
        raise HTTPException(500, f"Failed to launch Amni-Ai: {type(e).__name__}: {e}")
    new_url = f"http://{host}:{port}"
    if new_url != cfg.ai_url:
        cfg.ai_url = new_url
        cfg.save()
    return {"status": "starting", "pid": _AMNI_AI_PROC.pid, "port": port, "host": host,
            "ai_url": cfg.ai_url, "cmd": " ".join(args), "cwd": str(root)}
@router.post("/setup/stop")
async def setup_stop():
    global _AMNI_AI_PROC
    if not _AMNI_AI_PROC or _AMNI_AI_PROC.poll() is not None:
        _AMNI_AI_PROC = None
        return {"status": "not_running"}
    try:
        _AMNI_AI_PROC.terminate()
        return {"status": "stopping", "pid": _AMNI_AI_PROC.pid}
    except Exception as e:
        raise HTTPException(500, f"Failed to stop: {e}")
@router.get("/setup/models")
async def setup_models():
    root = _find_amni_ai()
    return {"models": _list_models(root) if root else [], "installed": root is not None}
