from fastapi import APIRouter, HTTPException
from urllib.parse import urlparse, urljoin
import re, html, asyncio
import httpx
router = APIRouter(prefix="/api/preview", tags=["preview"])
_META_RE = re.compile(r'<meta\b[^>]*?(?:property|name)\s*=\s*[\'\"]([^\'\"]+)[\'\"][^>]*?content\s*=\s*[\'\"]([^\'\"]*)[\'\"][^>]*?/?>', re.I | re.S)
_META_RE2 = re.compile(r'<meta\b[^>]*?content\s*=\s*[\'\"]([^\'\"]*)[\'\"][^>]*?(?:property|name)\s*=\s*[\'\"]([^\'\"]+)[\'\"][^>]*?/?>', re.I | re.S)
_TITLE_RE = re.compile(r'<title[^>]*>(.*?)</title>', re.I | re.S)
_LINK_ICON_RE = re.compile(r'<link\b[^>]*?rel\s*=\s*[\'\"](?:[^\'\"]*\b)?(?:icon|shortcut\s+icon|apple-touch-icon)(?:\b[^\'\"]*)?[\'\"][^>]*?href\s*=\s*[\'\"]([^\'\"]+)[\'\"]', re.I | re.S)
_BLOCK_HOSTS = ("localhost", "127.", "0.0.0.0", "::1", "10.", "192.168.", "172.16.", "172.17.", "172.18.", "172.19.", "172.20.", "172.21.", "172.22.", "172.23.", "172.24.", "172.25.", "172.26.", "172.27.", "172.28.", "172.29.", "172.30.", "172.31.", "169.254.")
def _safe_url(u: str) -> str:
    p = urlparse(u)
    if p.scheme not in ("http", "https"): raise HTTPException(400, "Only http/https URLs allowed")
    h = (p.hostname or "").lower()
    if not h or any(h == b.rstrip(".") or h.startswith(b) for b in _BLOCK_HOSTS): raise HTTPException(400, "Refusing to fetch private/local URL")
    return u
@router.get("/og")
async def og_preview(url: str):
    safe = _safe_url(url)
    try:
        async with httpx.AsyncClient(follow_redirects=True, timeout=6.0, headers={"User-Agent": "Mozilla/5.0 (compatible; Amni-Mail-LinkPreview/1.0)"}) as c:
            r = await c.get(safe)
            ct = (r.headers.get("content-type") or "").lower()
            if "html" not in ct and "xml" not in ct: raise HTTPException(415, f"Unsupported content-type: {ct}")
            txt = r.text[:262144]
    except httpx.RequestError as e:
        raise HTTPException(502, f"Fetch failed: {e}")
    meta = {}
    for m in _META_RE.finditer(txt):
        k = m.group(1).strip().lower(); v = html.unescape(m.group(2).strip())
        if k and v and k not in meta: meta[k] = v
    for m in _META_RE2.finditer(txt):
        k = m.group(2).strip().lower(); v = html.unescape(m.group(1).strip())
        if k and v and k not in meta: meta[k] = v
    title = meta.get("og:title") or meta.get("twitter:title")
    if not title:
        tm = _TITLE_RE.search(txt)
        title = html.unescape(tm.group(1).strip()) if tm else None
    desc = meta.get("og:description") or meta.get("twitter:description") or meta.get("description")
    img = meta.get("og:image") or meta.get("twitter:image") or meta.get("twitter:image:src")
    site = meta.get("og:site_name") or urlparse(safe).hostname or ""
    if img and not img.startswith(("http://", "https://")): img = urljoin(safe, img)
    icon = None
    im = _LINK_ICON_RE.search(txt)
    if im: icon = urljoin(safe, im.group(1))
    return {"url": safe, "title": (title or "")[:240], "description": (desc or "")[:500], "image": img, "site_name": site, "favicon": icon}
