from fastapi import APIRouter, HTTPException, UploadFile, File, Form
import mailbox, tempfile, os, asyncio
from email_parser import parse_email
import db
router = APIRouter(prefix="/api/import", tags=["import"])
async def _ingest_mbox(path: str, account_id: int, folder_id: int) -> dict:
    box = mailbox.mbox(path, create=False)
    inserted = 0
    skipped = 0
    uid_base = (await db.fetch_one("SELECT COALESCE(MAX(uid),0) as mx FROM emails WHERE account_id=? AND folder_id=?", [account_id, folder_id]))["mx"]
    for i, msg in enumerate(box):
        try:
            raw = msg.as_bytes()
            parsed = parse_email(raw)
            if not parsed:
                skipped += 1
                continue
            existing = await db.fetch_one("SELECT id FROM emails WHERE account_id=? AND message_id=?", [account_id, parsed["message_id"]]) if parsed["message_id"] else None
            if existing:
                skipped += 1
                continue
            uid = uid_base + i + 1
            cur = await db.exec_q(
                "INSERT OR IGNORE INTO emails (account_id,folder_id,uid,message_id,thread_id,in_reply_to,references_hdr,from_addr,from_name,to_addrs,cc_addrs,subject,date,size,preview,body_text,body_html,has_attachments,is_read,ics_uid,unsubscribe_uri,unsubscribe_post,body_fetched) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,1,?,?,?,1)",
                [account_id, folder_id, uid, parsed["message_id"], parsed["thread_id"], parsed["in_reply_to"],
                 parsed["references_hdr"], parsed["from_addr"], parsed["from_name"], parsed["to_addrs"],
                 parsed["cc_addrs"], parsed["subject"], parsed["date"], len(raw), parsed["preview"],
                 parsed["body_text"], parsed["body_html"], 1 if parsed["attachments"] else 0,
                 parsed.get("ics_uid") or "", parsed.get("unsubscribe_uri") or "", parsed.get("unsubscribe_post") or ""])
            if cur.lastrowid and parsed["attachments"]:
                for att in parsed["attachments"]:
                    await db.exec_q(
                        "INSERT INTO attachments (email_id,filename,content_type,size,content_id,data) VALUES (?,?,?,?,?,?)",
                        [cur.lastrowid, att["filename"], att["content_type"], att["size"], att.get("content_id") or "", att.get("data") or b""])
            inserted += 1
        except Exception:
            skipped += 1
    return {"inserted": inserted, "skipped": skipped}
@router.post("/mbox")
async def upload_mbox(account_id: int = Form(...), folder_id: int = Form(...), file: UploadFile = File(...)):
    acc = await db.fetch_one("SELECT id FROM accounts WHERE id=?", [account_id])
    if not acc:
        raise HTTPException(404, "Account not found")
    fld = await db.fetch_one("SELECT id FROM folders WHERE id=? AND account_id=?", [folder_id, account_id])
    if not fld:
        raise HTTPException(404, "Folder not found for this account")
    if not file.filename.lower().endswith((".mbox", ".mbx", ".eml")):
        raise HTTPException(400, "Only .mbox/.mbx/.eml files supported (PST deferred)")
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".mbox")
    try:
        data = await file.read()
        tmp.write(data)
        tmp.close()
        result = await _ingest_mbox(tmp.name, account_id, folder_id)
        return {"status": "ok", "filename": file.filename, **result}
    finally:
        try:
            os.unlink(tmp.name)
        except Exception:
            pass
