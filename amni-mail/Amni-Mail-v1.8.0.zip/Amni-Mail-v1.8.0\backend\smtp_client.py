import ssl, base64, mimetypes
import aiosmtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email.mime.image import MIMEImage
from email import encoders
from auth import load_account_creds
async def _send_mime(account: dict, msg, recipients: list):
    creds = load_account_creds(account["id"])
    if not creds:
        raise ValueError(f"No credentials for account {account['id']}")
    ctx = ssl.create_default_context()
    oauth_tok = creds.get("oauth_token")
    if oauth_tok and account.get("auth_type") == "oauth2":
        smtp = aiosmtplib.SMTP(hostname=account["smtp_host"], port=account["smtp_port"], tls_context=ctx)
        await smtp.connect()
        if account["smtp_port"] != 465:
            await smtp.starttls()
        xoauth2_str = f"user={creds['username']}\x01auth=Bearer {oauth_tok}\x01\x01"
        encoded = base64.b64encode(xoauth2_str.encode()).decode()
        resp = await smtp.execute_command(b"AUTH", b"XOAUTH2", encoded.encode())
        if resp.code not in (235, 250):
            raise RuntimeError(f"XOAUTH2 auth failed: {resp.code} {resp.message}")
        await smtp.sendmail(account["email"], recipients, msg.as_string())
        await smtp.quit()
    elif account["smtp_port"] == 465:
        await aiosmtplib.send(msg, hostname=account["smtp_host"], port=account["smtp_port"],
                              username=creds["username"], password=creds["password"],
                              use_tls=True, tls_context=ctx, recipients=recipients)
    else:
        await aiosmtplib.send(msg, hostname=account["smtp_host"], port=account["smtp_port"],
                              username=creds["username"], password=creds["password"],
                              start_tls=True, tls_context=ctx, recipients=recipients)
def _build_inline_part(att: dict):
    data = att["data"] if isinstance(att["data"], bytes) else att["data"].encode()
    ctype = mimetypes.guess_type(att["filename"])[0] or "application/octet-stream"
    maintype, _, subtype = ctype.partition("/")
    if maintype == "image" and subtype:
        part = MIMEImage(data, _subtype=subtype)
    else:
        part = MIMEBase(maintype or "application", subtype or "octet-stream")
        part.set_payload(data)
        encoders.encode_base64(part)
    cid = str(att["content_id"]).strip("<>")
    part.add_header("Content-ID", f"<{cid}>")
    part.add_header("Content-Disposition", "inline", filename=att["filename"])
    return part
async def send_email(account: dict, to: str, subject: str, body_html: str,
                     body_text: str = "", cc: str = "", bcc: str = "",
                     reply_to: str = "", in_reply_to: str = "",
                     attachments: list = None, extra_headers: dict = None,
                     from_override: str = "", from_name_override: str = ""):
    inline = [a for a in (attachments or []) if a.get("inline") and a.get("content_id")]
    files = [a for a in (attachments or []) if not (a.get("inline") and a.get("content_id"))]
    alt = MIMEMultipart("alternative")
    alt.attach(MIMEText(body_text or body_html, "plain", "utf-8"))
    alt.attach(MIMEText(body_html, "html", "utf-8"))
    if inline:
        body_root = MIMEMultipart("related")
        body_root.attach(alt)
        for img in inline:
            body_root.attach(_build_inline_part(img))
    else:
        body_root = alt
    msg = body_root
    _from_addr = (from_override or "").strip() or account["email"]
    _from_name = (from_name_override or "").strip()
    msg["From"] = f'"{_from_name}" <{_from_addr}>' if _from_name else _from_addr
    msg["To"] = to
    msg["Subject"] = subject
    if cc:
        msg["Cc"] = cc
    if reply_to:
        msg["Reply-To"] = reply_to
    if in_reply_to:
        msg["In-Reply-To"] = in_reply_to
        msg["References"] = in_reply_to
    for k, v in (extra_headers or {}).items():
        msg[k] = v
    if files:
        outer = MIMEMultipart("mixed")
        for key in ["From", "To", "Subject", "Cc", "Reply-To", "In-Reply-To", "References"] + list((extra_headers or {}).keys()):
            if msg[key]:
                outer[key] = msg[key]
        outer.attach(msg)
        for att in files:
            part = MIMEBase("application", "octet-stream")
            part.set_payload(att["data"] if isinstance(att["data"], bytes) else att["data"].encode())
            encoders.encode_base64(part)
            part.add_header("Content-Disposition", "attachment", filename=att["filename"])
            outer.attach(part)
        msg = outer
    recipients = [r.strip() for r in (to + "," + cc + "," + bcc).split(",") if r.strip()]
    await _send_mime(account, msg, recipients)
async def send_auto_reply(account: dict, to: str, subject: str, body_text: str, original_message_id: str = ""):
    msg = MIMEMultipart("alternative")
    msg["From"] = account["email"]
    msg["To"] = to
    msg["Subject"] = subject
    msg["Auto-Submitted"] = "auto-replied"
    msg["X-Auto-Response-Suppress"] = "All"
    msg["Precedence"] = "auto_reply"
    if original_message_id:
        msg["In-Reply-To"] = original_message_id
        msg["References"] = original_message_id
    msg.attach(MIMEText(body_text, "plain", "utf-8"))
    msg.attach(MIMEText(f"<div>{body_text}</div>", "html", "utf-8"))
    await _send_mime(account, msg, [to])
async def send_rsvp(account: dict, to: str, subject: str, ics_body: str, comment: str = ""):
    outer = MIMEMultipart("mixed")
    outer["From"] = account["email"]
    outer["To"] = to
    outer["Subject"] = subject
    text_part = MIMEText(comment or "RSVP", "plain", "utf-8")
    ics_part = MIMEBase("text", "calendar", method="REPLY", charset="utf-8")
    ics_part.set_payload(ics_body.encode("utf-8"))
    encoders.encode_base64(ics_part)
    ics_part.add_header("Content-Disposition", "attachment", filename="reply.ics")
    outer.attach(text_part)
    outer.attach(ics_part)
    await _send_mime(account, outer, [to])
