import asyncio, sys
sys.path.insert(0, '.')
import db, imap_client

async def test():
    await db.get_db()
    accs = await db.fetch_all('SELECT * FROM accounts WHERE enabled=1')
    acc = accs[0]
    print(f'Account: {acc["email"]}')
    folders = await db.fetch_all('SELECT * FROM folders WHERE account_id=?', [acc["id"]])
    if not folders:
        print('No folders in DB, syncing folder list first...')
        fl = await imap_client.list_folders(acc)
        print(f'Found {len(fl)} folders')
        for f in fl:
            await db.exec_q('INSERT OR IGNORE INTO folders (account_id,path,name,folder_type) VALUES (?,?,?,?)',
                [acc["id"], f["path"], f["name"], f["folder_type"]])
        folders = await db.fetch_all('SELECT * FROM folders WHERE account_id=?', [acc["id"]])
    inbox = next((f for f in folders if f["folder_type"] == "inbox"), folders[0])
    print(f'Syncing folder: {inbox["path"]} (id={inbox["id"]})')
    count = await imap_client.sync_folder(acc, inbox["path"], inbox["id"], limit=5)
    print(f'Synced {count} emails!')
    emails = await db.fetch_all('SELECT uid, subject, from_addr, date FROM emails WHERE folder_id=? ORDER BY uid DESC LIMIT 5', [inbox["id"]])
    for e in emails:
        print(f'  UID={e["uid"]} from={e["from_addr"]} subj={e["subject"][:60]}')
    await db.close_db()

asyncio.run(test())
