import httpx, json
from config import cfg
async def ai_request(prompt: str, system: str = "", max_tokens: int = 512, use_scout: bool = False) -> str:
    url = (cfg.ai_scout_url if use_scout else cfg.ai_url).rstrip("/")
    model = cfg.ai_scout_model if use_scout else cfg.ai_model
    messages = [{"role": "system", "content": system}] if system else []
    messages.append({"role": "user", "content": prompt})
    payload = {"model": model, "messages": messages, "temperature": 0.3, "max_tokens": max_tokens}
    try:
        async with httpx.AsyncClient(timeout=60) as client:
            resp = await client.post(f"{url}/v1/chat/completions", json=payload)
            resp.raise_for_status()
            data = resp.json()
            return (data.get("choices", [{}])[0].get("message", {}).get("content") or "").strip()
    except Exception as e:
        return f"[AI unavailable: {e}]"
async def ai_health() -> dict:
    url = cfg.ai_url.rstrip("/")
    try:
        async with httpx.AsyncClient(timeout=4) as client:
            r = await client.get(f"{url}/health")
            return {"online": r.status_code == 200, "url": url, "model": cfg.ai_model, "status": r.status_code}
    except Exception as e:
        return {"online": False, "url": url, "model": cfg.ai_model, "error": str(e)}
async def categorize_email(subject: str, from_addr: str, preview: str) -> dict:
    sys_prompt = "You categorize emails. Respond ONLY with valid JSON: {\"category\": \"...\", \"priority\": N}"
    prompt = f"""Categorize this email into exactly one category:
important, newsletter, social, receipt, notification, promotion, spam, personal, work
Also rate priority 1-5 (1=urgent, 5=ignorable).
From: {from_addr}
Subject: {subject}
Preview: {preview[:300]}"""
    result = await ai_request(prompt, sys_prompt, 64, use_scout=True)
    try:
        start = result.index("{")
        end = result.rindex("}") + 1
        return json.loads(result[start:end])
    except (ValueError, json.JSONDecodeError):
        return {"category": "unknown", "priority": 3}
async def summarize_thread(emails: list) -> str:
    sys_prompt = "You summarize email threads concisely. Focus on key points and action items."
    thread_text = "\n---\n".join(
        f"From: {e['from_addr']}\nDate: {e['date']}\nSubject: {e['subject']}\n{(e.get('body_text') or e.get('preview', ''))[:500]}"
        for e in emails[:10]
    )
    return await ai_request(f"Summarize this email thread:\n{thread_text}", sys_prompt, 300)
async def summarize_thread_structured(emails: list) -> dict:
    sys_prompt = ('You summarize email threads. Output ONLY valid JSON: '
                  '{"tldr": string (1-2 sentences), '
                  '"open_questions": [string], '
                  '"action_items": [{"who": string, "what": string}], '
                  '"decisions": [string], '
                  '"participants": [string]}. '
                  'tldr must be plain prose, not bullets. '
                  'Use empty arrays when nothing applies. JSON only, no preamble.')
    parts = []
    for e in emails[:20]:
        body = (e.get("body_text") or e.get("preview") or "")[:1500]
        parts.append(f"From: {e.get('from_name') or ''} <{e.get('from_addr') or ''}>\nDate: {e.get('date') or ''}\nSubject: {e.get('subject') or ''}\n{_strip_quoted(body)}")
    blob = "\n---\n".join(parts)[:14000]
    raw = await ai_request(f"Summarize this email thread for someone catching up:\n\n{blob}\n\nJSON:", sys_prompt, 700)
    try:
        s = raw.index("{"); e = raw.rindex("}") + 1
        parsed = json.loads(raw[s:e])
    except Exception:
        return {"tldr": raw.strip()[:600] or "(no summary)", "open_questions": [], "action_items": [], "decisions": [], "participants": []}
    parsed.setdefault("tldr", "")
    for k in ("open_questions", "action_items", "decisions", "participants"):
        if not isinstance(parsed.get(k), list):
            parsed[k] = []
    return parsed
def _strip_quoted(text: str) -> str:
    import re as _re
    if not text:
        return ""
    markers = [r"\nOn\s.+\swrote:\s*\n", r"\n-----\s*Original Message\s*-----", r"\nFrom:\s.+\nSent:\s", r"\n>+\s*"]
    cut = len(text)
    for m in markers:
        match = _re.search(m, text)
        if match and match.start() < cut:
            cut = match.start()
    body = text[:cut].strip()
    body = _re.sub(r"\nSent from my .+", "", body)
    return body
def _voice_style_block(profile: dict | None) -> str:
    if not profile:
        return ""
    parts = []
    if profile.get("greeting_style"): parts.append(f"- Greeting style: {profile['greeting_style']}")
    if profile.get("signoff"): parts.append(f"- Sign-off: {profile['signoff']}")
    if profile.get("formality"): parts.append(f"- Formality: {profile['formality']}")
    asl = profile.get("avg_sentence_length")
    if asl: parts.append(f"- Average sentence length: {asl} words")
    sigs = profile.get("signature_phrases") or []
    if sigs: parts.append(f"- Recurring phrasing the user often uses: {', '.join(sigs[:5])}")
    if not parts:
        return ""
    return "Match the user's writing voice precisely:\n" + "\n".join(parts)
async def derive_voice_profile(sent_bodies: list[str]) -> dict:
    samples = [_strip_quoted(b) for b in sent_bodies if b]
    samples = [s for s in samples if 30 <= len(s) <= 1500][:40]
    if not samples:
        return {}
    blob = "\n---\n".join(samples)[:12000]
    sys = ('You analyze a writer\'s style from email samples. Output ONLY a JSON object: '
           '{"greeting_style": string, "signoff": string, "formality": "casual"|"neutral"|"formal", '
           '"avg_sentence_length": int, "signature_phrases": [string]}. '
           'Greeting/signoff: capture their exact typical phrasing (e.g. "Hey {name}", "Cheers,"). '
           'signature_phrases: 3-7 distinctive recurring phrases or transitional words. JSON only.')
    raw = await ai_request(f"Analyze these sent-mail samples:\n{blob}\n\nJSON:", sys, 320)
    try:
        s = raw.index("{"); e = raw.rindex("}") + 1
        out = json.loads(raw[s:e])
    except (ValueError, json.JSONDecodeError):
        return {}
    out.setdefault("greeting_style", "")
    out.setdefault("signoff", "")
    out.setdefault("formality", "neutral")
    try:
        out["avg_sentence_length"] = int(out.get("avg_sentence_length") or 0)
    except (TypeError, ValueError):
        out["avg_sentence_length"] = 0
    sigs = out.get("signature_phrases") or []
    out["signature_phrases"] = [str(p)[:80] for p in sigs if p][:7] if isinstance(sigs, list) else []
    return out
async def draft_reply(original_email: dict, instructions: str = "", voice_profile: dict | None = None) -> str:
    voice_block = _voice_style_block(voice_profile)
    sys_prompt = "You draft email replies that sound exactly like the user. Be concise and appropriate in tone." + (f"\n\n{voice_block}" if voice_block else " Be professional.")
    prompt = f"""Draft a reply to this email:
From: {original_email['from_name']} <{original_email['from_addr']}>
Subject: {original_email['subject']}
Body: {(original_email.get('body_text') or original_email.get('preview', ''))[:800]}
{f'Instructions: {instructions}' if instructions else 'Write an appropriate reply.'}"""
    return await ai_request(prompt, sys_prompt, 500)
async def chat_inbox(question: str, contexts: list, history: list) -> str:
    import re as _re
    sys = ("You answer questions about the user's email inbox. Use ONLY the provided emails as evidence. "
           "Cite each source by its tag like [E12] inline where you use it. "
           "If the emails do not contain enough information to answer, say exactly: "
           "'I couldn't find that in your inbox.' Be concise — at most 4 sentences.")
    blocks = []
    for r in contexts[:8]:
        eid = r.get("id")
        body = (r.get("body_text") or r.get("preview") or "")
        body = _re.sub(r"<[^>]+>", " ", body)
        body = _re.sub(r"\s+", " ", body).strip()[:400]
        blocks.append(f"[E{eid}] From: {r.get('from_name') or r.get('from_addr') or ''} | Date: {r.get('date') or ''} | Subject: {r.get('subject') or ''}\n{body}")
    ctx_text = "\n\n".join(blocks) if blocks else "(no matching emails)"
    hist_text = ""
    for h in (history or [])[-6:]:
        role = "User" if (h.role if hasattr(h, 'role') else h.get('role')) == 'user' else "Assistant"
        content = (h.content if hasattr(h, 'content') else h.get('content', ''))
        hist_text += f"\n{role}: {content}"
    prompt = (f"Emails available:\n{ctx_text}\n\n"
              f"Conversation so far:{hist_text or ' (none)'}\n\n"
              f"User question: {question}\n\nAnswer:")
    return (await ai_request(prompt, sys, 400)).strip()
async def detect_event(em: dict) -> dict:
    from datetime import datetime, timezone
    import re
    body = (em.get("body_text") or em.get("preview") or "")[:1500]
    body = re.sub(r"<[^>]+>", " ", body)
    body = re.sub(r"\s+", " ", body).strip()
    if not body:
        return {"has_event": False}
    now = datetime.now().astimezone()
    today_iso = now.strftime("%Y-%m-%d")
    tz = now.strftime("%z") or "+0000"
    sys = ('You extract calendar events from email text. Output ONLY a single JSON object matching this schema: '
           '{"has_event": bool, "summary": string, "dtstart": "YYYY-MM-DDTHH:MM:SS"|null, "dtend": "YYYY-MM-DDTHH:MM:SS"|null, '
           '"location": string, "description": string, "confidence": float}. '
           'Only set has_event=true when text proposes a SPECIFIC dated meeting/event the user could put on a calendar. '
           'Resolve relative dates ("Tuesday", "tomorrow") against the provided "today". '
           'Confidence 0.0-1.0 — anything below 0.6 will be discarded. Output JSON only, no prose.')
    p = (f'Today is {today_iso} (timezone {tz}).\n'
         f'Subject: {em.get("subject") or ""}\nFrom: {em.get("from_addr") or ""}\nBody:\n{body}\n\nJSON:')
    raw = await ai_request(p, sys, 240, use_scout=True)
    try:
        s = raw.index("{"); e = raw.rindex("}") + 1
        out = json.loads(raw[s:e])
    except (ValueError, json.JSONDecodeError):
        return {"has_event": False}
    out["has_event"] = bool(out.get("has_event"))
    if not out["has_event"]:
        return {"has_event": False}
    out.setdefault("summary", em.get("subject") or "Detected event")
    out.setdefault("location", "")
    out.setdefault("description", "")
    try:
        out["confidence"] = float(out.get("confidence") or 0)
    except (TypeError, ValueError):
        out["confidence"] = 0.0
    if out["confidence"] < 0.6:
        return {"has_event": False, "confidence": out["confidence"]}
    for k in ("dtstart", "dtend"):
        v = out.get(k) or ""
        if v:
            try:
                datetime.fromisoformat(v.replace("Z", "+00:00"))
            except ValueError:
                out[k] = None
        else:
            out[k] = None
    if not out.get("dtstart"):
        return {"has_event": False, "confidence": out["confidence"]}
    return out
async def extract_actions(email_data: dict) -> str:
    sys_prompt = "Extract action items from emails. List each as a bullet point. If none, say 'No action items.'"
    prompt = f"""Extract action items from:
Subject: {email_data['subject']}
Body: {(email_data.get('body_text') or email_data.get('preview', ''))[:800]}"""
    return await ai_request(prompt, sys_prompt, 200, use_scout=True)
_TONE_HINTS = {
    "formal": "professional, courteous, business-appropriate",
    "casual": "friendly, conversational, approachable",
    "concise": "brief and direct, removing all filler",
    "expand": "richer detail with supporting context",
    "assertive": "confident and decisive without being rude",
    "apologetic": "warm, regretful, taking responsibility",
}
async def compose_from_prompt(instructions: str, recipient: str = "", subject: str = "") -> str:
    sys = "You write email bodies. Output only the body — no subject line, no greeting placeholders like [Name], no sign-off placeholders. Use the recipient name if provided."
    p = f"Write an email{f' to {recipient}' if recipient else ''}{f' about: {subject}' if subject else ''}.\nInstructions: {instructions}"
    return await ai_request(p, sys, 600)
async def proofread(text: str) -> str:
    sys = "You correct spelling, grammar, and punctuation. Preserve meaning, voice, and formatting exactly. Output only the corrected text."
    return await ai_request(f"Correct this:\n{text}", sys, max(300, min(2000, len(text)*2)))
async def rephrase(text: str, tone: str = "formal", length: str = "same") -> str:
    hint = _TONE_HINTS.get(tone, tone)
    length_note = {"shorter": " Make it noticeably shorter.", "longer": " Add helpful context to make it longer.", "same": ""}.get(length, "")
    sys = f"You rephrase email text to be {hint}.{length_note} Preserve the core meaning. Output only the rewritten text."
    return await ai_request(f"Rephrase:\n{text}", sys, max(300, min(2000, len(text)*2)))
async def translate(text: str, target_language: str) -> str:
    sys = f"You translate text into {target_language}. Output only the translation, preserving formatting."
    return await ai_request(f"Translate:\n{text}", sys, max(300, min(2000, len(text)*2)))
async def transform(op: str, text: str, params: dict | None = None) -> str:
    params = params or {}
    if op == "compose":
        return await compose_from_prompt(text, params.get("recipient", ""), params.get("subject", ""))
    if op == "proofread":
        return await proofread(text)
    if op == "rephrase":
        return await rephrase(text, params.get("tone", "formal"), params.get("length", "same"))
    if op == "translate":
        return await translate(text, params.get("target_language", "Spanish"))
    if op == "shorten":
        return await rephrase(text, "concise", "shorter")
    if op == "expand":
        return await rephrase(text, params.get("tone", "formal"), "longer")
    if op == "formalize":
        return await rephrase(text, "formal", "same")
    if op == "casualize":
        return await rephrase(text, "casual", "same")
    return f"[Unknown op: {op}]"
async def apply_template(template_body: str, context: str = "") -> str:
    sys = "You customize an email template for the specific recipient/situation described. Replace placeholders like {name}, {date}, {topic} with appropriate values inferred from context. Output only the finished email body."
    p = f"Template:\n{template_body}\n\nContext / situation: {context or '(none provided — fill placeholders with reasonable defaults or leave them blank)'}"
    return await ai_request(p, sys, 600)
async def complete(prefix: str, context: str = "", max_tokens: int = 40) -> str:
    sys = "You continue an email body the user is typing. Output ONLY the next 1-15 words that would naturally follow — no greetings, no sign-offs, no quotes, no bullet markers, no repetition of the input. If the prefix ends mid-sentence, finish that sentence. If it ends a sentence cleanly, output the next short sentence. If nothing useful would follow, output an empty string."
    p = f"Recipient/subject context: {context or '(none)'}\n\nEmail body so far:\n{prefix}\n\nNext words:"
    raw = (await ai_request(p, sys, max_tokens, use_scout=True)).strip().strip('"').strip("'")
    tail = prefix[-40:].lower().strip()
    if tail and raw.lower().startswith(tail):
        raw = raw[len(prefix[-40:].strip()):].lstrip()
    if raw.lower().startswith(prefix[-15:].lower()):
        raw = raw[len(prefix[-15:]):].lstrip()
    return raw[:200]
async def quick_replies(em: dict) -> list[str]:
    sys = "You generate exactly 3 short reply suggestions for an email. Each reply: ONE complete sentence the user could send as-is, varied in stance (acknowledge / clarify / decline-or-defer). No greeting, no sign-off, no quotes around the strings. Output ONLY a JSON array of 3 strings, nothing else."
    body = (em.get("body_text") or em.get("preview", ""))[:600]
    p = f"From: {em.get('from_name') or em.get('from_addr')}\nSubject: {em.get('subject')}\n\n{body}\n\nGive 3 short reply options."
    raw = await ai_request(p, sys, 200, use_scout=True)
    try:
        s = raw.index("["); e = raw.rindex("]") + 1
        arr = json.loads(raw[s:e])
        return [str(x).strip() for x in arr if str(x).strip()][:3]
    except Exception:
        return []
async def smart_filter_suggest(emails: list) -> str:
    sys_prompt = "Suggest email cleanup actions. Respond with JSON array of {\"action\": \"delete|archive|keep\", \"reason\": \"...\", \"ids\": [...]}"
    summaries = "\n".join(
        f"ID:{e['id']} From:{e['from_addr']} Subj:{e['subject']} Date:{e['date']} Cat:{e.get('ai_category','?')}"
        for e in emails[:50]
    )
    result = await ai_request(f"Suggest cleanup actions for these emails:\n{summaries}", sys_prompt, 500, use_scout=True)
    try:
        start = result.index("[")
        end = result.rindex("]") + 1
        return json.loads(result[start:end])
    except (ValueError, json.JSONDecodeError):
        return []
