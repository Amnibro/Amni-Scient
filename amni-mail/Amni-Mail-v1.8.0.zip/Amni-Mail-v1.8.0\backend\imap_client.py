import asyncio, ssl, json, email as email_lib
from aioimaplib import aioimaplib
from auth import load_account_creds
from email_parser import parse_email
from attachment_extractor import extract_text as extract_attachment_text
import db
_connections = {}
_locks: dict[int, asyncio.Lock] = {}
async def _refresh_if_needed(account):
    if account.get("auth_type") != "oauth2":
        return
    creds = load_account_creds(account["id"])
    if not creds.get("refresh_token"):
        return
    try:
        from routes.oauth import oauth_refresh
        await oauth_refresh(account["id"])
    except Exception:
        pass
async def get_imap(account: dict):
    aid = account["id"]
    if aid in _connections:
        try:
            await asyncio.wait_for(_connections[aid].noop(), timeout=5)
            return _connections[aid]
        except Exception:
            _connections.pop(aid, None)
    await _refresh_if_needed(account)
    creds = load_account_creds(aid)
    if not creds:
        raise ValueError(f"No credentials for account {aid}")
    ctx = ssl.create_default_context()
    client = aioimaplib.IMAP4_SSL(host=account["imap_host"], port=account["imap_port"], ssl_context=ctx, timeout=60)
    await client.wait_hello_from_server()
    if creds.get("oauth_token"):
        await client.xoauth2(creds['username'], creds['oauth_token'])
    else:
        await client.login(creds["username"], creds["password"])
    _connections[aid] = client
    return client
async def disconnect(account_id: int):
    client = _connections.pop(account_id, None)
    if client:
        try:
            await client.logout()
        except Exception:
            pass
async def list_folders(account: dict):
    client = await get_imap(account)
    resp = await client.list('""', '*')
    folders = []
    if resp.result == "OK":
        for line in resp.lines:
            if isinstance(line, bytes):
                line = line.decode("utf-8", errors="replace")
            if not line.strip():
                continue
            parts = line.split('"/"' if '"/"' in line else '" "')
            if len(parts) >= 2:
                path = parts[-1].strip().strip('"')
                ftype = "inbox" if path.upper() == "INBOX" else \
                    "sent" if any(x in path.lower() for x in ["sent", "envoy"]) else \
                    "drafts" if "draft" in path.lower() else \
                    "trash" if any(x in path.lower() for x in ["trash", "deleted", "bin"]) else \
                    "spam" if any(x in path.lower() for x in ["spam", "junk"]) else \
                    "archive" if "archive" in path.lower() else "custom"
                folders.append({"path": path, "name": path.split("/")[-1], "folder_type": ftype})
    return folders
def _extract_uid(line_str):
    parts = line_str.split()
    for j, p in enumerate(parts):
        if p.lstrip('(') == 'UID' and j + 1 < len(parts):
            v = parts[j + 1].rstrip(')')
            return int(v) if v.isdigit() else None
    return None
def _extract_seen(line_str):
    return 1 if '\\Seen' in line_str or r'\Seen' in line_str else 0
async def _upsert_contacts(parsed: dict):
    addrs = []
    if parsed.get("from_addr"):
        addrs.append((parsed["from_addr"], parsed.get("from_name") or ""))
    for field in ("to_addrs", "cc_addrs"):
        raw = parsed.get(field) or ""
        for piece in raw.split(","):
            e = piece.strip().split("<")[-1].rstrip(">").strip()
            n = piece.split("<")[0].strip(' "') if "<" in piece else ""
            if "@" in e:
                addrs.append((e, n))
    for e, n in addrs:
        if not e or "@" not in e:
            continue
        await db.exec_q(
            "INSERT INTO contacts (email, name, hit_count, last_seen) VALUES (?,?,1,CURRENT_TIMESTAMP) "
            "ON CONFLICT(email) DO UPDATE SET hit_count=hit_count+1, last_seen=CURRENT_TIMESTAMP, "
            "name=COALESCE(NULLIF(excluded.name,''), contacts.name)", [e.lower(), n])
async def _upsert_ics(email_id: int, account_id: int, parsed: dict):
    events = parsed.get("ics_events") or []
    method = parsed.get("ics_method") or ""
    for ev in events:
        try:
            await db.exec_q(
                "INSERT INTO calendar_events (account_id,email_id,uid,summary,description,location,organizer,attendees,dtstart,dtend,rrule,method,sequence) "
                "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?) "
                "ON CONFLICT(account_id,uid) DO UPDATE SET summary=excluded.summary, description=excluded.description, "
                "location=excluded.location, dtstart=excluded.dtstart, dtend=excluded.dtend, rrule=excluded.rrule, "
                "method=excluded.method, sequence=excluded.sequence, email_id=excluded.email_id",
                [account_id, email_id, ev.get("uid",""), ev.get("summary",""), ev.get("description",""),
                 ev.get("location",""), ev.get("organizer",""), json.dumps(ev.get("attendees", [])),
                 ev.get("dtstart"), ev.get("dtend"), ev.get("rrule",""), method, ev.get("sequence", 0)])
        except Exception:
            pass
async def _insert_parsed(account_id: int, folder_id: int, uid: int, parsed: dict, raw_size: int, is_seen: int, body_fetched: int):
    await db.exec_q(
        """INSERT OR IGNORE INTO emails
        (account_id,folder_id,uid,message_id,thread_id,in_reply_to,references_hdr,from_addr,from_name,
        to_addrs,cc_addrs,subject,date,size,flags,is_read,has_attachments,
        preview,body_text,body_html,body_fetched,unsubscribe_uri,unsubscribe_post,ics_uid,auth_results,reply_to)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        [account_id, folder_id, uid, parsed["message_id"], parsed["thread_id"],
         parsed.get("in_reply_to",""), parsed.get("references_hdr",""),
         parsed["from_addr"], parsed["from_name"], parsed["to_addrs"], parsed["cc_addrs"],
         parsed["subject"], parsed["date"], raw_size, "", is_seen,
         1 if parsed["attachments"] else 0, parsed["preview"],
         parsed["body_text"], parsed["body_html"], body_fetched,
         parsed.get("unsubscribe_uri",""), parsed.get("unsubscribe_post",""), parsed.get("ics_uid",""),
         parsed.get("auth_results",""), parsed.get("reply_to","")])
    row = await db.fetch_one("SELECT id FROM emails WHERE account_id=? AND folder_id=? AND uid=?", [account_id, folder_id, uid])
    if not row:
        return None
    await _upsert_contacts(parsed)
    if parsed.get("ics_events"):
        await _upsert_ics(row["id"], account_id, parsed)
    return row["id"]
async def sync_folder(account: dict, folder_path: str, folder_id: int, limit: int = 50000):
    aid = account["id"]
    print(f"[SYNC] Starting sync for {account.get('email', 'unknown')} / {folder_path} (folder_id={folder_id})")
    if aid not in _locks:
        _locks[aid] = asyncio.Lock()
    async with _locks[aid]:
        client = await get_imap(account)
        select_resp = await client.select(folder_path)
        if select_resp.result != 'OK':
            print(f"[SYNC] Select failed for {folder_path}")
            return 0
        resp = await client.uid_search('ALL')
        if resp.result != 'OK':
            print(f"[SYNC] UID_SEARCH failed for {folder_path}")
            return 0
        raw_uids = resp.lines[0] if resp.lines else b''
        raw_uids = raw_uids.decode('utf-8', errors='replace') if isinstance(raw_uids, bytes) else str(raw_uids)
        uids = [int(u) for u in raw_uids.split() if u.isdigit()]
        uids = uids[-limit:] if len(uids) > limit else uids
        print(f"[SYNC] Found {len(uids)} UIDs in {folder_path}")
        if not uids:
            return 0
    existing = {r["uid"] for r in await db.fetch_all("SELECT uid FROM emails WHERE account_id=? AND folder_id=?", [account["id"], folder_id])}
    new_uids = [u for u in uids if u not in existing]
    if not new_uids:
        return 0
    count = 0
    for i in range(0, len(new_uids), 20):
        batch = new_uids[i:i+20]
        uid_str = ",".join(str(u) for u in batch)
        resp = await client.uid('fetch', uid_str, '(UID FLAGS BODY.PEEK[HEADER])')
        if resp.result != "OK":
            continue
        raw_data, flags_map, current_uid = {}, {}, None
        for line in resp.lines:
            lb = line if isinstance(line, (bytes, bytearray)) else (line.encode('utf-8', errors='replace') if isinstance(line, str) else None)
            if lb is None:
                continue
            ls = lb.decode('utf-8', errors='replace')
            if b'FETCH' in lb and b'UID' in lb:
                current_uid = _extract_uid(ls)
                if current_uid:
                    raw_data[current_uid] = b""
                    flags_map[current_uid] = _extract_seen(ls)
            elif current_uid is not None:
                (raw_data.__setitem__(current_uid, raw_data.get(current_uid, b"") + bytes(line)) if isinstance(line, bytearray) else
                 flags_map.__setitem__(current_uid, _extract_seen(ls)) if isinstance(line, bytes) and b'FLAGS' in lb else None)
        for uid, raw in raw_data.items():
            if not raw:
                continue
            parsed = parse_email(raw)
            if not parsed:
                continue
            email_id = await _insert_parsed(account["id"], folder_id, uid, parsed, len(raw), flags_map.get(uid, 0), 1)
            _tid = (parsed.get("thread_id") or "").strip()
            _irt = (parsed.get("in_reply_to") or "").strip()
            if email_id and (_tid or _irt):
                try:
                    _cleared = await db.fetch_all(
                        "SELECT id FROM emails WHERE account_id=? AND id!=? AND snoozed_until IS NOT NULL AND snoozed_until > datetime('now') AND ((? != '' AND thread_id=?) OR (? != '' AND message_id=?))",
                        [account["id"], email_id, _tid, _tid, _irt, _irt])
                    if _cleared:
                        _ids = [r["id"] for r in _cleared]
                        _ph = ",".join(["?"] * len(_ids))
                        await db.exec_q(f"UPDATE emails SET snoozed_until=NULL WHERE id IN ({_ph})", _ids)
                        print(f"[AUTO-UNSNOOZE] Cleared snooze on {len(_ids)} thread-sibling(s) after reply to thread={_tid or _irt}")
                except Exception as _e:
                    print(f"[AUTO-UNSNOOZE] failed: {_e}")
            _mdn = (parsed.get("mdn_original_message_id") or "").strip()
            if _mdn:
                try:
                    _orig = await db.fetch_one("SELECT id FROM emails WHERE account_id=? AND message_id=?", [account["id"], _mdn])
                    _orig and await db.exec_q("INSERT INTO read_receipts (sent_email_id, account_id, recipient, disposition) VALUES (?,?,?,?)", [_orig["id"], account["id"], parsed.get("mdn_recipient",""), parsed.get("mdn_disposition","")])
                except Exception: pass
            if email_id and parsed["attachments"]:
                for att in parsed["attachments"]:
                    extracted = extract_attachment_text(att.get("filename") or "", att.get("content_type") or "", att.get("data") or b"")
                    await db.exec_q(
                        "INSERT INTO attachments (email_id,filename,content_type,size,content_id,data,extracted_text) VALUES (?,?,?,?,?,?,?)",
                        [email_id, att["filename"], att["content_type"], att["size"], att.get("content_id"), att["data"], extracted])
            count += 1
    await db.exec_q("UPDATE folders SET total_count=(SELECT COUNT(*) FROM emails WHERE folder_id=?),last_sync=CURRENT_TIMESTAMP WHERE id=?", [folder_id, folder_id])
    await db.exec_q("UPDATE folders SET unread_count=(SELECT COUNT(*) FROM emails WHERE folder_id=? AND is_read=0) WHERE id=?", [folder_id, folder_id])
    return count
async def sync_folder_headers(account: dict, folder_path: str, folder_id: int):
    aid = account["id"]
    print(f"[SYNC-HEADERS] Starting for {account.get('email', 'unknown')} / {folder_path}")
    if aid not in _locks:
        _locks[aid] = asyncio.Lock()
    async with _locks[aid]:
        try:
            client = await get_imap(account)
            select_resp = await client.select(folder_path)
            if select_resp.result != 'OK':
                print(f"[SYNC-HEADERS] Select failed for {folder_path}")
                return
            resp = await client.uid_search('ALL')
            if resp.result != 'OK':
                return
            raw_uids = resp.lines[0] if resp.lines else b''
            raw_uids = raw_uids.decode('utf-8', errors='replace') if isinstance(raw_uids, bytes) else str(raw_uids)
            all_uids = [int(u) for u in raw_uids.split() if u.isdigit()]
            existing = {r["uid"] for r in await db.fetch_all("SELECT uid FROM emails WHERE account_id=? AND folder_id=?", [account["id"], folder_id])}
            new_uids = [u for u in all_uids if u not in existing]
            print(f"[SYNC-HEADERS] {len(new_uids)} new UIDs in {folder_path}")
            if not new_uids:
                return
            for i in range(0, len(new_uids), 200):
                batch = new_uids[i:i+200]
                uid_str = ",".join(str(u) for u in batch)
                resp = await client.uid('fetch', uid_str, '(UID FLAGS BODY.PEEK[HEADER])')
                if resp.result != 'OK':
                    continue
                headers_map, flags_map, current_uid = {}, {}, None
                for line in resp.lines:
                    lb = line if isinstance(line, (bytes, bytearray)) else (line.encode('utf-8', errors='replace') if isinstance(line, str) else None)
                    if lb is None:
                        continue
                    ls = lb.decode('utf-8', errors='replace')
                    if b'FETCH' in lb and b'UID' in lb:
                        current_uid = _extract_uid(ls)
                        if current_uid:
                            headers_map[current_uid] = b""
                            flags_map[current_uid] = _extract_seen(ls)
                    elif current_uid is not None:
                        (headers_map.__setitem__(current_uid, headers_map.get(current_uid, b"") + bytes(line)) if isinstance(line, bytearray) else
                         flags_map.__setitem__(current_uid, _extract_seen(ls)) if isinstance(line, bytes) and b'FLAGS' in lb else None)
                for uid, raw_hdr in headers_map.items():
                    if not raw_hdr:
                        continue
                    parsed = parse_email(raw_hdr)
                    if not parsed:
                        continue
                    await _insert_parsed(account["id"], folder_id, uid, parsed, 0, flags_map.get(uid, 0), 0)
        except Exception:
            return
def _acct_lock(aid: int) -> asyncio.Lock:
    if aid not in _locks:
        _locks[aid] = asyncio.Lock()
    return _locks[aid]
async def fetch_email_body(account: dict, folder_path: str, uid: int):
    aid = account["id"]
    async with _acct_lock(aid):
        try:
            client = await get_imap(account)
            sel = await client.select(folder_path)
            if sel.result != 'OK':
                raise RuntimeError(f"SELECT {folder_path} -> {sel.result}")
            resp = await client.uid('fetch', str(uid), '(RFC822)')
            if resp.result != 'OK':
                raise RuntimeError(f"UID FETCH {uid} -> {resp.result}")
            for line in resp.lines:
                if isinstance(line, bytearray):
                    return bytes(line)
            raise RuntimeError(f"no bytearray in FETCH response ({len(resp.lines)} lines)")
        except Exception as e:
            print(f"[BODY] fetch failed for uid {uid} in {folder_path}: {type(e).__name__}: {e}")
            _connections.pop(aid, None)
            raise
async def batch_delete(account: dict, folder_path: str, uids: list):
    async with _acct_lock(account["id"]):
        client = await get_imap(account)
        await client.select(folder_path)
        uid_str = ",".join(str(u) for u in uids)
        await client.uid("store", uid_str, "+FLAGS", "(\\Deleted)")
        await client.expunge()
async def batch_move(account: dict, folder_path: str, uids: list, dest_folder: str):
    async with _acct_lock(account["id"]):
        client = await get_imap(account)
        await client.select(folder_path)
        uid_str = ",".join(str(u) for u in uids)
        await client.uid("copy", uid_str, dest_folder)
        await client.uid("store", uid_str, "+FLAGS", "(\\Deleted)")
        await client.expunge()
async def batch_flag(account: dict, folder_path: str, uids: list, flag: str, add: bool = True):
    async with _acct_lock(account["id"]):
        client = await get_imap(account)
        await client.select(folder_path)
        uid_str = ",".join(str(u) for u in uids)
        op = "+FLAGS" if add else "-FLAGS"
        await client.uid("store", uid_str, op, f"({flag})")
async def idle_listen(account: dict, folder_path: str, callback):
    client = await get_imap(account)
    await client.select(folder_path)
    while True:
        try:
            idle = await client.idle_start(timeout=300)
            msg = await client.wait_server_push()
            client.idle_done()
            if any(b"EXISTS" in (m if isinstance(m, bytes) else m.encode()) for m in msg):
                await callback(account, folder_path)
        except Exception:
            await asyncio.sleep(5)
            try:
                client = await get_imap(account)
                await client.select(folder_path)
            except Exception:
                break
