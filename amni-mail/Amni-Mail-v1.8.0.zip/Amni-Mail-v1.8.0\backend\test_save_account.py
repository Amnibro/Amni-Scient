import sys
sys.path.insert(0, '.')
import auth

try:
    print("Testing auth.save_account_creds...")
    auth.save_account_creds(999, "test@example.com", "password123")
    print("Success!")
    print("Creds:", auth.load_all_creds())
except Exception as e:
    import traceback
    traceback.print_exc()
