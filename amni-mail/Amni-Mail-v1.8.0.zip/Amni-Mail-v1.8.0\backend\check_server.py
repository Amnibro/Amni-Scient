import urllib.request
try:
    res = urllib.request.urlopen("http://localhost:8025/")
    print(res.headers)
    print(res.read()[:500])
except Exception as e:
    print(e)
    if hasattr(e, 'read'):
        print(e.read()[:500])
