import json, asyncio, re as _re
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
import db
router = APIRouter(prefix="/api/rules", tags=["rules"])
class RuleIn(BaseModel):
    account_id: Optional[int] = None
    name: Optional[str] = None
    enabled: Optional[bool] = None
    conditions: Optional[List[Dict[str, Any]]] = None
    condition_mode: Optional[str] = None
    actions: Optional[List[Dict[str, Any]]] = None
    run_on_existing: Optional[bool] = None
def _match(em: dict, cond: dict) -> bool:
    field, op, val = cond.get("field","subject"), cond.get("op","contains"), (cond.get("value","") or "").lower()
    target = (em.get(field) or "").lower()
    return (val in target if op == "contains" else
            val not in target if op == "not_contains" else
            val == target if op == "equals" else
            target.startswith(val) if op == "starts_with" else
            target.endswith(val) if op == "ends_with" else
            (bool(_re.search(val, target)) if op == "regex" else False))
def _matches(em: dict, conditions: list, mode: str) -> bool:
    return (not conditions) and False or (all(_match(em, c) for c in conditions) if mode == "all" else any(_match(em, c) for c in conditions))
async def _exec_action(em: dict, action: dict):
    t = action.get("type")
    (t == "mark_read" and await db.exec_q("UPDATE emails SET is_read=1 WHERE id=?", [em["id"]]) or
     t == "mark_starred" and await db.exec_q("UPDATE emails SET is_starred=1 WHERE id=?", [em["id"]]) or
     t == "delete" and await db.exec_q("UPDATE emails SET is_deleted=1 WHERE id=?", [em["id"]]) or
     t == "move" and action.get("folder_id") and await db.exec_q("UPDATE emails SET folder_id=? WHERE id=?", [action["folder_id"], em["id"]]) or
     t == "label" and action.get("value") and await db.exec_q("UPDATE emails SET ai_category=? WHERE id=?", [action["value"], em["id"]]))
async def apply_all_rules(account_id: int, email_ids: list):
    if not email_ids:
        return
    rules = await db.fetch_all("SELECT * FROM rules WHERE (account_id=? OR account_id IS NULL) AND enabled=1", [account_id])
    if not rules:
        return
    ph = ",".join("?" for _ in email_ids)
    emails = await db.fetch_all(f"SELECT id, uid, account_id, folder_id, from_addr, to_addrs, subject, body_text, preview, is_read FROM emails WHERE id IN ({ph}) AND is_deleted=0", email_ids)
    for em in emails:
        for rule in rules:
            try:
                conds = json.loads(rule["conditions"] or "[]")
                acts = json.loads(rule["actions"] or "[]")
                if _matches(em, conds, rule.get("condition_mode") or "any"):
                    for act in acts:
                        await _exec_action(em, act)
            except Exception:
                pass
def _parse_rule(r: dict) -> dict:
    return {**r, "conditions": json.loads(r["conditions"] or "[]"), "actions": json.loads(r["actions"] or "[]")}
@router.get("/")
async def list_rules(account_id: Optional[int] = None):
    rows = (await db.fetch_all("SELECT * FROM rules WHERE account_id=? OR account_id IS NULL ORDER BY id", [account_id])
            if account_id else await db.fetch_all("SELECT * FROM rules ORDER BY id"))
    return [_parse_rule(r) for r in rows]
@router.post("/")
async def create_rule(rule: RuleIn):
    cur = await db.exec_q(
        "INSERT INTO rules (account_id, name, enabled, conditions, condition_mode, actions, run_on_existing) VALUES (?,?,?,?,?,?,?)",
        [rule.account_id, rule.name or "", 1 if rule.enabled else 0,
         json.dumps(rule.conditions or []), rule.condition_mode or "any", json.dumps(rule.actions or []), 1 if rule.run_on_existing else 0])
    if rule.run_on_existing:
        sql = "SELECT id, uid, account_id, folder_id, from_addr, to_addrs, subject, body_text, preview FROM emails WHERE is_deleted=0"
        params = []
        if rule.account_id:
            sql += " AND account_id=?"
            params.append(rule.account_id)
        emails = await db.fetch_all(sql, params)
        matched = [e for e in emails if _matches(e, rule.conditions, rule.condition_mode)]
        for em in matched:
            for act in rule.actions:
                await _exec_action(em, act)
    return {"id": cur.lastrowid}
@router.patch("/{rule_id}")
async def update_rule(rule_id: int, rule: RuleIn):
    existing = await db.fetch_one("SELECT * FROM rules WHERE id=?", [rule_id])
    if not existing:
        raise HTTPException(404, "Rule not found")
    ex = dict(existing)
    name = rule.name if rule.name is not None else ex["name"]
    enabled = (1 if rule.enabled else 0) if rule.enabled is not None else ex["enabled"]
    conditions = json.dumps(rule.conditions) if rule.conditions is not None else ex["conditions"]
    condition_mode = rule.condition_mode if rule.condition_mode is not None else ex["condition_mode"]
    actions = json.dumps(rule.actions) if rule.actions is not None else ex["actions"]
    account_id = rule.account_id if rule.account_id is not None else ex["account_id"]
    await db.exec_q(
        "UPDATE rules SET name=?, enabled=?, conditions=?, condition_mode=?, actions=?, account_id=? WHERE id=?",
        [name, enabled, conditions, condition_mode, actions, account_id, rule_id])
    return {"id": rule_id}
@router.delete("/{rule_id}")
async def delete_rule(rule_id: int):
    await db.exec_q("DELETE FROM rules WHERE id=?", [rule_id])
    return {"deleted": True}
@router.post("/{rule_id}/run")
async def run_rule(rule_id: int, account_id: Optional[int] = None):
    rule = await db.fetch_one("SELECT * FROM rules WHERE id=?", [rule_id])
    if not rule:
        raise HTTPException(404, "Rule not found")
    sql = "SELECT id, uid, account_id, folder_id, from_addr, to_addrs, subject, body_text, preview FROM emails WHERE is_deleted=0"
    params: list = []
    if account_id:
        sql += " AND account_id=?"
        params.append(account_id)
    emails = await db.fetch_all(sql, params)
    conds = json.loads(rule["conditions"] or "[]")
    acts = json.loads(rule["actions"] or "[]")
    matched = 0
    for em in emails:
        if _matches(em, conds, rule.get("condition_mode") or "any"):
            for act in acts:
                await _exec_action(em, act)
            matched += 1
    return {"count": matched}
