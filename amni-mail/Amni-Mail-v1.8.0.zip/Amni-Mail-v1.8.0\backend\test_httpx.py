import httpx
import asyncio

async def test():
    async with httpx.AsyncClient() as client:
        resp = await client.post("http://localhost:8026/api/accounts/", json={
            "name": "test",
            "email": "httpx_test@gmail.com",
            "password": "test",
            "auth_type": "password",
            "color": "#ffffff"
        })
        print(f"Status: {resp.status_code}")
        print(f"Body: {resp.text}")

asyncio.run(test())
