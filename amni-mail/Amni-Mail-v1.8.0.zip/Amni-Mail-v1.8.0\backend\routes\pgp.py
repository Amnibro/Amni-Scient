from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional, List
import db, asyncio
from auth import _fernet
try:
    from pgpy import PGPKey, PGPMessage, PGPUID
    from pgpy.constants import PubKeyAlgorithm, KeyFlags, HashAlgorithm, SymmetricKeyAlgorithm, CompressionAlgorithm
    PGP_AVAILABLE = True
except Exception:
    PGP_AVAILABLE = False
router = APIRouter(prefix="/api/pgp", tags=["pgp"])
_BEGIN_MSG = "-----BEGIN PGP MESSAGE-----"
_BEGIN_SIG = "-----BEGIN PGP SIGNATURE-----"
_BEGIN_SIGNED = "-----BEGIN PGP SIGNED MESSAGE-----"
_BEGIN_PUB = "-----BEGIN PGP PUBLIC KEY BLOCK-----"
_BEGIN_PRIV = "-----BEGIN PGP PRIVATE KEY BLOCK-----"
class GenerateKeyIn(BaseModel):
    account_id: int
    name: str
    email: str
    passphrase: str
    rsa_bits: int = 4096
class ImportKeyIn(BaseModel):
    account_id: Optional[int] = None
    armored: str
    passphrase: Optional[str] = None
class RecipientImportIn(BaseModel):
    email: str
    armored: str
class SignIn(BaseModel):
    account_id: int
    body: str
    passphrase: str
class VerifyIn(BaseModel):
    body: str
    sender_email: Optional[str] = None
class EncryptIn(BaseModel):
    account_id: Optional[int] = None
    body: str
    recipients: List[str]
    sign: bool = True
    passphrase: Optional[str] = None
class DecryptIn(BaseModel):
    account_id: int
    armored: str
    passphrase: str
class DetectIn(BaseModel):
    body: str
def _ensure_pgp():
    if not PGP_AVAILABLE: raise HTTPException(503, "PGP support unavailable (pgpy not installed)")
async def _load_key_row(key_id: int = None, account_id: int = None, email: str = None, with_private: bool = False):
    if key_id:
        return await db.fetch_one("SELECT * FROM pgp_keys WHERE id=?", [key_id])
    if account_id:
        row = await db.fetch_one("SELECT * FROM pgp_keys WHERE account_id=? AND is_default=1 AND private_key_enc IS NOT NULL", [account_id])
        if row: return row
        return await db.fetch_one("SELECT * FROM pgp_keys WHERE account_id=? AND private_key_enc IS NOT NULL ORDER BY id DESC LIMIT 1", [account_id])
    if email:
        return await db.fetch_one("SELECT * FROM pgp_keys WHERE LOWER(email)=? ORDER BY (private_key_enc IS NOT NULL) DESC, is_default DESC LIMIT 1", [email.lower()])
    return None
def _decrypt_priv(row: dict) -> str:
    raw = row["private_key_enc"]
    if not raw: raise HTTPException(400, "Key row has no private component")
    return _fernet.decrypt(raw if isinstance(raw, bytes) else bytes(raw)).decode()
def _gen_keypair_sync(name: str, email: str, passphrase: str, rsa_bits: int):
    key = PGPKey.new(PubKeyAlgorithm.RSAEncryptOrSign, rsa_bits)
    uid = PGPUID.new(name, email=email)
    key.add_uid(uid, usage={KeyFlags.Sign, KeyFlags.EncryptCommunications, KeyFlags.EncryptStorage},
                hashes=[HashAlgorithm.SHA256, HashAlgorithm.SHA512],
                ciphers=[SymmetricKeyAlgorithm.AES256, SymmetricKeyAlgorithm.AES192],
                compression=[CompressionAlgorithm.ZLIB, CompressionAlgorithm.Uncompressed])
    key.protect(passphrase, SymmetricKeyAlgorithm.AES256, HashAlgorithm.SHA256)
    return key
@router.post("/keys/generate")
async def generate_key(data: GenerateKeyIn):
    _ensure_pgp()
    if not data.passphrase or len(data.passphrase) < 4: raise HTTPException(400, "passphrase too short (min 4 chars)")
    key = await asyncio.get_event_loop().run_in_executor(None, _gen_keypair_sync, data.name, data.email, data.passphrase, data.rsa_bits)
    fp = str(key.fingerprint).replace(" ", "")
    pub = str(key.pubkey)
    priv_enc = _fernet.encrypt(str(key).encode())
    is_default = 0 if await db.fetch_one("SELECT 1 FROM pgp_keys WHERE account_id=? AND private_key_enc IS NOT NULL", [data.account_id]) else 1
    await db.exec_q("INSERT INTO pgp_keys (account_id, email, fingerprint, public_key, private_key_enc, is_default) VALUES (?,?,?,?,?,?)",
                    [data.account_id, data.email.lower(), fp, pub, priv_enc, is_default])
    return {"fingerprint": fp, "email": data.email, "is_default": bool(is_default), "public_key": pub}
@router.post("/keys/import")
async def import_key(data: ImportKeyIn):
    _ensure_pgp()
    try: key, _ = PGPKey.from_blob(data.armored)
    except Exception as e: raise HTTPException(400, f"Could not parse PGP key: {e}")
    fp = str(key.fingerprint).replace(" ", "")
    uids = list(key.userids)
    email = (uids[0].email or "") if uids else ""
    if not email: raise HTTPException(400, "Key has no email UID")
    pub = str(key.pubkey)
    priv_enc = _fernet.encrypt(str(key).encode()) if key.is_protected or not key.is_public else (_fernet.encrypt(str(key).encode()) if not key.is_public else None)
    if data.account_id and priv_enc:
        is_default = 0 if await db.fetch_one("SELECT 1 FROM pgp_keys WHERE account_id=? AND private_key_enc IS NOT NULL AND fingerprint!=?", [data.account_id, fp]) else 1
    else:
        is_default = 0
    existing = await db.fetch_one("SELECT id FROM pgp_keys WHERE fingerprint=?", [fp])
    if existing:
        await db.exec_q("UPDATE pgp_keys SET account_id=COALESCE(?, account_id), public_key=?, private_key_enc=COALESCE(?, private_key_enc) WHERE id=?",
                        [data.account_id, pub, priv_enc, existing["id"]])
        return {"fingerprint": fp, "email": email, "updated": True}
    await db.exec_q("INSERT INTO pgp_keys (account_id, email, fingerprint, public_key, private_key_enc, is_default) VALUES (?,?,?,?,?,?)",
                    [data.account_id, email.lower(), fp, pub, priv_enc, is_default])
    return {"fingerprint": fp, "email": email, "is_default": bool(is_default)}
@router.get("/keys")
async def list_keys(account_id: Optional[int] = None):
    rows = await (db.fetch_all("SELECT id, account_id, email, fingerprint, is_default, created_at, (private_key_enc IS NOT NULL) AS has_private FROM pgp_keys WHERE account_id=? ORDER BY is_default DESC, id DESC", [account_id])
                  if account_id else
                  db.fetch_all("SELECT id, account_id, email, fingerprint, is_default, created_at, (private_key_enc IS NOT NULL) AS has_private FROM pgp_keys ORDER BY is_default DESC, id DESC"))
    return rows
@router.delete("/keys/{key_id}")
async def delete_key(key_id: int):
    await db.exec_q("DELETE FROM pgp_keys WHERE id=?", [key_id])
    return {"deleted": key_id}
@router.post("/recipients/import")
async def import_recipient(data: RecipientImportIn):
    _ensure_pgp()
    try: key, _ = PGPKey.from_blob(data.armored)
    except Exception as e: raise HTTPException(400, f"Could not parse public key: {e}")
    if not key.is_public: key = key.pubkey
    fp = str(key.fingerprint).replace(" ", "")
    pub = str(key)
    existing = await db.fetch_one("SELECT id FROM pgp_keys WHERE fingerprint=?", [fp])
    if existing:
        await db.exec_q("UPDATE pgp_keys SET email=?, public_key=? WHERE id=?", [data.email.lower(), pub, existing["id"]])
        return {"fingerprint": fp, "updated": True}
    await db.exec_q("INSERT INTO pgp_keys (account_id, email, fingerprint, public_key, private_key_enc) VALUES (NULL,?,?,?,NULL)",
                    [data.email.lower(), fp, pub])
    return {"fingerprint": fp, "imported": True}
@router.get("/recipients")
async def lookup_recipient(email: str):
    row = await db.fetch_one("SELECT id, email, fingerprint, public_key FROM pgp_keys WHERE LOWER(email)=? LIMIT 1", [email.lower()])
    return row or {"found": False}
@router.post("/sign")
async def sign(data: SignIn):
    _ensure_pgp()
    row = await _load_key_row(account_id=data.account_id)
    if not row: raise HTTPException(404, "No private key for account")
    armored = _decrypt_priv(row)
    key, _ = PGPKey.from_blob(armored)
    try:
        with key.unlock(data.passphrase):
            sig = key.sign(data.body)
    except Exception as e: raise HTTPException(401, f"Sign failed: {e}")
    return {"signature": str(sig), "fingerprint": row["fingerprint"]}
@router.post("/verify")
async def verify(data: VerifyIn):
    _ensure_pgp()
    body = data.body
    is_signed = _BEGIN_SIGNED in body or _BEGIN_SIG in body
    if not is_signed: return {"valid": False, "reason": "no signature found"}
    sender_row = None
    if data.sender_email:
        sender_row = await db.fetch_one("SELECT public_key, fingerprint FROM pgp_keys WHERE LOWER(email)=? ORDER BY id DESC LIMIT 1", [data.sender_email.lower()])
    try:
        msg = PGPMessage.from_blob(body)
    except Exception as e: return {"valid": False, "reason": f"parse error: {e}"}
    if not sender_row: return {"valid": False, "reason": "no public key for sender", "is_signed": True}
    try:
        pub, _ = PGPKey.from_blob(sender_row["public_key"])
        result = pub.verify(msg)
        ok = bool(result)
        return {"valid": ok, "fingerprint": sender_row["fingerprint"], "is_signed": True}
    except Exception as e: return {"valid": False, "reason": str(e), "is_signed": True}
@router.post("/encrypt")
async def encrypt(data: EncryptIn):
    _ensure_pgp()
    pubs = []
    for r in data.recipients:
        row = await db.fetch_one("SELECT public_key, fingerprint FROM pgp_keys WHERE LOWER(email)=? ORDER BY id DESC LIMIT 1", [r.lower()])
        if not row: raise HTTPException(404, f"No public key on file for {r}")
        pub, _ = PGPKey.from_blob(row["public_key"])
        pubs.append(pub)
    msg = PGPMessage.new(data.body)
    if data.sign and data.account_id:
        srow = await _load_key_row(account_id=data.account_id)
        if srow and srow["private_key_enc"]:
            sk, _ = PGPKey.from_blob(_decrypt_priv(srow))
            try:
                with sk.unlock(data.passphrase or ""):
                    msg |= sk.sign(msg)
            except Exception as e: raise HTTPException(401, f"Sign-during-encrypt failed: {e}")
    enc = pubs[0].encrypt(msg) if len(pubs) == 1 else None
    if enc is None:
        cipher = SymmetricKeyAlgorithm.AES256
        sess = cipher.gen_key()
        enc = msg
        for p in pubs: enc = p.encrypt(enc, cipher=cipher, sessionkey=sess)
        del sess
    return {"armored": str(enc), "recipients": data.recipients}
@router.post("/decrypt")
async def decrypt(data: DecryptIn):
    _ensure_pgp()
    row = await _load_key_row(account_id=data.account_id)
    if not row: raise HTTPException(404, "No private key for account")
    sk, _ = PGPKey.from_blob(_decrypt_priv(row))
    try:
        msg = PGPMessage.from_blob(data.armored)
    except Exception as e: raise HTTPException(400, f"parse error: {e}")
    try:
        with sk.unlock(data.passphrase):
            decrypted = sk.decrypt(msg)
    except Exception as e: raise HTTPException(401, f"decrypt failed: {e}")
    plaintext = decrypted.message if isinstance(decrypted.message, str) else decrypted.message.decode("utf-8", "replace")
    signers = []
    for s in (decrypted.signatures or []):
        try: signers.append(str(s.signer))
        except Exception: pass
    return {"plaintext": plaintext, "signers": signers, "fingerprint": row["fingerprint"]}
@router.post("/detect")
async def detect(data: DetectIn):
    body = data.body or ""
    has_msg = _BEGIN_MSG in body
    has_signed = _BEGIN_SIGNED in body
    has_sig = _BEGIN_SIG in body
    has_pub = _BEGIN_PUB in body
    if has_signed and has_sig: t = "clearsigned"
    elif has_msg: t = "encrypted"
    elif has_pub: t = "public_key_block"
    elif has_sig: t = "detached_signature"
    else: t = None
    return {"is_pgp": bool(t), "type": t, "has_public_key_block": has_pub, "has_message": has_msg, "has_signed": has_signed}
