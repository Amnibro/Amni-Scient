import re
from datetime import datetime, timezone
from typing import Optional
_LINE = re.compile(r"\r\n[ \t]")
def _unfold(text: str) -> str:
    return _LINE.sub("", (text or "").replace("\r\n", "\r\n").replace("\n", "\r\n"))
def _split_prop(line: str):
    if ":" not in line:
        return None, {}, ""
    head, value = line.split(":", 1)
    parts = head.split(";")
    name = parts[0].upper()
    params = {}
    for p in parts[1:]:
        if "=" in p:
            k, v = p.split("=", 1)
            params[k.upper()] = v.strip().strip('"')
    return name, params, value.strip()
def _parse_dt(value: str, params: dict) -> Optional[str]:
    if not value:
        return None
    v = value.strip()
    try:
        if v.endswith("Z"):
            return datetime.strptime(v, "%Y%m%dT%H%M%SZ").replace(tzinfo=timezone.utc).isoformat()
        if "T" in v:
            return datetime.strptime(v, "%Y%m%dT%H%M%S").isoformat()
        return datetime.strptime(v, "%Y%m%d").isoformat()
    except Exception:
        return v
def _unescape(s: str) -> str:
    return (s or "").replace("\\N", "\n").replace("\\n", "\n").replace("\\,", ",").replace("\\;", ";").replace("\\\\", "\\")
def parse_ics(text: str) -> list:
    if not text:
        return []
    unfolded = _unfold(text)
    events = []
    cur = None
    attendees = []
    for raw in unfolded.split("\r\n"):
        line = raw.strip()
        if not line:
            continue
        name, params, value = _split_prop(line)
        if name == "BEGIN" and value.upper() == "VEVENT":
            cur = {"attendees": []}
            attendees = []
            continue
        if name == "END" and value.upper() == "VEVENT":
            if cur is not None:
                cur["attendees"] = attendees
                events.append(cur)
            cur = None
            continue
        if cur is None:
            if name == "METHOD":
                method = value.upper()
            continue
        if name == "UID":
            cur["uid"] = value
        elif name == "SUMMARY":
            cur["summary"] = _unescape(value)
        elif name == "DESCRIPTION":
            cur["description"] = _unescape(value)
        elif name == "LOCATION":
            cur["location"] = _unescape(value)
        elif name == "ORGANIZER":
            cur["organizer"] = value.replace("MAILTO:", "").replace("mailto:", "")
            cur["organizer_name"] = params.get("CN", "")
        elif name == "ATTENDEE":
            attendees.append({
                "email": value.replace("MAILTO:", "").replace("mailto:", ""),
                "name": params.get("CN", ""),
                "partstat": params.get("PARTSTAT", "NEEDS-ACTION"),
                "role": params.get("ROLE", "REQ-PARTICIPANT")
            })
        elif name == "DTSTART":
            cur["dtstart"] = _parse_dt(value, params)
        elif name == "DTEND":
            cur["dtend"] = _parse_dt(value, params)
        elif name == "RRULE":
            cur["rrule"] = value
        elif name == "SEQUENCE":
            try:
                cur["sequence"] = int(value)
            except Exception:
                cur["sequence"] = 0
        elif name == "STATUS":
            cur["status"] = value
    for ev in events:
        ev.setdefault("summary", "")
        ev.setdefault("description", "")
        ev.setdefault("location", "")
        ev.setdefault("organizer", "")
        ev.setdefault("dtstart", None)
        ev.setdefault("dtend", None)
        ev.setdefault("rrule", "")
        ev.setdefault("uid", "")
        ev.setdefault("sequence", 0)
    return events
def get_method(text: str) -> str:
    for raw in _unfold(text or "").split("\r\n"):
        name, _, value = _split_prop(raw.strip())
        if name == "METHOD":
            return value.upper()
    return ""
def _fold(line: str) -> str:
    return line if len(line) <= 75 else line[:75] + "\r\n " + _fold(line[75:])
def build_reply(event: dict, attendee_email: str, attendee_name: str, partstat: str, comment: str = "") -> str:
    now = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    lines = [
        "BEGIN:VCALENDAR",
        "VERSION:2.0",
        "PRODID:-//Amni//Amni-Mail//EN",
        "METHOD:REPLY",
        "BEGIN:VEVENT",
        f"UID:{event.get('uid','')}",
        f"DTSTAMP:{now}",
        f"SEQUENCE:{event.get('sequence', 0)}",
        f"SUMMARY:{event.get('summary','')}",
        f"ORGANIZER:mailto:{event.get('organizer','')}",
        f"ATTENDEE;CN={attendee_name or attendee_email};PARTSTAT={partstat.upper()};RSVP=TRUE:mailto:{attendee_email}",
    ]
    if event.get("dtstart"):
        lines.append(f"DTSTART:{event['dtstart'].replace('-','').replace(':','').split('.')[0].replace('+00:00','Z') if 'T' in event['dtstart'] else event['dtstart'].replace('-','')}")
    if comment:
        lines.append(f"COMMENT:{comment}")
    lines += ["END:VEVENT", "END:VCALENDAR"]
    return "\r\n".join(_fold(l) for l in lines)
