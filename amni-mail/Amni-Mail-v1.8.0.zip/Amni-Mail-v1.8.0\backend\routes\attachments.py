from fastapi import APIRouter, HTTPException, Response
from typing import Optional
from pathlib import PurePosixPath, PureWindowsPath
from urllib.parse import quote
import db, re, io, zipfile
from attachment_extractor import extract_text
router = APIRouter(prefix="/api/attachments", tags=["attachments"])
_SAFE_ASCII = re.compile(r'[^A-Za-z0-9._-]+')
def _safe_filename(raw: str) -> str:
    name = (raw or "file").replace("\x00", "")
    name = PurePosixPath(PureWindowsPath(name).name).name
    name = name.lstrip(".") or "file"
    return name[:200]
@router.get("/")
async def list_attachments(account_id: Optional[int] = None, q: Optional[str] = None,
    content_type: Optional[str] = None, limit: int = 200, offset: int = 0):
    sql = ("SELECT a.id, a.email_id, a.filename, a.content_type, a.size, e.from_addr, e.from_name, "
           "e.subject, e.date, e.account_id FROM attachments a JOIN emails e ON a.email_id=e.id "
           "WHERE e.is_deleted=0")
    params = []
    if account_id:
        sql += " AND e.account_id=?"
        params.append(account_id)
    if q:
        sql += " AND (a.filename LIKE ? OR e.subject LIKE ? OR e.from_addr LIKE ?)"
        like = f"%{q}%"
        params.extend([like, like, like])
    if content_type:
        sql += " AND a.content_type LIKE ?"
        params.append(f"{content_type}%")
    sql += " ORDER BY e.date DESC LIMIT ? OFFSET ?"
    params.extend([limit, offset])
    rows = await db.fetch_all(sql, params)
    total = await db.fetch_one(
        "SELECT COUNT(*) as cnt FROM attachments a JOIN emails e ON a.email_id=e.id WHERE e.is_deleted=0" + (" AND e.account_id=?" if account_id else ""),
        [account_id] if account_id else [])
    return {"attachments": rows, "total": total["cnt"], "offset": offset, "limit": limit}
@router.get("/{attachment_id}")
async def download_attachment(attachment_id: int, inline: int = 0):
    row = await db.fetch_one("SELECT filename, content_type, data FROM attachments WHERE id=?", [attachment_id])
    if not row or not row.get("data"):
        raise HTTPException(404, "Attachment not found")
    safe = _safe_filename(row.get("filename"))
    ascii_fallback = _SAFE_ASCII.sub('_', safe) or "file"
    ct = (row.get("content_type") or "").lower()
    is_image = ct.startswith("image/") and any(ct.startswith(f"image/{x}") for x in ("jpeg","jpg","png","gif","webp","bmp","x-icon","vnd.microsoft.icon"))
    if inline and is_image:
        return Response(content=row["data"], media_type=row.get("content_type") or "image/jpeg",
            headers={"Content-Disposition": f'inline; filename="{ascii_fallback}"', "X-Content-Type-Options": "nosniff", "Cache-Control": "private, max-age=3600"})
    disp = f'attachment; filename="{ascii_fallback}"; filename*=UTF-8\'\'{quote(safe)}'
    return Response(content=row["data"], media_type="application/octet-stream",
        headers={"Content-Disposition": disp, "X-Content-Type-Options": "nosniff"})
@router.get("/email/{email_id}/zip")
async def download_email_zip(email_id: int):
    em = await db.fetch_one("SELECT subject FROM emails WHERE id=? AND is_deleted=0", [email_id])
    if not em:
        raise HTTPException(404, "Email not found")
    rows = await db.fetch_all("SELECT filename, data FROM attachments WHERE email_id=? ORDER BY id", [email_id])
    if not rows:
        raise HTTPException(404, "No attachments")
    buf = io.BytesIO()
    seen = {}
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
        for r in rows:
            data = r.get("data") or b""
            if not data:
                continue
            name = _safe_filename(r.get("filename") or "file")
            n = seen.get(name, 0)
            seen[name] = n + 1
            if n:
                stem, _, ext = name.rpartition(".")
                name = f"{stem}_{n}.{ext}" if stem and ext else f"{name}_{n}"
            zf.writestr(name, data)
    blob = buf.getvalue()
    subj = _safe_filename((em.get("subject") or f"email-{email_id}")[:80]) or f"email-{email_id}"
    zip_name = _SAFE_ASCII.sub('_', subj) + ".zip"
    disp = f'attachment; filename="{zip_name}"; filename*=UTF-8\'\'{quote(subj + ".zip")}'
    return Response(content=blob, media_type="application/zip",
        headers={"Content-Disposition": disp, "X-Content-Type-Options": "nosniff"})
@router.get("/extract/status")
async def extract_status():
    total = await db.fetch_one("SELECT COUNT(*) AS n FROM attachments")
    done = await db.fetch_one("SELECT COUNT(*) AS n FROM attachments WHERE extracted_text IS NOT NULL AND extracted_text != ''")
    pending = await db.fetch_one("SELECT COUNT(*) AS n FROM attachments WHERE extracted_text IS NULL")
    return {"total": (total or {}).get("n", 0), "indexed": (done or {}).get("n", 0), "pending": (pending or {}).get("n", 0)}
@router.post("/extract/all")
async def extract_all(batch: int = 100):
    rows = await db.fetch_all("SELECT id, filename, content_type, data FROM attachments WHERE extracted_text IS NULL LIMIT ?", [batch])
    n = 0
    for r in rows:
        text = extract_text(r.get("filename") or "", r.get("content_type") or "", r.get("data") or b"")
        await db.exec_q("UPDATE attachments SET extracted_text=? WHERE id=?", [text or "", r["id"]])
        n += 1
    return {"processed": n, "remaining": (await extract_status()).get("pending", 0)}
@router.get("/stats/types")
async def stats_types(account_id: Optional[int] = None):
    sql = ("SELECT a.content_type, COUNT(*) as count, SUM(a.size) as total_size FROM attachments a "
           "JOIN emails e ON a.email_id=e.id WHERE e.is_deleted=0")
    params = []
    if account_id:
        sql += " AND e.account_id=?"
        params.append(account_id)
    sql += " GROUP BY a.content_type ORDER BY count DESC"
    return await db.fetch_all(sql, params)
