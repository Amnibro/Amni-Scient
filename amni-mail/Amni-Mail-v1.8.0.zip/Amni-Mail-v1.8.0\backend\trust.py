import re
_AUTH_SPF = re.compile(r'\bspf\s*=\s*(pass|fail|softfail|neutral|none|temperror|permerror)\b', re.I)
_AUTH_DKIM = re.compile(r'\bdkim\s*=\s*(pass|fail|none|policy|neutral|temperror|permerror)\b', re.I)
_AUTH_DMARC = re.compile(r'\bdmarc\s*=\s*(pass|fail|none|bestguesspass|temperror|permerror)\b', re.I)
_IMG_TAG = re.compile(r'<img\b([^>]*)>', re.I)
_ATTR = re.compile(r'(\w+)\s*=\s*"([^"]*)"|(\w+)\s*=\s*\'([^\']*)\'|(\w+)\s*=\s*(\S+)', re.I)
_TRACK_HINTS = ('/track', '/open', '/pixel', '/beacon', '/wf/open', '/email/o', '?utm_', '&utm_', '/o/eJ', '/e/c/', 'pixel.gif', 'open.gif', '1x1.gif', '/spacer', 'mailtrack', 'sendgrid', 'mandrill', 'mailgun', 'campaign-archive', 'list-manage')
_BRANDS = {'paypal':'paypal.com','amazon':'amazon.com','microsoft':'microsoft.com','apple':'apple.com','google':'google.com','dhl':'dhl.com','fedex':'fedex.com','ups':'ups.com','netflix':'netflix.com','usps':'usps.com','irs':'irs.gov','linkedin':'linkedin.com','facebook':'facebook.com','meta':'meta.com','chase':'chase.com','wellsfargo':'wellsfargo.com','bankofamerica':'bofa.com','docusign':'docusign.com','dropbox':'dropbox.com','github':'github.com'}
def _parse_auth(auth_results: str) -> dict:
    if not auth_results:
        return {'spf': 'unknown', 'dkim': 'unknown', 'dmarc': 'unknown', 'present': False}
    s = auth_results.lower()
    spf = (_AUTH_SPF.search(s) or [None, 'unknown'])[1]
    dkim = (_AUTH_DKIM.search(s) or [None, 'unknown'])[1]
    dmarc = (_AUTH_DMARC.search(s) or [None, 'unknown'])[1]
    return {'spf': spf, 'dkim': dkim, 'dmarc': dmarc, 'present': True}
def _count_trackers(html: str) -> int:
    if not html:
        return 0
    n = 0
    for m in _IMG_TAG.finditer(html):
        if n >= 50:
            break
        attrs = {}
        for a in _ATTR.finditer(m.group(1)):
            k = (a.group(1) or a.group(3) or a.group(5) or '').lower()
            v = a.group(2) or a.group(4) or a.group(6) or ''
            if k:
                attrs[k] = v
        src = attrs.get('src', '').lower()
        if not src or src.startswith('cid:') or src.startswith('data:'):
            continue
        if not (src.startswith('http://') or src.startswith('https://') or src.startswith('//')):
            continue
        try:
            w = int(attrs.get('width', '999'))
            h = int(attrs.get('height', '999'))
        except ValueError:
            w = h = 999
        if w <= 3 or h <= 3 or any(t in src for t in _TRACK_HINTS):
            n += 1
    return n
def _domain(addr: str) -> str:
    return (addr or '').rsplit('@', 1)[-1].lower().strip('>').strip()
def _brand_mismatch(from_name: str, from_addr: str) -> str:
    n = (from_name or '').lower()
    d = _domain(from_addr)
    for brand, official in _BRANDS.items():
        if brand in n and official not in d and not d.endswith('.' + official):
            return brand
    return ''
def compute_trust(row: dict, history: dict) -> dict:
    auth = _parse_auth(row.get('auth_results') or '')
    trackers = _count_trackers(row.get('body_html') or '')
    from_addr = row.get('from_addr') or ''
    from_name = row.get('from_name') or ''
    reply_to = row.get('reply_to') or ''
    fdom = _domain(from_addr)
    rdom = _domain(reply_to)
    rt_diverges = bool(reply_to) and rdom != fdom and not row.get('is_list')
    brand_spoof = _brand_mismatch(from_name, from_addr)
    sender_count = int(history.get('count') or 0)
    first_seen = history.get('first_seen') or ''
    replied = int(history.get('replied') or 0)
    signals = []
    score = 50
    if auth['present']:
        if auth['dmarc'] == 'pass': score += 20; signals.append({'kind':'good','label':f"DMARC pass"})
        elif auth['dmarc'] == 'fail': score -= 30; signals.append({'kind':'bad','label':"DMARC fail"})
        if auth['dkim'] == 'pass': score += 10; signals.append({'kind':'good','label':"DKIM signature valid"})
        elif auth['dkim'] == 'fail': score -= 20; signals.append({'kind':'bad','label':"DKIM signature invalid"})
        if auth['spf'] == 'pass': score += 10; signals.append({'kind':'good','label':"SPF pass"})
        elif auth['spf'] in ('fail','softfail'): score -= 15; signals.append({'kind':'bad','label':f"SPF {auth['spf']}"})
    else:
        signals.append({'kind':'neutral','label':"No Authentication-Results header (server stripped it)"})
    if trackers > 0:
        score -= min(15, trackers * 2)
        signals.append({'kind':'warn','label':f"{trackers} tracker pixel{'s' if trackers != 1 else ''} detected"})
    if brand_spoof:
        score -= 40
        signals.append({'kind':'bad','label':f"Display name says \"{brand_spoof}\" but domain is {fdom}"})
    if rt_diverges:
        score -= 20
        signals.append({'kind':'warn','label':f"Reply-To ({rdom}) differs from sender ({fdom})"})
    if sender_count >= 3:
        score += min(15, sender_count // 3)
        signals.append({'kind':'good','label':f"{sender_count} prior emails from this sender"})
    elif sender_count == 0:
        signals.append({'kind':'neutral','label':"First email from this sender"})
    if replied > 0:
        score += 10
        signals.append({'kind':'good','label':f"You've replied {replied} time{'s' if replied != 1 else ''}"})
    score = max(0, min(100, score))
    if brand_spoof or auth['dmarc'] == 'fail' or auth['dkim'] == 'fail':
        verdict = 'spoofing'
    elif rt_diverges or (auth['present'] and auth['spf'] in ('fail','softfail')):
        verdict = 'caution'
    elif sender_count >= 3 and replied > 0 and (auth['dmarc'] == 'pass' or not auth['present']):
        verdict = 'verified'
    elif sender_count >= 3:
        verdict = 'trusted'
    elif sender_count == 0:
        verdict = 'new'
    else:
        verdict = 'trusted'
    return {'verdict': verdict, 'score': score, 'signals': signals, 'auth': auth, 'trackers': trackers, 'sender': {'count': sender_count, 'first_seen': first_seen, 'replied': replied, 'from_domain': fdom, 'reply_to_domain': rdom}}
