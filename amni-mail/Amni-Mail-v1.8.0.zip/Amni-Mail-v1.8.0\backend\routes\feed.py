from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional
import asyncio
import db
import imap_client
router = APIRouter(prefix="/api/feed", tags=["feed"])
_FEED_CATS = ("newsletter", "promotion", "notification", "social", "receipt")
class ArchiveSenderRequest(BaseModel):
    account_id: int
    from_addr: str
class MarkSenderReadRequest(BaseModel):
    account_id: int
    from_addr: str
class ScreenSenderRequest(BaseModel):
    account_id: int
    from_addr: str
    decision: str
def _norm(addr: str) -> str:
    return (addr or "").strip().lower()
@router.get("/senders")
async def feed_senders(account_id: Optional[int] = None, limit: int = 200, days: int = 30):
    cat_phs = ",".join("?" for _ in _FEED_CATS)
    q = f"""
    SELECT
      LOWER(e.from_addr) as from_addr_lc,
      MAX(e.from_name) as from_name,
      MAX(e.from_addr) as from_addr,
      e.account_id as account_id,
      COUNT(*) as count,
      SUM(CASE WHEN e.is_read=0 THEN 1 ELSE 0 END) as unread,
      MAX(e.date) as last_seen,
      MIN(e.date) as first_seen,
      (SELECT id FROM emails WHERE LOWER(from_addr)=LOWER(e.from_addr) AND account_id=e.account_id ORDER BY date DESC LIMIT 1) as sample_id,
      (SELECT preview FROM emails WHERE LOWER(from_addr)=LOWER(e.from_addr) AND account_id=e.account_id ORDER BY date DESC LIMIT 1) as last_preview,
      (SELECT subject FROM emails WHERE LOWER(from_addr)=LOWER(e.from_addr) AND account_id=e.account_id ORDER BY date DESC LIMIT 1) as last_subject,
      MAX(e.ai_category) as ai_category,
      EXISTS(SELECT 1 FROM muted_senders m WHERE m.account_id=e.account_id AND m.from_addr=LOWER(e.from_addr)) as is_muted,
      EXISTS(SELECT 1 FROM emails u WHERE LOWER(u.from_addr)=LOWER(e.from_addr) AND u.account_id=e.account_id AND (u.unsubscribe_uri IS NOT NULL OR u.unsubscribe_post IS NOT NULL)) as has_unsub
    FROM emails e
    JOIN folders f ON e.folder_id=f.id
    WHERE e.ai_category IN ({cat_phs})
      AND f.folder_type IN ('inbox','archive')
      AND e.date >= datetime('now', ?)
    """
    params: list = list(_FEED_CATS) + [f"-{int(days)} days"]
    if account_id is not None:
        q += " AND e.account_id=?"
        params.append(account_id)
    q += f" GROUP BY e.account_id, LOWER(e.from_addr) ORDER BY unread DESC, count DESC LIMIT ?"
    params.append(int(limit))
    rows = await db.fetch_all(q, params)
    return {"items": rows, "categories": list(_FEED_CATS), "days": days}
@router.post("/archive-sender")
async def archive_sender(req: ArchiveSenderRequest):
    addr = _norm(req.from_addr)
    if not addr:
        raise HTTPException(400, "from_addr required")
    arch = await db.fetch_one("SELECT id, path FROM folders WHERE account_id=? AND folder_type='archive' LIMIT 1", [req.account_id])
    if not arch:
        raise HTTPException(404, "No archive folder for account")
    rows = await db.fetch_all(
        "SELECT e.id, e.uid, f.path as src_path FROM emails e JOIN folders f ON e.folder_id=f.id WHERE e.account_id=? AND LOWER(e.from_addr)=? AND f.folder_type='inbox'",
        [req.account_id, addr]
    )
    if not rows:
        return {"archived": 0}
    ids = [r["id"] for r in rows]
    placeholders = ",".join("?" for _ in ids)
    await db.exec_q(f"UPDATE emails SET folder_id=? WHERE id IN ({placeholders})", [arch["id"]] + ids)
    by_folder: dict = {}
    for r in rows:
        by_folder.setdefault(r["src_path"], []).append(r["uid"])
    async def _bg(fpath, uids):
        try:
            acc = await db.fetch_one("SELECT * FROM accounts WHERE id=?", [req.account_id])
            if acc:
                await asyncio.wait_for(imap_client.batch_move(acc, fpath, uids, arch["path"]), timeout=30)
        except Exception:
            pass
    for fpath, uids in by_folder.items():
        asyncio.create_task(_bg(fpath, uids))
    return {"archived": len(ids), "ids": ids}
@router.get("/unscreened")
async def unscreened_senders(account_id: Optional[int] = None, limit: int = 30, days: int = 30, min_count: int = 2):
    q = """
    SELECT
      LOWER(e.from_addr) as from_addr_lc,
      MAX(e.from_name) as from_name,
      MAX(e.from_addr) as from_addr,
      e.account_id as account_id,
      COUNT(*) as count,
      SUM(CASE WHEN e.is_read=0 THEN 1 ELSE 0 END) as unread,
      MAX(e.date) as last_seen,
      MIN(e.date) as first_seen,
      (SELECT subject FROM emails WHERE LOWER(from_addr)=LOWER(e.from_addr) AND account_id=e.account_id ORDER BY date DESC LIMIT 1) as last_subject,
      MAX(e.ai_category) as ai_category
    FROM emails e
    JOIN folders f ON e.folder_id=f.id
    WHERE f.folder_type IN ('inbox','archive')
      AND e.date >= datetime('now', ?)
      AND NOT EXISTS (SELECT 1 FROM screened_senders s WHERE s.account_id=e.account_id AND s.from_addr=LOWER(e.from_addr))
      AND NOT EXISTS (SELECT 1 FROM muted_senders m WHERE m.account_id=e.account_id AND m.from_addr=LOWER(e.from_addr))
    """
    params: list = [f"-{int(days)} days"]
    if account_id is not None:
        q += " AND e.account_id=?"
        params.append(account_id)
    q += " GROUP BY e.account_id, LOWER(e.from_addr) HAVING count >= ? ORDER BY count DESC, unread DESC LIMIT ?"
    params.extend([int(min_count), int(limit)])
    rows = await db.fetch_all(q, params)
    return {"items": rows, "now": __import__('datetime').datetime.utcnow().isoformat() + 'Z'}
@router.post("/screen-sender")
async def screen_sender(req: ScreenSenderRequest):
    addr = _norm(req.from_addr)
    if not addr or "@" not in addr:
        raise HTTPException(400, "Invalid from_addr")
    decision = (req.decision or "").lower()
    if decision not in ("inbox", "feed", "bin"):
        raise HTTPException(400, "decision must be inbox, feed, or bin")
    await db.exec_q("INSERT OR REPLACE INTO screened_senders (account_id, from_addr, decision) VALUES (?,?,?)", [req.account_id, addr, decision])
    archived = 0
    if decision == "feed":
        arch = await db.fetch_one("SELECT id, path FROM folders WHERE account_id=? AND folder_type='archive' LIMIT 1", [req.account_id])
        if arch:
            rows = await db.fetch_all(
                "SELECT e.id, e.uid, f.path as src_path FROM emails e JOIN folders f ON e.folder_id=f.id WHERE e.account_id=? AND LOWER(e.from_addr)=? AND f.folder_type='inbox'",
                [req.account_id, addr]
            )
            if rows:
                ids = [r["id"] for r in rows]
                ph = ",".join("?" for _ in ids)
                await db.exec_q(f"UPDATE emails SET folder_id=? WHERE id IN ({ph})", [arch["id"]] + ids)
                archived = len(ids)
                by_folder: dict = {}
                for r in rows:
                    by_folder.setdefault(r["src_path"], []).append(r["uid"])
                async def _bg(fpath, uids):
                    try:
                        acc = await db.fetch_one("SELECT * FROM accounts WHERE id=?", [req.account_id])
                        if acc:
                            await asyncio.wait_for(imap_client.batch_move(acc, fpath, uids, arch["path"]), timeout=30)
                    except Exception:
                        pass
                for fpath, uids in by_folder.items():
                    asyncio.create_task(_bg(fpath, uids))
    elif decision == "bin":
        await db.exec_q("INSERT OR IGNORE INTO muted_senders (account_id, from_addr) VALUES (?,?)", [req.account_id, addr])
        from routes.muted import _sweep_existing
        archived = await _sweep_existing(req.account_id, addr)
    return {"ok": True, "decision": decision, "archived": archived}
@router.post("/screen-bulk")
async def screen_bulk(req: dict):
    items = req.get("items") or []
    total_archived = 0
    results = []
    for it in items:
        try:
            r = await screen_sender(ScreenSenderRequest(**it))
            total_archived += r.get("archived", 0)
            results.append({"from_addr": it.get("from_addr"), "ok": True, "archived": r.get("archived", 0)})
        except Exception as e:
            results.append({"from_addr": it.get("from_addr"), "ok": False, "error": str(e)})
    return {"ok": True, "total_archived": total_archived, "results": results}
@router.post("/mark-sender-read")
async def mark_sender_read(req: MarkSenderReadRequest):
    addr = _norm(req.from_addr)
    rows = await db.fetch_all(
        "SELECT e.id, e.uid, f.path as src_path FROM emails e JOIN folders f ON e.folder_id=f.id WHERE e.account_id=? AND LOWER(e.from_addr)=? AND e.is_read=0",
        [req.account_id, addr]
    )
    if not rows:
        return {"marked": 0}
    ids = [r["id"] for r in rows]
    ph = ",".join("?" for _ in ids)
    await db.exec_q(f"UPDATE emails SET is_read=1 WHERE id IN ({ph})", ids)
    by_folder: dict = {}
    for r in rows:
        by_folder.setdefault(r["src_path"], []).append(r["uid"])
    async def _bg(fpath, uids):
        try:
            acc = await db.fetch_one("SELECT * FROM accounts WHERE id=?", [req.account_id])
            if acc:
                await asyncio.wait_for(imap_client.batch_flag(acc, fpath, uids, "\\Seen", True), timeout=30)
        except Exception:
            pass
    for fpath, uids in by_folder.items():
        asyncio.create_task(_bg(fpath, uids))
    return {"marked": len(ids)}
