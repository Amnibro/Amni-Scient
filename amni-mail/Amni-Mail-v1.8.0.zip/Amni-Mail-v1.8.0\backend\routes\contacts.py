from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional
import db
router = APIRouter(prefix="/api/contacts", tags=["contacts"])
class ContactUpdate(BaseModel):
    name: Optional[str] = None
    starred: Optional[bool] = None
    notes: Optional[str] = None
@router.get("/")
async def list_contacts(q: Optional[str] = None, limit: int = 100, starred: Optional[bool] = None):
    sql = "SELECT * FROM contacts WHERE 1=1"
    params = []
    if q:
        sql += " AND (email LIKE ? OR name LIKE ?)"
        like = f"%{q}%"
        params.extend([like, like])
    if starred is not None:
        sql += " AND starred=?"
        params.append(1 if starred else 0)
    sql += " ORDER BY starred DESC, hit_count DESC, name ASC LIMIT ?"
    params.append(limit)
    return await db.fetch_all(sql, params)
@router.get("/autocomplete")
async def autocomplete(q: str, limit: int = 10):
    if not q:
        return []
    like = f"%{q}%"
    prefix = f"{q}%"
    return await db.fetch_all(
        "SELECT id,email,name,hit_count,starred FROM contacts WHERE email LIKE ? OR name LIKE ? ORDER BY CASE WHEN email LIKE ? OR name LIKE ? THEN 0 ELSE 1 END, starred DESC, hit_count DESC LIMIT ?",
        [like, like, prefix, prefix, limit])
@router.get("/insights")
async def insights(email: str, account_id: int):
    addr = (email or "").strip().lower()
    if not addr:
        raise HTTPException(400, "email required")
    contact = await db.fetch_one("SELECT name, hit_count, starred, notes FROM contacts WHERE LOWER(email)=?", [addr])
    received = await db.fetch_one("SELECT COUNT(*) AS c, MIN(date) AS first_d, MAX(date) AS last_d FROM emails WHERE account_id=? AND LOWER(from_addr)=?", [account_id, addr])
    sent_row = await db.fetch_one("SELECT COUNT(*) AS c FROM emails e JOIN folders f ON f.id=e.folder_id WHERE e.account_id=? AND f.folder_type='sent' AND (LOWER(e.to_addrs) LIKE ? OR LOWER(e.cc_addrs) LIKE ?)", [account_id, f"%{addr}%", f"%{addr}%"])
    last_subjects = await db.fetch_all("SELECT subject, date, is_read FROM emails WHERE account_id=? AND LOWER(from_addr)=? ORDER BY date DESC LIMIT 5", [account_id, addr])
    cats = await db.fetch_all("SELECT ai_category AS cat, COUNT(*) AS c FROM emails WHERE account_id=? AND LOWER(from_addr)=? AND ai_category IS NOT NULL AND ai_category!='' GROUP BY ai_category ORDER BY c DESC LIMIT 6", [account_id, addr])
    vip = await db.fetch_one("SELECT 1 FROM vip_senders WHERE account_id=? AND LOWER(from_addr)=?", [account_id, addr])
    muted = await db.fetch_one("SELECT 1 FROM muted_senders WHERE account_id=? AND LOWER(from_addr)=?", [account_id, addr])
    daily_rows = await db.fetch_all("SELECT substr(date,1,10) AS d, COUNT(*) AS c FROM emails WHERE account_id=? AND LOWER(from_addr)=? AND date >= datetime('now','-30 days') GROUP BY substr(date,1,10)", [account_id, addr])
    from datetime import date as _date, timedelta as _td
    _today = _date.today()
    _dmap = {(r["d"] or ""): r["c"] for r in (daily_rows or [])}
    daily_counts = [_dmap.get((_today - _td(days=29 - i)).isoformat(), 0) for i in range(30)]
    pairs = await db.fetch_all("SELECT date FROM emails WHERE account_id=? AND LOWER(from_addr)=? ORDER BY date ASC", [account_id, addr])
    sent_to = await db.fetch_all("SELECT e.date FROM emails e JOIN folders f ON f.id=e.folder_id WHERE e.account_id=? AND f.folder_type='sent' AND (LOWER(e.to_addrs) LIKE ? OR LOWER(e.cc_addrs) LIKE ?) ORDER BY e.date ASC", [account_id, f"%{addr}%", f"%{addr}%"])
    avg_resp_h = None
    if pairs and sent_to:
        from datetime import datetime
        def _p(s):
            try: return datetime.fromisoformat(str(s).replace('Z','+00:00').split('.')[0]) if s else None
            except Exception: return None
        recv_dts = [d for d in (_p(r["date"]) for r in pairs) if d]
        sent_dts = [d for d in (_p(r["date"]) for r in sent_to) if d]
        deltas = []
        si = 0
        for rd in recv_dts:
            while si < len(sent_dts) and sent_dts[si] <= rd: si += 1
            if si < len(sent_dts):
                dh = (sent_dts[si] - rd).total_seconds() / 3600.0
                if 0 < dh < 720: deltas.append(dh)
        if deltas: avg_resp_h = round(sum(deltas) / len(deltas), 1)
    return {
        "email": addr,
        "contact_name": (contact or {}).get("name") if contact else None,
        "notes": (contact or {}).get("notes") if contact else None,
        "starred": bool((contact or {}).get("starred")) if contact else False,
        "total_received": (received or {}).get("c", 0) if received else 0,
        "total_sent": (sent_row or {}).get("c", 0) if sent_row else 0,
        "first_contact_date": (received or {}).get("first_d") if received else None,
        "last_contact_date": (received or {}).get("last_d") if received else None,
        "last_subjects": [{"subject": r["subject"], "date": r["date"], "is_read": bool(r["is_read"])} for r in (last_subjects or [])],
        "categories": [{"category": r["cat"], "count": r["c"]} for r in (cats or [])],
        "avg_response_time_hours": avg_resp_h,
        "is_vip": bool(vip),
        "is_muted": bool(muted),
        "daily_counts_30d": daily_counts,
    }
@router.patch("/{contact_id}")
async def update_contact(contact_id: int, data: ContactUpdate):
    existing = await db.fetch_one("SELECT id FROM contacts WHERE id=?", [contact_id])
    if not existing:
        raise HTTPException(404, "Contact not found")
    payload = data.model_dump(exclude_none=True)
    if "starred" in payload:
        payload["starred"] = 1 if payload["starred"] else 0
    if payload:
        cols = ",".join(f"{k}=?" for k in payload)
        await db.exec_q(f"UPDATE contacts SET {cols} WHERE id=?", list(payload.values()) + [contact_id])
    return await db.fetch_one("SELECT * FROM contacts WHERE id=?", [contact_id])
@router.delete("/{contact_id}")
async def delete_contact(contact_id: int):
    await db.exec_q("DELETE FROM contacts WHERE id=?", [contact_id])
    return {"deleted": contact_id}
