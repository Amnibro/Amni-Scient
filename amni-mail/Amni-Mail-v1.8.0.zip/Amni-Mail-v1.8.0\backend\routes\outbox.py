from fastapi import APIRouter, HTTPException
from typing import Optional
import db
router = APIRouter(prefix="/api/outbox", tags=["outbox"])
@router.get("")
async def list_outbox(account_id: Optional[int] = None, include_sent: bool = False):
    statuses = "('pending','sending','failed','sent')" if include_sent else "('pending','sending','failed')"
    sql = f"SELECT id,account_id,to_addrs,cc_addrs,bcc_addrs,subject,send_at,status,attempts,next_retry_at,error,created_at,sent_at,is_outbox FROM scheduled_sends WHERE status IN {statuses}"
    params = []
    if account_id:
        sql += " AND account_id=?"
        params.append(account_id)
    sql += " ORDER BY (status='failed') DESC, COALESCE(next_retry_at, send_at) ASC LIMIT 200"
    rows = await db.fetch_all(sql, params)
    return {"items": rows, "failed_count": sum(1 for r in rows if r.get("status") == "failed"), "pending_count": sum(1 for r in rows if r.get("status") == "pending")}
@router.post("/{item_id}/retry")
async def retry_one(item_id: int):
    row = await db.fetch_one("SELECT id,status FROM scheduled_sends WHERE id=?", [item_id])
    if not row:
        raise HTTPException(404, "Not found")
    if row.get("status") not in ("failed", "pending"):
        raise HTTPException(400, f"Cannot retry status={row.get('status')}")
    await db.exec_q("UPDATE scheduled_sends SET status='pending', next_retry_at=NULL, send_at=datetime('now'), is_outbox=1 WHERE id=?", [item_id])
    return {"id": item_id, "status": "pending"}
@router.post("/flush")
async def flush_all(account_id: Optional[int] = None):
    sql = "UPDATE scheduled_sends SET status='pending', next_retry_at=NULL, send_at=datetime('now') WHERE status='failed' AND is_outbox=1"
    params = []
    if account_id:
        sql += " AND account_id=?"
        params.append(account_id)
    cur = await db.exec_q(sql, params)
    return {"queued": cur.rowcount}
@router.delete("/{item_id}")
async def cancel_one(item_id: int):
    row = await db.fetch_one("SELECT status FROM scheduled_sends WHERE id=?", [item_id])
    if not row:
        raise HTTPException(404, "Not found")
    if row.get("status") in ("sending", "sent"):
        raise HTTPException(400, "Already sending or sent")
    await db.exec_q("DELETE FROM scheduled_sends WHERE id=?", [item_id])
    return {"id": item_id, "deleted": True}
@router.get("/count")
async def outbox_count():
    row = await db.fetch_one("SELECT COUNT(*) AS n FROM scheduled_sends WHERE status='failed' AND is_outbox=1")
    return {"failed": int((row or {}).get("n") or 0)}
