import io, re
_PDF_PAGE_CAP = 50
_MAX_BYTES = 25 * 1024 * 1024
_SKIP_EXTS = ('.docm', '.xlsm', '.xltm', '.pptm', '.dotm', '.exe', '.dll', '.zip', '.tar', '.gz', '.7z', '.rar')
_TEXT_CTS = ('text/plain', 'text/csv', 'text/markdown', 'text/x-markdown', 'application/json', 'application/xml', 'text/xml')
_TEXT_EXTS = ('.txt', '.csv', '.md', '.markdown', '.log', '.json', '.xml', '.yaml', '.yml', '.ini', '.cfg', '.tsv')
_WS_RE = re.compile(r'[ \t]+')
_NL_RE = re.compile(r'\n{3,}')
def _normalize(text: str, max_chars: int) -> str:
    t = _WS_RE.sub(' ', text or '')
    t = _NL_RE.sub('\n\n', t).strip()
    return t[:max_chars]
def _extract_pdf(data: bytes, max_chars: int) -> str:
    from pypdf import PdfReader
    reader = PdfReader(io.BytesIO(data))
    parts = []
    total = 0
    for i, page in enumerate(reader.pages[:_PDF_PAGE_CAP]):
        if total >= max_chars:
            break
        try:
            t = page.extract_text() or ''
        except Exception:
            t = ''
        if t:
            parts.append(t)
            total += len(t)
    return _normalize('\n'.join(parts), max_chars)
def _extract_docx(data: bytes, max_chars: int) -> str:
    from docx import Document
    doc = Document(io.BytesIO(data))
    parts = [p.text for p in doc.paragraphs if p.text]
    for table in doc.tables:
        for row in table.rows:
            parts.append(' | '.join(c.text for c in row.cells if c.text))
    return _normalize('\n'.join(parts), max_chars)
def _extract_text(data: bytes, max_chars: int) -> str:
    try:
        return _normalize(data.decode('utf-8', errors='replace'), max_chars)
    except Exception:
        return ''
def extract_text(filename: str, content_type: str, data: bytes, max_chars: int = 200_000) -> str:
    if not data:
        return ''
    if len(data) > _MAX_BYTES:
        return ''
    fn = (filename or '').lower()
    ct = (content_type or '').lower()
    if any(fn.endswith(ext) for ext in _SKIP_EXTS):
        return ''
    try:
        if 'pdf' in ct or fn.endswith('.pdf'):
            return _extract_pdf(data, max_chars)
        if 'wordprocessingml' in ct or fn.endswith('.docx'):
            return _extract_docx(data, max_chars)
        if any(ct.startswith(t) for t in _TEXT_CTS) or any(fn.endswith(ext) for ext in _TEXT_EXTS):
            return _extract_text(data, max_chars)
    except Exception:
        return ''
    return ''
