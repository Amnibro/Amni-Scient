import os
import base64
import hashlib
import json
from cryptography.fernet import Fernet

def recover():
    path = r'data\credentials.enc'
    if not os.path.exists(path):
        print("No creds found")
        return
    token = open(path, 'rb').read()
    
    mac_strs = [
        "A0-AD-9F-87-0C-C8",
        "00-FF-17-B4-67-16",
        "5A-02-05-4E-E0-48",
        "5A-02-05-4E-F0-58",
        "58-02-05-4E-C0-68",
        "58-02-05-4E-C0-69"
    ]
    
    macs = [int(m.replace('-', ''), 16) for m in mac_strs]
    
    # In Windows, getnode can sometimes return random MACs or ones not listed, but hopefully it's one of these.
    
    cnames = [os.environ.get('COMPUTERNAME', ''), "ANTMAN-PC", "Antman-Pc"]
    unames = [os.environ.get('USERNAME', ''), "antho", "Antho", "Anth"]
    
    # Remove duplicates
    cnames = list(set(cnames))
    unames = list(set(unames))
    
    for mac in macs:
        for cname in cnames:
            for uname in unames:
                seed = cname + uname + str(mac)
                key = base64.urlsafe_b64encode(hashlib.sha256(seed.encode()).digest())
                try:
                    data = json.loads(Fernet(key).decrypt(token).decode())
                    print(f"SUCCESS: mac={mac}, cname={cname}, uname={uname}")
                    
                    # Overwrite auth.py's _get_machine_key to return this specific key,
                    # or just save the key to a file! Let's do that!
                    return key
                except Exception:
                    pass
    print("FAILED to decrypt")

recover()
