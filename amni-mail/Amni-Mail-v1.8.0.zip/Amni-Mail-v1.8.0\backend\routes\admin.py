import time
from fastapi import APIRouter, HTTPException
import db
router = APIRouter(prefix="/api/admin", tags=["admin"])
_FTS = [
    ("emails_fts",      "emails",      "subject, from_addr, from_name, body_text, preview"),
    ("attachments_fts", "attachments", "filename, extracted_text"),
]
@router.post("/rebuild-search")
async def rebuild_search():
    _db = await db.get_db()
    out = []
    t0 = time.time()
    try:
        await _db.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        for fts, content, cols in _FTS:
            t = time.time()
            await _db.execute(f"DROP TABLE IF EXISTS {fts}")
            await _db.execute(f"CREATE VIRTUAL TABLE {fts} USING fts5({cols}, content='{content}', content_rowid='id')")
            await _db.execute(f"INSERT INTO {fts}({fts}) VALUES('rebuild')")
            out.append({"table": fts, "seconds": round(time.time() - t, 2)})
        await _db.commit()
        await _db.execute("VACUUM")
        return {"status": "ok", "total_seconds": round(time.time() - t0, 2), "tables": out}
    except Exception as e:
        raise HTTPException(500, f"Rebuild failed: {type(e).__name__}: {e}")
@router.get("/db-health")
async def db_health():
    _db = await db.get_db()
    cur = await _db.execute("PRAGMA integrity_check(5)")
    rows = await cur.fetchall()
    check = [r[0] for r in rows]
    cur = await _db.execute("PRAGMA foreign_key_check")
    fk_violations = len(await cur.fetchall())
    cur = await _db.execute("SELECT COUNT(*) FROM emails")
    email_count = (await cur.fetchone())[0]
    return {"integrity_check": check, "fk_violations": fk_violations, "email_count": email_count, "healthy": check == ["ok"] and fk_violations == 0}
