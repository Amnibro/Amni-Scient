from fastapi.testclient import TestClient
from main import app

client = TestClient(app)

print("Sending POST request...")
try:
    response = client.post("/api/accounts/", json={
        "name": "test",
        "email": "test_fastapi@gmail.com",
        "password": "test",
        "auth_type": "password",
        "color": "#ffffff"
    })
    print(response.status_code)
    print(response.json())
except Exception as e:
    import traceback
    traceback.print_exc()
