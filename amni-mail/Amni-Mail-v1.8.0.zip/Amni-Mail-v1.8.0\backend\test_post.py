import urllib.request
import json
import urllib.error

data = json.dumps({
    'name': 'test',
    'email': 'random_email_123@gmail.com',
    'password': 'test',
    'auth_type': 'password',
    'color': '#ffffff'
}).encode()

req = urllib.request.Request('http://localhost:8025/api/accounts', data=data, headers={'Content-Type': 'application/json'}, method='POST')

try:
    res = urllib.request.urlopen(req)
    print("Success:", res.read().decode())
except urllib.error.HTTPError as e:
    print("HTTP Error:", e.code)
    print("Response:", e.read().decode())
except Exception as e:
    print("Error:", e)
