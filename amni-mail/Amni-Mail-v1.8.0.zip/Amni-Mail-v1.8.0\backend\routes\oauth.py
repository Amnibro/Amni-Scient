import secrets, hashlib, base64, json, time, os
from urllib.parse import urlencode
from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import HTMLResponse
import httpx
from config import cfg
import db, auth
router = APIRouter(prefix="/api/oauth", tags=["oauth"])
_pending: dict[str, dict] = {}
_CALLBACK = f"http://localhost:{cfg.port}/api/oauth/callback"
def _get_creds(provider: str):
    prefix = "GOOGLE" if provider == "gmail" else "MICROSOFT"
    env_id = os.environ.get(f"{prefix}_CLIENT_ID", "")
    env_sec = os.environ.get(f"{prefix}_CLIENT_SECRET", "")
    if provider == "gmail":
        return env_id or (cfg.google_client_id or ""), env_sec or (cfg.google_client_secret or "")
    return env_id or (cfg.microsoft_client_id or ""), env_sec or (cfg.microsoft_client_secret or "")
_PROVIDERS = {
    "gmail": {
        "auth_url": "https://accounts.google.com/o/oauth2/v2/auth",
        "token_url": "https://oauth2.googleapis.com/token",
        "userinfo_url": "https://www.googleapis.com/oauth2/v2/userinfo",
        "scopes": "https://mail.google.com/ openid email profile",
        "imap_host": "imap.gmail.com", "imap_port": 993,
        "smtp_host": "smtp.gmail.com", "smtp_port": 587,
    },
    "outlook": {
        "auth_url": "https://login.microsoftonline.com/common/oauth2/v2.0/authorize",
        "token_url": "https://login.microsoftonline.com/common/oauth2/v2.0/token",
        "userinfo_url": "https://graph.microsoft.com/v1.0/me",
        "scopes": "https://outlook.office.com/IMAP.AccessAsUser.All https://outlook.office.com/SMTP.Send openid email profile offline_access",
        "imap_host": "outlook.office365.com", "imap_port": 993,
        "smtp_host": "smtp.office365.com", "smtp_port": 587,
    },
}
def _pkce():
    verifier = secrets.token_urlsafe(64)
    challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b"=").decode()
    return verifier, challenge
@router.get("/start")
async def oauth_start(provider: str):
    prov = _PROVIDERS.get(provider)
    if not prov:
        raise HTTPException(400, f"Unknown provider: {provider}")
    cid, _ = _get_creds(provider)
    if not cid:
        raise HTTPException(400, f"No OAuth app for {provider}. Settings → Accounts → paste your {provider} client id and secret, or use an app password.")
    verifier, challenge = _pkce()
    state = secrets.token_urlsafe(32)
    _pending[state] = {"provider": provider, "verifier": verifier, "ts": time.time()}
    for k in list(_pending):
        if time.time() - _pending[k]["ts"] > 600:
            _pending.pop(k, None)
    params = {
        "client_id": cid,
        "redirect_uri": _CALLBACK,
        "response_type": "code",
        "scope": prov["scopes"],
        "code_challenge": challenge,
        "code_challenge_method": "S256",
        "state": state,
        "access_type": "offline",
        "prompt": "select_account",
    }
    return {"url": f"{prov['auth_url']}?{urlencode(params)}"}
@router.get("/callback")
async def oauth_callback(code: str = "", state: str = "", error: str = ""):
    if error:
        return HTMLResponse(_done_html(f"Authorization denied: {error}", False))
    pending = _pending.pop(state, None)
    if not pending:
        return HTMLResponse(_done_html("Invalid or expired state. Try again.", False))
    provider = pending["provider"]
    verifier = pending["verifier"]
    prov = _PROVIDERS[provider]
    cid, csec = _get_creds(provider)
    if not cid or not csec:
        return HTMLResponse(_done_html("Provider credentials not configured.", False))
    async with httpx.AsyncClient(timeout=15) as client:
        tok_resp = await client.post(prov["token_url"], data={
            "client_id": cid, "client_secret": csec,
            "code": code, "redirect_uri": _CALLBACK,
            "grant_type": "authorization_code",
            "code_verifier": verifier,
            "scope": prov["scopes"],
        })
    if tok_resp.status_code != 200:
        return HTMLResponse(_done_html(f"Token exchange failed: {tok_resp.text[:200]}", False))
    tokens = tok_resp.json()
    access_token = tokens.get("access_token", "")
    refresh_token = tokens.get("refresh_token", "")
    id_token = tokens.get("id_token", "")
    email_addr = display_name = ""
    if id_token:
        try:
            payload = id_token.split(".")[1]
            payload += "=" * (4 - len(payload) % 4)
            ui = json.loads(base64.urlsafe_b64decode(payload).decode("utf-8"))
            email_addr = ui.get("email") or ui.get("preferred_username") or ui.get("upn") or ""
            dn = ui.get("name") or ""
            if not dn:
                gn = ui.get("given_name", "")
                fn = ui.get("family_name", "")
                dn = (gn + " " + fn).strip()
            display_name = dn or (email_addr.split("@")[0] if "@" in email_addr else "")
        except Exception:
            pass
    if not email_addr:
        async with httpx.AsyncClient(timeout=10) as client:
            hdr = {"Authorization": f"Bearer {access_token}"}
            ui_resp = await client.get(prov["userinfo_url"], headers=hdr)
            if ui_resp.status_code == 200:
                ui = ui_resp.json()
                email_addr = ui.get("email") or ui.get("mail") or ui.get("userPrincipalName", "")
                display_name = ui.get("name") or ui.get("displayName") or (email_addr.split("@")[0] if email_addr else "")
    if not email_addr:
        return HTMLResponse(_done_html("Could not retrieve email from provider.", False))
    import sqlite3
    try:
        cursor = await db.exec_q(
            "INSERT INTO accounts (name,email,imap_host,imap_port,smtp_host,smtp_port,auth_type,color) VALUES (?,?,?,?,?,?,?,?)",
            [display_name, email_addr, prov["imap_host"], prov["imap_port"],
             prov["smtp_host"], prov["smtp_port"], "oauth2", "#4A90D9"]
        )
    except sqlite3.IntegrityError:
        return HTMLResponse(_done_html(f"Account {email_addr} is already connected.", False))
    aid = cursor.lastrowid
    auth.save_account_creds(aid, email_addr, "", oauth_token=access_token, refresh_token=refresh_token)
    import asyncio, sync_engine
    account = await db.fetch_one("SELECT * FROM accounts WHERE id=?", [aid])
    if account:
        asyncio.create_task(sync_engine.sync_account(dict(account)))
    return HTMLResponse(_done_html(f"Signed in as {email_addr}! You can close this tab.", True))
@router.post("/refresh/{account_id}")
async def oauth_refresh(account_id: int):
    acc = await db.fetch_one("SELECT * FROM accounts WHERE id=?", [account_id])
    if not acc or acc["auth_type"] != "oauth2":
        raise HTTPException(400, "Not an OAuth account")
    creds = auth.load_account_creds(account_id)
    rt = creds.get("refresh_token")
    if not rt:
        raise HTTPException(400, "No refresh token stored")
    domain = acc["email"].split("@")[-1].lower()
    provider = "outlook" if domain in ("outlook.com", "hotmail.com", "live.com") else "gmail"
    prov = _PROVIDERS.get(provider)
    cid, csec = _get_creds(provider)
    if not cid or not csec:
        raise HTTPException(400, "Provider credentials not configured")
    async with httpx.AsyncClient(timeout=15) as client:
        resp = await client.post(prov["token_url"], data={
            "client_id": cid, "client_secret": csec,
            "refresh_token": rt, "grant_type": "refresh_token",
        })
    if resp.status_code != 200:
        raise HTTPException(400, f"Refresh failed: {resp.text[:200]}")
    tokens = resp.json()
    new_access = tokens.get("access_token", "")
    new_refresh = tokens.get("refresh_token", rt)
    auth.save_account_creds(account_id, acc["email"], "", oauth_token=new_access, refresh_token=new_refresh)
    return {"status": "refreshed"}
@router.get("/providers")
async def oauth_providers():
    out = {}
    for k in _PROVIDERS:
        cid, _ = _get_creds(k)
        out[k] = {"configured": bool(cid), "name": k.capitalize()}
    return out
def _done_html(msg: str, ok: bool) -> str:
    color = "#4caf50" if ok else "#ff5252"
    icon = "&#10004;" if ok else "&#10008;"
    return f"""<!DOCTYPE html><html><head><title>Amni-Mail OAuth</title>
<style>@font-face{{font-family:Archivo;src:local('Archivo')}}body{{font-family:Archivo,'Segoe UI',sans-serif;background:#08090B;color:#EDEFF2;display:flex;align-items:center;justify-content:center;height:100vh;margin:0}}
.card{{text-align:center;padding:40px;border-radius:3px;background:#111418;border:1px solid #20242B;max-width:400px}}
.icon{{font-size:48px;color:{color};margin-bottom:16px}}
p{{font-size:15px;line-height:1.6;margin:0}}</style></head>
<body><div class="card"><div class="icon">{icon}</div><p>{msg}</p></div>
<script>
try {{ window.opener && window.opener.postMessage({{ type: 'amni-oauth-done', ok: {'true' if ok else 'false'}, msg: '{msg.replace(chr(39), chr(92)+chr(39))}' }}, '*'); }} catch(e) {{}}
setTimeout(function(){{ window.close(); }}, 2000);
</script>
</body></html>"""
