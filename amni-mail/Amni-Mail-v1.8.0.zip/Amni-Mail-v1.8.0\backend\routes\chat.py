from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional
import re
import db, ai_engine
router = APIRouter(prefix="/api/chat", tags=["chat"])
class ChatTurn(BaseModel):
    role: str
    content: str
class AskRequest(BaseModel):
    question: str
    account_id: Optional[int] = None
    top_k: int = 8
    history: list[ChatTurn] = []
def _snippet(em: dict, max_chars: int = 400) -> str:
    txt = em.get("body_text") or em.get("preview") or ""
    txt = re.sub(r"<[^>]+>", " ", txt)
    txt = re.sub(r"\s+", " ", txt).strip()
    return txt[:max_chars]
@router.post("/ask")
async def ask(data: AskRequest):
    q = (data.question or "").strip()
    if not q:
        raise HTTPException(400, "question is required")
    q = q[:1000]
    top_k = max(1, min(20, data.top_k))
    history = (data.history or [])[-6:]
    matches = await db.search_emails(q, account_id=data.account_id, limit=top_k)
    if not matches:
        return {"answer": "I couldn't find any emails relevant to that question.", "citations": []}
    full_rows = []
    for m in matches[:top_k]:
        eid = m.get("id")
        if eid is None:
            continue
        row = await db.fetch_one(
            "SELECT id, subject, from_addr, from_name, date, body_text, preview FROM emails WHERE id=?", [eid])
        if row:
            full_rows.append(dict(row))
    citations = [{
        "email_id": r["id"], "subject": r.get("subject") or "(no subject)",
        "from": r.get("from_name") or r.get("from_addr") or "", "date": r.get("date") or "",
        "snippet": _snippet(r, 160),
    } for r in full_rows]
    answer = await ai_engine.chat_inbox(q, full_rows, history)
    return {"answer": answer, "citations": citations}
