import os, json, base64, hashlib, uuid
from cryptography.fernet import Fernet, InvalidToken
from config import CRED_PATH, DATA_DIR

MACHINE_KEY_PATH = DATA_DIR / "machine.key"

def _get_machine_key():
    if MACHINE_KEY_PATH.exists():
        return MACHINE_KEY_PATH.read_bytes()
    
    seed = os.environ.get("COMPUTERNAME", "") + os.environ.get("USERNAME", "") + str(uuid.getnode())
    old_key = base64.urlsafe_b64encode(hashlib.sha256(seed.encode()).digest())
    
    # Try to decrypt existing creds with old key. If it works, save it.
    if CRED_PATH.exists():
        try:
            Fernet(old_key).decrypt(CRED_PATH.read_bytes())
            MACHINE_KEY_PATH.write_bytes(old_key)
            return old_key
        except InvalidToken:
            pass # corrupted or changed MAC
    
    # Otherwise generate a new random key and save it
    new_key = Fernet.generate_key()
    MACHINE_KEY_PATH.write_bytes(new_key)
    return new_key

_fernet = Fernet(_get_machine_key())

def encrypt_creds(data: dict) -> bytes:
    return _fernet.encrypt(json.dumps(data).encode())

def decrypt_creds(token: bytes) -> dict:
    try:
        return json.loads(_fernet.decrypt(token).decode())
    except InvalidToken:
        return {}

def save_account_creds(account_id: int, username: str, password: str, oauth_token: str = None, refresh_token: str = None):
    creds = load_all_creds()
    creds[str(account_id)] = {"username": username, "password": password, "oauth_token": oauth_token, "refresh_token": refresh_token}
    CRED_PATH.write_bytes(encrypt_creds(creds))
def load_account_creds(account_id: int) -> dict:
    creds = load_all_creds()
    return creds.get(str(account_id), {})
def has_account_creds(account_id: int) -> bool:
    c = load_account_creds(account_id)
    return bool(c and (c.get("password") or c.get("oauth_token") or c.get("refresh_token")))
def load_all_creds() -> dict:
    return decrypt_creds(CRED_PATH.read_bytes()) if CRED_PATH.exists() else {}
def delete_account_creds(account_id: int):
    creds = load_all_creds()
    creds.pop(str(account_id), None)
    CRED_PATH.write_bytes(encrypt_creds(creds)) if creds else CRED_PATH.unlink(missing_ok=True)
OAUTH_PROVIDERS = {
    "gmail": {
        "auth_url": "https://accounts.google.com/o/oauth2/v2/auth",
        "token_url": "https://oauth2.googleapis.com/token",
        "scopes": ["https://mail.google.com/"],
        "imap_host": "imap.gmail.com", "imap_port": 993,
        "smtp_host": "smtp.gmail.com", "smtp_port": 587,
    },
    "outlook": {
        "auth_url": "https://login.microsoftonline.com/common/oauth2/v2.0/authorize",
        "token_url": "https://login.microsoftonline.com/common/oauth2/v2.0/token",
        "scopes": ["https://outlook.office.com/IMAP.AccessAsUser.All", "https://outlook.office.com/SMTP.Send", "openid", "email", "profile", "offline_access"],
        "imap_host": "outlook.office365.com", "imap_port": 993,
        "smtp_host": "smtp.office365.com", "smtp_port": 587,
    }
}
COMMON_PROVIDERS = {
    "gmail.com": {"imap_host": "imap.gmail.com", "imap_port": 993, "smtp_host": "smtp.gmail.com", "smtp_port": 587},
    "outlook.com": {"imap_host": "outlook.office365.com", "imap_port": 993, "smtp_host": "smtp.office365.com", "smtp_port": 587},
    "hotmail.com": {"imap_host": "outlook.office365.com", "imap_port": 993, "smtp_host": "smtp.office365.com", "smtp_port": 587},
    "live.com": {"imap_host": "outlook.office365.com", "imap_port": 993, "smtp_host": "smtp.office365.com", "smtp_port": 587},
    "yahoo.com": {"imap_host": "imap.mail.yahoo.com", "imap_port": 993, "smtp_host": "smtp.mail.yahoo.com", "smtp_port": 587},
    "aol.com": {"imap_host": "imap.aol.com", "imap_port": 993, "smtp_host": "smtp.aol.com", "smtp_port": 587},
    "icloud.com": {"imap_host": "imap.mail.me.com", "imap_port": 993, "smtp_host": "smtp.mail.me.com", "smtp_port": 587},
    "protonmail.com": {"imap_host": "127.0.0.1", "imap_port": 1143, "smtp_host": "127.0.0.1", "smtp_port": 1025},
    "zoho.com": {"imap_host": "imap.zoho.com", "imap_port": 993, "smtp_host": "smtp.zoho.com", "smtp_port": 587},
    "fastmail.com": {"imap_host": "imap.fastmail.com", "imap_port": 993, "smtp_host": "smtp.fastmail.com", "smtp_port": 587},
}
def detect_provider(email: str) -> dict:
    domain = email.split("@")[-1].lower()
    return COMMON_PROVIDERS.get(domain, {})
