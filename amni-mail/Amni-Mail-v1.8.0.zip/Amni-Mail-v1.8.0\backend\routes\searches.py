import json
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional, Dict, Any
import db
router = APIRouter(prefix="/api/searches", tags=["searches"])
_COLS = "id, name, query, pinned, created_at, auto_apply, auto_action"
class SearchCreate(BaseModel):
    name: str
    query: str
    pinned: bool = False
    auto_apply: Optional[bool] = False
    auto_action: Optional[Dict[str, Any]] = None
class SearchUpdate(BaseModel):
    name: Optional[str] = None
    query: Optional[str] = None
    pinned: Optional[bool] = None
    auto_apply: Optional[bool] = None
    auto_action: Optional[Dict[str, Any]] = None
def _hydrate(row: dict) -> dict:
    if not row: return row
    out = dict(row)
    raw = out.get("auto_action")
    out["auto_action"] = json.loads(raw) if raw else None
    return out
@router.get("/")
async def list_saved():
    rows = await db.fetch_all(f"SELECT {_COLS} FROM saved_searches ORDER BY pinned DESC, name ASC")
    return [_hydrate(r) for r in rows]
@router.post("/")
async def create_saved(data: SearchCreate):
    name = (data.name or "").strip()
    query = (data.query or "").strip()
    if not name or not query:
        raise HTTPException(400, "name and query are required")
    cur = await db.exec_q(
        "INSERT INTO saved_searches (name, query, pinned, auto_apply, auto_action) VALUES (?,?,?,?,?)",
        [name, query, 1 if data.pinned else 0, 1 if data.auto_apply else 0,
         json.dumps(data.auto_action) if data.auto_action else None])
    return _hydrate(await db.fetch_one(f"SELECT {_COLS} FROM saved_searches WHERE id=?", [cur.lastrowid]))
@router.patch("/{sid}")
async def update_saved(sid: int, data: SearchUpdate):
    row = await db.fetch_one("SELECT id FROM saved_searches WHERE id=?", [sid])
    if not row: raise HTTPException(404, "Saved search not found")
    fields, params = [], []
    if data.name is not None: fields.append("name=?"); params.append(data.name.strip())
    if data.query is not None: fields.append("query=?"); params.append(data.query.strip())
    if data.pinned is not None: fields.append("pinned=?"); params.append(1 if data.pinned else 0)
    if data.auto_apply is not None: fields.append("auto_apply=?"); params.append(1 if data.auto_apply else 0)
    if data.auto_action is not None: fields.append("auto_action=?"); params.append(json.dumps(data.auto_action) if data.auto_action else None)
    if fields:
        params.append(sid)
        await db.exec_q(f"UPDATE saved_searches SET {','.join(fields)} WHERE id=?", params)
    return _hydrate(await db.fetch_one(f"SELECT {_COLS} FROM saved_searches WHERE id=?", [sid]))
@router.delete("/{sid}")
async def delete_saved(sid: int):
    row = await db.fetch_one("SELECT id FROM saved_searches WHERE id=?", [sid])
    if not row: raise HTTPException(404, "Saved search not found")
    await db.exec_q("DELETE FROM saved_searches WHERE id=?", [sid])
    return {"deleted": sid}
async def _apply_action(em_id: int, action: dict):
    t = (action or {}).get("type")
    if t == "mark_read": await db.exec_q("UPDATE emails SET is_read=1 WHERE id=?", [em_id])
    elif t == "mark_starred": await db.exec_q("UPDATE emails SET is_starred=1 WHERE id=?", [em_id])
    elif t == "mark_pinned": await db.exec_q("UPDATE emails SET is_pinned=1 WHERE id=?", [em_id])
    elif t == "delete": await db.exec_q("UPDATE emails SET is_deleted=1 WHERE id=?", [em_id])
    elif t == "label" and action.get("value"):
        await db.exec_q("UPDATE emails SET ai_category=? WHERE id=?", [str(action["value"]).lower(), em_id])
    elif t == "move" and action.get("folder_id"):
        await db.exec_q("UPDATE emails SET folder_id=? WHERE id=?", [int(action["folder_id"]), em_id])
async def apply_smart_filters(account_id: int, email_ids: list):
    if not email_ids: return
    filters = await db.fetch_all(
        "SELECT id, name, query, auto_action FROM saved_searches WHERE auto_apply=1 AND auto_action IS NOT NULL")
    if not filters: return
    ph = ",".join("?" for _ in email_ids)
    for f in filters:
        try:
            action = json.loads(f["auto_action"] or "null")
            if not action: continue
            where, op_params, fts_text = db.parse_query(f["query"] or "")
            if fts_text:
                fts_term = f'"{fts_text.replace(chr(34), chr(34)*2)}"'
                sql = (f"SELECT e.id FROM emails e JOIN emails_fts fts ON e.id=fts.rowid "
                       f"WHERE fts MATCH ? AND e.account_id=? AND e.id IN ({ph}) AND e.is_deleted=0")
                params = [fts_term, account_id, *email_ids]
            else:
                sql = f"SELECT e.id FROM emails e WHERE e.account_id=? AND e.id IN ({ph}) AND e.is_deleted=0"
                params = [account_id, *email_ids]
            for w in where:
                sql += f" AND {w}"
            params.extend(op_params)
            matched = await db.fetch_all(sql, params)
            for row in matched:
                await _apply_action(row["id"], action)
        except Exception:
            pass
@router.post("/{sid}/run")
async def run_smart(sid: int, account_id: Optional[int] = None):
    row = await db.fetch_one(f"SELECT {_COLS} FROM saved_searches WHERE id=?", [sid])
    if not row: raise HTTPException(404, "Saved search not found")
    s = _hydrate(row)
    if not s.get("auto_action"):
        raise HTTPException(400, "Saved search has no auto_action configured")
    where, op_params, fts_text = db.parse_query(s["query"] or "")
    if fts_text:
        fts_term = f'"{fts_text.replace(chr(34), chr(34)*2)}"'
        sql = "SELECT e.id FROM emails e JOIN emails_fts fts ON e.id=fts.rowid WHERE fts MATCH ? AND e.is_deleted=0"
        params = [fts_term]
    else:
        sql = "SELECT e.id FROM emails e WHERE e.is_deleted=0"
        params = []
    if account_id:
        sql += " AND e.account_id=?"; params.append(account_id)
    for w in where: sql += f" AND {w}"
    params.extend(op_params)
    matched = await db.fetch_all(sql, params)
    for r in matched:
        await _apply_action(r["id"], s["auto_action"])
    return {"count": len(matched)}
