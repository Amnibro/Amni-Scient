import aiosqlite, asyncio, re, hashlib
from config import DB_PATH
SCHEMA = """
CREATE TABLE IF NOT EXISTS accounts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    imap_host TEXT NOT NULL,
    imap_port INTEGER DEFAULT 993,
    smtp_host TEXT NOT NULL,
    smtp_port INTEGER DEFAULT 587,
    auth_type TEXT DEFAULT 'password',
    color TEXT DEFAULT '#4A90D9',
    enabled INTEGER DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS folders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    account_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    path TEXT NOT NULL,
    folder_type TEXT DEFAULT 'custom',
    unread_count INTEGER DEFAULT 0,
    total_count INTEGER DEFAULT 0,
    last_sync TIMESTAMP,
    FOREIGN KEY (account_id) REFERENCES accounts(id) ON DELETE CASCADE,
    UNIQUE(account_id, path)
);
CREATE TABLE IF NOT EXISTS emails (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    account_id INTEGER NOT NULL,
    folder_id INTEGER NOT NULL,
    uid INTEGER NOT NULL,
    message_id TEXT,
    thread_id TEXT,
    from_addr TEXT,
    from_name TEXT,
    to_addrs TEXT,
    cc_addrs TEXT,
    bcc_addrs TEXT,
    subject TEXT,
    date TIMESTAMP,
    size INTEGER DEFAULT 0,
    flags TEXT DEFAULT '',
    is_read INTEGER DEFAULT 0,
    is_starred INTEGER DEFAULT 0,
    is_deleted INTEGER DEFAULT 0,
    has_attachments INTEGER DEFAULT 0,
    preview TEXT,
    body_text TEXT,
    body_html TEXT,
    ai_category TEXT,
    ai_summary TEXT,
    ai_priority INTEGER,
    cached_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (account_id) REFERENCES accounts(id) ON DELETE CASCADE,
    FOREIGN KEY (folder_id) REFERENCES folders(id) ON DELETE CASCADE,
    UNIQUE(account_id, folder_id, uid)
);
CREATE VIRTUAL TABLE IF NOT EXISTS emails_fts USING fts5(
    subject, from_addr, from_name, body_text, preview,
    content='emails', content_rowid='id'
);
CREATE TRIGGER IF NOT EXISTS emails_ai AFTER INSERT ON emails BEGIN
    INSERT INTO emails_fts(rowid, subject, from_addr, from_name, body_text, preview)
    VALUES (new.id, new.subject, new.from_addr, new.from_name, new.body_text, new.preview);
END;
CREATE TRIGGER IF NOT EXISTS emails_ad AFTER DELETE ON emails BEGIN
    INSERT INTO emails_fts(emails_fts, rowid, subject, from_addr, from_name, body_text, preview)
    VALUES ('delete', old.id, old.subject, old.from_addr, old.from_name, old.body_text, old.preview);
END;
CREATE TRIGGER IF NOT EXISTS emails_au AFTER UPDATE ON emails BEGIN
    INSERT INTO emails_fts(emails_fts, rowid, subject, from_addr, from_name, body_text, preview)
    VALUES ('delete', old.id, old.subject, old.from_addr, old.from_name, old.body_text, old.preview);
    INSERT INTO emails_fts(rowid, subject, from_addr, from_name, body_text, preview)
    VALUES (new.id, new.subject, new.from_addr, new.from_name, new.body_text, new.preview);
END;
CREATE INDEX IF NOT EXISTS idx_emails_account ON emails(account_id);
CREATE INDEX IF NOT EXISTS idx_emails_folder ON emails(folder_id);
CREATE INDEX IF NOT EXISTS idx_emails_date ON emails(date DESC);
CREATE INDEX IF NOT EXISTS idx_emails_from ON emails(from_addr);
CREATE INDEX IF NOT EXISTS idx_emails_category ON emails(ai_category);
CREATE INDEX IF NOT EXISTS idx_emails_thread ON emails(thread_id);
CREATE TABLE IF NOT EXISTS attachments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email_id INTEGER NOT NULL,
    filename TEXT,
    content_type TEXT,
    size INTEGER DEFAULT 0,
    content_id TEXT,
    data BLOB,
    FOREIGN KEY (email_id) REFERENCES emails(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS saved_searches (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    query TEXT NOT NULL,
    pinned INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_attachments_email ON attachments(email_id);
CREATE INDEX IF NOT EXISTS idx_attachments_ct ON attachments(content_type);
CREATE VIRTUAL TABLE IF NOT EXISTS attachments_fts USING fts5(
    filename, extracted_text, content='attachments', content_rowid='id'
);
CREATE TRIGGER IF NOT EXISTS attachments_ai AFTER INSERT ON attachments BEGIN
    INSERT INTO attachments_fts(rowid, filename, extracted_text)
    VALUES (new.id, new.filename, COALESCE(new.extracted_text, ''));
END;
CREATE TRIGGER IF NOT EXISTS attachments_ad AFTER DELETE ON attachments BEGIN
    INSERT INTO attachments_fts(attachments_fts, rowid, filename, extracted_text)
    VALUES ('delete', old.id, old.filename, COALESCE(old.extracted_text, ''));
END;
CREATE TRIGGER IF NOT EXISTS attachments_au AFTER UPDATE ON attachments BEGIN
    INSERT INTO attachments_fts(attachments_fts, rowid, filename, extracted_text)
    VALUES ('delete', old.id, old.filename, COALESCE(old.extracted_text, ''));
    INSERT INTO attachments_fts(rowid, filename, extracted_text)
    VALUES (new.id, new.filename, COALESCE(new.extracted_text, ''));
END;
CREATE TABLE IF NOT EXISTS ai_cache (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email_id INTEGER NOT NULL UNIQUE,
    category TEXT,
    summary TEXT,
    priority INTEGER,
    action_items TEXT,
    processed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (email_id) REFERENCES emails(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS rules (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    account_id INTEGER,
    name TEXT NOT NULL,
    enabled INTEGER DEFAULT 1,
    conditions TEXT NOT NULL DEFAULT '[]',
    condition_mode TEXT DEFAULT 'any',
    actions TEXT NOT NULL DEFAULT '[]',
    run_on_existing INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (account_id) REFERENCES accounts(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS scheduled_sends (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    account_id INTEGER NOT NULL,
    to_addrs TEXT NOT NULL,
    cc_addrs TEXT DEFAULT '',
    bcc_addrs TEXT DEFAULT '',
    subject TEXT DEFAULT '',
    body_html TEXT DEFAULT '',
    body_text TEXT DEFAULT '',
    reply_to_id INTEGER,
    attachments TEXT DEFAULT '[]',
    send_at TIMESTAMP NOT NULL,
    status TEXT DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    sent_at TIMESTAMP,
    error TEXT,
    recurrence TEXT,
    FOREIGN KEY (account_id) REFERENCES accounts(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_sched_status_at ON scheduled_sends(status, send_at);
CREATE TABLE IF NOT EXISTS calendar_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    account_id INTEGER,
    email_id INTEGER,
    uid TEXT,
    summary TEXT,
    description TEXT,
    location TEXT,
    organizer TEXT,
    attendees TEXT DEFAULT '[]',
    dtstart TIMESTAMP,
    dtend TIMESTAMP,
    rrule TEXT,
    partstat TEXT,
    method TEXT,
    sequence INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (email_id) REFERENCES emails(id) ON DELETE SET NULL,
    UNIQUE(account_id, uid)
);
CREATE INDEX IF NOT EXISTS idx_cal_dtstart ON calendar_events(dtstart);
CREATE TABLE IF NOT EXISTS contacts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT NOT NULL UNIQUE,
    name TEXT,
    hit_count INTEGER DEFAULT 1,
    last_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    starred INTEGER DEFAULT 0,
    notes TEXT
);
CREATE INDEX IF NOT EXISTS idx_contacts_hits ON contacts(hit_count DESC);
CREATE INDEX IF NOT EXISTS idx_contacts_name ON contacts(name);
CREATE TABLE IF NOT EXISTS ooo_settings (
    account_id INTEGER PRIMARY KEY,
    enabled INTEGER DEFAULT 0,
    subject TEXT DEFAULT 'Out of office',
    body TEXT DEFAULT '',
    start_at TIMESTAMP,
    end_at TIMESTAMP,
    exclude_domains TEXT DEFAULT '[]',
    FOREIGN KEY (account_id) REFERENCES accounts(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS ooo_sent_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    account_id INTEGER NOT NULL,
    sender TEXT NOT NULL,
    sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (account_id) REFERENCES accounts(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_ooo_log ON ooo_sent_log(account_id, sender, sent_at);
CREATE TABLE IF NOT EXISTS templates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    category TEXT DEFAULT 'general',
    body TEXT NOT NULL DEFAULT '',
    is_builtin INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_templates_cat ON templates(category);
"""
BUILTIN_TEMPLATES = [
    ("Acknowledge receipt", "acknowledge", "Hi {name},\n\nThanks for sending this over — I've received it and will get back to you with a full response by {date}.\n\nBest,\n", None),
    ("Decline politely", "decline", "Hi {name},\n\nThanks for thinking of me. Unfortunately I won't be able to {topic} at this time, but I appreciate the offer and hope we can connect on something else down the line.\n\nBest,\n", None),
    ("Follow up", "followup", "Hi {name},\n\nJust circling back on my note from {date} about {topic}. Wanted to make sure it didn't get buried — happy to provide more context if helpful.\n\nThanks,\n", "fu"),
    ("Schedule a meeting", "scheduling", "Hi {name},\n\nWould love to find time to discuss {topic}. I'm generally free {availability}. Let me know what works on your end and I'll send an invite.\n\nThanks,\n", None),
    ("Request information", "request", "Hi {name},\n\nCould you share {topic} when you have a moment? Looking to {reason}, and your input would be a big help.\n\nThanks in advance,\n", None),
    ("Thank you", "thanks", "Hi {name},\n\nJust wanted to say thank you for {topic} — really appreciated it.\n\nBest,\n", "ty"),
    ("Email signature", "snippet", "Best regards,\n", "sig"),
    ("Sounds good", "snippet", "Sounds good — thanks!", "sg"),
    ("On it", "snippet", "On it — will report back shortly.", "oi"),
    ("Will do", "snippet", "Will do.", "wd"),
]
_db = None
_STOP_WORDS = {"re:", "re :", "fw:", "fwd:", "fw :", "fwd :", "aw:", "r:", "tr:"}
def normalize_subject(subject: str) -> str:
    s = (subject or "").strip().lower()
    changed = True
    while changed:
        changed = False
        for w in _STOP_WORDS:
            if s.startswith(w):
                s = s[len(w):].strip()
                changed = True
    s = re.sub(r"\[[^\]]{1,40}\]\s*", "", s).strip()
    return s
def derive_thread_id(references: str, in_reply_to: str, message_id: str, subject: str, from_addr: str) -> str:
    refs = [r.strip() for r in re.findall(r"<[^>]+>", references or "")]
    root = refs[0] if refs else (in_reply_to.strip() if in_reply_to else "")
    if root:
        return root
    norm = normalize_subject(subject)
    if norm:
        h = hashlib.sha1(f"{norm}|{(from_addr or '').lower()}".encode()).hexdigest()[:16]
        return f"<subj-{h}@amni>"
    return message_id or f"<orphan-{hashlib.sha1((subject or '').encode()).hexdigest()[:12]}@amni>"
async def get_db():
    global _db
    if _db is None:
        _db = await aiosqlite.connect(str(DB_PATH))
        _db.row_factory = aiosqlite.Row
        await _db.execute("PRAGMA journal_mode=WAL")
        await _db.execute("PRAGMA synchronous=NORMAL")
        await _db.execute("PRAGMA foreign_keys=ON")
        await _db.execute("PRAGMA cache_size=-64000")
        await _db.executescript(SCHEMA)
        await _db.commit()
        for migration in [
            "ALTER TABLE emails ADD COLUMN body_fetched INTEGER NOT NULL DEFAULT 0",
            "UPDATE emails SET body_fetched=1 WHERE id IS NOT NULL",
            "ALTER TABLE emails ADD COLUMN snoozed_until TIMESTAMP",
            "ALTER TABLE emails ADD COLUMN unsubscribe_uri TEXT",
            "ALTER TABLE emails ADD COLUMN unsubscribe_post TEXT",
            "ALTER TABLE emails ADD COLUMN ics_uid TEXT",
            "ALTER TABLE emails ADD COLUMN in_reply_to TEXT",
            "ALTER TABLE emails ADD COLUMN references_hdr TEXT",
            "ALTER TABLE emails ADD COLUMN auth_results TEXT",
            "ALTER TABLE emails ADD COLUMN reply_to TEXT",
            "ALTER TABLE attachments ADD COLUMN extracted_text TEXT",
            "ALTER TABLE ai_cache ADD COLUMN detected_event TEXT",
            "ALTER TABLE accounts ADD COLUMN voice_profile TEXT",
            "ALTER TABLE accounts ADD COLUMN voice_updated_at TIMESTAMP",
            "CREATE INDEX IF NOT EXISTS idx_emails_snooze ON emails(snoozed_until)",
            "CREATE INDEX IF NOT EXISTS idx_emails_from ON emails(from_addr)",
            "CREATE INDEX IF NOT EXISTS idx_emails_ics ON emails(ics_uid)",
            "CREATE TABLE IF NOT EXISTS follow_ups (id INTEGER PRIMARY KEY AUTOINCREMENT, email_id INTEGER NOT NULL, account_id INTEGER, thread_id TEXT, message_id TEXT, remind_at TIMESTAMP NOT NULL, status TEXT NOT NULL DEFAULT 'pending', note TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, resolved_at TIMESTAMP, FOREIGN KEY(email_id) REFERENCES emails(id) ON DELETE CASCADE)",
            "CREATE TABLE IF NOT EXISTS deferred_actions (id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, payload TEXT NOT NULL, expires_at TIMESTAMP NOT NULL, status TEXT NOT NULL DEFAULT 'pending', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, executed_at TIMESTAMP)",
            "CREATE INDEX IF NOT EXISTS idx_deferred_status_expires ON deferred_actions(status, expires_at)",
            "CREATE INDEX IF NOT EXISTS idx_followups_status ON follow_ups(status, remind_at)",
            "CREATE INDEX IF NOT EXISTS idx_followups_email ON follow_ups(email_id)",
            "CREATE INDEX IF NOT EXISTS idx_followups_thread ON follow_ups(thread_id)",
            "CREATE TABLE IF NOT EXISTS trusted_image_senders (account_id INTEGER NOT NULL, from_addr TEXT NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (account_id, from_addr))",
            "CREATE INDEX IF NOT EXISTS idx_trusted_imgs_account ON trusted_image_senders(account_id)",
            "ALTER TABLE scheduled_sends ADD COLUMN recurrence TEXT",
            "ALTER TABLE templates ADD COLUMN trigger TEXT",
            "CREATE INDEX IF NOT EXISTS idx_templates_trigger ON templates(trigger)",
            "ALTER TABLE emails ADD COLUMN is_pinned INTEGER NOT NULL DEFAULT 0",
            "CREATE INDEX IF NOT EXISTS idx_emails_pinned ON emails(is_pinned) WHERE is_pinned=1",
            "CREATE TABLE IF NOT EXISTS muted_senders (id INTEGER PRIMARY KEY AUTOINCREMENT, account_id INTEGER NOT NULL, from_addr TEXT NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, UNIQUE(account_id, from_addr))",
            "CREATE INDEX IF NOT EXISTS idx_muted_account ON muted_senders(account_id)",
            "CREATE INDEX IF NOT EXISTS idx_muted_addr ON muted_senders(from_addr)",
            "CREATE TABLE IF NOT EXISTS screened_senders (account_id INTEGER NOT NULL, from_addr TEXT NOT NULL, decision TEXT NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (account_id, from_addr))",
            "CREATE INDEX IF NOT EXISTS idx_screened_account ON screened_senders(account_id)",
            "CREATE TABLE IF NOT EXISTS muted_threads (account_id INTEGER NOT NULL, thread_id TEXT NOT NULL, last_subject TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (account_id, thread_id))",
            "CREATE INDEX IF NOT EXISTS idx_muted_threads_account ON muted_threads(account_id)",
            "ALTER TABLE scheduled_sends ADD COLUMN archive_after_send INTEGER NOT NULL DEFAULT 0",
            "ALTER TABLE saved_searches ADD COLUMN auto_apply INTEGER NOT NULL DEFAULT 0",
            "ALTER TABLE saved_searches ADD COLUMN auto_action TEXT",
            "CREATE INDEX IF NOT EXISTS idx_saved_searches_auto ON saved_searches(auto_apply) WHERE auto_apply=1",
            "CREATE TABLE IF NOT EXISTS pgp_keys (id INTEGER PRIMARY KEY AUTOINCREMENT, account_id INTEGER, email TEXT NOT NULL, fingerprint TEXT NOT NULL UNIQUE, public_key TEXT NOT NULL, private_key_enc BLOB, is_default INTEGER NOT NULL DEFAULT 0, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)",
            "CREATE INDEX IF NOT EXISTS idx_pgp_keys_account ON pgp_keys(account_id)",
            "CREATE INDEX IF NOT EXISTS idx_pgp_keys_email ON pgp_keys(LOWER(email))",
            "ALTER TABLE scheduled_sends ADD COLUMN attempts INTEGER NOT NULL DEFAULT 0",
            "ALTER TABLE scheduled_sends ADD COLUMN next_retry_at TIMESTAMP",
            "ALTER TABLE scheduled_sends ADD COLUMN is_outbox INTEGER NOT NULL DEFAULT 0",
            "CREATE INDEX IF NOT EXISTS idx_sched_outbox ON scheduled_sends(is_outbox, status, next_retry_at) WHERE is_outbox=1",
            "CREATE TABLE IF NOT EXISTS account_aliases (id INTEGER PRIMARY KEY AUTOINCREMENT, account_id INTEGER NOT NULL, email TEXT NOT NULL, display_name TEXT DEFAULT '', is_default INTEGER NOT NULL DEFAULT 0, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (account_id) REFERENCES accounts(id) ON DELETE CASCADE, UNIQUE(account_id, email))",
            "CREATE INDEX IF NOT EXISTS idx_aliases_account ON account_aliases(account_id)",
            "ALTER TABLE scheduled_sends ADD COLUMN from_alias_id INTEGER",
            "CREATE TABLE IF NOT EXISTS vip_senders (id INTEGER PRIMARY KEY AUTOINCREMENT, account_id INTEGER NOT NULL, from_addr TEXT NOT NULL, label TEXT DEFAULT '', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (account_id) REFERENCES accounts(id) ON DELETE CASCADE, UNIQUE(account_id, from_addr))",
            "CREATE INDEX IF NOT EXISTS idx_vip_account ON vip_senders(account_id)",
            "CREATE INDEX IF NOT EXISTS idx_vip_addr ON vip_senders(LOWER(from_addr))",
            "CREATE TABLE IF NOT EXISTS category_overrides (id INTEGER PRIMARY KEY AUTOINCREMENT, account_id INTEGER NOT NULL, from_addr TEXT NOT NULL, category TEXT NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (account_id) REFERENCES accounts(id) ON DELETE CASCADE, UNIQUE(account_id, from_addr))",
            "CREATE INDEX IF NOT EXISTS idx_catover_account ON category_overrides(account_id)",
            "CREATE INDEX IF NOT EXISTS idx_catover_addr ON category_overrides(LOWER(from_addr))",
            "CREATE TABLE IF NOT EXISTS thread_summaries (id INTEGER PRIMARY KEY AUTOINCREMENT, account_id INTEGER NOT NULL, thread_id TEXT NOT NULL, last_message_date TEXT NOT NULL, message_count INTEGER NOT NULL, summary_json TEXT NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, UNIQUE(account_id, thread_id), FOREIGN KEY (account_id) REFERENCES accounts(id) ON DELETE CASCADE)",
            "CREATE INDEX IF NOT EXISTS idx_thrsum_account ON thread_summaries(account_id)",
            "CREATE TABLE IF NOT EXISTS read_receipts (id INTEGER PRIMARY KEY AUTOINCREMENT, sent_email_id INTEGER NOT NULL, account_id INTEGER NOT NULL, recipient TEXT DEFAULT '', disposition TEXT DEFAULT '', reported_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(sent_email_id) REFERENCES emails(id) ON DELETE CASCADE)",
            "CREATE INDEX IF NOT EXISTS idx_receipts_email ON read_receipts(sent_email_id)"
        ]:
            try:
                await _db.execute(migration)
                await _db.commit()
            except Exception:
                pass
    return _db
async def init_builtin_templates():
    db = await get_db()
    cur = await db.execute("SELECT COUNT(*) FROM templates WHERE is_builtin=1")
    row = await cur.fetchone()
    if row and row[0] >= len(BUILTIN_TEMPLATES):
        return
    for entry in BUILTIN_TEMPLATES:
        name, cat, body = entry[0], entry[1], entry[2]
        trig = entry[3] if len(entry) > 3 else None
        existing = await db.execute("SELECT id, trigger FROM templates WHERE name=? AND is_builtin=1", [name])
        row = await existing.fetchone()
        if not row:
            await db.execute("INSERT INTO templates (name, category, body, is_builtin, trigger) VALUES (?,?,?,1,?)", [name, cat, body, trig])
        elif trig and not row[1]:
            await db.execute("UPDATE templates SET trigger=? WHERE id=?", [trig, row[0]])
    await db.commit()
async def close_db():
    global _db
    if _db:
        await _db.close()
        _db = None
async def exec_q(query, params=None):
    db = await get_db()
    cursor = await db.execute(query, params or [])
    await db.commit()
    return cursor
async def fetch_all(query, params=None):
    db = await get_db()
    cursor = await db.execute(query, params or [])
    return [dict(row) for row in await cursor.fetchall()]
async def fetch_one(query, params=None):
    db = await get_db()
    cursor = await db.execute(query, params or [])
    row = await cursor.fetchone()
    return dict(row) if row else None
_DSL_OP_RE = re.compile(r'(\w+):("[^"]*"|\S+)')
_DSL_QUOTED_RE = re.compile(r'"([^"]*)"')
_REL_TIME_RE = re.compile(r'^(\d+)\s*([dwmy])$', re.IGNORECASE)
_SIZE_RE = re.compile(r'^(\d+(?:\.\d+)?)\s*([kmgt]?)$', re.IGNORECASE)
def _rel_time_seconds(v: str):
    m = _REL_TIME_RE.match(v or "")
    if not m: return None
    n = int(m.group(1)); u = m.group(2).lower()
    return n * {"d": 86400, "w": 604800, "m": 2592000, "y": 31536000}[u]
def _size_bytes(v: str):
    m = _SIZE_RE.match(v or "")
    if not m: return None
    n = float(m.group(1)); u = m.group(2).lower()
    return int(n * {"": 1, "k": 1024, "m": 1048576, "g": 1073741824, "t": 1099511627776}[u])
def parse_query(q: str):
    if not q:
        return [], [], ""
    where, params = [], []
    for k, v in _DSL_OP_RE.findall(q):
        v = v.strip('"').strip()
        if not v: continue
        kl = k.lower()
        if kl == "from":
            where.append("(e.from_addr LIKE ? OR e.from_name LIKE ?)"); params += [f"%{v}%", f"%{v}%"]
        elif kl == "to":
            where.append("e.to_addrs LIKE ?"); params.append(f"%{v}%")
        elif kl == "cc":
            where.append("e.cc_addrs LIKE ?"); params.append(f"%{v}%")
        elif kl == "bcc":
            where.append("e.bcc_addrs LIKE ?"); params.append(f"%{v}%")
        elif kl == "subject":
            where.append("e.subject LIKE ?"); params.append(f"%{v}%")
        elif kl == "has":
            vl = v.lower()
            if vl in ("attachment", "attachments", "file", "files"): where.append("e.has_attachments=1")
            elif vl in ("link", "links", "url"): where.append("(e.body_text LIKE '%http://%' OR e.body_text LIKE '%https://%')")
        elif kl == "filename":
            pat = v.replace("*", "%").replace("?", "_")
            if "%" not in pat and "_" not in pat: pat = f"%{pat}%"
            where.append("EXISTS (SELECT 1 FROM attachments a WHERE a.email_id=e.id AND a.filename LIKE ?)")
            params.append(pat)
        elif kl == "is":
            vl = v.lower()
            mapping = {"unread": "e.is_read=0", "read": "e.is_read=1",
                       "starred": "e.is_starred=1", "unstarred": "e.is_starred=0",
                       "snoozed": "e.snoozed_until IS NOT NULL AND e.snoozed_until > datetime('now')",
                       "vip": "EXISTS (SELECT 1 FROM vip_senders v WHERE v.account_id=e.account_id AND LOWER(v.from_addr)=LOWER(e.from_addr))",
                       "muted": "EXISTS (SELECT 1 FROM muted_senders m WHERE m.account_id=e.account_id AND LOWER(m.from_addr)=LOWER(e.from_addr))"}
            if vl in mapping: where.append(mapping[vl])
        elif kl == "before":
            where.append("e.date < ?"); params.append(v)
        elif kl == "after":
            where.append("e.date >= ?"); params.append(v)
        elif kl == "older_than":
            s = _rel_time_seconds(v)
            if s: where.append(f"e.date < datetime('now', '-{s} seconds')")
        elif kl == "newer_than":
            s = _rel_time_seconds(v)
            if s: where.append(f"e.date >= datetime('now', '-{s} seconds')")
        elif kl == "larger":
            b = _size_bytes(v)
            if b is not None: where.append("e.size > ?"); params.append(b)
        elif kl == "smaller":
            b = _size_bytes(v)
            if b is not None: where.append("e.size < ?"); params.append(b)
        elif kl == "in":
            where.append("e.folder_id IN (SELECT id FROM folders WHERE LOWER(name) LIKE ? OR folder_type=?)")
            params += [f"%{v.lower()}%", v.lower()]
        elif kl == "category":
            where.append("e.ai_category=?"); params.append(v.lower())
    rest = _DSL_QUOTED_RE.sub(lambda m: m.group(1), _DSL_OP_RE.sub("", q)).strip()
    return where, params, rest
async def search_emails(query_text, account_id=None, folder_id=None, limit=200):
    where, op_params, fts_text = parse_query(query_text or "")
    use_fts = bool(fts_text)
    cols = "e.id, e.uid, e.account_id, e.folder_id, e.from_addr, e.from_name, e.to_addrs, e.subject, e.date, e.size, e.is_read, e.is_starred, e.has_attachments, e.preview, e.ai_category, e.ai_priority, e.thread_id, e.snoozed_until, e.ics_uid, e.unsubscribe_uri"
    if use_fts:
        fts_term = f'"{fts_text.replace(chr(34), chr(34)*2)}"'
        match_cte = """WITH matches AS (
            SELECT e.id AS eid, bm25(emails_fts) AS rank, 'body' AS source
            FROM emails e JOIN emails_fts f ON e.id = f.rowid WHERE f MATCH ?
            UNION ALL
            SELECT a.email_id AS eid, bm25(attachments_fts) + 0.5 AS rank, 'attachment' AS source
            FROM attachments a JOIN attachments_fts af ON a.id = af.rowid WHERE af MATCH ?
        )"""
        sql = f"{match_cte} SELECT {cols}, MIN(m.rank) AS best_rank, GROUP_CONCAT(DISTINCT m.source) AS match_sources FROM matches m JOIN emails e ON e.id = m.eid WHERE e.is_deleted=0"
        params = [fts_term, fts_term]
    else:
        sql = f"SELECT {cols} FROM emails e WHERE e.is_deleted=0"
        params = []
    for w in where:
        sql += f" AND {w}"
    params.extend(op_params)
    if account_id:
        sql += " AND e.account_id = ?"; params.append(account_id)
    if folder_id:
        sql += " AND e.folder_id = ?"; params.append(folder_id)
    if use_fts:
        sql += " GROUP BY e.id ORDER BY best_rank"
    else:
        sql += " ORDER BY e.date DESC"
    sql += " LIMIT ?"; params.append(limit)
    rows = await fetch_all(sql, params)
    for r in rows:
        srcs = (r.get('match_sources') or '').split(',') if isinstance(r, dict) else []
        if 'body' in srcs and 'attachment' in srcs:
            r['matched_in'] = 'both'
        elif 'attachment' in srcs:
            r['matched_in'] = 'attachment'
        elif 'body' in srcs:
            r['matched_in'] = 'body'
    return rows
async def backfill_threads(batch=2000):
    rows = await fetch_all("SELECT id, message_id, subject, from_addr, thread_id, in_reply_to, references_hdr FROM emails WHERE thread_id IS NULL OR thread_id='' OR thread_id=message_id LIMIT ?", [batch])
    for r in rows:
        tid = derive_thread_id(r.get("references_hdr") or "", r.get("in_reply_to") or "", r.get("message_id") or "", r.get("subject") or "", r.get("from_addr") or "")
        await exec_q("UPDATE emails SET thread_id=? WHERE id=?", [tid, r["id"]])
