import asyncio, json
from datetime import datetime, timezone, timedelta
import db, imap_client, ai_engine, auth, smtp_client
from config import cfg
_sync_tasks = {}
_running = False
_in_progress = False
_last_sync_at = ""
_last_error = ""
_ws_broadcast_ref = None
def _next_recurrence(send_at_iso, rule):
    try:
        base = datetime.fromisoformat(str(send_at_iso).replace("Z","+00:00")) if send_at_iso else datetime.now(timezone.utc)
    except Exception:
        base = datetime.now(timezone.utc)
    rule = (rule or "").lower()
    if rule == "daily": return base + timedelta(days=1)
    if rule == "weekly": return base + timedelta(days=7)
    if rule == "weekdays":
        nxt = base + timedelta(days=1)
        while nxt.weekday() >= 5: nxt += timedelta(days=1)
        return nxt
    if rule == "monthly":
        y, m, d = base.year, base.month + 1, base.day
        if m > 12: y, m = y + 1, 1
        for try_d in (d, 30, 29, 28):
            try: return base.replace(year=y, month=m, day=try_d)
            except ValueError: continue
        return base + timedelta(days=30)
    return None
async def _maybe_auto_reply(account: dict, email_id: int):
    ooo = await db.fetch_one("SELECT * FROM ooo_settings WHERE account_id=? AND enabled=1", [account["id"]])
    if not ooo:
        return
    now = datetime.now(timezone.utc)
    start = ooo.get("start_at")
    end = ooo.get("end_at")
    try:
        if start and datetime.fromisoformat(start.replace("Z","+00:00")) > now:
            return
        if end and datetime.fromisoformat(end.replace("Z","+00:00")) < now:
            return
    except Exception:
        pass
    em = await db.fetch_one("SELECT id, from_addr, subject, message_id, unsubscribe_uri FROM emails WHERE id=?", [email_id])
    if not em or not em.get("from_addr"):
        return
    sender = (em["from_addr"] or "").lower()
    if not sender or sender == (account["email"] or "").lower():
        return
    if em.get("unsubscribe_uri"):
        return
    try:
        excluded = json.loads(ooo.get("exclude_domains") or "[]")
        if any(sender.endswith("@"+d.lower().lstrip("@")) for d in excluded):
            return
    except Exception:
        pass
    cutoff = (now - timedelta(hours=24)).isoformat()
    recent = await db.fetch_one("SELECT id FROM ooo_sent_log WHERE account_id=? AND sender=? AND sent_at>?", [account["id"], sender, cutoff])
    if recent:
        return
    try:
        await smtp_client.send_auto_reply(account, sender, ooo.get("subject") or "Out of office", ooo.get("body") or "", em.get("message_id") or "")
        await db.exec_q("INSERT INTO ooo_sent_log (account_id, sender) VALUES (?,?)", [account["id"], sender])
    except Exception as e:
        print(f"[OOO] auto-reply failed for {sender}: {e}")
async def sync_account(account: dict, ws_broadcast=None, only_inbox: bool = False):
    folders = await imap_client.list_folders(account)
    for f in folders:
        if only_inbox and f.get("folder_type") != "inbox":
            continue
        existing = await db.fetch_one(
            "SELECT id FROM folders WHERE account_id=? AND path=?",
            [account["id"], f["path"]]
        )
        if not existing:
            cursor = await db.exec_q(
                "INSERT INTO folders (account_id, name, path, folder_type) VALUES (?,?,?,?)",
                [account["id"], f["name"], f["path"], f["folder_type"]]
            )
            f["id"] = cursor.lastrowid
        else:
            f["id"] = existing["id"]
        before = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
        count = await imap_client.sync_folder(account, f["path"], f["id"])
        asyncio.create_task(imap_client.sync_folder_headers(account, f["path"], f["id"]))
        if count > 0:
            if ws_broadcast:
                await ws_broadcast({"type": "new_emails", "account_id": account["id"], "folder": f["path"], "count": count})
            new_emails = await db.fetch_all(
                "SELECT id FROM emails WHERE folder_id=? AND cached_at >= ?",
                [f["id"], before]
            )
            if new_emails:
                try:
                    from routes.rules import apply_all_rules
                    asyncio.create_task(apply_all_rules(account["id"], [e["id"] for e in new_emails]))
                except Exception:
                    pass
                try:
                    from routes.searches import apply_smart_filters
                    asyncio.create_task(apply_smart_filters(account["id"], [e["id"] for e in new_emails]))
                except Exception:
                    pass
                try:
                    from routes.muted import apply_mute_filter
                    asyncio.create_task(apply_mute_filter(account["id"], [e["id"] for e in new_emails]))
                except Exception:
                    pass
                if f["folder_type"] == "inbox":
                    for e in new_emails:
                        try:
                            await _maybe_auto_reply(account, e["id"])
                        except Exception:
                            pass
                    try:
                        ids = [e["id"] for e in new_emails]
                        placeholders = ",".join("?" * len(ids))
                        vip_hits = await db.fetch_all(
                            f"SELECT e.id, e.from_addr, e.from_name, e.subject, v.label FROM emails e INNER JOIN vip_senders v ON v.account_id=e.account_id AND LOWER(v.from_addr)=LOWER(e.from_addr) WHERE e.id IN ({placeholders})",
                            ids
                        )
                        if vip_hits and ws_broadcast:
                            for h in vip_hits:
                                await ws_broadcast({"type": "vip_arrival", "account_id": account["id"], "email_id": h["id"], "from_addr": h["from_addr"], "from_name": h["from_name"] or "", "subject": h["subject"] or "", "label": h["label"] or ""})
                    except Exception:
                        pass
    uncategorized = await db.fetch_all(
        "SELECT id, subject, from_addr, preview FROM emails WHERE account_id=? AND ai_category IS NULL LIMIT 50",
        [account["id"]]
    )
    for em in uncategorized:
        ovr = await db.fetch_one("SELECT category FROM category_overrides WHERE account_id=? AND LOWER(from_addr)=LOWER(?)", [account["id"], em["from_addr"] or ""])
        if ovr and ovr.get("category"):
            cat = {"category": ovr["category"], "priority": 3}
        else:
            cat = await ai_engine.categorize_email(em["subject"], em["from_addr"], em["preview"])
        await db.exec_q(
            "UPDATE emails SET ai_category=?, ai_priority=? WHERE id=?",
            [cat.get("category", "unknown"), cat.get("priority", 3), em["id"]]
        )
        await db.exec_q(
            "INSERT OR REPLACE INTO ai_cache (email_id, category, priority) VALUES (?,?,?)",
            [em["id"], cat.get("category", "unknown"), cat.get("priority", 3)]
        )
async def _run_sync_pass(ws_broadcast=None, manual: bool = False):
    global _in_progress, _last_sync_at, _last_error
    if _in_progress:
        return False
    _in_progress = True
    if ws_broadcast:
        await ws_broadcast({"type": "sync_started", "manual": manual})
    err = ""
    try:
        accounts = await db.fetch_all("SELECT * FROM accounts WHERE enabled=1")
        for acc in accounts:
            if not auth.load_account_creds(acc['id']):
                print(f"Skipping sync for {acc['email']}: no credentials")
                continue
            try:
                await sync_account(acc, ws_broadcast, only_inbox=cfg.auto_sync_only_inbox)
            except Exception as e:
                err = f"{acc['email']}: {type(e).__name__}: {e}"
                print(f"Sync error for {err}")
    except Exception as e:
        err = f"{type(e).__name__}: {e}"
        print(f"Sync pass error: {err}")
    _last_sync_at = datetime.now(timezone.utc).isoformat()
    _last_error = err
    cfg.last_sync_at = _last_sync_at
    cfg.last_sync_error = err
    cfg.save()
    _in_progress = False
    try:
        from routes.followups import auto_resolve as _auto_resolve
        ar = await _auto_resolve()
        if ws_broadcast and ar.get("resolved"):
            await ws_broadcast({"type": "followups_resolved", "count": ar["resolved"]})
    except Exception as _e:
        print(f"followup auto-resolve skipped: {_e}")
    try:
        from routes.emails import _execute_deferred
        commits = await _execute_deferred()
        if ws_broadcast and commits:
            await ws_broadcast({"type": "deferred_committed", "count": commits})
    except Exception as _e:
        print(f"deferred-action commit skipped: {_e}")
    if ws_broadcast:
        await ws_broadcast({"type": "sync_complete", "at": _last_sync_at, "error": err, "manual": manual})
    return True
async def trigger_sync_now(ws_broadcast=None):
    if _in_progress:
        return {"status": "already_running"}
    asyncio.create_task(_run_sync_pass(ws_broadcast, manual=True))
    return {"status": "started"}
def get_sync_status():
    return {
        "auto_enabled": cfg.auto_sync_enabled,
        "interval": cfg.sync_interval,
        "only_inbox": cfg.auto_sync_only_inbox,
        "last_sync_at": _last_sync_at or cfg.last_sync_at,
        "last_error": _last_error or cfg.last_sync_error,
        "in_progress": _in_progress,
    }
async def start_sync_loop(interval: int = 60, ws_broadcast=None):
    global _running, _ws_broadcast_ref
    _running = True
    _ws_broadcast_ref = ws_broadcast
    next_sync = 0.0
    while _running:
        try:
            now = asyncio.get_event_loop().time()
            if cfg.auto_sync_enabled and now >= next_sync:
                done = await _run_sync_pass(ws_broadcast)
                if done:
                    next_sync = asyncio.get_event_loop().time() + max(15, int(cfg.sync_interval))
            elif not cfg.auto_sync_enabled:
                next_sync = asyncio.get_event_loop().time() + 30
        except Exception as e:
            if "closed database" in str(e).lower() or "cannot operate" in str(e).lower():
                break
            print(f"Sync loop error: {type(e).__name__}: {e}")
        await asyncio.sleep(min(30, max(5, int(cfg.sync_interval))))
async def start_scheduler_loop(ws_broadcast=None, interval: int = 5):
    while _running or _running is False:
        try:
            due = await db.fetch_all(
                "SELECT * FROM scheduled_sends WHERE (status='pending' AND send_at <= datetime('now')) OR (is_outbox=1 AND status='failed' AND attempts < 8 AND (next_retry_at IS NULL OR next_retry_at <= datetime('now'))) ORDER BY send_at LIMIT 20")
        except Exception:
            await asyncio.sleep(interval)
            continue
        for sched in due:
            try:
                acc = await db.fetch_one("SELECT * FROM accounts WHERE id=?", [sched["account_id"]])
                if not acc:
                    await db.exec_q("UPDATE scheduled_sends SET status='failed', error='account gone' WHERE id=?", [sched["id"]])
                    continue
                await db.exec_q("UPDATE scheduled_sends SET status='sending' WHERE id=?", [sched["id"]])
                in_reply_to = ""
                if sched.get("reply_to_id"):
                    orig = await db.fetch_one("SELECT message_id FROM emails WHERE id=?", [sched["reply_to_id"]])
                    in_reply_to = (orig or {}).get("message_id") or ""
                atts = []
                try:
                    for a in json.loads(sched.get("attachments") or "[]"):
                        import base64 as _b64
                        atts.append({"filename": a.get("filename",""), "data": _b64.b64decode(a.get("data","")) if a.get("data") else b""})
                except Exception:
                    atts = []
                from_addr = ""; from_name = ""
                if sched.get("from_alias_id"):
                    al = await db.fetch_one("SELECT email, display_name FROM account_aliases WHERE id=? AND account_id=?", [sched["from_alias_id"], sched["account_id"]])
                    if al: from_addr = al.get("email") or ""; from_name = al.get("display_name") or ""
                await smtp_client.send_email(
                    acc, sched["to_addrs"], sched.get("subject",""), sched.get("body_html",""),
                    sched.get("body_text",""), sched.get("cc_addrs",""), sched.get("bcc_addrs",""),
                    in_reply_to=in_reply_to, attachments=atts,
                    from_override=from_addr, from_name_override=from_name)
                await db.exec_q("UPDATE scheduled_sends SET status='sent', sent_at=CURRENT_TIMESTAMP WHERE id=?", [sched["id"]])
                if sched.get("archive_after_send") and sched.get("reply_to_id"):
                    try:
                        from routes.muted import archive_thread_after_send
                        archived = await archive_thread_after_send(sched["account_id"], sched["reply_to_id"])
                        if archived and ws_broadcast:
                            await ws_broadcast({"type": "thread_archived", "count": archived, "reply_to_id": sched["reply_to_id"]})
                    except Exception:
                        pass
                rec = sched.get("recurrence")
                if rec:
                    nxt = _next_recurrence(sched.get("send_at"), rec)
                    if nxt:
                        next_cur = await db.exec_q(
                            "INSERT INTO scheduled_sends (account_id,to_addrs,cc_addrs,bcc_addrs,subject,body_html,body_text,reply_to_id,attachments,send_at,recurrence) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                            [sched["account_id"], sched["to_addrs"], sched.get("cc_addrs",""), sched.get("bcc_addrs",""),
                             sched.get("subject",""), sched.get("body_html",""), sched.get("body_text",""),
                             sched.get("reply_to_id"), sched.get("attachments") or "[]", nxt.isoformat(), rec])
                        if ws_broadcast:
                            await ws_broadcast({"type": "scheduled_recurred", "id": next_cur.lastrowid, "send_at": nxt.isoformat(), "recurrence": rec})
                if ws_broadcast:
                    await ws_broadcast({"type": "scheduled_sent", "id": sched["id"]})
            except Exception as e:
                attempts = int(sched.get("attempts") or 0) + 1
                backoff = min(3600, 60 * (2 ** (attempts - 1)))
                from datetime import datetime as _dt, timezone as _tz, timedelta as _td
                nxt = (_dt.now(_tz.utc) + _td(seconds=backoff)).isoformat()
                await db.exec_q("UPDATE scheduled_sends SET status='failed', error=?, attempts=?, next_retry_at=?, is_outbox=1 WHERE id=?", [str(e), attempts, nxt, sched["id"]])
                if ws_broadcast:
                    await ws_broadcast({"type": "outbox_failed", "id": sched["id"], "attempts": attempts, "next_retry_at": nxt, "error": str(e)})
        try:
            from routes.emails import _execute_deferred
            n = await _execute_deferred()
            if n and ws_broadcast:
                await ws_broadcast({"type": "deferred_committed", "count": n})
        except Exception as _e:
            print(f"deferred commit (sched loop) skipped: {_e}")
        await asyncio.sleep(interval)
        if not _running:
            break
async def start_snooze_loop(ws_broadcast=None, interval: int = 30):
    while _running or _running is False:
        try:
            due = await db.fetch_all(
                "SELECT id, folder_id FROM emails WHERE snoozed_until IS NOT NULL AND snoozed_until <= datetime('now')")
            if due:
                ids = [d["id"] for d in due]
                ph = ",".join("?" for _ in ids)
                await db.exec_q(f"UPDATE emails SET snoozed_until=NULL WHERE id IN ({ph})", ids)
                if ws_broadcast:
                    await ws_broadcast({"type": "unsnoozed", "ids": ids})
        except Exception:
            pass
        await asyncio.sleep(interval)
        if not _running:
            break
async def start_thread_backfill():
    try:
        for _ in range(50):
            await db.backfill_threads(2000)
            await asyncio.sleep(0.1)
    except Exception as e:
        print(f"[THREAD-BACKFILL] {e}")
async def stop_sync():
    global _running
    _running = False
    for aid in list(_sync_tasks.keys()):
        await imap_client.disconnect(aid)
    _sync_tasks.clear()
async def start_idle_listeners(ws_broadcast=None):
    try:
        accounts = await db.fetch_all("SELECT * FROM accounts WHERE enabled=1")
    except Exception as e:
        if "closed database" in str(e).lower() or "cannot operate" in str(e).lower():
            return
        print(f"Idle listeners DB error: {type(e).__name__}: {e}")
        return
    for acc in accounts:
        if not auth.load_account_creds(acc['id']):
            print(f"Skipping idle listener for {acc['email']}: no credentials")
            continue
        inbox = await db.fetch_one(
            "SELECT * FROM folders WHERE account_id=? AND folder_type='inbox'",
            [acc["id"]]
        )
        if inbox:
            async def on_new(account, folder_path):
                fld = await db.fetch_one("SELECT id FROM folders WHERE account_id=? AND path=?", [account["id"], folder_path])
                if fld:
                    count = await imap_client.sync_folder(account, folder_path, fld["id"])
                    if count > 0 and ws_broadcast:
                        await ws_broadcast({"type": "new_emails", "account_id": account["id"], "folder": folder_path, "count": count})
            task = asyncio.create_task(imap_client.idle_listen(acc, inbox["path"], on_new))
            _sync_tasks[acc["id"]] = task
