from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
from datetime import datetime, timezone, timedelta
import base64, json
import db, smtp_client
router = APIRouter(prefix="/api/compose", tags=["compose"])
class ComposeData(BaseModel):
    account_id: int
    to: str
    subject: str
    body_html: str
    body_text: str = ""
    cc: str = ""
    bcc: str = ""
    reply_to_id: Optional[int] = None
    attachments: List[Dict[str, Any]] = []
    archive_after_send: bool = False
    from_alias_id: Optional[int] = None
    request_receipt: bool = False
class DraftData(BaseModel):
    account_id: int
    to: str = ""
    subject: str = ""
    body_html: str = ""
    body_text: str = ""
    cc: str = ""
    bcc: str = ""
    draft_id: Optional[int] = None
    reply_to_id: Optional[int] = None
class ScheduleData(ComposeData):
    send_at: str
    recurrence: Optional[str] = None
class UndoDelayData(BaseModel):
    delay_seconds: int = 10
class PrecheckData(BaseModel):
    account_id: int
    to: str = ""
    cc: str = ""
    bcc: str = ""
    body_text: str = ""
    has_attachments: bool = False
@router.post("/send")
async def send_email(data: ComposeData):
    acc = await db.fetch_one("SELECT * FROM accounts WHERE id=?", [data.account_id])
    if not acc:
        raise HTTPException(404, "Account not found")
    in_reply_to = ""
    if data.reply_to_id:
        orig = await db.fetch_one("SELECT message_id FROM emails WHERE id=?", [data.reply_to_id])
        in_reply_to = orig["message_id"] if orig else ""
    try:
        processed = []
        for att in data.attachments:
            try:
                processed.append({
                    "filename": att["filename"],
                    "data": base64.b64decode(att["data"]),
                    "content_id": att.get("content_id"),
                    "inline": bool(att.get("inline")),
                })
            except Exception:
                pass
        from_addr = ""; from_name = ""
        if data.from_alias_id:
            al = await db.fetch_one("SELECT email, display_name FROM account_aliases WHERE id=? AND account_id=?", [data.from_alias_id, data.account_id])
            if al: from_addr = al.get("email") or ""; from_name = al.get("display_name") or ""
        receipt_to = (from_addr or acc.get("email") or "").strip()
        extra = {"Disposition-Notification-To": receipt_to, "Return-Receipt-To": receipt_to} if (data.request_receipt and receipt_to) else None
        await smtp_client.send_email(acc, data.to, data.subject, data.body_html,
            data.body_text, data.cc, data.bcc, in_reply_to=in_reply_to, attachments=processed,
            from_override=from_addr, from_name_override=from_name, extra_headers=extra)
        archived = 0
        if data.archive_after_send and data.reply_to_id:
            try:
                from routes.muted import archive_thread_after_send
                archived = await archive_thread_after_send(data.account_id, data.reply_to_id)
            except Exception:
                pass
        return {"status": "sent", "archived_thread": archived}
    except Exception as e:
        raise HTTPException(500, f"Send failed: {e}")
@router.post("/schedule")
async def schedule_send(data: ScheduleData):
    try:
        send_at = datetime.fromisoformat(data.send_at.replace("Z", "+00:00"))
    except Exception:
        raise HTTPException(400, "Invalid send_at (ISO 8601 required)")
    rec = (data.recurrence or "").strip().lower() or None
    if rec and rec not in {"daily", "weekdays", "weekly", "monthly"}:
        raise HTTPException(400, "recurrence must be one of: daily, weekdays, weekly, monthly")
    cur = await db.exec_q(
        "INSERT INTO scheduled_sends (account_id,to_addrs,cc_addrs,bcc_addrs,subject,body_html,body_text,reply_to_id,attachments,send_at,recurrence) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
        [data.account_id, data.to, data.cc, data.bcc, data.subject, data.body_html, data.body_text,
         data.reply_to_id, json.dumps(data.attachments or []), send_at.isoformat(), rec])
    return {"id": cur.lastrowid, "status": "scheduled", "send_at": send_at.isoformat(), "recurrence": rec}
@router.post("/undo-send")
async def undo_send(data: ComposeData, delay_seconds: int = 10):
    delay_seconds = max(0, min(60, int(delay_seconds)))
    send_at = (datetime.now(timezone.utc) + timedelta(seconds=delay_seconds)).isoformat()
    cur = await db.exec_q(
        "INSERT INTO scheduled_sends (account_id,to_addrs,cc_addrs,bcc_addrs,subject,body_html,body_text,reply_to_id,attachments,send_at,archive_after_send,is_outbox,from_alias_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,1,?)",
        [data.account_id, data.to, data.cc, data.bcc, data.subject, data.body_html, data.body_text,
         data.reply_to_id, json.dumps(data.attachments or []), send_at, 1 if data.archive_after_send else 0, data.from_alias_id])
    return {"id": cur.lastrowid, "status": "pending", "send_at": send_at, "expires_in": delay_seconds, "archive_after_send": bool(data.archive_after_send)}
@router.get("/scheduled")
async def list_scheduled(account_id: Optional[int] = None):
    sql = "SELECT id,account_id,to_addrs,cc_addrs,subject,send_at,status,created_at,sent_at,error,recurrence FROM scheduled_sends WHERE status IN ('pending','sending','sent','failed')"
    params = []
    if account_id:
        sql += " AND account_id=?"
        params.append(account_id)
    sql += " ORDER BY send_at DESC LIMIT 200"
    return await db.fetch_all(sql, params)
@router.post("/suggest-send-time")
async def suggest_send_time(payload: Dict[str, str]):
    import re as _re
    raw = (payload.get("to") or "").strip()
    if not raw: raise HTTPException(400, "to required")
    addrs = [a.strip().lower() for a in _re.split(r"[,;]+", raw) if a.strip()]
    addrs = [_re.search(r"<([^>]+)>", a).group(1) if _re.search(r"<([^>]+)>", a) else a for a in addrs]
    if not addrs: raise HTTPException(400, "no valid addresses")
    placeholders = ",".join(["?"] * len(addrs))
    rows = await db.fetch_all(
        f"SELECT e.date FROM emails e JOIN folders f ON e.folder_id=f.id WHERE f.folder_type IN ('inbox','archive') AND lower(e.from_addr) IN ({placeholders}) ORDER BY e.date DESC LIMIT 200",
        addrs)
    now = datetime.now().astimezone()
    tz_offset = now.utcoffset() or timedelta(0)
    hour_counts = [0] * 24
    dow_counts = [0] * 7
    sample = 0
    for r in rows:
        try:
            d = r["date"]
            dt = datetime.fromisoformat(d.replace("Z", "+00:00")) if isinstance(d, str) else d
            if dt.tzinfo is None: dt = dt.replace(tzinfo=timezone.utc)
            local = dt + tz_offset
            hour_counts[local.hour] += 1
            dow_counts[local.weekday()] += 1
            sample += 1
        except Exception: continue
    if sample < 3:
        candidate = now.replace(hour=9, minute=0, second=0, microsecond=0)
        if candidate <= now: candidate += timedelta(days=1)
        while candidate.weekday() >= 5: candidate += timedelta(days=1)
        return {"send_at": candidate.isoformat(), "rationale": "Default 9am next business day (insufficient history).", "sample_size": sample, "confidence": 0.2}
    work_hours = list(range(7, 19))
    best_hour = max(work_hours, key=lambda h: hour_counts[h]) if any(hour_counts[h] for h in work_hours) else 9
    best_dows = sorted(range(5), key=lambda d: -dow_counts[d])
    candidate = now.replace(hour=best_hour, minute=0, second=0, microsecond=0)
    if candidate <= now + timedelta(minutes=5): candidate += timedelta(days=1)
    for _ in range(7):
        if candidate.weekday() in best_dows[:3] and candidate.weekday() < 5: break
        candidate += timedelta(days=1)
    total_work = sum(hour_counts[h] for h in work_hours) or 1
    confidence = min(0.95, hour_counts[best_hour] / total_work * 3)
    return {"send_at": candidate.isoformat(), "rationale": f"Recipient is most active at {best_hour:02d}:00 ({hour_counts[best_hour]}/{sample} emails).", "sample_size": sample, "confidence": round(confidence, 2)}
@router.post("/suggest-send-times")
async def suggest_send_times(payload: Dict[str, str]):
    import re as _re
    raw = (payload.get("to") or "").strip()
    addrs: list[str] = []
    if raw:
        addrs = [a.strip().lower() for a in _re.split(r"[,;]+", raw) if a.strip()]
        addrs = [_re.search(r"<([^>]+)>", a).group(1) if _re.search(r"<([^>]+)>", a) else a for a in addrs]
    now = datetime.now().astimezone()
    tz_offset = now.utcoffset() or timedelta(0)
    sender_tz_label = now.tzname() or "local"
    hour_counts = [0] * 24
    sample = 0
    if addrs:
        placeholders = ",".join(["?"] * len(addrs))
        rows = await db.fetch_all(
            f"SELECT e.date FROM emails e JOIN folders f ON e.folder_id=f.id WHERE f.folder_type IN ('inbox','archive') AND lower(e.from_addr) IN ({placeholders}) ORDER BY e.date DESC LIMIT 200",
            addrs)
        for r in rows:
            try:
                d = r["date"]
                dt = datetime.fromisoformat(d.replace("Z", "+00:00")) if isinstance(d, str) else d
                if dt.tzinfo is None: dt = dt.replace(tzinfo=timezone.utc)
                local = dt + tz_offset
                hour_counts[local.hour] += 1
                sample += 1
            except Exception: continue
    work_hours = list(range(7, 19))
    best_hour = max(work_hours, key=lambda h: hour_counts[h]) if any(hour_counts[h] for h in work_hours) else None
    tz_aware = best_hour is not None and sample >= 5
    recipient_offset_h = (10 - best_hour) if tz_aware else 0
    recipient_offset_h = max(-12, min(14, recipient_offset_h))
    def in_local(target_hour_recipient: int, day_offset: int = 0, weekday: int | None = None) -> datetime:
        local_hour = target_hour_recipient - recipient_offset_h
        c = now.replace(minute=0, second=0, microsecond=0)
        if weekday is not None:
            delta = (weekday - c.weekday()) % 7
            if delta == 0 and c.hour >= local_hour: delta = 7
            c = c + timedelta(days=delta)
        else:
            c = c + timedelta(days=day_offset)
        c = c.replace(hour=local_hour % 24)
        if c <= now + timedelta(minutes=2):
            c = c + timedelta(days=1)
        return c
    def fmt_their(hour_recipient: int) -> str:
        h12 = hour_recipient % 12 or 12
        ampm = "am" if hour_recipient < 12 else "pm"
        return f"{h12}{ampm}"
    suggestions: list[dict] = []
    eod_local = now.replace(hour=17, minute=0, second=0, microsecond=0)
    if eod_local > now + timedelta(minutes=15):
        suggestions.append({"id": "eod_today", "label": "End of your day", "subtitle": f"Today 5pm {sender_tz_label}", "send_at": eod_local.isoformat(), "tz_aware": False, "confidence": 0.6})
    if tz_aware:
        m = in_local(9, day_offset=0)
        suggestions.append({"id": "their_morning_today", "label": "Their morning", "subtitle": f"9am their time ≈ {m.strftime('%a %I:%M%p').lower()} {sender_tz_label}".replace(" ", " "), "send_at": m.isoformat(), "tz_aware": True, "confidence": min(0.9, sample / 20)})
    tomorrow = in_local(9 if tz_aware else 9, day_offset=1)
    suggestions.append({"id": "tomorrow_morning", "label": ("Tomorrow their morning" if tz_aware else "Tomorrow morning"), "subtitle": f"{tomorrow.strftime('%a %I:%M%p').lower()} {sender_tz_label}", "send_at": tomorrow.isoformat(), "tz_aware": tz_aware, "confidence": 0.7 if tz_aware else 0.5})
    monday = in_local(9, weekday=0)
    suggestions.append({"id": "monday_morning", "label": ("Monday their morning" if tz_aware else "Monday 9am"), "subtitle": f"{monday.strftime('%b %d, %I:%M%p').lower()} {sender_tz_label}", "send_at": monday.isoformat(), "tz_aware": tz_aware, "confidence": 0.5})
    friday = in_local(16, weekday=4)
    suggestions.append({"id": "friday_eow", "label": "End of week", "subtitle": f"Fri 4pm their time" if tz_aware else "Fri 4pm", "send_at": friday.isoformat(), "tz_aware": tz_aware, "confidence": 0.4})
    if best_hour is not None and sample >= 3:
        peak = in_local(best_hour + recipient_offset_h, day_offset=1)
        suggestions.append({"id": "their_peak", "label": "When they read most", "subtitle": f"{fmt_their(best_hour)} their time ({sample} samples)", "send_at": peak.isoformat(), "tz_aware": True, "confidence": min(0.95, sample / 30)})
    return {"suggestions": suggestions, "sample_size": sample, "recipient_tz_offset_hours": recipient_offset_h if tz_aware else None, "tz_inferred": tz_aware, "sender_tz": sender_tz_label}
@router.post("/cancel/{sched_id}")
async def cancel_scheduled(sched_id: int):
    row = await db.fetch_one("SELECT status FROM scheduled_sends WHERE id=?", [sched_id])
    if not row:
        raise HTTPException(404, "Not found")
    if row["status"] != "pending":
        raise HTTPException(409, f"Cannot cancel (status={row['status']})")
    await db.exec_q("UPDATE scheduled_sends SET status='canceled' WHERE id=?", [sched_id])
    return {"status": "canceled"}
@router.post("/draft")
async def save_draft(data: DraftData):
    draft_folder = await db.fetch_one("SELECT id FROM folders WHERE account_id=? AND folder_type='drafts'", [data.account_id])
    if not draft_folder:
        raise HTTPException(404, "Drafts folder not found")
    acc = await db.fetch_one("SELECT email FROM accounts WHERE id=?", [data.account_id])
    if data.draft_id:
        existing = await db.fetch_one("SELECT id FROM emails WHERE id=? AND account_id=? AND flags LIKE '%\\Draft%'", [data.draft_id, data.account_id])
        if existing:
            await db.exec_q(
                "UPDATE emails SET to_addrs=?, cc_addrs=?, bcc_addrs=?, subject=?, body_html=?, body_text=?, date=CURRENT_TIMESTAMP WHERE id=?",
                [data.to, data.cc, data.bcc, data.subject, data.body_html, data.body_text, data.draft_id])
            return {"id": data.draft_id, "status": "draft_updated"}
    cur = await db.exec_q(
        "INSERT INTO emails (account_id,folder_id,uid,from_addr,to_addrs,cc_addrs,bcc_addrs,subject,body_html,body_text,date,flags) VALUES (?,?,0,?,?,?,?,?,?,?,CURRENT_TIMESTAMP,'\\Draft')",
        [data.account_id, draft_folder["id"], acc["email"], data.to, data.cc, data.bcc, data.subject, data.body_html, data.body_text])
    return {"id": cur.lastrowid, "status": "draft_saved"}
@router.post("/reply/{email_id}")
async def reply(email_id: int, data: ComposeData):
    orig = await db.fetch_one("SELECT * FROM emails WHERE id=?", [email_id])
    if not orig:
        raise HTTPException(404, "Original email not found")
    data.reply_to_id = email_id
    return await send_email(data)
@router.post("/forward/{email_id}")
async def forward(email_id: int, data: ComposeData):
    orig = await db.fetch_one("SELECT * FROM emails WHERE id=?", [email_id])
    if not orig:
        raise HTTPException(404, "Original email not found")
    fwd_html = f"<br><hr><b>Forwarded from {orig['from_addr']}</b><br>{orig.get('body_html') or orig.get('body_text', '')}"
    data.body_html = data.body_html + fwd_html
    data.subject = f"Fwd: {orig['subject']}" if not data.subject.lower().startswith("fwd:") else data.subject
    return await send_email(data)
def _damerau_levenshtein(a: str, b: str, cap: int = 3) -> int:
    la, lb = len(a), len(b)
    if abs(la - lb) > cap: return cap + 1
    if la == 0: return lb
    if lb == 0: return la
    prev2 = [0] * (lb + 1)
    prev1 = list(range(lb + 1))
    cur = [0] * (lb + 1)
    for i in range(1, la + 1):
        cur[0] = i
        row_min = cur[0]
        for j in range(1, lb + 1):
            cost = 0 if a[i-1] == b[j-1] else 1
            cur[j] = min(prev1[j] + 1, cur[j-1] + 1, prev1[j-1] + cost)
            if i > 1 and j > 1 and a[i-1] == b[j-2] and a[i-2] == b[j-1]:
                cur[j] = min(cur[j], prev2[j-2] + cost)
            if cur[j] < row_min: row_min = cur[j]
        if row_min > cap: return cap + 1
        prev2, prev1, cur = prev1, cur, prev2
    return prev1[lb]
def _strip_quoted_simple(text: str) -> str:
    import re as _re
    if not text: return ""
    cut = len(text)
    for m in [r"\nOn\s.+\swrote:\s*\n", r"\n-----\s*Original Message", r"\n>+\s*", r"\nFrom:\s.+\nSent:\s"]:
        match = _re.search(m, text)
        if match and match.start() < cut: cut = match.start()
    return text[:cut]
def _parse_addrs(raw: str) -> list[str]:
    import re as _re
    if not raw: return []
    out = []
    for chunk in _re.split(r"[,;]+", raw):
        chunk = chunk.strip()
        if not chunk: continue
        m = _re.search(r"<([^>]+)>", chunk)
        addr = (m.group(1) if m else chunk).strip().lower()
        if "@" in addr: out.append(addr)
    return out
@router.post("/precheck")
async def precheck(data: PrecheckData):
    import re as _re
    warnings: list[dict] = []
    addrs = _parse_addrs(data.to) + _parse_addrs(data.cc) + _parse_addrs(data.bcc)
    if addrs:
        contacts = await db.fetch_all("SELECT email, name, hit_count FROM contacts WHERE email IS NOT NULL AND email != '' AND hit_count >= 2")
        contact_set = {(c["email"] or "").lower() for c in contacts}
        for addr in addrs:
            if addr in contact_set: continue
            best = None; best_dist = 99
            for c in contacts:
                cand = (c["email"] or "").lower()
                if not cand or cand == addr: continue
                d = _damerau_levenshtein(addr, cand, cap=2)
                if d <= 2 and d < best_dist:
                    best = c; best_dist = d
                    if d == 1: break
            if best:
                warnings.append({"kind": "recipient_typo", "severity": "warn", "field": "to" if addr in _parse_addrs(data.to) else ("cc" if addr in _parse_addrs(data.cc) else "bcc"), "message": f"Did you mean {best['email']}?", "original": addr, "suggestion": best["email"], "contact_name": best.get("name") or "", "edit_distance": best_dist})
    if not data.has_attachments and data.body_text:
        body = _strip_quoted_simple(data.body_text)
        if _re.search(r"\b(attach(ed|ing|ment|ments)?|enclos(ed|ure|ures)?)\b", body, _re.IGNORECASE) or _re.search(r"\bsee\s+(the|my|attached)?\s*(file|doc|pdf|image|screenshot)", body, _re.IGNORECASE):
            warnings.append({"kind": "missing_attachment", "severity": "warn", "field": "body", "message": "You mention an attachment but nothing is attached."})
    return {"warnings": warnings}
