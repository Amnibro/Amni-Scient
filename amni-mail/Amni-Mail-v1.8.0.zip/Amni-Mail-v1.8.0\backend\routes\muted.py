from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional
import asyncio
import db
import imap_client
router = APIRouter(prefix="/api/muted", tags=["muted"])
class AddRequest(BaseModel):
    account_id: int
    from_addr: str
class RemoveRequest(BaseModel):
    account_id: int
    from_addr: str
class ThreadMuteRequest(BaseModel):
    account_id: int
    thread_id: str
    last_subject: Optional[str] = None
def _norm(addr: str) -> str:
    return (addr or "").strip().lower()
@router.get("/list")
async def list_muted(account_id: Optional[int] = None):
    q = "SELECT m.id, m.account_id, m.from_addr, m.created_at, a.name as account_name, a.color as account_color FROM muted_senders m LEFT JOIN accounts a ON a.id=m.account_id"
    params: list = []
    if account_id is not None:
        q += " WHERE m.account_id=?"
        params.append(account_id)
    q += " ORDER BY m.created_at DESC"
    return {"items": await db.fetch_all(q, params)}
@router.post("/add")
async def add_muted(req: AddRequest):
    addr = _norm(req.from_addr)
    if not addr or "@" not in addr:
        raise HTTPException(400, "Invalid from_addr")
    try:
        await db.exec_q("INSERT OR IGNORE INTO muted_senders (account_id, from_addr) VALUES (?,?)", [req.account_id, addr])
    except Exception as e:
        raise HTTPException(500, str(e))
    archived = await _sweep_existing(req.account_id, addr)
    return {"ok": True, "archived": archived}
@router.post("/remove")
async def remove_muted(req: RemoveRequest):
    addr = _norm(req.from_addr)
    await db.exec_q("DELETE FROM muted_senders WHERE account_id=? AND from_addr=?", [req.account_id, addr])
    return {"ok": True}
@router.delete("/{muted_id}")
async def delete_muted(muted_id: int):
    await db.exec_q("DELETE FROM muted_senders WHERE id=?", [muted_id])
    return {"ok": True}
async def _sweep_existing(account_id: int, addr: str) -> int:
    arch = await db.fetch_one("SELECT id, path FROM folders WHERE account_id=? AND folder_type='archive' LIMIT 1", [account_id])
    if not arch:
        return 0
    rows = await db.fetch_all(
        "SELECT e.id, e.uid, f.path as src_path FROM emails e JOIN folders f ON e.folder_id=f.id WHERE e.account_id=? AND LOWER(e.from_addr)=? AND f.folder_type='inbox'",
        [account_id, addr]
    )
    if not rows:
        return 0
    ids = [r["id"] for r in rows]
    placeholders = ",".join("?" for _ in ids)
    await db.exec_q(f"UPDATE emails SET folder_id=? WHERE id IN ({placeholders})", [arch["id"]] + ids)
    by_folder: dict = {}
    for r in rows:
        by_folder.setdefault(r["src_path"], []).append(r["uid"])
    async def _bg(fpath, uids):
        try:
            acc = await db.fetch_one("SELECT * FROM accounts WHERE id=?", [account_id])
            if acc:
                await asyncio.wait_for(imap_client.batch_move(acc, fpath, uids, arch["path"]), timeout=30)
        except Exception:
            pass
    for fpath, uids in by_folder.items():
        asyncio.create_task(_bg(fpath, uids))
    return len(ids)
async def apply_mute_filter(account_id: int, email_ids: list[int]) -> int:
    if not email_ids:
        return 0
    muted = await db.fetch_all("SELECT from_addr FROM muted_senders WHERE account_id=?", [account_id])
    muted_threads = await db.fetch_all("SELECT thread_id FROM muted_threads WHERE account_id=?", [account_id])
    muted_set = {row["from_addr"] for row in muted}
    muted_thread_set = {row["thread_id"] for row in muted_threads}
    if not muted_set and not muted_thread_set:
        return 0
    placeholders = ",".join("?" for _ in email_ids)
    rows = await db.fetch_all(
        f"SELECT e.id, e.uid, e.from_addr, e.thread_id, f.path as src_path FROM emails e JOIN folders f ON e.folder_id=f.id WHERE e.id IN ({placeholders}) AND f.folder_type='inbox'",
        email_ids
    )
    targets = [r for r in rows if _norm(r["from_addr"]) in muted_set or (r.get("thread_id") and r["thread_id"] in muted_thread_set)]
    if not targets:
        return 0
    arch = await db.fetch_one("SELECT id, path FROM folders WHERE account_id=? AND folder_type='archive' LIMIT 1", [account_id])
    if not arch:
        return 0
    ids = [r["id"] for r in targets]
    ph = ",".join("?" for _ in ids)
    await db.exec_q(f"UPDATE emails SET folder_id=? WHERE id IN ({ph})", [arch["id"]] + ids)
    by_folder: dict = {}
    for r in targets:
        by_folder.setdefault(r["src_path"], []).append(r["uid"])
    async def _bg(fpath, uids):
        try:
            acc = await db.fetch_one("SELECT * FROM accounts WHERE id=?", [account_id])
            if acc:
                await asyncio.wait_for(imap_client.batch_move(acc, fpath, uids, arch["path"]), timeout=30)
        except Exception:
            pass
    for fpath, uids in by_folder.items():
        asyncio.create_task(_bg(fpath, uids))
    return len(ids)
async def _sweep_thread(account_id: int, thread_id: str) -> int:
    arch = await db.fetch_one("SELECT id, path FROM folders WHERE account_id=? AND folder_type='archive' LIMIT 1", [account_id])
    if not arch:
        return 0
    rows = await db.fetch_all(
        "SELECT e.id, e.uid, f.path as src_path FROM emails e JOIN folders f ON e.folder_id=f.id WHERE e.account_id=? AND e.thread_id=? AND f.folder_type='inbox'",
        [account_id, thread_id]
    )
    if not rows:
        return 0
    ids = [r["id"] for r in rows]
    placeholders = ",".join("?" for _ in ids)
    await db.exec_q(f"UPDATE emails SET folder_id=? WHERE id IN ({placeholders})", [arch["id"]] + ids)
    by_folder: dict = {}
    for r in rows:
        by_folder.setdefault(r["src_path"], []).append(r["uid"])
    async def _bg(fpath, uids):
        try:
            acc = await db.fetch_one("SELECT * FROM accounts WHERE id=?", [account_id])
            if acc:
                await asyncio.wait_for(imap_client.batch_move(acc, fpath, uids, arch["path"]), timeout=30)
        except Exception:
            pass
    for fpath, uids in by_folder.items():
        asyncio.create_task(_bg(fpath, uids))
    return len(ids)
@router.get("/threads")
async def list_muted_threads(account_id: Optional[int] = None):
    q = "SELECT account_id, thread_id, last_subject, created_at FROM muted_threads"
    params: list = []
    if account_id is not None:
        q += " WHERE account_id=?"
        params.append(account_id)
    q += " ORDER BY created_at DESC LIMIT 500"
    return {"items": await db.fetch_all(q, params)}
@router.post("/thread/add")
async def add_muted_thread(req: ThreadMuteRequest):
    if not req.thread_id:
        raise HTTPException(400, "thread_id required")
    try:
        await db.exec_q("INSERT OR REPLACE INTO muted_threads (account_id, thread_id, last_subject) VALUES (?,?,?)",
                       [req.account_id, req.thread_id, req.last_subject])
    except Exception as e:
        raise HTTPException(500, str(e))
    archived = await _sweep_thread(req.account_id, req.thread_id)
    return {"ok": True, "archived": archived}
@router.post("/thread/remove")
async def remove_muted_thread(req: ThreadMuteRequest):
    await db.exec_q("DELETE FROM muted_threads WHERE account_id=? AND thread_id=?", [req.account_id, req.thread_id])
    return {"ok": True}
async def archive_thread_after_send(account_id: int, reply_to_id: int) -> int:
    orig = await db.fetch_one("SELECT thread_id FROM emails WHERE id=?", [reply_to_id])
    if not orig or not orig.get("thread_id"):
        return 0
    return await _sweep_thread(account_id, orig["thread_id"])
