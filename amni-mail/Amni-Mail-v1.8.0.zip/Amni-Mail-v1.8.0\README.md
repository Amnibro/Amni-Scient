# Amni-Mail

A local-first Outlook replacement from [amni-scient.com](https://amni-scient.com). Mail stays on your machine. Graphite, brass, Archivo.

## Anyone can install (Windows)

You need [Python 3.11+](https://www.python.org/downloads/) with **Add python.exe to PATH** checked.

```powershell
iwr -useb https://amni-scient.com/amni-mail/install.ps1 | iex
```

Or unzip `Amni-Mail-v1.8.0.zip`, then:

```powershell
powershell -ExecutionPolicy Bypass -File .\install.ps1
```

That copies the app to `%LOCALAPPDATA%\Amni-Mail`, installs packages, and drops Desktop + Start Menu shortcuts. Double-click **Amni-Mail**. Browser opens `http://127.0.0.1:8026`.

From this repo:

```bat
run.bat
```

`run.bat` builds the UI if needed, starts one process, and opens the app.

## First account

Settings → Accounts.

- **Any IMAP** (Gmail, Outlook, iCloud, Fastmail, Yahoo): email + app password. Provider hosts are detected.
- **Google / Microsoft one-click**: paste *your* OAuth desktop client id + secret (redirect `http://localhost:8026/api/oauth/callback`). Nothing is phoned home to amni-scient.

## What it does

Inbox, threads, send, drafts, search, rules, snooze, scheduled send, undo send, calendar (month grid + .ics RSVP), contacts, attachments hub, out of office, PGP, VIP, subscriptions, sender trust, optional local AI.

## Privacy

IMAP/SMTP talk to *your* mail host. Credentials sit in `backend/data/credentials.enc`. The database is local SQLite. No amni-scient telemetry. See [privacy-mail](https://amni-scient.com/privacy-mail.html).

## Dev

```
backend\venv\Scripts\python.exe backend\main.py
cd frontend && npm install && npm run dev
```

UI on `:5173`, API on `:8026`. Package a zip with `scripts\package.ps1`.
